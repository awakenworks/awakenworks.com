# Architecture

## Whole-system objective and critical path

Pilot turns durable project context plus a direction into an observable Managed Session without creating a second execution system. The critical paths are `Project -> Deployment` and `goal + Deployment -> Session(initial_events) -> Awaken runtime -> committed event log -> Pilot projections -> user decision or terminal result`.

The boundary is deliberate: Pilot owns application policy and presentation; Awaken owns the Anthropic Managed Agents compatibility surface **and** the execution runtime behind it. “Pilot owns application logic” does not move worker selection, retries, leases, sandboxes, tools, skills, memory, orchestration, or durable Session facts out of Awaken.

## Reuse and change classification

| Classification | Authoritative owner | Pilot use |
|---|---|---|
| Reused unchanged | `@anthropic-ai/sdk` Deployments, Deployment Runs, Sessions, Agents, Environments, Files, Memory Stores and Vaults | The only wire client/type owner: requests, pagination, uploads, SSE, errors and Anthropic compatibility |
| Reused unchanged | Awaken Session, WorkQueue, Worker, sandbox, tools, skills, memory, files, thread orchestration | All execution and durable truth |
| Reused unchanged | Awaken config-plane webhook subscription, SecretStore, lifecycle outbox and dispatcher | The only subscription, signing-secret, delivery, retry and failure-state authority |
| Reused unchanged | Awaken IAM product token, Organization/Workspace membership, authorization profile and Workspace-path PEP | The only identity, membership, grant and final resource-access authority |
| Reused unchanged | Awaken IAM `cap+jwt`, shared asymmetric signer/JWKS and ordinary Grant PAP/PDP | Public links are short-lived authentication evidence plus one exact-resource Grant; rotation replaces the Grant subject and revocation removes it |
| Reused unchanged | `@awaken/ui` | Product-neutral accessible interactions and semantic CSS contract |
| Existing code modified | `apps/web` | Adds Agent/Connector/Vault, Project/resource, Branch, public-link and webhook interactions as upstream projections; all interaction still calls only the same-origin Pilot API |
| Existing code modified | `apps/api` | Resolves one request-scoped SDK/config adapter and composes IAM capability/Grant commands with Managed reads; it gains no identity, membership, grant, database, transcript, scheduler or webhook dispatcher |
| Existing code modified | `packages/contracts` | Owns Pilot commands at the browser boundary, including Agent/Connector/Vault credentials, Branch, public-link duration and thin webhook authoring; it owns no Awaken transcript, secret, share authority or delivery state |
| Existing code modified | root scripts, README, this document | Start and describe the single Web → API → SDK path |
| Genuinely new | `apps/web/src/domain/project.ts`, `use-projects.ts`, `ProjectDialog.tsx` | Product projection, query orchestration and editing UI over Deployment, Files and Memory Store authorities |
| Genuinely new | `apps/web/src/infrastructure/legacy-settings.ts` | One-way deletion of obsolete browser defaults; it cannot read or migrate them into another store |
| Genuinely new | `apps/web/src/application/use-webhooks.ts`, `ui/WebhookDialog.tsx` | Volatile authoring UI over Awaken subscription rows; a newly minted signing secret is displayed once and never persisted by Pilot |
| Genuinely new | `apps/web/src/ui/AgentProfilesDialog.tsx`, `ConnectorCredentialsDialog.tsx` | Volatile authoring UI over versioned Awaken Agents and write-only Vault credential commands; it creates no local Agent, Connector, Skill, permission, OAuth-token or secret record |
| Genuinely new | `apps/web/src/infrastructure/identity.ts`, `apps/api/src/request-gateway.ts` | Thin relying-party seams over IAM's canonical product token and Awaken Workspace path; no PKCE, token verifier, member store or PDP is added |
| Genuinely new | `apps/api/src/public-links.ts`, `apps/web/src/ui/PublicMission.tsx` | Stateless composition over IAM capability/Grant and Awaken read projections; no share row, ACL, token registry, snapshot or copied artifact catalog |
| Reused unchanged | `apps/application-mcp` | Existing stateless plan/notification/result affordances recorded into Session events; one isolated protocol/transport pair per HTTP request |
| Genuinely new durable component | None | Project, schedule, run history, Mission and artifacts all remain upstream records |

## Static structure

```text
Browser: Awaken Pilot Web
  UI --------------------------> @awaken/ui
  IAM product bearer <---------- canonical product-origin PKCE adapter
  application hooks -----------> PilotGateway port
  domain projections <---------- Deployments + Managed Session events
  PilotApiGateway --------------> same-origin /api
                                      |
Server: Pilot API BFF               v
  request contracts -----------> @awaken/pilot-contracts
  request identity ------------> bearer + /v1/workspaces/{workspace}
  public-link application -----> IAM cap+jwt + exact-resource Grant PAP/PDP
  AnthropicManagedPilotGateway -> @anthropic-ai/sdk (only Managed wire client)
  Agent/Vault commands --------> versioned Agent + write-only Vault APIs
  Awaken webhook adapter -------> explicit /v1/config/webhook-subscriptions extension
                                      |
                                      v
                                Awaken / Awaken Cloud
                                  Deployment + Deployment Run
                                  Session + Worker + Files + Memory Stores
                                  IAM signer/JWKS + Grant authority
                                      |
                                      v
Pilot application MCP <--------- Managed Agent MCP client
  stateless tool contracts ------ tool results into the Session event log
```

The Web `PilotGateway` is an application/test port, not a Managed Agents protocol client. It speaks only Pilot's HTTP API. `AnthropicManagedPilotGateway` is the single SDK adapter and exists only in the server process. `Project.id === Deployment.id`; Project fields are derived from the Deployment response and are never persisted by Pilot.

### Ownership and contracts

| Concern | Authority | Contract/boundary |
|---|---|---|
| Project identity, standing instruction, Agent/Environment binding, resources, Vault references, budget and schedule | Awaken Deployment | Project ID equals Deployment ID; the system event is the one standing-instruction source |
| Reusable knowledge files and cross-Mission memory | Awaken Files and Memory Stores | Pilot uploads/lists/selects upstream IDs; it owns no blob store, file catalog, vector index or memory copy |
| Agent tools, document Skills, MCP Connector routes, permissions and coordinator roster | Awaken versioned Agent | Pilot authors one Agent version through the official SDK; the four managed document Skills are ordinary Agent bindings, not Pilot implementations |
| Connector OAuth/bearer/environment secrets | Awaken Vault and credential materializer | Pilot relays write-only values once and clears browser form state; Project stores only opaque Vault IDs and Pilot cannot read plaintext back. A sealed connector environment credential is not an ambient Awaken process variable |
| Model-provider API keys | Awaken Provider Connection and secret authority | Awaken service and Worker startup reject `API_KEY`/`*_API_KEY` process variables before execution; Native inference receives only explicitly resolved Provider Connection material |
| Schedule pause state, next fires, execution and run history | Awaken Deployment and Deployment Run | Pilot issues pause/unpause/run commands and projects responses; no timer, retry loop or run table exists in Pilot |
| Outbound webhook subscriptions, secrets and delivery | Awaken config plane, SecretStore and lifecycle outbox | Pilot authors workspace-scoped rows; create relays the signing secret once; Pilot owns no secret copy, event outbox, retry counter or delivery worker |
| Product login, Workspace membership and grants | Awaken IAM / Awaken Cloud | Pilot consumes the canonical product token and selected Workspace; it neither implements PKCE nor persists users, members, roles or grants |
| Team Mission link | Pilot route + Awaken authorization | Link contains only Workspace and Session IDs; every read/action is re-authorized upstream and no snapshot/copy is created |
| Anonymous public Mission link | IAM capability token + Grant | URL fragment carries the short-lived token; deterministic Mission Grant is the only durable authority; Pilot exposes a read-only projection and persists nothing |
| Mission identity, status, transcript, plan/result events, threads, artifacts | Awaken Session event log and Files scope | Mission ID equals Session ID; Pilot only queries/projects |
| Agent execution, retry, lease, sandbox, browsing/computer use, skills and multi-agent orchestration | Awaken runtime and Agent definition | Managed Agents SDK resources/events; Pilot selects and explains capabilities but does not reimplement tools |
| Mission launch and Plan Mode policy, UI copy and authorization to use Pilot features | Pilot | Shared request schemas plus Pilot API routes; approval is still a Session user event |
| Final permission to access a Session/File | Awaken | SDK authentication and scope checks; Pilot's product ACL may narrow but never widen it |
| Awaken service authentication credential | Pilot API process | Server-side product/service credential; never a model-provider API key, browser setting, or response field |
| Structured plan/update/result affordance | Stateless application MCP | Complete tool inputs/outputs are committed to the Session event log |

## Dynamic behavior

### Project configuration and scheduling

```text
User       Pilot Web/API             official SDK                  Awaken
 | edit Project |                         |                           |
 |------------->| validate command        |                           |
 |              | create/update Deployment-------------------------->|
 |<-------------|<------------------------| Deployment projection ----|
 | pause/run    | pause/unpause/run ------|-------------------------->|
 |<-------------|<------------------------| status / Deployment Run --|
 |              |                         |               cron fire ->| create Session
```

- Create and update are full Deployment configuration commands. The system event owns the standing instruction; `description` is not used as a parallel copy.
- Schedule prompt is the Deployment's initial user event. Cron expression, timezone, pause reason, upcoming timestamps, run errors and Session association remain upstream.
- A manual “run now” invokes the official Deployment operation. Pilot never retries an ambiguous run command and never manufactures a run-history row.
- Knowledge upload streams once through the BFF into the official Files API. Only unscoped workspace Files are selectable as reusable Project knowledge; Session-scoped outputs remain Mission artifacts. Memory creation returns an upstream Memory Store ID that is mounted read/write through the Deployment.
- The Project editor projects effective built-in research/workspace tools, pinned Skills, MCP connector names, custom tools and multi-agent roster size from the selected Agent version. This is explanatory only: capability definitions, permissions and execution remain on the Agent/Awaken side.

### Agent, Connector, Skill and credential configuration

```text
User        Pilot Web/API          official SDK                 Awaken
 | Agent form   |                       |                          |
 |------------->| validate one profile |                          |
 |              | create Agent --------|------------------------->| version + tools/Skills/MCP/roster
 | Vault secret | create credential ---|------------------------->| seal write-only material
 |<-------------|<----------------------| redacted IDs/projection -|
 | Project save | attach Vault IDs ----|------------------------->| Deployment reference
```

- The Agent command is a full versioned profile: built-in tools and their permission policy, Anthropic/custom Skills, URL MCP servers and matching toolsets, and an optional one-level coordinator roster. Update uses Awaken's version precondition; Pilot stores no editable shadow.
- The reserved `pilot` MCP server remains a Mission-time override so application tools are present without duplicating them in every authored Agent. An authored server with that name is replaced, never merged into a parallel toolset.
- Vault creation and credential creation call the official write-only types. OAuth refresh material, bearer tokens and connector environment secrets exist only in the request and Awaken secret authority. Lists and validation return redacted metadata. Model-provider API keys are a separate Awaken Provider Connection concern: Awaken never resolves them from its process environment, and every service/Worker entry point fails closed if an ambient `API_KEY`/`*_API_KEY` name is present.
- External business effects such as Gmail, Slack, Stripe, publishing and analytics execute only through the configured MCP server and its real provider account. The generic Connector path is implemented; no vendor-specific success may be claimed until that provider's OAuth/account/sandbox acceptance has run.

### Mission interaction

```text
User       Pilot Web        Pilot API       official SDK      Awaken runtime      Pilot MCP
 | project+goal|                 |                |                  |                |
 |------------>| POST Mission    |                |                  |                |
 |             |---------------->| retrieve Deployment + Agent ---->|                |
 |             |                 | create(project config + goal) -->|                |
 |             |<----------------|<------------- Session(running) --|                |
 |             | GET SSE --------| follow events ------------------>|                |
 |             |                 |                                  |-- set_plan --->|
 |             |<-- JSON SSE ----|<----- tool use/result events ----|<---- result ----|
 |<-- plan ----| fold committed event log                           |                |
 | approve     | POST decision -->| send confirmation ------------->|                |
 |             |                 |                                  |-- workers/tools
 |             |<-- committed refresh/SSE -- idle/error/terminated -|                |
 |<-- result --| projection + Session-scoped artifact link          |                |
```

- Manual creation reads the tagged Deployment and its pinned Agent version, then issues one Session create containing the Project's environment, resources, Vault references, budget, standing instruction and the new goal. It does not persist a copied Project configuration. Because the current Awaken HTTP route rejects `Idempotency-Key` together with `initial_events`, Pilot does not automatically retry an ambiguous create failure.
- Execute Mode asks the Session to proceed autonomously. Plan Mode asks the same Session to publish a complete plan and stop before mutating or externally visible work. “Approve and execute” appends one canonical user message; the current plan's approval is derived from event order and resets when a newer `set_plan` snapshot is committed. There is no Plan record or review-status column.
- Execute Mode may define one text-rubric outcome with a bounded revision count. Awaken owns evaluation, iteration and terminal verdict in `Session.outcome_evaluations`; Pilot only submits the initial `user.define_outcome` event and projects the returned quality facts. Plan Mode rejects an outcome rubric at launch so evaluation cannot execute before plan approval.
- Event history is authoritative. The API relays SDK stream items as JSON SSE; browser disconnect aborts the upstream follow. Stream failure closes the preview, while periodic committed-history refresh recovers without replaying commands. Deltas are display-only and disappear when their committed event arrives or the turn terminates.
- `set_plan` sends a complete snapshot. Pilot accepts the latest snapshot only after the matching MCP result succeeds. No incremental plan store exists.
- Human confirmation is an explicit inbound event. A denied action may include the user's reason and returns control to the agent.
- Invalid browser commands fail at the shared API contract before the SDK. SDK/network failures expose a stable Pilot error, retain committed state, and fall back to history refresh. Awaken owns execution retries; Pilot does not duplicate them.
- Artifact download first resolves the file inside the requested Session scope, then streams bytes with attachment headers. Missing, cross-scope, and non-downloadable files terminate as `404`.
- Terminal outcomes are idle, terminated, archived, or error. Produced files remain Files API records scoped to the Session.

### Outbound webhook authoring and delivery

```text
User       Pilot Web/API          Awaken config plane       Session lifecycle outbox
 | register/edit |                         |                         |
 |-------------->| PUT subscription ------>| mint/seal secret        |
 |<--------------|<-- row + secret once ---|                         |
 | close dialog  | discard secret          |                         |
 |               |                         |<-- committed fact -------|
 |               |                         | resolve/sign/deliver      |--> receiver
 |               |                         | retry / disable row       |
```

- The webhook URL, event-type filter, and enabled flag are authored directly on the workspace-scoped Awaken resource. An empty filter retains Awaken's canonical “all lifecycle events” meaning.
- Awaken returns `whsec_` material only on first creation. Pilot renders that response in component state and has no persistence path for it.
- The config endpoint is an explicit Awaken extension not covered by the Anthropic SDK. The server-side adapter is limited to CRUD translation and server authentication; Managed Agents traffic remains exclusively owned by `@anthropic-ai/sdk`.
- Session lifecycle facts are delivered from Awaken's durable outbox. Pilot does not observe and re-emit events, so there is no dual write, second retry loop, or competing disable state.

### Identity, Workspace collaboration and public API

```text
Browser/client       Pilot BFF             official SDK              Awaken + IAM
 | IAM token + ws |      |                       |                         |
 |--------------------->| request Gateway       |                         |
 |                      | SDK call ------------>| /v1/workspaces/{ws}/…  |
 |                      |                       |------------------------>|
 |                      |                       |        verify token + membership + action
 |<---------------------|<----------------------|<------------------------|
 | copy team link       |                                                 |
 |-- /w/{ws}/missions/{session} --> recipient repeats the same authorized path
```

- The browser reads only IAM's canonical short-lived `awaken.product.session-bearer`; login itself remains the product-origin `/v1/oauth/browser/*` PKCE adapter owned by IAM/Cloud.
- The BFF creates a request-scoped Managed gateway. A presented user bearer overrides the optional local server credential, and the one Workspace header is translated into Awaken's canonical `/v1/workspaces/{workspace}/…` path before both SDK and config calls.
- Hosted mode requires both identity and Workspace. In local mode, a server credential may retain the flat single-tenant path; an unauthenticated caller cannot select a different Workspace for that credential.
- A team link contains no authorization or Mission data. A recipient must already be an IAM member of the Workspace, and Awaken remains the final authority for the referenced Deployment, Session and Files.
- The same authenticated BFF routes are the Pilot public API. There is no second API-token table or authorization middleware; failures from missing edge context or Awaken IAM fail closed.

### Anonymous read-only link

```text
Workspace writer     Pilot BFF              IAM                    Awaken
 | create/rotate |      |                    |                        |
 |--------------------->| verify Mission --->| PDP workspace.write   |
 |                      | mint cap+jwt ------>| shared signer/JWKS    |
 |                      | upsert exact Grant->| one deterministic id  |
 |<-- /public#token ----|                    |                        |
Anonymous browser      |                    |                        |
 | token header ------>| introspect -------->| signature/aud/expiry  |
 |                     | authorize --------->| subject+Mission Grant |
 |                     | server SDK read --------------------------->|
 |<-- committed read-only projection -------------------------------|
 | revoke             ->| delete Grant ----->| old/current tokens deny
```

- Creation requires both access to the Pilot-owned Mission and IAM `workspace.write`; Pilot never treats possession of its server credential as user authorization.
- The default lifetime is seven days and the contract caps it at thirty. The capability remains in the URL fragment and is sent only in `X-Pilot-Public-Token`, so it does not enter the HTTP request target or Referer.
- The deterministic `(Workspace, Mission)` Grant id admits one current subject. Rotation mints a fresh subject and replaces that Grant; revocation deletes it. IAM's PAP/PDP is the sole share authority. Pilot has no share table or token denylist.
- The anonymous surface returns only the committed Session projection, plan/result, thread summaries and authorized artifacts. It has no message, approval, interrupt, archive or mutation route.

## Frozen integration decisions

1. **The BFF is mandatory.** Production and local Web traffic use the same `/api` boundary. The browser carries an IAM product token only to this same origin; it never constructs the SDK or receives a server automation credential.
2. **No Awaken Flow integration.** Pilot launches and observes Managed Sessions directly. A future Flow handoff must be explicit and idempotent and may exchange a command/result reference only; it cannot synchronize a parallel task aggregate.
3. **Project is a Deployment, now.** Pilot uses the official Deployment and Deployment Run resources directly through the server SDK adapter. Missing upstream behavior must be added to Awaken compatibility; Pilot cannot own a substitute Project record, scheduler, rollout state or run history.
4. **Authorization is layered, never duplicated.** Pilot may enforce product membership/policy at its API. Awaken remains the final authority for Agent, Environment, Session, Vault, and File access. Pilot authorization can only narrow an Awaken-authenticated capability.
5. **Extensions are explicit.** Pilot-specific HTTP commands and MCP event payloads are separately named/versioned. They must not masquerade as Anthropic fields or fork the SDK type model.

## Manus capability acceptance map

This map is organized by authoritative implementation rather than UI resemblance. “Agent-backed” means the capability is available when the selected Awaken Agent/Environment is configured for it; Pilot must not ship a competing executor.

| Capability family | Acceptance | Authoritative path / remaining work |
|---|---|---|
| Autonomous tasks, conversation, approvals, progress, artifacts | End-to-end | One Managed Session, committed events, Session threads and scoped Files |
| Projects and reusable context | End-to-end | One Project equals one Deployment; Files, Memory Stores, Vault references, budget and standing instruction remain upstream |
| Plan Mode | End-to-end with Pilot MCP | `set_plan` snapshot and approval user event in the same Session log; no review aggregate |
| Scheduled and recurring tasks | End-to-end | Deployment cron/pause/run and append-only Deployment Run history |
| Wide/deep research and parallel work | Native end-to-end | Awaken coordinator concurrently executes two publication-pinned research Agents with live configurable `web_search`, `web_fetch`, and spill-file `grep`; Pilot projects committed child-thread and citation evidence |
| Skills and connectors | Agent-backed, observable | Pinned Agent Skills, MCP servers and Vaults remain Awaken-managed; Pilot selects the Agent and shows effective capabilities |
| Browser/cloud-computer/desktop operation | Native browser end-to-end | Separate desktop Chrome and iPhone 15 emulation MCP Connectors prove navigation, form input, click and DOM read; physical-device/cloud-computer providers remain connector-specific |
| Docs, slides, sheets, design/media and data visualization | Agent-backed artifacts | Skills/tools produce Session Files; Pilot provides generic artifact access, not parallel editors |
| Web/mobile building, publishing, hosting, payments and analytics | Connector/product-plane backed | Coding can run in the Agent; deployment/payment/analytics require configured connectors or explicit future Pilot product integrations |
| Branch conversation | Deferred | Awaken retains one internal immutable transcript-prefix model, but the official Managed SDK has no typed create command for it. Pilot exposes no private field, metadata command, or copied-transcript fallback. |
| Team collaboration and sharing | End-to-end | Workspace teammates open stable Mission links; Awaken IAM membership and resource authorization are checked on every request, with no Pilot ACL or copied Mission |
| Public unauthenticated links | End-to-end, read-only | IAM shared `cap+jwt` authenticates a short-lived link and one deterministic exact-Mission Grant authorizes it; rotation/revocation replace/delete that Grant; Pilot stores no share state |
| Public API | End-to-end in strict mode | Request-scoped IAM bearer + Workspace enters the same BFF/SDK path; Pilot stores no API token or grant state |
| Outbound webhooks | End-to-end | Pilot authors Awaken config-plane subscriptions; Awaken alone owns sealed secrets, committed lifecycle outbox, signed delivery, retries and disable state |

Every enabled application-level Manus capability family has an end-to-end or
explicit Agent/connector-backed authoritative path. Branch conversation remains
disabled until one official typed ingress exists. Agent-backed creation and
external publishing still require the selected Awaken Agent/Environment
connectors; Pilot does not duplicate those executors.

## Required invariants

1. Session IDs are Mission IDs.
2. Deployment IDs are Project IDs; Deployment Run is the only scheduled-run record.
3. The event log is the only transcript, plan, notification, approval, and result history.
4. Pilot never claims or executes WorkQueue items.
5. Pilot never interprets token usage as billing. Awaken Cloud alone may add cost UI.
6. The application MCP has no database and cannot become a workflow engine.
7. Flow integration, if added, is a one-way command/result handoff rather than shared mutable status.
8. Only the Pilot API process constructs `@anthropic-ai/sdk`; the browser may hold IAM's short-lived product bearer but never an Awaken server/service credential.
9. Pilot does not persist a Project, schedule, run, Mission status, plan, transcript, worker registry, memory copy or artifact catalog.
10. Pilot does not persist webhook signing secrets or delivery state and never re-emits Session events into a second outbox.
11. Pilot does not persist accounts, memberships, roles, grants, API tokens or shared Mission copies; Awaken IAM and the upstream resource PEP decide every request.
12. An anonymous public link persists only one IAM exact-Mission Grant. Its capability is one-time output/URL-fragment input; Pilot stores neither token nor ACL, and every read rechecks both token and Grant before using the upstream server credential.
13. Model-provider API keys enter Awaken only through its write-only Provider Connection authority. Awaken services and Workers must refuse any ambient `API_KEY` or `*_API_KEY` process variable without reading its value.
