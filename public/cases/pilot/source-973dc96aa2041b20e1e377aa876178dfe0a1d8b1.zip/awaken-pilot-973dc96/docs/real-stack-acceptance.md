# Real cross-service acceptance

Pilot's release acceptance runs six separately spawned service processes, one
in-process fixture, and a browser over their production HTTP contracts:

```text
browser -> Pilot Web -> Pilot API -> Awaken Managed Agents
                               \-> IAM capability/PDP
Awaken Worker -> Pilot application MCP
              -> official Playwright MCP -> isolated Chrome -> HTTP fixture
              -> [host-login Codex ACP | Awaken Native DeepSeek]
```

Awaken remains the sole owner of Agent, Environment, Session, Worker, sandbox,
tool permission, retry, and event state. IAM remains the sole owner of public
capabilities and Grants. The runner creates no Pilot-side mirror of those
records: it idempotently provisions one tagged Agent and one runtime-appropriate
Environment through `@anthropic-ai/sdk`, and creates Projects and Missions
through the browser.

## Scope and ownership of this acceptance

The whole-system objective is to prove the production
`Browser -> Pilot BFF -> official SDK -> Awaken runtime -> committed Session`
path plus IAM authorization, without adding another execution or persistence
authority. This acceptance focuses on the cross-service boundary; lower-level
Awaken gates remain the authority for real-kernel sandboxing, external MCP,
multi-agent scheduling, Skills, and standalone Outcome evaluation.

| Classification | Authoritative owner | Acceptance use |
| --- | --- | --- |
| Reused unchanged | Awaken Deployment/Run, Session event log, Agent, Environment, File, Memory, Outcome, sandbox, and artifact machinery | The browser scenario creates and observes those records through their production contracts |
| Reused unchanged | IAM capability signer and Grant PAP/PDP | The public projection is authorized by one exact-Mission Grant and fails closed after revocation |
| Existing code modified | Pilot BFF mission prompt and existing real-stack runner/spec | The prompt names the runtime output-directory port; the runner provisions exact real profiles and the spec extends one causal workflow |
| Existing code modified | Awaken's existing Managed/runtime/Native owners | MCP transport completion, frozen-context installation, claim-scoped Work continuation, permission resume, artifact harvesting, and Outcome continuation are corrected in place |
| Genuinely new product/runtime authority | None | No Project, Mission, scheduler, transcript, Worker, Outcome, Connector, or artifact owner is added |
| Genuinely new verification mechanism | Binary provenance fence and expanded causal browser case | These reject stale binaries/profiles and exercise the same authoritative production path |

## Prerequisites

1. Build the Awaken revision under test in an isolated Cargo target and build
   `iam-daemon`.
2. For the default ACP lane, log Codex in on the host and confirm `awaken doctor
   acp --json` reports the credential state as `available`. For the Native lane,
   place the DeepSeek key in a mode-`0600` import file. The acceptance runner
   reads that file once, deletes it immediately, and writes the secret through
   Awaken's Provider Connection API. It never injects the key into an Awaken,
   Worker, Pilot, browser, or MCP process environment.
3. Keep the Pilot MCP reachable from the Awaken Worker. The bundled acceptance
   uses loopback because all services are separate host processes. A remote
   deployment must use a routable HTTPS URL; protect it with
   `PILOT_MCP_BEARER_TOKEN`, keep that bearer in Awaken Vault, and attach only
   the opaque Vault ID to the Project.
4. Provide Chrome or Chromium.

Run:

```sh
PILOT_E2E_AWAKEN_BIN=/absolute/path/to/awaken \
PILOT_E2E_AWAKEN_SOURCE_ROOT=/absolute/path/to/awaken/source \
PILOT_E2E_IAM_BIN=/absolute/path/to/iam-daemon \
PILOT_E2E_CHROME_BIN=/usr/bin/google-chrome \
pnpm e2e:real
```

To require the Awaken Native lane explicitly:

```sh
PILOT_E2E_AGENT_RUNTIME=native-deepseek \
PILOT_E2E_RECORD_VIDEO=1 \
PILOT_E2E_DEEPSEEK_IMPORT_FILE=/run/user/$(id -u)/deepseek-import \
PILOT_E2E_AWAKEN_BIN=/absolute/path/to/awaken \
PILOT_E2E_AWAKEN_SOURCE_ROOT=/absolute/path/to/awaken/source \
PILOT_E2E_IAM_BIN=/absolute/path/to/iam-daemon \
pnpm e2e:real
```

The import file is a one-time test-harness input, not a runtime credential
source. Create it without exporting its contents, restrict it to the current
user, and do not reuse it after the runner deletes it. Awaken service and Worker
entry points reject startup when the process contains `API_KEY` or any
case-insensitive `*_API_KEY` environment name. Only an Awaken Provider
Connection may supply a model-provider API key. The guard enumerates names but
never reads or logs their values; unrelated bearer-token and `*_API_KEY_FILE`
descriptors are not provider key material and are not rejected.

`PILOT_E2E_RECORD_VIDEO=1` changes the existing Playwright video policy from
failure-only to every run. A successful recording is retained below
`test-results/real-e2e/`; without the flag, routine successful runs remain
artifact-free and failures still retain diagnostic video.

For a released Awaken binary without a local source tree, set
`PILOT_E2E_AWAKEN_SHA256` instead of `PILOT_E2E_AWAKEN_SOURCE_ROOT`. The runner
requires one of those provenance fences. A local-source run records the Git
revision and dirty state and rejects a binary older than any Rust/Cargo input;
an optional checksum must also match exactly.

The runner uses an isolated temporary Awaken data directory and IAM database,
reads Awaken's own persisted local Workspace coordinate, starts the Pilot
MCP/API/Web services, the pinned official Playwright MCP and an isolated browser
fixture, creates one exact Agent with `pilot` and `browser` MCP Connectors plus
the four Anthropic document Skills, and then launches Playwright. The default
`PILOT_E2E_AGENT_RUNTIME=acp` lane provisions `acp:codex` and a Cloud
Environment. The `native-deepseek` lane requires the one-time import file,
provisions the write-only DeepSeek Provider connection and exact inference profile, selects
`deepseek-v4-flash`, and binds a self-hosted Environment to an immutable
`on_tool_use` Hand policy. Its dynamic critical path is:

```text
provision exact model + Agent + Environment profiles
 -> create Deployment + File + Memory + cron -> detach File -> fire Deployment Run
 -> browser MCP navigates/fills/clicks and reads the real DOM result
 -> Plan Session awaits approval -> same Session resumes
 -> fresh Outcome Session -> bash awaits approval
 -> [native: materialize Hand Sandbox] -> same Run resumes
 -> root Work settles; claimed successor may wake, renewal may not resurrect
 -> output harvested -> Outcome worker/grader serialize through that Environment
 -> Outcome satisfied -> IAM read -> Grant revoked/denied
```

It verifies one causally connected browser workflow rather than independent
mocked feature demos:

- Agent and Environment selection from the live Awaken catalog;
- browser upload of an Awaken File, creation of an Awaken Memory Store, and
  attachment of both official IDs to one scheduled Deployment-backed Project;
- a real manual Deployment schedule fire and its DeploymentRun-backed Session;
- Plan Mode stopping at a committed Pilot plan, then continuing in the same
  Session only after the browser records approval;
- an explicit update of that same Deployment which removes only the File before
  BackendOwned Workdir execution while retaining the Memory Store;
- Outcome rubric execution whose real Worker crosses an `always_ask` bash
  boundary, resumes after browser approval, reaches a satisfied evaluation, and
  publishes a harvested output Artifact under `$AWAKEN_OUTPUTS_DIR`;
- committed `set_plan` and `publish_result` tool events from the stateless MCP;
- a real official Playwright MCP process navigating a reachable page, filling a
  labeled form, clicking submit, reading the changed DOM, and committing the
  unique result through the same Session event path without an approval prompt;
- a second isolated Playwright MCP using the iPhone 15 browser/device profile,
  proving the same navigate/fill/click/DOM effect through the mobile route (this
  is mobile-browser emulation, not a claim about a physical handset);
- live delegated research through two published Native research Agents, with
  concurrent child Runs, committed `agent_run`, `web_search`, `web_fetch`, and
  spill-file `grep` events, plus citations to the required NIST and W3C primary
  sources;
- live Agent projection of `pptx`, `xlsx`, `docx`, and `pdf` managed Skills;
- IAM-minted capability plus exact-resource Grant in the public UI;
- fail-closed public access after IAM Grant revocation.

Failed runs retain their temporary service logs and print the directory. Set
`PILOT_E2E_KEEP_RUN_DIR=1` to retain logs after successful runs as well.

The same Outcome/HITL transition is covered below the browser in Awaken's
standalone `awaken-ext-goal`, Runtime Host, Managed projection, and real-kernel
coordinator tests. The real Hand workdir/namespace/container matrices own File
mount and read-only enforcement; the browser scenario is integration evidence
for those same authorities, not a second implementation.

## Capability evidence boundaries

| Capability family | Required evidence | What this browser run proves |
| --- | --- | --- |
| Session, Plan, approval, Outcome, artifact | browser E2E plus Runtime/Managed regressions | one event log, same-Session continuation, one permission resume, satisfied rubric, harvested byte |
| Deployment, schedule, File, Memory | browser E2E plus real-kernel resource suites | official IDs and one Deployment/Run path; kernel suites separately prove mount enforcement |
| real Agent and MCP Connector | exact SDK-provisioned Agent plus external-MCP gate | ACP lane proves host-login compatibility; Native lane proves live DeepSeek through an Awaken-managed Provider Connection without ACP or ambient API keys; both prove stateless Pilot MCP and official Playwright MCP behavior |
| Skills, research, multi-agent, resource limits | Awaken crate, deterministic E2E, sandbox, and formal gates | Pilot projects all four managed document Skill bindings; Awaken alone executes and constrains them |
| browser/computer use | official Playwright MCP plus a reachable isolated page | navigate, form fill, click, DOM read and committed result are proven end to end |
| external publishing/payment/analytics/Gmail/Slack | each configured provider's OAuth/account/sandbox acceptance | the generic Agent/Connector/Vault seam is proven; this suite does not claim an unconfigured vendor account |
| ext-goal without services | `awaken-ext-goal` package tests with no coordinator/HTTP dependency | definition, grading, iteration, limits, and terminal outcomes remain usable standalone |

A release may claim the first four rows only when their named gates pass. The
fifth row remains configuration-specific and must not be reported as a tested
vendor capability unless its real Connector acceptance has also run.

## FMECA and elimination measures

This is the sole real-stack FMECA for Pilot. Component tests keep their
cause/effect rules beside the test cases; they do not copy this cross-service
table. `S`, `O`, and `D` use 1–5 residual-risk scores and `RPN=S×O×D`.

| ID | Failure mode and end effect | S/O/D · RPN | Elimination, detection, and recovery | Acceptance evidence |
| --- | --- | --- | --- | --- |
| PF1 | Runner silently uses a stale binary or Agent/Connector/Skill/tool policy, so a green UI does not certify the declared runtime | 5/2/2 · 20 | isolated Cargo target; Cargo depfile source-root binding, source mtime/revision/dirty-state and SHA-256 fence; tagged Agent/Environment each have one exact profile and drift aborts provisioning | startup provenance/profile validation + capability UI |
| PF2 | Pilot invents File/Memory identities or stores a parallel resource catalog | 5/1/2 · 10 | upload/create returns official Awaken IDs; Project and Session carry those IDs unchanged | browser Project creation + Deployment resource response |
| PF3 | Cron is merely rendered but cannot create work | 4/2/3 · 24 | manual fire uses the same Deployment application command as cron; require a real DeploymentRun, Session, and result | “Run schedule now” → scheduled-run UI → MCP result |
| PF4 | Plan Mode acts before approval, or approval creates a replacement Session | 5/2/3 · 30 | initial event is ordinary plan-only message; approval is one later user event on the same Session | plan review visible with no result; same URL/Session completes after approval |
| PF5 | Outcome Worker awaits a tool and is reported failed, or Run resumes while Outcome remains stuck | 5/2/3 · 30 | Awaken returns typed Awaiting, commits ordinary permission resume, then reloads the sole Thread Outcome aggregate; default Judge derives the frozen Worker model and disables tools | upstream O2–O4 rules + browser bash approval + satisfied Quality |
| PF6 | Pilot smuggles an unsupported private Session-create field or copies transcript events to simulate branching | 5/2/3 · 30 | expose no Branch command until the official SDK and Awaken provide one typed ingress; retain Awaken's internal immutable prefix model without a second wire path | closed SDK DTO regression + absence of Pilot branch route/type/UI |
| PF7 | Artifact is only an MCP marker because Workdir writes outside the scan root | 4/2/2 · 16 | prompt exposes `$AWAKEN_OUTPUTS_DIR` as the physical write port and `outputs/...` as the logical publication path; Awaken harvests the concrete Session file | prompt seam rule + browser permission card + `outcome-result.txt` in Artifacts |
| PF8 | Public link authority leaks to another Mission or remains valid after revoke | 5/1/2 · 10 | IAM token plus exact `(Workspace,Mission)` Grant; revoke removes that one Grant | public result before revoke; fail-closed page after revoke |
| PF9 | ACP `session/load` history or a prior prompt is replayed as the current request | 5/2/2 · 20 | load uses a discard-only fact sink and the activation input remains authoritative | ACP replay/input decision-table tests + independent fresh-Session prompts |
| PF10 | A resumed permission has a new wire call ID, is applied twice, or collides with a later activation | 5/2/2 · 20 | one semantic permission identity, one-shot consumption, and activation-namespaced wire sequence | ACP resume rules + exactly one browser approval |
| PF11 | One self-hosted Work lease serializes schedule/browser/Plan/Outcome Sessions and a successor is falsely reported failed or claim/relinquish hot-loops during the handoff | 4/2/2 · 16 | `session_resume` is the sole Session Work admission edge; claim-current checks are side-effect free; typed NotReady relinquishes without crash accounting and the canonical pool applies a 250 ms minimum retry floor | Session Work signed-transport rules + pool backpressure decision test + schedule/browser/Plan/Outcome Sessions complete in order |
| PF12 | BackendOwned Workdir is mistaken for a read-only mounted File sandbox | 5/2/2 · 20 | same Deployment removes File before ACP; real bwrap/container gates separately prove File enforcement | Project update assertion + real-kernel sandbox/resource gates |
| PF13 | Deep Native delegation recursively polls child Runs on one Tokio worker stack | 5/2/2 · 20 | canonical child executor gains one abort-on-drop Tokio task boundary; no second executor or global stack override | standard-stack managed delegation E2E, including recursive/delegated paths |
| PF14 | Initial Deployment event or webhook test transport bypasses its canonical authority | 4/1/2 · 8 | initial events enter the ordinary event batch; outbound HTTP test support is a dev-only feature of the real guarded sender | Managed Deployment and webhook delivery regression gates |
| PF15 | E2E accepts swallowed transport errors, missing infrastructure, or prior run state | 5/1/2 · 10 | isolated data dirs/ports, exact response status checks, new Session IDs, bounded waits, retained logs/traces on failure | runner startup fences and Playwright causal assertions |
| PF16 | Official raw Work client or WorkPoller cannot claim/finish an item because Worker ID is optional or absent on some SDK calls | 5/2/2 · 20 | the authenticated Environment credential fingerprint is the single lease owner; optional Worker ID is only the liveness-observation label; both feed the same atomic WorkQueue | protocol credential decision table + raw-client lifecycle + unmodified official WorkPoller E2E |
| PF17 | ACP reports an MCP implementation name (`playwright`) instead of the authored alias (`browser`), so an `always_allow` toolset unexpectedly pauses or an unsafe fallback widens access | 5/2/2 · 20 | Awaken evaluates exact aliases directly; drifted names use conservative consensus across the Session's configured aliases: any deny denies, any ask asks, only unanimous allow allows; audit facts retain the real wire name | Awaken ACP decision table + real browser run with no unexpected approval |
| PF18 | A fresh binary is paired with a different adjacent source worktree, so the mtime fence records false provenance | 5/2/1 · 10 | local-source acceptance requires the Cargo depfile to name an input under the declared canonical source root before comparing mtimes or Git revision | runner startup depfile fence + successful exact-root run |
| PF19 | A claimed Native run silently uses ACP, leaks the Provider key, or executes Hand tools in Brain | 5/2/2 · 20 | closed runtime enum; exact non-`acp:*` Agent model and runtime metadata; write-only response non-leak assertion; exact `on_tool_use` policy binding; Awaken Hand matrices remain the isolation authority | live Native DeepSeek provisioning + browser Outcome bash/result/artifact + H1–H5/W1–W6 |
| PF20 | Official Playwright MCP sends protocol `ping`, a response arrives on its GET stream, or the final SSE event ends at EOF; mishandling closes the MCP Session or repeats a browser side effect | 5/2/2 · 20 | one wire-level server-request reply helper answers standard ping; one pending-response demultiplexer owns POST/GET routing; the canonical SSE parser flushes EOF exactly once | MCP ping, dual-route, EOF decision tests + real navigate/fill/click result |
| PF21 | Same-Session approval installs a frozen projection while its Runtime is active and is rejected as a competing projection | 5/2/2 · 20 | the one Runtime slot reuses an exact baseline or existing Session-dispatch marker; an unmarked active default context still fails closed | frozen-projection P1–P4 table + Plan approval completes on the same Session |
| PF22 | Successor wake races predecessor retirement, or background realization renewal revives stopped Work with no Run left to release it | 5/2/2 · 20 | `SessionWorkAcquisition` distinguishes a live `ClaimedRun` from `RealizationRenewal`; only the former may reuse canonical wake and retry once; terminal and renewal paths remain unowned | Session Work W1–W5 table + final Native database has four stopped Session rows and no active lease |
| PF23 | A delegated child addresses its own thread as Session Work or releases the parent's borrowed Work, deadlocking/fencing the waiting parent | 5/1/2 · 10 | every admission/resume uses existing `RunDispatch::session_thread_id()` affinity; child settle retains borrowed Work and only the root Run releases it | signed Worker T22/T23 + durable child-run regression |
| PF24 | E2E concatenates a tool button's accessible name with adjacent arguments or assumes ACP tool IDs in Native, producing a false failure after the business effect succeeded | 3/2/1 · 6 | assert button identity/state and adjacent arguments separately; select raw Native `mcp__...` or ACP `mcp....` audit identity from the declared runtime; terminal result/rubric owns content proof | real bash approval card, Native Pilot/browser tool IDs, satisfied Quality and artifact assertions |
| PF25 | Model-authored plan text repeats a result heading and makes a broad UI locator ambiguous after the committed result succeeded | 2/2/1 · 4 | select the result projection by its unique committed acceptance marker, not presentation order or generic copy | public Mission result marker assertion |
| PF25 | An ambient provider API key silently bypasses Awaken secret ownership, leaks through a child process, or makes a test pass without the declared Provider Connection | 5/2/1 · 10 | all service and Worker construction entry points call one canonical case-insensitive name guard before runtime startup; the guard never reads values; Native E2E scrubs all matching names and imports a one-time file through the write-only Provider Connection API | credential-materializer decision table, latest-binary refusal probe, Native E2E startup and redacted provider projection |
| PF26 | A Native Agent exhausts its step budget immediately after the last tool call and publishes raw provider protocol text instead of a business result | 4/2/2 · 16 | one runtime-contract constant owns the 16-step default across config authoring, Managed projection and snapshot building; standard Agents omit a redundant extension; typed-tools responses containing only raw DSML are retryable failures and are never parsed or executed | default-budget cross-owner tests, DSML cause/effect test, desktop/mobile/research Native E2E |
| PF27 | A delegated child requires registered-Worker placement, the parent cannot claim it locally, and the stable child Run disappears before any compatible Worker can observe it | 5/2/2 · 20 | the canonical `DispatchWorker::start_run` atomically claims locally compatible work and otherwise idempotently retains the same Run in the sole durable queue; the parent waits only on committed child truth | unclaimable-child C1–C3 decision test + live two-Agent Native research |
| PF28 | A foreground child runs longer than its initial dispatch lease, is reclaimed with a cold projection, and then loses its model or commit fence | 5/2/2 · 20 | every exact drive, including foreground child and recovered Worker, uses the one `DispatchWorker::drive_claimed` lease-renewal guard; cold recovery materializes the already-published model candidate | exact-claim renewal decision test + Native child Runs remain at one epoch through long live research |
| PF29 | Large official pages spill to a file but `grep` omits its required path schema, or independent all-allow children are serialized as though they could require HITL | 4/2/2 · 16 | the canonical Grep descriptor exposes the executor's exact `pattern + path` input; only a child's own immutable publication can prove all enabled tools terminal/always-allow and admit the existing durable parallel barrier | Grep descriptor rule G1 + child terminal-proof R1–R3 + two-source Native research |

No mitigation synchronizes duplicate state: Project is Deployment, Mission is
Session, schedule/run/resource/Outcome/artifact truth remains in Awaken, public
authorization remains in IAM, and Pilot owns only adapters, routes, copy, and UI
projection.
