import { createMcpExpressApp } from "@modelcontextprotocol/sdk/server/express.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import type { Express } from "express";
import { createPilotMcpServer } from "./tools.js";

export interface PilotMcpHttpOptions {
  host: string;
  bearer?: string;
  allowedHosts?: string[];
}

export function createPilotMcpApp(options: PilotMcpHttpOptions): Express {
  const app = createMcpExpressApp({
    host: options.host,
    ...(options.allowedHosts?.length ? { allowedHosts: options.allowedHosts } : {}),
  });

  app.get("/healthz", (_request, response) => {
    response.json({ status: "ok", service: "awaken-pilot-application-mcp" });
  });

  app.use("/mcp", (request, response, next) => {
    if (!options.bearer || request.headers.authorization === `Bearer ${options.bearer}`) return next();
    response.setHeader("WWW-Authenticate", "Bearer");
    response.status(401).json({ error: "unauthorized" });
  });

  app.all("/mcp", async (request, response) => {
    // Stateless HTTP requires one fresh Protocol + transport pair per request.
    // Reusing either can cross-route responses between clients; the SDK rejects
    // that pattern from v1.26 onward.
    const server = createPilotMcpServer();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    let closed = false;
    const cleanup = async () => {
      if (closed) return;
      closed = true;
      await transport.close().catch(() => undefined);
      await server.close().catch(() => undefined);
    };
    response.once("close", () => void cleanup());
    try {
      await server.connect(transport);
      await transport.handleRequest(request, response, request.body);
    } catch (error) {
      await cleanup();
      if (!response.headersSent) response.status(500).json({ error: "mcp_request_failed" });
      console.error("Pilot MCP request failed", error);
    }
  });
  return app;
}

