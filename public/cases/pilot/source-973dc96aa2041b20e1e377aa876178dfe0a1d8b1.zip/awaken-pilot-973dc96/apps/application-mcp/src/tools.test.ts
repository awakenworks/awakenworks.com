import { describe, expect, it } from "vitest";
import { executePilotTool } from "./tools.js";

/**
 * Cause-effect graph and decision table for the stateless application boundary:
 * C1 known tool + valid complete input -> E1 typed snapshot and readable text.
 * C2 known tool + invalid/missing required input -> E2 reject; no partial snapshot.
 * C3 set_plan with N complete steps -> E3 preserve all steps and their statuses.
 * C4 publish_result without artifacts -> E4 canonical empty artifact list.
 * Constraints: tool execution has no prior-state input and no durable side effect.
 * Rules R1=C1(set_plan)+C3, R2=C1(notify), R3=C1(result)+C4, R4=C2.
 */
describe("Pilot MCP tool decision table", () => {
  it("R1 publishes one complete plan snapshot", () => {
    const result = executePilotTool("set_plan", {
      summary: "Ship a verified slice",
      steps: [
        { id: "inspect", title: "Inspect", status: "completed" },
        { id: "build", title: "Build", status: "in_progress", detail: "Implementing" },
      ],
    });
    expect(result.structuredContent).toEqual({
      kind: "pilot.plan.v1",
      summary: "Ship a verified slice",
      steps: [
        { id: "inspect", title: "Inspect", status: "completed" },
        { id: "build", title: "Build", status: "in_progress", detail: "Implementing" },
      ],
    });
  });

  it("R2 returns a typed notification", () => {
    expect(executePilotTool("notify_user", { level: "warning", message: "Approval required" }).structuredContent)
      .toEqual({ kind: "pilot.notification.v1", level: "warning", message: "Approval required" });
  });

  it("R3 normalizes an omitted artifact list", () => {
    expect(executePilotTool("publish_result", { summary: "Done" }).structuredContent)
      .toEqual({ kind: "pilot.result.v1", summary: "Done", artifacts: [] });
  });

  it("R4 rejects an invalid snapshot atomically", () => {
    expect(() => executePilotTool("set_plan", { summary: "Incomplete", steps: [] })).toThrow();
    expect(() => executePilotTool("notify_user", { level: "debug", message: "x" })).toThrow();
  });
});
