import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";

const stepStatusSchema = z.enum(["pending", "in_progress", "completed", "blocked"]);

export const planStepSchema = z.object({
  id: z.string().min(1).max(80),
  title: z.string().min(1).max(500),
  status: stepStatusSchema,
  detail: z.string().max(2_000).optional(),
});

export const setPlanInputSchema = z.object({
  summary: z.string().min(1).max(2_000),
  steps: z.array(planStepSchema).min(1).max(100),
});

export const notifyUserInputSchema = z.object({
  level: z.enum(["info", "warning", "success"]),
  message: z.string().min(1).max(4_000),
});

export const publishResultInputSchema = z.object({
  summary: z.string().min(1).max(8_000),
  artifacts: z.array(z.object({
    path: z.string().min(1).max(1_000),
    description: z.string().max(2_000).optional(),
  })).max(100).default([]),
});

export type PilotToolName = "set_plan" | "notify_user" | "publish_result";

type ToolResult = {
  content: Array<{ type: "text"; text: string }>;
  structuredContent: Record<string, unknown>;
};

export function executePilotTool(name: PilotToolName, input: unknown): ToolResult {
  if (name === "set_plan") {
    const plan = setPlanInputSchema.parse(input);
    return {
      content: [{ type: "text", text: `Plan published with ${plan.steps.length} step(s).` }],
      structuredContent: { kind: "pilot.plan.v1", ...plan },
    };
  }
  if (name === "notify_user") {
    const notification = notifyUserInputSchema.parse(input);
    return {
      content: [{ type: "text", text: notification.message }],
      structuredContent: { kind: "pilot.notification.v1", ...notification },
    };
  }
  const result = publishResultInputSchema.parse(input);
  return {
    content: [{ type: "text", text: result.summary }],
    structuredContent: { kind: "pilot.result.v1", ...result },
  };
}

/** Build one stateless MCP surface. Inputs and returned snapshots are persisted by
 * Managed Agents as ordinary MCP tool-use/result events; this server owns no state. */
export function createPilotMcpServer(): McpServer {
  const server = new McpServer({ name: "awaken-pilot", version: "0.1.0" });
  server.registerTool("set_plan", {
    title: "Set mission plan",
    description: "Publish the complete current mission plan. Replace the prior snapshot; do not send a patch.",
    inputSchema: setPlanInputSchema,
  }, (input) => executePilotTool("set_plan", input));
  server.registerTool("notify_user", {
    title: "Notify user",
    description: "Surface a concise material progress, risk, or completion notification.",
    inputSchema: notifyUserInputSchema,
  }, (input) => executePilotTool("notify_user", input));
  server.registerTool("publish_result", {
    title: "Publish mission result",
    description: "Publish the terminal mission summary and paths of produced artifacts.",
    inputSchema: publishResultInputSchema,
  }, (input) => executePilotTool("publish_result", input));
  return server;
}

