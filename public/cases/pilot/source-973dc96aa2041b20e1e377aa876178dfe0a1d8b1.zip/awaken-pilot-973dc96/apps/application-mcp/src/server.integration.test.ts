import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import type { Server } from "node:http";
import { afterEach, describe, expect, it } from "vitest";
import { createPilotMcpApp } from "./http.js";
import { createPilotMcpServer } from "./tools.js";

const closeables: Array<{ close(): Promise<void> }> = [];
const listeners: Server[] = [];
afterEach(async () => {
  await Promise.all(closeables.splice(0).map((item) => item.close()));
  await Promise.all(listeners.splice(0).map((listener) => new Promise<void>((resolve, reject) => listener.close((error) => error ? reject(error) : resolve()))));
});

/**
 * Official MCP client/server integration causes and effects:
 * I1 initialized official client -> E1 exactly one discoverable canonical catalog.
 * I2 known tool + valid input -> E2 successful JSON-RPC result with typed snapshot.
 * I3 unknown tool -> E3 protocol error; no alternate dispatch path.
 * Rules R1=I1, R2=I1+I2, R3=I1+I3. The in-memory transport removes network
 * variability while exercising the same official protocol stack used over HTTP.
 */
describe("Pilot MCP official SDK integration", () => {
  it("R1/R2 discovers and calls the canonical tools", async () => {
    const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
    const server = createPilotMcpServer();
    const client = new Client({ name: "pilot-test", version: "1.0.0" });
    closeables.push(client, server);
    await server.connect(serverTransport);
    await client.connect(clientTransport);

    const listed = await client.listTools();
    expect(listed.tools.map((tool) => tool.name).sort()).toEqual(["notify_user", "publish_result", "set_plan"]);
    const called = await client.callTool({
      name: "set_plan",
      arguments: { summary: "Verify", steps: [{ id: "test", title: "Test", status: "completed" }] },
    });
    expect(called.isError).not.toBe(true);
    expect(called.structuredContent).toEqual({
      kind: "pilot.plan.v1",
      summary: "Verify",
      steps: [{ id: "test", title: "Test", status: "completed" }],
    });
  });

  it("R3 rejects an unknown tool through the protocol", async () => {
    const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
    const server = createPilotMcpServer();
    const client = new Client({ name: "pilot-test", version: "1.0.0" });
    closeables.push(client, server);
    await server.connect(serverTransport);
    await client.connect(clientTransport);
    const result = await client.callTool({ name: "parallel_plan_store", arguments: {} });
    expect(result.isError).toBe(true);
  });

  it("R1/R2 serves initialization, discovery, and call across isolated HTTP requests", async () => {
    const app = createPilotMcpApp({ host: "127.0.0.1", bearer: "test-token" });
    const listener = app.listen(0, "127.0.0.1");
    listeners.push(listener);
    await new Promise<void>((resolve) => listener.once("listening", resolve));
    const address = listener.address();
    if (!address || typeof address === "string") throw new Error("missing HTTP address");
    const transport = new StreamableHTTPClientTransport(new URL(`http://127.0.0.1:${address.port}/mcp`), {
      requestInit: { headers: { authorization: "Bearer test-token" } },
    });
    const client = new Client({ name: "pilot-http-test", version: "1.0.0" });
    closeables.push(client);
    await client.connect(transport);
    expect((await client.listTools()).tools).toHaveLength(3);
    const result = await client.callTool({ name: "notify_user", arguments: { level: "info", message: "Working" } });
    expect(result.structuredContent).toEqual({ kind: "pilot.notification.v1", level: "info", message: "Working" });
  });
});
