import { createPilotMcpApp } from "./http.js";

const host = process.env.PILOT_MCP_HOST ?? "127.0.0.1";
const port = Number(process.env.PILOT_MCP_PORT ?? "8788");
const bearer = process.env.PILOT_MCP_BEARER_TOKEN;
const allowedHosts = process.env.PILOT_MCP_ALLOWED_HOSTS?.split(",").map((item) => item.trim()).filter(Boolean);

if (!Number.isInteger(port) || port < 1 || port > 65_535) {
  throw new Error("PILOT_MCP_PORT must be an integer between 1 and 65535");
}

const app = createPilotMcpApp({
  host,
  ...(bearer ? { bearer } : {}),
  ...(allowedHosts?.length ? { allowedHosts } : {}),
});

const listener = app.listen(port, host, () => {
  console.log(`Awaken Pilot MCP listening on http://${host}:${port}/mcp`);
});

const close = async (): Promise<void> => {
  listener.close();
};
process.once("SIGINT", () => void close());
process.once("SIGTERM", () => void close());
