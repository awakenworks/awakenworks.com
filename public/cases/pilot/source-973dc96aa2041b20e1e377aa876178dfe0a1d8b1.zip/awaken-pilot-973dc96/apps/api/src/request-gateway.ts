import type { Request } from "express";
import { PILOT_WORKSPACE_HEADER } from "@awaken/pilot-contracts/headers";
import type { PilotApiConfig } from "./config.js";
import { AnthropicManagedPilotGateway, type ManagedPilotGateway } from "./managed-gateway.js";

export type ManagedPilotGatewayProvider = (request: Request) => ManagedPilotGateway;
export interface ManagedRequestContext {
  credential: string;
  workspaceId: string;
}

/** Construct the sole Managed SDK adapter from a resolved trusted context. */
export function managedGatewayForContext(
  config: PilotApiConfig,
  context: ManagedRequestContext,
  fetcher: typeof fetch = fetch,
): ManagedPilotGateway {
  return new AnthropicManagedPilotGateway(
    config.awakenApiUrl,
    context.credential,
    config.applicationMcpUrl,
    fetcher,
    context.workspaceId,
  );
}

export function requestCredential(request: Request): string {
  const authorization = request.header("authorization");
  if (authorization !== undefined) {
    const match = authorization.match(/^Bearer ([^\s]+)$/);
    if (!match?.[1]) throw Object.assign(new Error("Invalid bearer credential"), { status: 401 });
    return match[1];
  }
  return request.header("x-api-key")?.trim() ?? "";
}

function requestWorkspace(request: Request, fallback: string): string {
  const workspace = request.header(PILOT_WORKSPACE_HEADER)?.trim() || fallback;
  if (workspace.length > 500 || /[\x00-\x1f/\\]/.test(workspace)) {
    throw Object.assign(new Error("Invalid workspace"), { status: 400 });
  }
  return workspace;
}

/**
 * Resolve one request-scoped adapter. Identity and Workspace are not authorized
 * here: they are forwarded to Awaken's IAM PEP, which remains the sole PDP.
 */
export function createManagedGatewayProvider(
  config: PilotApiConfig,
  fetcher: typeof fetch = fetch,
): ManagedPilotGatewayProvider {
  return (request) => {
    return managedGatewayForContext(config, resolveManagedRequestContext(config, request), fetcher);
  };
}

/** Resolve the one credential/Workspace selection shared by every Pilot app service. */
export function resolveManagedRequestContext(
  config: PilotApiConfig,
  request: Request,
): ManagedRequestContext {
  const presented = requestCredential(request);
  if (config.requireRequestIdentity && !presented) {
    throw Object.assign(new Error("Authentication required"), { status: 401 });
  }
  const requestedWorkspace = request.header(PILOT_WORKSPACE_HEADER)?.trim() ?? "";
  if (!presented && requestedWorkspace && requestedWorkspace !== config.defaultWorkspaceId) {
    throw Object.assign(new Error("Authentication required for the selected Workspace"), { status: 401 });
  }
  const workspaceId = requestWorkspace(request, config.defaultWorkspaceId);
  if (config.requireRequestIdentity && !workspaceId) {
    throw Object.assign(new Error("Workspace required"), { status: 400 });
  }
  return { credential: presented || config.awakenAuthToken, workspaceId };
}
