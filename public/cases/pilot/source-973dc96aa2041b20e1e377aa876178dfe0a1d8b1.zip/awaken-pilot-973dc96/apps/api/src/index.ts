import { createServer } from "node:http";
import { readPilotApiConfig } from "./config.js";
import { createPilotApi } from "./http.js";
import { createManagedGatewayProvider } from "./request-gateway.js";
import { PilotPublicLinkService } from "./public-links.js";

const config = readPilotApiConfig();
const server = createServer(createPilotApi(
  createManagedGatewayProvider(config),
  new PilotPublicLinkService(config),
  config,
));

server.listen(config.port, config.host, () => {
  console.log(`Awaken Pilot API listening on http://${config.host}:${config.port}`);
});

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.once(signal, () => server.close(() => process.exit(0)));
}
