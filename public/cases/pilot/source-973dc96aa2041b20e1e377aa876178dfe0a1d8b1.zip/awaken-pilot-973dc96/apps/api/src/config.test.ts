import { describe, expect, it } from "vitest";
import { readPilotApiConfig } from "./config.js";

/**
 * Configuration cause-effect table:
 * C1 values absent -> E1 loopback defaults and no credential.
 * C2 valid explicit URL/port/token -> E2 exact server-only connection config.
 * C3 invalid URL or port -> E3 fail before listening.
 * C4 strict identity flag + default Workspace -> E4 exact request-edge policy.
 * Rules R1=C1; R2=C2; R3=C3; R4=C4. No browser setting participates.
 */
describe("API configuration decision table", () => {
  it("R1 uses safe local defaults", () => {
    expect(readPilotApiConfig({})).toEqual({
      host: "127.0.0.1",
      port: 4174,
      awakenApiUrl: "http://127.0.0.1:8080",
      awakenAuthToken: "",
      iamApiUrl: "http://127.0.0.1:8080",
      iamAdminToken: "",
      applicationMcpUrl: "",
      requireRequestIdentity: false,
      defaultWorkspaceId: "",
    });
  });

  it("R2 reads an explicit server-only Awaken connection", () => {
    expect(readPilotApiConfig({
      PILOT_API_HOST: "0.0.0.0",
      PILOT_API_PORT: "5000",
      PILOT_AWAKEN_API_URL: "https://awaken.example.test",
      PILOT_AWAKEN_AUTH_TOKEN: "server-token",
      PILOT_IAM_API_URL: "https://iam.example.test",
      PILOT_IAM_ADMIN_TOKEN: "iam-admin",
      PILOT_APPLICATION_MCP_URL: "https://pilot.example.test/mcp",
      PILOT_REQUIRE_REQUEST_IDENTITY: "true",
      PILOT_DEFAULT_WORKSPACE_ID: "workspace_team",
    })).toEqual({
      host: "0.0.0.0",
      port: 5000,
      awakenApiUrl: "https://awaken.example.test",
      awakenAuthToken: "server-token",
      iamApiUrl: "https://iam.example.test",
      iamAdminToken: "iam-admin",
      applicationMcpUrl: "https://pilot.example.test/mcp",
      requireRequestIdentity: true,
      defaultWorkspaceId: "workspace_team",
    });
  });

  it("R3 rejects invalid listener and upstream values", () => {
    expect(() => readPilotApiConfig({ PILOT_API_PORT: "0" })).toThrow("PILOT_API_PORT");
    expect(() => readPilotApiConfig({ PILOT_AWAKEN_API_URL: "relative" })).toThrow("PILOT_AWAKEN_API_URL");
    expect(() => readPilotApiConfig({ PILOT_AWAKEN_API_URL: "ftp://awaken.example.test" })).toThrow("PILOT_AWAKEN_API_URL");
    expect(() => readPilotApiConfig({ PILOT_IAM_API_URL: "file:///tmp/iam" })).toThrow("PILOT_IAM_API_URL");
    expect(() => readPilotApiConfig({ PILOT_APPLICATION_MCP_URL: "file:///tmp/mcp" })).toThrow("PILOT_APPLICATION_MCP_URL");
    expect(() => readPilotApiConfig({ PILOT_REQUIRE_REQUEST_IDENTITY: "yes" })).toThrow("PILOT_REQUIRE_REQUEST_IDENTITY");
  });
});
