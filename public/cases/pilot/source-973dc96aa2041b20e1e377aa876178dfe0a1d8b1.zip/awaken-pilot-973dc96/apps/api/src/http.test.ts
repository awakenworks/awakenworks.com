import { createServer } from "node:http";
import type { AddressInfo } from "node:net";
import { describe, expect, it, vi } from "vitest";
import { createPilotApi } from "./http.js";
import type { ManagedPilotGateway } from "./managed-gateway.js";
import type { PilotPublicLinkService } from "./public-links.js";
import type { PilotApiConfig } from "./config.js";

function fakeGateway(): ManagedPilotGateway {
  return {
    listProjects: vi.fn(async () => []),
    getProject: vi.fn(async () => ({ id: "deployment_1" })),
    createProject: vi.fn(async () => ({ id: "deployment_1" })),
    updateProject: vi.fn(async () => ({ id: "deployment_1" })),
    archiveProject: vi.fn(async () => undefined),
    pauseProject: vi.fn(async () => ({ id: "deployment_1", status: "paused" })),
    unpauseProject: vi.fn(async () => ({ id: "deployment_1", status: "active" })),
    runProject: vi.fn(async () => ({ id: "run_1" })),
    listProjectRuns: vi.fn(async () => []),
    listAgents: vi.fn(async () => []),
    createAgentProfile: vi.fn(async () => ({ id: "agent_profile" })),
    updateAgentProfile: vi.fn(async () => ({ id: "agent_profile", version: 2 })),
    listEnvironments: vi.fn(async () => []),
    listKnowledgeFiles: vi.fn(async () => []),
    uploadKnowledgeFile: vi.fn(async () => ({ id: "file_1" })),
    listMemoryStores: vi.fn(async () => []),
    createMemoryStore: vi.fn(async () => ({ id: "memstore_1" })),
    listVaults: vi.fn(async () => []),
    createVault: vi.fn(async () => ({ id: "vlt_1" })),
    listVaultCredentials: vi.fn(async () => []),
    createVaultCredential: vi.fn(async () => ({ id: "vcrd_1" })),
    validateVaultCredential: vi.fn(async () => ({ credential_id: "vcrd_1", status: "valid" })),
    listWebhooks: vi.fn(async () => []),
    putWebhook: vi.fn(async (id) => ({ id, workspace_id: "ws_1", url: "https://example.test/hook", event_types: [], disabled: false })),
    deleteWebhook: vi.fn(async () => undefined),
    listMissions: vi.fn(async () => []),
    createMission: vi.fn(async () => ({ id: "sesn_1" }) as never),
    getMission: vi.fn(async () => ({ id: "sesn_1" }) as never),
    listEvents: vi.fn(async () => []),
    followEvents: vi.fn(async () => undefined),
    sendMessage: vi.fn(async () => undefined),
    interrupt: vi.fn(async () => undefined),
    decide: vi.fn(async () => undefined),
    listThreads: vi.fn(async () => []),
    listThreadEvents: vi.fn(async () => []),
    listArtifacts: vi.fn(async () => []),
    downloadArtifact: vi.fn(async () => undefined),
    archive: vi.fn(async () => undefined),
  };
}

const apiConfig: PilotApiConfig = {
  host: "127.0.0.1", port: 4174, awakenApiUrl: "https://awaken.test", awakenAuthToken: "server",
  iamApiUrl: "https://iam.test", iamAdminToken: "admin", applicationMcpUrl: "",
  requireRequestIdentity: false, defaultWorkspaceId: "ws_1",
};

async function withApi<T>(gateway: ManagedPilotGateway, action: (baseUrl: string) => Promise<T>, publicLinks?: PilotPublicLinkService): Promise<T> {
  const server = createServer(createPilotApi(() => gateway, publicLinks, publicLinks ? apiConfig : undefined));
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const { port } = server.address() as AddressInfo;
  try {
    return await action(`http://127.0.0.1:${port}`);
  } finally {
    server.closeAllConnections();
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
}

const validMission = {
  projectId: "deployment_1",
  title: "Brief",
  goal: "Verify the result",
  mode: "execute" as const,
  acceptanceCriteria: "Every claim cites a primary source.",
  maxIterations: 3,
};

const validProject = {
  name: "Research desk",
  instruction: "Use primary sources and verify every claim.",
  agentId: "agent_1",
  environmentId: "env_1",
  vaultIds: [],
  fileIds: [],
  memoryStoreIds: [],
  budgetUsdCents: 2500,
  schedule: { prompt: "Publish the weekly brief.", expression: "0 9 * * 1", timezone: "Asia/Shanghai" },
};

/**
 * HTTP command cause-effect table:
 * C1 body satisfies the shared contract -> E1 dispatch exactly once and return 201.
 * C2 body violates the shared contract -> E2 return 400 and perform no SDK command.
 * C3 upstream throws an opaque error -> E3 return stable 502 without leaking details.
 * C4 valid text/decision -> E4 normalize and dispatch the corresponding event command.
 * C5 allow plus denial reason -> E5 reject the contradictory decision before the SDK.
 * C6 non-empty raw file plus encoded name -> E6 dispatch exact bytes/media metadata.
 * C7 missing name or empty file -> E7 reject before the SDK.
 * C8 valid/invalid Memory Store command -> E8 dispatch once/reject before SDK.
 * C9 valid/invalid webhook command -> E9 dispatch once/reject before config plane.
 * C10 valid/unsafe write-only credential -> E10 dispatch once/reject before Vault.
 * C11 obsolete private Branch route -> E11 fail as an unregistered route without
 * issuing any Session-create command.
 * Rules R1=C1; R2=C2; R3=C3; R4=C4; R5=C5; R6=C6; R7=C7; R8=C8;
 * R9=C9; R10=C10; R11=C11. This is the sole browser-to-SDK command boundary.
 */
describe("Pilot API command decision table", () => {
  it("R1 validates and dispatches Project creation to the one Deployment gateway", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/projects`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validProject),
      });
      expect(response.status).toBe(201);
      expect(await response.json()).toEqual({ id: "deployment_1" });
    });
    expect(gateway.createProject).toHaveBeenCalledOnce();
    expect(gateway.createProject).toHaveBeenCalledWith(validProject);
  });

  it("R2 rejects an invalid schedule before the Deployment gateway", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/projects`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...validProject, schedule: { ...validProject.schedule, expression: "@daily" } }),
      });
      expect(response.status).toBe(400);
    });
    expect(gateway.createProject).not.toHaveBeenCalled();
  });

  it("R10 rejects an unsafe Connector URL before secret egress", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/vaults/vlt_1/credentials`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          displayName: "Browser",
          auth: { type: "static_bearer", mcpServerUrl: "https://user:secret@example.test/mcp", token: "write-only-secret" },
        }),
      });
      expect(response.status).toBe(400);
    });
    expect(gateway.createVaultCredential).not.toHaveBeenCalled();
  });

  it("R1 validates and dispatches mission creation once", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validMission),
      });
      expect(response.status).toBe(201);
      expect(await response.json()).toEqual({ id: "sesn_1" });
    });
    expect(gateway.createMission).toHaveBeenCalledOnce();
    expect(gateway.createMission).toHaveBeenCalledWith(validMission);
  });

  it("R11 leaves the unsupported private Branch command unregistered", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/branches`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...validMission, projectId: undefined }),
      });
      expect(response.status).toBe(404);
    });
    expect(gateway.createMission).not.toHaveBeenCalled();
  });

  it("R2 rejects invalid input before the gateway", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...validMission, goal: "" }),
      });
      expect(response.status).toBe(400);
      expect(await response.json()).toEqual(expect.objectContaining({ error: "Invalid request" }));
      const prematureOutcome = await fetch(`${baseUrl}/api/missions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...validMission, mode: "plan", acceptanceCriteria: "Must pass" }),
      });
      expect(prematureOutcome.status).toBe(400);
    });
    expect(gateway.createMission).not.toHaveBeenCalled();
  });

  it("R3 maps opaque upstream failures without exposing their message", async () => {
    const gateway = fakeGateway();
    vi.mocked(gateway.listMissions).mockRejectedValue(new Error("upstream-secret"));
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions`);
      expect(response.status).toBe(502);
      expect(await response.json()).toEqual({ error: "Awaken request failed" });
    });
  });

  it("R4 normalizes and dispatches a valid message command", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: "  continue  " }),
      });
      expect(response.status).toBe(204);
    });
    expect(gateway.sendMessage).toHaveBeenCalledWith("sesn_1", "continue");
  });

  it("R5 rejects a contradictory approval before dispatch", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/decisions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ toolUseId: "tool_1", allow: true, reason: "contradiction" }),
      });
      expect(response.status).toBe(400);
    });
    expect(gateway.decide).not.toHaveBeenCalled();
  });

  it("R6 relays a knowledge file once without creating a Pilot file record", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/files`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream", "X-Pilot-Filename": encodeURIComponent("资料.md"), "X-Pilot-Mime-Type": "text/markdown" },
        body: "verified",
      });
      expect(response.status).toBe(201);
    });
    expect(gateway.uploadKnowledgeFile).toHaveBeenCalledOnce();
    expect(gateway.uploadKnowledgeFile).toHaveBeenCalledWith("资料.md", "text/markdown", expect.any(Buffer));
    expect(vi.mocked(gateway.uploadKnowledgeFile).mock.calls[0]?.[2]).toEqual(Buffer.from("verified"));
  });

  it("R7 rejects an empty upload before the Files API", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/files`, {
        method: "POST",
        headers: { "X-Pilot-Filename": "empty.txt" },
        body: new Uint8Array(),
      });
      expect(response.status).toBe(400);
    });
    expect(gateway.uploadKnowledgeFile).not.toHaveBeenCalled();
  });

  it("R8 validates a Memory Store before creating the upstream resource", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const accepted = await fetch(`${baseUrl}/api/memory-stores`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Research memory", description: "Verified findings" }),
      });
      const rejected = await fetch(`${baseUrl}/api/memory-stores`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "", description: "invalid" }),
      });
      expect(accepted.status).toBe(201);
      expect(rejected.status).toBe(400);
    });
    expect(gateway.createMemoryStore).toHaveBeenCalledOnce();
  });

  it("R9 validates a webhook command before the authoritative config plane", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const accepted = await fetch(`${baseUrl}/api/webhooks/wh_1`, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: "https://receiver.example/hook", eventTypes: [], disabled: false }),
      });
      const rejected = await fetch(`${baseUrl}/api/webhooks/wh_2`, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: "", eventTypes: [""], disabled: false }),
      });
      expect(accepted.status).toBe(200);
      expect(rejected.status).toBe(400);
    });
    expect(gateway.putWebhook).toHaveBeenCalledOnce();
    expect(gateway.putWebhook).toHaveBeenCalledWith("wh_1", {
      url: "https://receiver.example/hook", eventTypes: [], disabled: false,
    });
  });

  it("projects child evidence through its thread route without flattening the Mission log", async () => {
    /* Cause/effect graph: C1 authenticated Session id + C2 child Thread id ->
     * E1 one gateway read with both exact identities -> E2 child event response.
     * R1 C1+C2 -> E1+E2. FMECA: copying child tool events into the root Mission
     * transcript would duplicate committed facts and violate Managed Agents'
     * isolated-thread contract; this route preserves the upstream owner. */
    const gateway = fakeGateway();
    vi.mocked(gateway.listThreadEvents).mockResolvedValue([
      { id: "evt_1", type: "agent.tool_use", name: "web_search" },
    ]);
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/threads/sthr_1/events`);
      expect(response.status).toBe(200);
      await expect(response.json()).resolves.toEqual([
        { id: "evt_1", type: "agent.tool_use", name: "web_search" },
      ]);
    });
    expect(gateway.listThreadEvents).toHaveBeenCalledWith("sesn_1", "sthr_1");
  });

  it("R10 exposes only the public-link application service, not a parallel ACL", async () => {
    /* C10 valid duration + authenticated Mission route -> E10 one service
     * command and one-time token response; invalid duration -> reject before
     * service. Public snapshot is a separate token-only read route. */
    const gateway = fakeGateway();
    const publicLinks = {
      create: vi.fn(async () => ({ missionId: "sesn_1", workspaceId: "ws_1", token: "cap", expiresAt: "2026-08-20T00:00:00.000Z" })),
      revoke: vi.fn(async () => undefined),
      snapshot: vi.fn(async () => ({ mission: { id: "sesn_1" }, events: [], threads: [], artifacts: [] })),
      artifact: vi.fn(async () => undefined),
    } as unknown as PilotPublicLinkService;
    await withApi(gateway, async (baseUrl) => {
      const issued = await fetch(`${baseUrl}/api/missions/sesn_1/public-link`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ expiresInDays: 7 }),
      });
      const invalid = await fetch(`${baseUrl}/api/missions/sesn_1/public-link`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ expiresInDays: 31 }),
      });
      const viewed = await fetch(`${baseUrl}/api/public/workspaces/ws_1/missions/sesn_1`, {
        headers: { "X-Pilot-Public-Token": "cap" },
      });
      expect(issued.status).toBe(201);
      expect(invalid.status).toBe(400);
      expect(viewed.status).toBe(200);
    }, publicLinks);
    expect(publicLinks.create).toHaveBeenCalledOnce();
    expect(publicLinks.snapshot).toHaveBeenCalledWith("cap", "ws_1", "sesn_1");
  });
});

/**
 * Artifact access cause-effect table:
 * A1 file is in the Session scope and downloadable -> E1 bytes plus safe attachment headers.
 * A2 file is missing, out of scope, or not downloadable -> E2 404 and no bytes.
 * Rules R1=A1; R2=A2. Scope resolution stays in the one Managed gateway.
 */
describe("artifact access decision table", () => {
  it("R1 serves only the gateway-authorized artifact", async () => {
    const gateway = fakeGateway();
    vi.mocked(gateway.downloadArtifact).mockResolvedValue({
      data: new TextEncoder().encode("report"),
      filename: "结果.md",
      contentType: "text/markdown",
    });
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/artifacts/file_1/content`);
      expect(response.status).toBe(200);
      expect(response.headers.get("content-type")).toContain("text/markdown");
      expect(response.headers.get("content-disposition")).toContain("filename*=UTF-8''");
      expect(await response.text()).toBe("report");
    });
    expect(gateway.downloadArtifact).toHaveBeenCalledWith("sesn_1", "file_1");
  });

  it("R2 returns 404 when the gateway cannot authorize the file", async () => {
    const gateway = fakeGateway();
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/artifacts/file_2/content`);
      expect(response.status).toBe(404);
    });
  });
});

/**
 * Live-event cause-effect table:
 * S1 upstream event -> E1 one JSON SSE data frame.
 * S2 browser disconnect -> E2 abort the one upstream follow operation and terminate.
 * S3 upstream stream failure -> E3 close without exposing internals; committed-event refresh recovers.
 * Rules R1=S1+S2; R3=S3.
 */
describe("live event stream decision table", () => {
  it("R1 relays an event and aborts upstream after browser cancellation", async () => {
    const gateway = fakeGateway();
    let upstreamAborted = false;
    vi.mocked(gateway.followEvents).mockImplementation(async (_id, receive, signal) => {
      receive({ type: "session.end" });
      await new Promise<void>((resolve) => signal.addEventListener("abort", () => {
        upstreamAborted = true;
        resolve();
      }, { once: true }));
    });
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/events/stream`);
      const reader = response.body?.getReader();
      if (!reader) throw new Error("stream body missing");
      let received = "";
      while (!received.includes("session.end")) {
        const chunk = await reader.read();
        if (chunk.done) break;
        received += new TextDecoder().decode(chunk.value);
      }
      expect(received).toContain("connected");
      expect(received).toContain("session.end");
      await reader.cancel();
      await vi.waitFor(() => expect(upstreamAborted).toBe(true));
    });
  });

  it("R3 closes a failed stream without exposing upstream details", async () => {
    const gateway = fakeGateway();
    vi.mocked(gateway.followEvents).mockRejectedValue(new Error("upstream-stream-secret"));
    await withApi(gateway, async (baseUrl) => {
      const response = await fetch(`${baseUrl}/api/missions/sesn_1/events/stream`);
      const body = await response.text();
      expect(response.status).toBe(200);
      expect(body).toContain("connected");
      expect(body).not.toContain("upstream-stream-secret");
    });
  });
});
