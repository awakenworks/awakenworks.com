import { createHash, randomUUID } from "node:crypto";
import type { BetaManagedAgentsSession } from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import type { PublicMissionLink, PublicMissionLinkRequest } from "@awaken/pilot-contracts";
import type { PilotApiConfig } from "./config.js";
import type { ArtifactDownload, ManagedPilotGateway } from "./managed-gateway.js";
import { managedGatewayForContext, type ManagedRequestContext } from "./request-gateway.js";

const PILOT_APPLICATION = "awaken-pilot";
const PUBLIC_AUDIENCE = "awaken-pilot-public";
const PUBLIC_ACTION = "pilot.mission.read";
const PUBLIC_RESOURCE_TYPE = "pilot_mission";
const SHARE_ADMIN_ACTION = "awaken.runtime.resources::workspace.write";

interface CapabilityClaims {
  sub: string;
  aud: string;
  exp: number;
  scope: string[];
}

interface PublicMissionSnapshot {
  mission: unknown;
  events: unknown[];
  threads: unknown[];
  artifacts: unknown[];
}

function linkGrantId(workspaceId: string, missionId: string): string {
  return `pilot-public:${createHash("sha256").update(JSON.stringify([workspaceId, missionId])).digest("hex")}`;
}

function resourceId(workspaceId: string, missionId: string): string {
  return JSON.stringify([workspaceId, missionId]);
}

function isPilotMission(mission: BetaManagedAgentsSession): boolean {
  return mission.metadata.application === PILOT_APPLICATION && Boolean(mission.metadata.pilot_project_id);
}

async function responseError(response: Response): Promise<Error & { status?: number }> {
  let message = response.statusText || `IAM request failed (${response.status})`;
  try {
    const body = await response.json() as { message?: unknown; error?: unknown };
    if (typeof body.message === "string") message = body.message;
    else if (typeof body.error === "string") message = body.error;
  } catch {
    // Stable status text remains the fallback for non-JSON infrastructure errors.
  }
  return Object.assign(new Error(message), { status: response.status });
}

export class PilotPublicLinkService {
  constructor(
    private readonly config: PilotApiConfig,
    private readonly fetcher: typeof fetch = fetch,
  ) {}

  async create(
    gateway: ManagedPilotGateway,
    context: ManagedRequestContext,
    missionId: string,
    input: PublicMissionLinkRequest,
  ): Promise<PublicMissionLink> {
    await this.#pilotMission(gateway, missionId);
    await this.#authorizeIssuer(context);
    this.#requireAdminToken();

    const now = Math.floor(Date.now() / 1000);
    const expiresAtSeconds = now + input.expiresInDays * 86_400;
    const subject = `pilot-public-${randomUUID()}`;
    const tokenId = `cap-${randomUUID()}`;
    const tokenResponse = await this.#adminRequest("/v1/admin/capabilities", {
      method: "POST",
      body: JSON.stringify({
        issuer: this.config.iamApiUrl,
        subject,
        audience: PUBLIC_AUDIENCE,
        token_id: tokenId,
        issued_at: now,
        expires_at: expiresAtSeconds,
        scopes: [PUBLIC_ACTION],
      }),
    });
    const issued = await tokenResponse.json() as { token?: unknown };
    if (typeof issued.token !== "string" || !issued.token) throw new Error("IAM returned an invalid capability");

    // The deterministic Grant id is the sole durable share authority. Replacing
    // its fresh subject rotates the link and makes every older token fail closed.
    await this.#adminRequest("/v1/admin/grants", {
      method: "POST",
      body: JSON.stringify({
        id: linkGrantId(context.workspaceId, missionId),
        subject: { kind: "principal", principal: { kind: "service", service_id: subject } },
        action_pattern: PUBLIC_ACTION,
        scope: {
          kind: "resource",
          resource_type: PUBLIC_RESOURCE_TYPE,
          resource_id: resourceId(context.workspaceId, missionId),
        },
        effect: "allow",
      }),
    });
    return {
      missionId,
      workspaceId: context.workspaceId,
      token: issued.token,
      expiresAt: new Date(expiresAtSeconds * 1000).toISOString(),
    };
  }

  async revoke(
    gateway: ManagedPilotGateway,
    context: ManagedRequestContext,
    missionId: string,
  ): Promise<void> {
    await this.#pilotMission(gateway, missionId);
    await this.#authorizeIssuer(context);
    this.#requireAdminToken();
    const response = await this.fetcher(
      new URL(`/v1/admin/grants/${encodeURIComponent(linkGrantId(context.workspaceId, missionId))}`, this.config.iamApiUrl),
      { method: "DELETE", headers: { Authorization: `Bearer ${this.config.iamAdminToken}` } },
    );
    if (!response.ok && response.status !== 404) throw await responseError(response);
  }

  async snapshot(token: string, workspaceId: string, missionId: string): Promise<PublicMissionSnapshot> {
    await this.#authorizeViewer(token, workspaceId, missionId);
    const gateway = this.#serverGateway(workspaceId);
    const mission = await this.#pilotMission(gateway, missionId);
    const [events, threads, artifacts] = await Promise.all([
      gateway.listEvents(missionId),
      gateway.listThreads(missionId),
      gateway.listArtifacts(missionId),
    ]);
    return { mission, events, threads, artifacts };
  }

  async artifact(token: string, workspaceId: string, missionId: string, fileId: string): Promise<ArtifactDownload | undefined> {
    await this.#authorizeViewer(token, workspaceId, missionId);
    const gateway = this.#serverGateway(workspaceId);
    await this.#pilotMission(gateway, missionId);
    return gateway.downloadArtifact(missionId, fileId);
  }

  async #pilotMission(gateway: ManagedPilotGateway, missionId: string): Promise<BetaManagedAgentsSession> {
    const mission = await gateway.getMission(missionId) as BetaManagedAgentsSession;
    if (!isPilotMission(mission)) throw Object.assign(new Error("Mission not found"), { status: 404 });
    return mission;
  }

  async #authorizeIssuer(context: ManagedRequestContext): Promise<void> {
    if (!context.credential || !context.workspaceId) throw Object.assign(new Error("Authentication required"), { status: 401 });
    const principal = await this.#resolvePrincipal(context.credential, context.workspaceId);
    if (!await this.#isAllowed(principal, SHARE_ADMIN_ACTION, { kind: "workspace", workspace_id: context.workspaceId })) {
      throw Object.assign(new Error("Workspace write permission required"), { status: 403 });
    }
  }

  async #resolvePrincipal(credential: string, workspaceId: string): Promise<unknown> {
    const tokenResponse = await this.fetcher(new URL("/v1/tokens/introspect", this.config.iamApiUrl), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: credential }),
    });
    if (tokenResponse.ok) {
      const body = await tokenResponse.json() as { principal?: unknown; workspace?: unknown };
      if (body.workspace !== workspaceId || !body.principal) throw Object.assign(new Error("Credential Workspace mismatch"), { status: 403 });
      return body.principal;
    }
    const userInfo = await this.fetcher(new URL("/v1/oauth/userinfo", this.config.iamApiUrl), {
      headers: { Authorization: `Bearer ${credential}` },
    });
    if (!userInfo.ok) throw Object.assign(new Error("IAM identity could not be resolved"), { status: 401 });
    const body = await userInfo.json() as { sub?: unknown };
    if (typeof body.sub !== "string" || !body.sub) throw Object.assign(new Error("IAM returned an invalid identity"), { status: 502 });
    return { kind: "account", account_id: body.sub };
  }

  async #authorizeViewer(token: string, workspaceId: string, missionId: string): Promise<void> {
    if (!token) throw Object.assign(new Error("Public link token required"), { status: 401 });
    const verified = await this.#iamRequest("/v1/capabilities/introspect", {
      method: "POST",
      body: JSON.stringify({ token, audience: PUBLIC_AUDIENCE }),
    });
    const claims = await verified.json() as CapabilityClaims;
    if (claims.aud !== PUBLIC_AUDIENCE || !claims.scope?.includes(PUBLIC_ACTION) || typeof claims.sub !== "string") {
      throw Object.assign(new Error("Invalid public link token"), { status: 401 });
    }
    if (!await this.#isAllowed(
      { kind: "service", service_id: claims.sub },
      PUBLIC_ACTION,
      { kind: "resource", resource_type: PUBLIC_RESOURCE_TYPE, resource_id: resourceId(workspaceId, missionId) },
    )) throw Object.assign(new Error("Public link is revoked"), { status: 403 });
  }

  async #isAllowed(principal: unknown, action: string, scope: unknown): Promise<boolean> {
    const response = await this.#iamRequest("/v1/authorize", {
      method: "POST",
      body: JSON.stringify({ principal, on_behalf_of: [], action, scope }),
    });
    const outcome = await response.json() as { decision?: unknown };
    return outcome.decision === "allow";
  }

  #serverGateway(workspaceId: string): ManagedPilotGateway {
    if (!this.config.awakenAuthToken) throw Object.assign(new Error("Public Mission projection is not configured"), { status: 503 });
    return managedGatewayForContext(
      this.config,
      { credential: this.config.awakenAuthToken, workspaceId },
      this.fetcher,
    );
  }

  #requireAdminToken(): void {
    if (!this.config.iamAdminToken) throw Object.assign(new Error("Public link issuance is not configured"), { status: 503 });
  }

  #iamRequest(path: string, init: RequestInit): Promise<Response> {
    return this.#request(path, init, undefined);
  }

  #adminRequest(path: string, init: RequestInit): Promise<Response> {
    return this.#request(path, init, this.config.iamAdminToken);
  }

  async #request(path: string, init: RequestInit, bearer: string | undefined): Promise<Response> {
    const headers = new Headers(init.headers);
    headers.set("Content-Type", "application/json");
    if (bearer) headers.set("Authorization", `Bearer ${bearer}`);
    const response = await this.fetcher(new URL(path, this.config.iamApiUrl), { ...init, headers });
    if (!response.ok) throw await responseError(response);
    return response;
  }
}
