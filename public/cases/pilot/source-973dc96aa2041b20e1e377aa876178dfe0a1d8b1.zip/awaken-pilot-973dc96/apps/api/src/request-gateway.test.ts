import type { Request } from "express";
import { describe, expect, it, vi } from "vitest";
import type { PilotApiConfig } from "./config.js";
import { createManagedGatewayProvider } from "./request-gateway.js";

const config: PilotApiConfig = {
  host: "127.0.0.1",
  port: 4174,
  awakenApiUrl: "https://awaken.example.test",
  awakenAuthToken: "server-token",
  iamApiUrl: "https://iam.example.test",
  iamAdminToken: "iam-admin",
  applicationMcpUrl: "",
  requireRequestIdentity: true,
  defaultWorkspaceId: "",
};

function request(headers: Record<string, string> = {}): Request {
  const normalized = Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), value]));
  return { header: (name: string) => normalized[name.toLowerCase()] } as Request;
}

/**
 * Request identity cause-effect table:
 * I1 strict mode + user bearer + Workspace -> E1 user token overrides the service
 * token and every upstream `/v1` call is Workspace-path scoped.
 * I2 strict mode + missing bearer -> E2 reject before any upstream request.
 * I3 strict mode + missing Workspace -> E3 reject; account JWTs are never treated
 * as implicitly single-tenant.
 * I4 local mode + no request identity -> E4 use the configured server credential
 * and flat upstream path.
 * I5 caller selects a Workspace without identity -> E5 reject rather than spend
 * a potentially broader service credential on the caller's scope choice.
 * Rules R1=I1; R2=I2; R3=I3; R4=I4; R5=I5. Awaken's IAM PEP still makes the final
 * authorization decision; Pilot has no membership or grant evaluator.
 */
describe("request-scoped Managed gateway decision table", () => {
  it("R1 forwards the user identity through the trusted Workspace route", async () => {
    const fetcher = vi.fn(async (_input: RequestInfo | URL, _init?: RequestInit) => new Response(JSON.stringify({ data: [], has_more: false }), {
      headers: { "content-type": "application/json" },
    }));
    const gateway = createManagedGatewayProvider(config, fetcher as unknown as typeof fetch)(request({
      authorization: "Bearer user-token",
      "x-pilot-workspace-id": "workspace_team",
    }));
    await gateway.listProjects();
    await gateway.listWebhooks();
    const upstream = fetcher.mock.calls.map((call) => {
      const input = call[0] as RequestInfo | URL;
      return input instanceof globalThis.Request ? input : new globalThis.Request(input, call[1] as RequestInit | undefined);
    });
    expect(upstream.map((item) => item.url)).toEqual([
      expect.stringMatching(/^https:\/\/awaken\.example\.test\/v1\/workspaces\/workspace_team\/deployments/),
      "https://awaken.example.test/v1/workspaces/workspace_team/config/webhook-subscriptions",
    ]);
    expect(upstream.every((item) => item.headers.get("authorization") === "Bearer user-token")).toBe(true);
  });

  it("R2/R3 fails closed before reaching Awaken when identity context is incomplete", () => {
    const fetcher = vi.fn();
    const provider = createManagedGatewayProvider(config, fetcher as unknown as typeof fetch);
    expect(() => provider(request({ "x-pilot-workspace-id": "workspace_team" }))).toThrow("Authentication required");
    expect(() => provider(request({ authorization: "Bearer user-token" }))).toThrow("Workspace required");
    expect(fetcher).not.toHaveBeenCalled();
  });

  it("R4 preserves the explicit local single-tenant mode", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ data: [], has_more: false }), {
      headers: { "content-type": "application/json" },
    }));
    const provider = createManagedGatewayProvider({ ...config, requireRequestIdentity: false }, fetcher as unknown as typeof fetch);
    await provider(request()).listWebhooks();
    const [input, init] = fetcher.mock.calls[0] as unknown as [RequestInfo | URL, RequestInit | undefined];
    const upstream = input instanceof globalThis.Request ? input : new globalThis.Request(input, init);
    expect(upstream.url).toBe("https://awaken.example.test/v1/config/webhook-subscriptions");
    expect(upstream.headers.get("authorization")).toBe("Bearer server-token");
  });

  it("R5 never lets an anonymous caller steer the server credential", () => {
    const provider = createManagedGatewayProvider({ ...config, requireRequestIdentity: false }, vi.fn() as unknown as typeof fetch);
    expect(() => provider(request({ "x-pilot-workspace-id": "workspace_other" }))).toThrow("Authentication required for the selected Workspace");
  });
});
