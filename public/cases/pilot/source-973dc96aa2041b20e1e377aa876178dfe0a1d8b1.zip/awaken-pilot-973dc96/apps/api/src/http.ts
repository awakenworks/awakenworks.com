import express, { type NextFunction, type Request, type Response } from "express";
import {
  parseApprovalDecision,
  parseAgentProfileCommand,
  parseCreateMissionRequest,
  parseMessageRequest,
  parseMemoryStoreCommand,
  parseProjectCommand,
  parsePublicMissionLinkRequest,
  parseWebhookCommand,
  parseUpdateAgentProfileCommand,
  parseVaultCommand,
  parseVaultCredentialCommand,
  RequestValidationError,
} from "@awaken/pilot-contracts";
import type { ManagedPilotGatewayProvider } from "./request-gateway.js";
import type { PilotPublicLinkService } from "./public-links.js";
import type { PilotApiConfig } from "./config.js";
import { resolveManagedRequestContext } from "./request-gateway.js";

function routeId(request: Request, name = "id"): string {
  const value = request.params[name];
  if (typeof value !== "string" || value.length === 0) throw new HttpError(400, `Missing ${name}`);
  return value;
}

class HttpError extends Error {
  constructor(readonly status: number, message: string) {
    super(message);
  }
}

function upstreamStatus(error: unknown): number {
  if (typeof error !== "object" || error === null || !("status" in error)) return 502;
  const status = Number(error.status);
  return Number.isInteger(status) && status >= 400 && status <= 599 ? status : 502;
}

function contentDisposition(filename: string): string {
  const fallback = filename.replace(/[^\x20-\x7e]/g, "_").replace(/["\\]/g, "_") || "artifact";
  return `attachment; filename="${fallback}"; filename*=UTF-8''${encodeURIComponent(filename)}`;
}

export function createPilotApi(
  gatewayFor: ManagedPilotGatewayProvider,
  publicLinks?: PilotPublicLinkService,
  config?: PilotApiConfig,
): express.Express {
  const app = express();
  app.disable("x-powered-by");
  app.use(express.json({ limit: "1mb" }));

  app.get("/healthz", (_request, response) => response.json({ status: "ok" }));

  app.get("/api/catalog/agents", async (request, response) => {
    response.json(await gatewayFor(request).listAgents());
  });

  app.post("/api/agents", async (request, response) => {
    response.status(201).json(await gatewayFor(request).createAgentProfile(parseAgentProfileCommand(request.body)));
  });

  app.put("/api/agents/:id", async (request, response) => {
    response.json(await gatewayFor(request).updateAgentProfile(routeId(request), parseUpdateAgentProfileCommand(request.body)));
  });

  app.get("/api/catalog/environments", async (request, response) => {
    response.json(await gatewayFor(request).listEnvironments());
  });

  app.get("/api/catalog/files", async (request, response) => {
    response.json(await gatewayFor(request).listKnowledgeFiles());
  });

  app.post("/api/files", express.raw({ type: () => true, limit: "100mb" }), async (request, response) => {
    const encodedFilename = request.header("x-pilot-filename");
    if (!encodedFilename) throw new HttpError(400, "Missing file name");
    let filename: string;
    try {
      filename = decodeURIComponent(encodedFilename).trim();
    } catch {
      throw new HttpError(400, "Invalid file name");
    }
    if (!filename || filename.length > 500 || !Buffer.isBuffer(request.body) || request.body.length === 0) {
      throw new HttpError(400, "Invalid file upload");
    }
    response.status(201).json(await gatewayFor(request).uploadKnowledgeFile(
      filename,
      request.header("x-pilot-mime-type")?.slice(0, 200) || "application/octet-stream",
      request.body,
    ));
  });

  app.get("/api/catalog/memory-stores", async (request, response) => {
    response.json(await gatewayFor(request).listMemoryStores());
  });

  app.get("/api/catalog/vaults", async (request, response) => {
    response.json(await gatewayFor(request).listVaults());
  });

  app.post("/api/vaults", async (request, response) => {
    response.status(201).json(await gatewayFor(request).createVault(parseVaultCommand(request.body)));
  });

  app.get("/api/vaults/:vaultId/credentials", async (request, response) => {
    response.json(await gatewayFor(request).listVaultCredentials(routeId(request, "vaultId")));
  });

  app.post("/api/vaults/:vaultId/credentials", async (request, response) => {
    response.status(201).json(await gatewayFor(request).createVaultCredential(
      routeId(request, "vaultId"),
      parseVaultCredentialCommand(request.body),
    ));
  });

  app.post("/api/vaults/:vaultId/credentials/:credentialId/validate", async (request, response) => {
    response.json(await gatewayFor(request).validateVaultCredential(
      routeId(request, "vaultId"),
      routeId(request, "credentialId"),
    ));
  });

  app.post("/api/memory-stores", async (request, response) => {
    response.status(201).json(await gatewayFor(request).createMemoryStore(parseMemoryStoreCommand(request.body)));
  });

  app.get("/api/webhooks", async (request, response) => {
    response.json(await gatewayFor(request).listWebhooks());
  });

  app.put("/api/webhooks/:id", async (request, response) => {
    const webhook = await gatewayFor(request).putWebhook(routeId(request), parseWebhookCommand(request.body));
    response.status(webhook.secret ? 201 : 200).json(webhook);
  });

  app.delete("/api/webhooks/:id", async (request, response) => {
    await gatewayFor(request).deleteWebhook(routeId(request));
    response.status(204).end();
  });

  app.get("/api/projects", async (request, response) => {
    response.json(await gatewayFor(request).listProjects());
  });

  app.post("/api/projects", async (request, response) => {
    response.status(201).json(await gatewayFor(request).createProject(parseProjectCommand(request.body)));
  });

  app.get("/api/projects/:id", async (request, response) => {
    response.json(await gatewayFor(request).getProject(routeId(request)));
  });

  app.put("/api/projects/:id", async (request, response) => {
    response.json(await gatewayFor(request).updateProject(routeId(request), parseProjectCommand(request.body)));
  });

  app.post("/api/projects/:id/archive", async (request, response) => {
    await gatewayFor(request).archiveProject(routeId(request));
    response.status(204).end();
  });

  app.post("/api/projects/:id/pause", async (request, response) => {
    response.json(await gatewayFor(request).pauseProject(routeId(request)));
  });

  app.post("/api/projects/:id/unpause", async (request, response) => {
    response.json(await gatewayFor(request).unpauseProject(routeId(request)));
  });

  app.post("/api/projects/:id/run", async (request, response) => {
    response.status(201).json(await gatewayFor(request).runProject(routeId(request)));
  });

  app.get("/api/projects/:id/runs", async (request, response) => {
    response.json(await gatewayFor(request).listProjectRuns(routeId(request)));
  });

  app.get("/api/missions", async (request, response) => {
    response.json(await gatewayFor(request).listMissions());
  });

  app.post("/api/missions", async (request, response) => {
    const mission = await gatewayFor(request).createMission(parseCreateMissionRequest(request.body));
    response.status(201).json(mission);
  });

  app.post("/api/missions/:id/public-link", async (request, response) => {
    if (!publicLinks || !config) throw new HttpError(503, "Public links are not configured");
    const link = await publicLinks.create(
      gatewayFor(request),
      resolveManagedRequestContext(config, request),
      routeId(request),
      parsePublicMissionLinkRequest(request.body),
    );
    response.set("Cache-Control", "no-store");
    response.status(201).json(link);
  });

  app.delete("/api/missions/:id/public-link", async (request, response) => {
    if (!publicLinks || !config) throw new HttpError(503, "Public links are not configured");
    await publicLinks.revoke(
      gatewayFor(request),
      resolveManagedRequestContext(config, request),
      routeId(request),
    );
    response.status(204).end();
  });

  app.get("/api/public/workspaces/:workspaceId/missions/:id", async (request, response) => {
    if (!publicLinks) throw new HttpError(503, "Public links are not configured");
    response.set({ "Cache-Control": "private, no-store", "Referrer-Policy": "no-referrer" });
    response.json(await publicLinks.snapshot(
      request.header("x-pilot-public-token")?.trim() ?? "",
      routeId(request, "workspaceId"),
      routeId(request),
    ));
  });

  app.get("/api/public/workspaces/:workspaceId/missions/:id/artifacts/:fileId/content", async (request, response) => {
    if (!publicLinks) throw new HttpError(503, "Public links are not configured");
    const artifact = await publicLinks.artifact(
      request.header("x-pilot-public-token")?.trim() ?? "",
      routeId(request, "workspaceId"),
      routeId(request),
      routeId(request, "fileId"),
    );
    if (!artifact) throw new HttpError(404, "Artifact not found");
    response.set({
      "Cache-Control": "private, no-store",
      "Content-Disposition": contentDisposition(artifact.filename),
      "Content-Type": artifact.contentType ?? "application/octet-stream",
      "Referrer-Policy": "no-referrer",
    });
    response.send(Buffer.from(artifact.data));
  });

  app.get("/api/missions/:id", async (request, response) => {
    response.json(await gatewayFor(request).getMission(routeId(request)));
  });

  app.get("/api/missions/:id/events", async (request, response) => {
    response.json(await gatewayFor(request).listEvents(routeId(request)));
  });

  app.get("/api/missions/:id/events/stream", async (request, response) => {
    const controller = new AbortController();
    response.status(200);
    response.set({
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "Content-Type": "text/event-stream; charset=utf-8",
    });
    response.flushHeaders();
    response.write(": connected\n\n");

    const heartbeat = setInterval(() => response.write(": heartbeat\n\n"), 15_000);
    const close = () => controller.abort();
    response.once("close", close);
    try {
      await gatewayFor(request).followEvents(
        routeId(request),
        (event) => response.write(`data: ${JSON.stringify(event)}\n\n`),
        controller.signal,
      );
    } catch {
      // The committed-event query remains the recovery path when an upstream
      // stream closes. Never serialize upstream details into an established SSE.
    } finally {
      clearInterval(heartbeat);
      response.off("close", close);
      if (!response.writableEnded) response.end();
    }
  });

  app.post("/api/missions/:id/messages", async (request, response) => {
    const { text } = parseMessageRequest(request.body);
    await gatewayFor(request).sendMessage(routeId(request), text);
    response.status(204).end();
  });

  app.post("/api/missions/:id/interrupt", async (request, response) => {
    await gatewayFor(request).interrupt(routeId(request));
    response.status(204).end();
  });

  app.post("/api/missions/:id/decisions", async (request, response) => {
    await gatewayFor(request).decide(routeId(request), parseApprovalDecision(request.body));
    response.status(204).end();
  });

  app.get("/api/missions/:id/threads", async (request, response) => {
    response.json(await gatewayFor(request).listThreads(routeId(request)));
  });

  app.get("/api/missions/:id/threads/:threadId/events", async (request, response) => {
    response.json(await gatewayFor(request).listThreadEvents(
      routeId(request),
      routeId(request, "threadId"),
    ));
  });

  app.get("/api/missions/:id/artifacts", async (request, response) => {
    response.json(await gatewayFor(request).listArtifacts(routeId(request)));
  });

  app.get("/api/missions/:id/artifacts/:fileId/content", async (request, response) => {
    const artifact = await gatewayFor(request).downloadArtifact(routeId(request), routeId(request, "fileId"));
    if (!artifact) throw new HttpError(404, "Artifact not found");
    response.set({
      "Content-Disposition": contentDisposition(artifact.filename),
      "Content-Type": artifact.contentType ?? "application/octet-stream",
    });
    response.send(Buffer.from(artifact.data));
  });

  app.post("/api/missions/:id/archive", async (request, response) => {
    await gatewayFor(request).archive(routeId(request));
    response.status(204).end();
  });

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    if (error instanceof RequestValidationError) {
      response.status(400).json({ error: "Invalid request", issues: error.issues });
      return;
    }
    if (error instanceof HttpError) {
      response.status(error.status).json({ error: error.message });
      return;
    }
    response.status(upstreamStatus(error)).json({ error: "Awaken request failed" });
  });

  return app;
}
