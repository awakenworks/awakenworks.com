import { describe, expect, it, vi } from "vitest";
import type { PilotApiConfig } from "./config.js";
import type { ManagedPilotGateway } from "./managed-gateway.js";
import { PilotPublicLinkService } from "./public-links.js";

const config: PilotApiConfig = {
  host: "127.0.0.1",
  port: 4174,
  awakenApiUrl: "https://awaken.example.test",
  awakenAuthToken: "server-awaken",
  iamApiUrl: "https://iam.example.test",
  iamAdminToken: "iam-admin",
  applicationMcpUrl: "",
  requireRequestIdentity: true,
  defaultWorkspaceId: "",
};

const mission = {
  id: "sesn_1",
  metadata: { application: "awaken-pilot", pilot_project_id: "deploy_1" },
};

function gateway(): ManagedPilotGateway {
  return { getMission: vi.fn(async () => mission) } as unknown as ManagedPilotGateway;
}

function json(value: unknown, status = 200): Response {
  return new Response(JSON.stringify(value), { status, headers: { "Content-Type": "application/json" } });
}

function requestUrl(input: RequestInfo | URL): string {
  return input instanceof Request ? input.url : String(input);
}

/**
 * Public-link authority cause/effect table:
 * C1=authenticated Workspace writer, C2=Pilot-owned source Mission,
 * C3=existing deterministic share Grant, C4=valid capability but Grant denied,
 * C5=valid link targets a non-Pilot Session.
 * E1=mint capability then upsert one exact-resource Grant; E2=rotation replaces
 * the same Grant id with a fresh subject; E3=reject before Awaken projection;
 * E4=reject before artifact enumeration/download.
 * Rules R1=C1+C2+!C3 -> E1; R2=C1+C2+C3 -> E2; R3=C4 -> E3; R4=C5 -> E4.
 * The test asserts no Pilot token/share store participates in any rule.
 */
describe("IAM-backed public Mission links", () => {
  it("R1/R2 rotates through one deterministic IAM Grant", async () => {
    const requests: Array<{ url: string; body?: unknown; authorization: string | null }> = [];
    let issued = 0;
    const fetcher = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = requestUrl(input);
      requests.push({
        url,
        body: typeof init?.body === "string" ? JSON.parse(init.body) : undefined,
        authorization: new Headers(init?.headers).get("authorization"),
      });
      if (url.endsWith("/v1/tokens/introspect")) return json({ principal: { kind: "account", account_id: "ada" }, workspace: "ws_1" });
      if (url.endsWith("/v1/authorize")) return json({ decision: "allow" });
      if (url.endsWith("/v1/admin/capabilities")) return json({ token: `cap-${++issued}` }, 201);
      if (url.endsWith("/v1/admin/grants")) return json({ version: issued });
      throw new Error(`unexpected request ${url}`);
    });
    const service = new PilotPublicLinkService(config, fetcher as typeof fetch);
    const context = { credential: "member-token", workspaceId: "ws_1" };
    const first = await service.create(gateway(), context, "sesn_1", { expiresInDays: 7 });
    const second = await service.create(gateway(), context, "sesn_1", { expiresInDays: 7 });

    expect([first.token, second.token]).toEqual(["cap-1", "cap-2"]);
    const grants = requests.filter((request) => request.url.endsWith("/v1/admin/grants"));
    expect(grants).toHaveLength(2);
    expect((grants[0]?.body as { id: string }).id).toBe((grants[1]?.body as { id: string }).id);
    expect((grants[0]?.body as { subject: unknown }).subject).not.toEqual((grants[1]?.body as { subject: unknown }).subject);
    expect((grants[0]?.body as { action_pattern: string }).action_pattern).toBe("pilot.mission.read");
    expect((grants[0]?.body as { scope: unknown }).scope).toEqual({
      kind: "resource",
      resource_type: "pilot_mission",
      resource_id: JSON.stringify(["ws_1", "sesn_1"]),
    });
    expect(grants.every((request) => request.authorization === "Bearer iam-admin")).toBe(true);
    const capabilities = requests.filter((request) => request.url.endsWith("/v1/admin/capabilities"));
    const claims = capabilities[0]?.body as { audience: string; scopes: string[]; issued_at: number; expires_at: number };
    expect(claims.audience).toBe("awaken-pilot-public");
    expect(claims.scopes).toEqual(["pilot.mission.read"]);
    expect(claims.expires_at - claims.issued_at).toBe(7 * 86_400);
  });

  it("R3 refuses a cryptographically valid but revoked capability before Awaken", async () => {
    const fetcher = vi.fn(async (input: RequestInfo | URL) => {
      const url = requestUrl(input);
      if (url.endsWith("/v1/capabilities/introspect")) return json({ sub: "public-1", aud: "awaken-pilot-public", exp: 9_999_999_999, scope: ["pilot.mission.read"] });
      if (url.endsWith("/v1/authorize")) return json({ decision: "deny" });
      throw new Error(`Awaken must not be called after IAM denial: ${url}`);
    });
    const service = new PilotPublicLinkService(config, fetcher as typeof fetch);
    await expect(service.snapshot("capability", "ws_1", "sesn_1")).rejects.toMatchObject({ status: 403 });
    expect(fetcher).toHaveBeenCalledTimes(2);
  });

  it("R4 refuses artifacts when the exact resource is not a Pilot Mission", async () => {
    const fetcher = vi.fn(async (input: RequestInfo | URL) => {
      const url = requestUrl(input);
      if (url.endsWith("/v1/capabilities/introspect")) return json({ sub: "public-1", aud: "awaken-pilot-public", exp: 9_999_999_999, scope: ["pilot.mission.read"] });
      if (url.endsWith("/v1/authorize")) return json({ decision: "allow" });
      if (url.includes("/v1/workspaces/ws_1/sessions/sesn_1")) return json({ id: "sesn_1", type: "session", metadata: {} });
      throw new Error(`artifact enumeration must not be called: ${url}`);
    });
    const service = new PilotPublicLinkService(config, fetcher as typeof fetch);
    await expect(service.artifact("capability", "ws_1", "sesn_1", "file_1")).rejects.toMatchObject({ status: 404 });
    expect(fetcher).toHaveBeenCalledTimes(3);
  });
});
