import Anthropic from "@anthropic-ai/sdk";
import type { AgentCreateParams, BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaManagedAgentsDeploymentRun } from "@anthropic-ai/sdk/resources/beta/deployment-runs";
import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import type { BetaEnvironment } from "@anthropic-ai/sdk/resources/beta/environments/environments";
import type { FileMetadata } from "@anthropic-ai/sdk/resources/beta/files";
import type { BetaManagedAgentsMemoryStore } from "@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores";
import type { BetaManagedAgentsVault } from "@anthropic-ai/sdk/resources/beta/vaults/vaults";
import type {
  BetaManagedAgentsCredential,
  BetaManagedAgentsCredentialValidation,
  CredentialCreateParams,
} from "@anthropic-ai/sdk/resources/beta/vaults/credentials";
import type { BetaManagedAgentsSessionEvent } from "@anthropic-ai/sdk/resources/beta/sessions/events";
import type {
  BetaManagedAgentsAgentWithOverridesParams,
  BetaManagedAgentsSession,
  SessionCreateParams,
} from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import type { BetaManagedAgentsSessionThread } from "@anthropic-ai/sdk/resources/beta/sessions/threads/threads";
import type {
  ApprovalDecision,
  AgentProfileCommand,
  CreateMissionRequest,
  MemoryStoreCommand,
  ProjectCommand,
  UpdateAgentProfileCommand,
  VaultCommand,
  VaultCredentialCommand,
  WebhookCommand,
  WebhookSubscription,
} from "@awaken/pilot-contracts";

export const MANAGED_BETAS = ["managed-agents-2026-04-01"] as const;
const PILOT_APPLICATION = "awaken-pilot";
const PILOT_PROJECT_KIND = "project";
const PILOT_AGENT_KIND = "agent_profile";

export interface ArtifactDownload {
  contentType?: string;
  data: Uint8Array;
  filename: string;
}

export interface ManagedPilotGateway {
  listProjects(): Promise<unknown[]>;
  getProject(id: string): Promise<unknown>;
  createProject(input: ProjectCommand): Promise<unknown>;
  updateProject(id: string, input: ProjectCommand): Promise<unknown>;
  archiveProject(id: string): Promise<void>;
  pauseProject(id: string): Promise<unknown>;
  unpauseProject(id: string): Promise<unknown>;
  runProject(id: string): Promise<unknown>;
  listProjectRuns(id: string): Promise<unknown[]>;
  listAgents(): Promise<unknown[]>;
  createAgentProfile(input: AgentProfileCommand): Promise<unknown>;
  updateAgentProfile(id: string, input: UpdateAgentProfileCommand): Promise<unknown>;
  listEnvironments(): Promise<unknown[]>;
  listKnowledgeFiles(): Promise<unknown[]>;
  uploadKnowledgeFile(filename: string, mimeType: string, data: Uint8Array): Promise<unknown>;
  listMemoryStores(): Promise<unknown[]>;
  createMemoryStore(input: MemoryStoreCommand): Promise<unknown>;
  listVaults(): Promise<unknown[]>;
  createVault(input: VaultCommand): Promise<unknown>;
  listVaultCredentials(vaultId: string): Promise<unknown[]>;
  createVaultCredential(vaultId: string, input: VaultCredentialCommand): Promise<unknown>;
  validateVaultCredential(vaultId: string, credentialId: string): Promise<unknown>;
  listWebhooks(): Promise<WebhookSubscription[]>;
  putWebhook(id: string, input: WebhookCommand): Promise<WebhookSubscription>;
  deleteWebhook(id: string): Promise<void>;
  listMissions(): Promise<unknown[]>;
  createMission(input: CreateMissionRequest): Promise<unknown>;
  getMission(id: string): Promise<unknown>;
  listEvents(id: string): Promise<unknown[]>;
  followEvents(id: string, receive: (event: unknown) => void, signal: AbortSignal): Promise<void>;
  sendMessage(id: string, text: string): Promise<void>;
  interrupt(id: string): Promise<void>;
  decide(id: string, decision: ApprovalDecision): Promise<void>;
  listThreads(id: string): Promise<unknown[]>;
  listThreadEvents(id: string, threadId: string): Promise<unknown[]>;
  listArtifacts(id: string): Promise<unknown[]>;
  downloadArtifact(id: string, fileId: string): Promise<ArtifactDownload | undefined>;
  archive(id: string): Promise<void>;
}

function missionPrompt(goal: string, hasPilotMcp: boolean, mode: "execute" | "plan" = "execute"): string {
  const planGuidance = hasPilotMcp
    ? "Use the pilot set_plan tool to publish a complete plan whenever it materially changes, notify_user for material progress or risk, and publish_result when the work is complete."
    : "Keep the user informed through concise messages as the work progresses.";
  return [
    mode === "plan"
      ? "Plan this mission before acting. Produce a complete, decision-ready plan, then stop and wait for the user to approve or revise it. Do not perform mutating or externally visible actions before approval."
      : "Execute this mission autonomously and continue until it is complete or genuinely requires a user decision.",
    planGuidance,
    "Use available agents and tools when they improve the result. Write deliverables under the runtime-owned AWAKEN_OUTPUTS_DIR (for example, $AWAKEN_OUTPUTS_DIR/report.md) so they become Session artifacts; publish their logical paths as outputs/report.md.",
    "Mission goal:",
    goal.trim(),
  ].join("\n\n");
}

function missionInitialEvent(input: CreateMissionRequest, hasPilotMcp: boolean) {
  const description = missionPrompt(input.goal, hasPilotMcp, input.mode);
  if (input.mode === "execute" && input.acceptanceCriteria) {
    return {
      type: "user.define_outcome" as const,
      description,
      rubric: { type: "text" as const, content: input.acceptanceCriteria },
      max_iterations: input.maxIterations,
    };
  }
  return {
    type: "user.message" as const,
    content: [{ type: "text" as const, text: description }],
  };
}

export function withPilotMcp(agent: BetaManagedAgentsAgent, url: string): BetaManagedAgentsAgentWithOverridesParams {
  return {
    id: agent.id,
    type: "agent_with_overrides",
    version: agent.version,
    mcp_servers: [
      ...agent.mcp_servers.filter((server) => server.name !== "pilot"),
      { name: "pilot", type: "url", url },
    ],
    tools: [
      ...agent.tools.filter((tool) => !(tool.type === "mcp_toolset" && tool.mcp_server_name === "pilot")),
      {
        type: "mcp_toolset",
        mcp_server_name: "pilot",
        default_config: { enabled: true, permission_policy: { type: "always_allow" } },
      },
    ],
  };
}

function projectInstruction(project: BetaManagedAgentsDeployment): string {
  return project.initial_events.flatMap((event) => event.type === "system.message"
    ? event.content.map((block) => block.text)
    : []).join("\n").trim();
}

function projectAgent(
  agent: BetaManagedAgentsAgent,
  instruction: string,
  applicationMcpUrl: string,
): BetaManagedAgentsAgentWithOverridesParams {
  const override = applicationMcpUrl
    ? withPilotMcp(agent, applicationMcpUrl)
    : { id: agent.id, type: "agent_with_overrides" as const, version: agent.version };
  const system = [agent.system?.trim(), instruction ? `Project instructions:\n${instruction}` : ""]
    .filter(Boolean).join("\n\n");
  return { ...override, system: system || null };
}

function commandResources(input: ProjectCommand) {
  return [
    ...input.fileIds.map((fileId) => ({ type: "file" as const, file_id: fileId })),
    ...input.memoryStoreIds.map((memoryStoreId) => ({
      type: "memory_store" as const,
      memory_store_id: memoryStoreId,
      access: "read_write" as const,
    })),
  ];
}

function sessionResources(project: BetaManagedAgentsDeployment) {
  return project.resources.map((resource) => {
    if (resource.type === "file") {
      return { type: "file" as const, file_id: resource.file_id, ...(resource.mount_path ? { mount_path: resource.mount_path } : {}) };
    }
    if (resource.type === "memory_store") {
      return {
        type: "memory_store" as const,
        memory_store_id: resource.memory_store_id,
        ...(resource.access ? { access: resource.access } : {}),
        ...(resource.instructions ? { instructions: resource.instructions } : {}),
      };
    }
    throw new Error("Project contains a repository resource that cannot be replayed without its write-only credential");
  });
}

function projectEvents(input: ProjectCommand) {
  return [
    { type: "system.message" as const, content: [{ type: "text" as const, text: input.instruction }] },
    ...(input.schedule ? [{
      type: "user.message" as const,
      content: [{ type: "text" as const, text: missionPrompt(input.schedule.prompt, false) }],
    }] : []),
  ];
}

function projectBudget(input: ProjectCommand) {
  return input.budgetUsdCents === null
    ? null
    : { type: "limit" as const, max_list_cost: { amount: String(input.budgetUsdCents), currency: "USD" as const } };
}

function assertPilotProject(project: BetaManagedAgentsDeployment): BetaManagedAgentsDeployment {
  if (project.metadata.application !== PILOT_APPLICATION || project.metadata.pilot_kind !== PILOT_PROJECT_KIND) {
    throw Object.assign(new Error("Project not found"), { status: 404 });
  }
  return project;
}

function assertPilotAgentProfile(agent: BetaManagedAgentsAgent): BetaManagedAgentsAgent {
  if (agent.metadata.application !== PILOT_APPLICATION || agent.metadata.pilot_kind !== PILOT_AGENT_KIND) {
    throw Object.assign(new Error("Agent profile not found"), { status: 404 });
  }
  return agent;
}

function agentProfileFields(input: AgentProfileCommand): Pick<AgentCreateParams,
  "name" | "description" | "model" | "system" | "mcp_servers" | "tools" | "skills" | "multiagent"> {
  const tools: NonNullable<AgentCreateParams["tools"]> = [];
  if (input.tools.length) {
    tools.push({
      type: "agent_toolset_20260401",
      default_config: { enabled: false, permission_policy: { type: "always_ask" } },
      configs: input.tools.map((tool) => ({
        name: tool.name,
        enabled: true,
        permission_policy: { type: tool.permission },
      })),
    });
  }
  tools.push(...input.connectors.map((connector) => ({
    type: "mcp_toolset" as const,
    mcp_server_name: connector.name,
    default_config: { enabled: true, permission_policy: { type: connector.permission } },
  })));
  const roster = [
    ...(input.includeSelf ? [{ type: "self" as const }] : []),
    ...input.subagentIds,
  ];
  return {
    name: input.name,
    description: input.description || null,
    model: input.model,
    system: input.system || null,
    mcp_servers: input.connectors.map((connector) => ({ type: "url", name: connector.name, url: connector.url })),
    tools,
    skills: input.skills.map((skill) => ({
      type: skill.type,
      skill_id: skill.skillId,
      version: skill.version,
    })),
    multiagent: roster.length ? { type: "coordinator", agents: roster } : null,
  };
}

function credentialAuth(input: VaultCredentialCommand["auth"]): CredentialCreateParams["auth"] {
  if (input.type === "static_bearer") {
    return { type: input.type, mcp_server_url: input.mcpServerUrl, token: input.token };
  }
  if (input.type === "mcp_oauth") {
    const refresh = input.refresh ? {
      client_id: input.refresh.clientId,
      refresh_token: input.refresh.refreshToken,
      token_endpoint: input.refresh.tokenEndpoint,
      token_endpoint_auth: input.refresh.tokenEndpointAuth.type === "none"
        ? { type: "none" as const }
        : {
          type: input.refresh.tokenEndpointAuth.type,
          client_secret: input.refresh.tokenEndpointAuth.clientSecret,
        },
      scope: input.refresh.scope,
      resource: input.refresh.resource,
    } : null;
    return {
      type: input.type,
      mcp_server_url: input.mcpServerUrl,
      access_token: input.accessToken,
      expires_at: input.expiresAt,
      refresh,
    };
  }
  return {
    type: input.type,
    secret_name: input.secretName,
    secret_value: input.secretValue,
    networking: input.unrestricted
      ? { type: "unrestricted" }
      : { type: "limited", allowed_hosts: input.allowedHosts },
    injection_location: { header: input.injectHeader, body: input.injectBody },
  };
}

export function createAnthropicClient(apiBaseUrl: string, authToken: string, fetcher: typeof fetch = fetch): Anthropic {
  return new Anthropic({
    baseURL: apiBaseUrl.replace(/\/$/, ""),
    apiKey: authToken ? null : "awaken-local",
    authToken: authToken || null,
    fetch: fetcher,
  });
}

export function withAwakenWorkspace(fetcher: typeof fetch, workspaceId: string): typeof fetch {
  if (!workspaceId) return fetcher;
  return (async (input: RequestInfo | URL, init?: RequestInit) => {
    const request = input instanceof Request ? input : new Request(input, init);
    const url = new URL(request.url);
    if (url.pathname.startsWith("/v1/") && !url.pathname.startsWith("/v1/workspaces/")) {
      url.pathname = `/v1/workspaces/${encodeURIComponent(workspaceId)}/${url.pathname.slice(4)}`;
      return fetcher(new Request(url, request));
    }
    return fetcher(request);
  }) as typeof fetch;
}

async function collect<T>(iterable: AsyncIterable<T>, maximum = 500): Promise<T[]> {
  const items: T[] = [];
  for await (const item of iterable) {
    items.push(item);
    if (items.length >= maximum) break;
  }
  return items;
}

export class AnthropicManagedPilotGateway implements ManagedPilotGateway {
  readonly #client: Anthropic;
  readonly #applicationMcpUrl: string;
  readonly #apiBaseUrl: string;
  readonly #authToken: string;
  readonly #fetcher: typeof fetch;

  constructor(apiBaseUrl: string, authToken: string, applicationMcpUrl = "", fetcher: typeof fetch = fetch, workspaceId = "") {
    const scopedFetcher = withAwakenWorkspace(fetcher, workspaceId);
    this.#client = createAnthropicClient(apiBaseUrl, authToken, scopedFetcher);
    this.#applicationMcpUrl = applicationMcpUrl;
    this.#apiBaseUrl = apiBaseUrl.replace(/\/$/, "");
    this.#authToken = authToken;
    this.#fetcher = scopedFetcher;
  }

  async #configRequest(path: string, init: RequestInit = {}): Promise<Response> {
    const headers = new Headers(init.headers);
    headers.set("Accept", "application/json");
    if (init.body) headers.set("Content-Type", "application/json");
    if (this.#authToken) headers.set("Authorization", `Bearer ${this.#authToken}`);
    else headers.set("X-Api-Key", "awaken-local");
    const response = await this.#fetcher(`${this.#apiBaseUrl}${path}`, { ...init, headers });
    if (!response.ok) {
      throw Object.assign(new Error("Awaken config request failed"), { status: response.status });
    }
    return response;
  }

  listProjects(): Promise<BetaManagedAgentsDeployment[]> {
    return collect(this.#client.beta.deployments.list({ betas: [...MANAGED_BETAS], limit: 100 }))
      .then((projects) => projects.filter((project) =>
        project.metadata.application === PILOT_APPLICATION && project.metadata.pilot_kind === PILOT_PROJECT_KIND));
  }

  async getProject(id: string): Promise<BetaManagedAgentsDeployment> {
    return assertPilotProject(await this.#client.beta.deployments.retrieve(id, { betas: [...MANAGED_BETAS] }));
  }

  createProject(input: ProjectCommand): Promise<BetaManagedAgentsDeployment> {
    return this.#client.beta.deployments.create({
      name: input.name,
      agent: input.agentId,
      environment_id: input.environmentId,
      initial_events: projectEvents(input),
      metadata: { application: PILOT_APPLICATION, pilot_kind: PILOT_PROJECT_KIND },
      resources: commandResources(input),
      vault_ids: input.vaultIds,
      budget: projectBudget(input),
      schedule: input.schedule ? {
        type: "cron",
        expression: input.schedule.expression,
        timezone: input.schedule.timezone,
      } : null,
      betas: [...MANAGED_BETAS],
    });
  }

  async updateProject(id: string, input: ProjectCommand): Promise<BetaManagedAgentsDeployment> {
    await this.getProject(id);
    return this.#client.beta.deployments.update(id, {
      name: input.name,
      description: null,
      agent: input.agentId,
      environment_id: input.environmentId,
      initial_events: projectEvents(input),
      metadata: { application: PILOT_APPLICATION, pilot_kind: PILOT_PROJECT_KIND },
      resources: commandResources(input),
      vault_ids: input.vaultIds,
      budget: projectBudget(input),
      schedule: input.schedule ? {
        type: "cron",
        expression: input.schedule.expression,
        timezone: input.schedule.timezone,
      } : null,
      betas: [...MANAGED_BETAS],
    });
  }

  async archiveProject(id: string): Promise<void> {
    await this.getProject(id);
    await this.#client.beta.deployments.archive(id, { betas: [...MANAGED_BETAS] });
  }

  async pauseProject(id: string): Promise<BetaManagedAgentsDeployment> {
    await this.getProject(id);
    return this.#client.beta.deployments.pause(id, { betas: [...MANAGED_BETAS] });
  }

  async unpauseProject(id: string): Promise<BetaManagedAgentsDeployment> {
    await this.getProject(id);
    return this.#client.beta.deployments.unpause(id, { betas: [...MANAGED_BETAS] });
  }

  async runProject(id: string): Promise<BetaManagedAgentsDeploymentRun> {
    await this.getProject(id);
    return this.#client.beta.deployments.run(id, { betas: [...MANAGED_BETAS] });
  }

  async listProjectRuns(id: string): Promise<BetaManagedAgentsDeploymentRun[]> {
    await this.getProject(id);
    return collect(this.#client.beta.deploymentRuns.list({
      deployment_id: id,
      betas: [...MANAGED_BETAS],
      limit: 100,
    }));
  }

  listAgents(): Promise<BetaManagedAgentsAgent[]> {
    return collect(this.#client.beta.agents.list({ betas: [...MANAGED_BETAS], limit: 100 }));
  }

  createAgentProfile(input: AgentProfileCommand): Promise<BetaManagedAgentsAgent> {
    return this.#client.beta.agents.create({
      ...agentProfileFields(input),
      metadata: { application: PILOT_APPLICATION, pilot_kind: PILOT_AGENT_KIND },
      betas: [...MANAGED_BETAS],
    });
  }

  async updateAgentProfile(id: string, input: UpdateAgentProfileCommand): Promise<BetaManagedAgentsAgent> {
    assertPilotAgentProfile(await this.#client.beta.agents.retrieve(id, { betas: [...MANAGED_BETAS] }));
    return this.#client.beta.agents.update(id, {
      ...agentProfileFields(input),
      version: input.version,
      betas: [...MANAGED_BETAS],
    });
  }

  listEnvironments(): Promise<BetaEnvironment[]> {
    return collect(this.#client.beta.environments.list({ betas: [...MANAGED_BETAS], limit: 100 }));
  }

  listKnowledgeFiles(): Promise<FileMetadata[]> {
    return collect(this.#client.beta.files.list({ betas: [...MANAGED_BETAS], limit: 100 }))
      .then((files) => files.filter((file) => !file.scope));
  }

  uploadKnowledgeFile(filename: string, mimeType: string, data: Uint8Array): Promise<FileMetadata> {
    // Express supplies a Node Buffer whose backing slab can be larger than the
    // request body. Uint8Array.from owns an exact-sized ArrayBuffer; passing a
    // Buffer's `.buffer` would upload unrelated bytes outside its active view.
    const exactBytes = Uint8Array.from(data);
    return this.#client.beta.files.upload({
      file: new File([exactBytes.buffer], filename, { type: mimeType }),
      betas: [...MANAGED_BETAS],
    });
  }

  listMemoryStores(): Promise<BetaManagedAgentsMemoryStore[]> {
    return collect(this.#client.beta.memoryStores.list({ betas: [...MANAGED_BETAS], limit: 100 }));
  }

  createMemoryStore(input: MemoryStoreCommand): Promise<BetaManagedAgentsMemoryStore> {
    return this.#client.beta.memoryStores.create({
      name: input.name,
      description: input.description,
      metadata: { application: PILOT_APPLICATION, pilot_kind: "project_memory" },
      betas: [...MANAGED_BETAS],
    });
  }

  listVaults(): Promise<BetaManagedAgentsVault[]> {
    return collect(this.#client.beta.vaults.list({ betas: [...MANAGED_BETAS], limit: 100 }))
      .then((vaults) => vaults.filter((vault) => !vault.archived_at));
  }

  createVault(input: VaultCommand): Promise<BetaManagedAgentsVault> {
    return this.#client.beta.vaults.create({
      display_name: input.displayName,
      metadata: { application: PILOT_APPLICATION, pilot_kind: "connector_credentials" },
      betas: [...MANAGED_BETAS],
    });
  }

  listVaultCredentials(vaultId: string): Promise<BetaManagedAgentsCredential[]> {
    return collect(this.#client.beta.vaults.credentials.list(vaultId, {
      betas: [...MANAGED_BETAS], limit: 100,
    })).then((credentials) => credentials.filter((credential) => !credential.archived_at));
  }

  createVaultCredential(vaultId: string, input: VaultCredentialCommand): Promise<BetaManagedAgentsCredential> {
    return this.#client.beta.vaults.credentials.create(vaultId, {
      display_name: input.displayName,
      auth: credentialAuth(input.auth),
      metadata: { application: PILOT_APPLICATION, pilot_kind: "connector_credential" },
      betas: [...MANAGED_BETAS],
    });
  }

  validateVaultCredential(vaultId: string, credentialId: string): Promise<BetaManagedAgentsCredentialValidation> {
    return this.#client.beta.vaults.credentials.mcpOAuthValidate(credentialId, {
      vault_id: vaultId,
      betas: [...MANAGED_BETAS],
    });
  }

  async listWebhooks(): Promise<WebhookSubscription[]> {
    const response = await this.#configRequest("/v1/config/webhook-subscriptions");
    const body = await response.json() as { data?: unknown };
    if (!Array.isArray(body.data)) throw new Error("Awaken returned an invalid webhook list");
    return body.data as WebhookSubscription[];
  }

  async putWebhook(id: string, input: WebhookCommand): Promise<WebhookSubscription> {
    const response = await this.#configRequest(`/v1/config/webhook-subscriptions/${encodeURIComponent(id)}`, {
      method: "PUT",
      body: JSON.stringify({ url: input.url, event_types: input.eventTypes, disabled: input.disabled }),
    });
    return response.json() as Promise<WebhookSubscription>;
  }

  async deleteWebhook(id: string): Promise<void> {
    await this.#configRequest(`/v1/config/webhook-subscriptions/${encodeURIComponent(id)}`, { method: "DELETE" });
  }

  listMissions(): Promise<BetaManagedAgentsSession[]> {
    return collect(this.#client.beta.sessions.list({ betas: [...MANAGED_BETAS], order: "desc", limit: 100 }))
      .then((missions) => missions.filter((mission) => mission.metadata.application === "awaken-pilot"));
  }

  async createMission(input: CreateMissionRequest): Promise<BetaManagedAgentsSession> {
    const project = await this.getProject(input.projectId);
    return this.#launchMission(project, input);
  }

  async #launchMission(
    project: BetaManagedAgentsDeployment,
    input: CreateMissionRequest,
  ): Promise<BetaManagedAgentsSession> {
    const agent = await this.#client.beta.agents.retrieve(project.agent.id, {
      version: project.agent.version,
      betas: [...MANAGED_BETAS],
    });
    const params: SessionCreateParams = {
      agent: projectAgent(agent, projectInstruction(project), this.#applicationMcpUrl),
      environment_id: project.environment_id,
      title: input.title.trim(),
      metadata: {
        application: PILOT_APPLICATION,
        pilot_project_id: project.id,
        pilot_mode: input.mode,
      },
      resources: sessionResources(project),
      vault_ids: project.vault_ids,
      ...(project.budget ? { budget: project.budget } : {}),
      initial_events: [missionInitialEvent(input, Boolean(this.#applicationMcpUrl))],
      betas: [...MANAGED_BETAS],
    };
    return this.#client.beta.sessions.create(params);
  }

  getMission(id: string): Promise<BetaManagedAgentsSession> {
    return this.#client.beta.sessions.retrieve(id, { betas: [...MANAGED_BETAS] });
  }

  listEvents(id: string): Promise<BetaManagedAgentsSessionEvent[]> {
    return collect(this.#client.beta.sessions.events.list(id, { betas: [...MANAGED_BETAS], order: "asc", limit: 100 }));
  }

  async followEvents(id: string, receive: (event: unknown) => void, signal: AbortSignal): Promise<void> {
    const stream = await this.#client.beta.sessions.events.stream(id, {
      betas: [...MANAGED_BETAS],
      event_deltas: ["agent.message", "agent.thinking"],
    }, { signal });
    for await (const event of stream) receive(event);
  }

  async sendMessage(id: string, text: string): Promise<void> {
    await this.#client.beta.sessions.events.send(id, {
      events: [{ type: "user.message", content: [{ type: "text", text: text.trim() }] }],
      betas: [...MANAGED_BETAS],
    });
  }

  async interrupt(id: string): Promise<void> {
    await this.#client.beta.sessions.events.send(id, {
      events: [{ type: "user.interrupt" }],
      betas: [...MANAGED_BETAS],
    });
  }

  async decide(id: string, decision: ApprovalDecision): Promise<void> {
    await this.#client.beta.sessions.events.send(id, {
      events: [{
        type: "user.tool_confirmation",
        tool_use_id: decision.toolUseId,
        result: decision.allow ? "allow" : "deny",
        ...(!decision.allow && decision.reason ? { deny_message: decision.reason } : {}),
        ...(decision.sessionThreadId ? { session_thread_id: decision.sessionThreadId } : {}),
      }],
      betas: [...MANAGED_BETAS],
    });
  }

  listThreads(id: string): Promise<BetaManagedAgentsSessionThread[]> {
    return collect(this.#client.beta.sessions.threads.list(id, { betas: [...MANAGED_BETAS], limit: 100 }));
  }

  listThreadEvents(id: string, threadId: string): Promise<BetaManagedAgentsSessionEvent[]> {
    return collect(this.#client.beta.sessions.threads.events.list(threadId, {
      session_id: id,
      betas: [...MANAGED_BETAS],
      limit: 100,
    }));
  }

  listArtifacts(id: string): Promise<FileMetadata[]> {
    return collect(this.#client.beta.files.list({ scope_id: id, betas: [...MANAGED_BETAS], limit: 100 }));
  }

  async downloadArtifact(id: string, fileId: string): Promise<ArtifactDownload | undefined> {
    const file = (await this.listArtifacts(id)).find((candidate) => candidate.id === fileId);
    if (!file || file.downloadable === false) return undefined;
    const response = await this.#client.beta.files.download(file.id, { betas: [...MANAGED_BETAS] });
    return {
      data: new Uint8Array(await response.arrayBuffer()),
      filename: file.filename,
      ...(response.headers.get("content-type") ? { contentType: response.headers.get("content-type") ?? undefined } : {}),
    };
  }

  async archive(id: string): Promise<void> {
    await this.#client.beta.sessions.archive(id, { betas: [...MANAGED_BETAS] });
  }
}
