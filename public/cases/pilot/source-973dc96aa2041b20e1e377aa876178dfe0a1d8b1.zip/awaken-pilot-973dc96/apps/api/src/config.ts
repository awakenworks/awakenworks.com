export interface PilotApiConfig {
  host: string;
  port: number;
  awakenApiUrl: string;
  awakenAuthToken: string;
  iamApiUrl: string;
  iamAdminToken: string;
  applicationMcpUrl: string;
  requireRequestIdentity: boolean;
  defaultWorkspaceId: string;
}

function booleanSetting(name: string, value: string | undefined): boolean {
  if (value === undefined || value.trim() === "") return false;
  if (value === "true") return true;
  if (value === "false") return false;
  throw new Error(`${name} must be true or false`);
}

export function readPilotApiConfig(environment: NodeJS.ProcessEnv = process.env): PilotApiConfig {
  const port = Number(environment.PILOT_API_PORT ?? "4174");
  if (!Number.isInteger(port) || port < 1 || port > 65_535) {
    throw new Error("PILOT_API_PORT must be an integer between 1 and 65535");
  }
  const awakenApiUrl = (environment.PILOT_AWAKEN_API_URL ?? "http://127.0.0.1:8080").trim();
  if (!URL.canParse(awakenApiUrl) || !["http:", "https:"].includes(new URL(awakenApiUrl).protocol)) {
    throw new Error("PILOT_AWAKEN_API_URL must be an HTTP(S) URL");
  }
  const applicationMcpUrl = (environment.PILOT_APPLICATION_MCP_URL ?? "").trim();
  if (applicationMcpUrl && (!URL.canParse(applicationMcpUrl) || !["http:", "https:"].includes(new URL(applicationMcpUrl).protocol))) {
    throw new Error("PILOT_APPLICATION_MCP_URL must be an HTTP(S) URL or empty");
  }
  const iamApiUrl = environment.PILOT_IAM_API_URL?.trim() || awakenApiUrl;
  if (!URL.canParse(iamApiUrl) || !["http:", "https:"].includes(new URL(iamApiUrl).protocol)) {
    throw new Error("PILOT_IAM_API_URL must be an HTTP(S) URL");
  }
  return {
    host: environment.PILOT_API_HOST?.trim() || "127.0.0.1",
    port,
    awakenApiUrl,
    awakenAuthToken: environment.PILOT_AWAKEN_AUTH_TOKEN ?? "",
    iamApiUrl,
    iamAdminToken: environment.PILOT_IAM_ADMIN_TOKEN ?? "",
    applicationMcpUrl,
    requireRequestIdentity: booleanSetting("PILOT_REQUIRE_REQUEST_IDENTITY", environment.PILOT_REQUIRE_REQUEST_IDENTITY),
    defaultWorkspaceId: environment.PILOT_DEFAULT_WORKSPACE_ID?.trim() ?? "",
  };
}
