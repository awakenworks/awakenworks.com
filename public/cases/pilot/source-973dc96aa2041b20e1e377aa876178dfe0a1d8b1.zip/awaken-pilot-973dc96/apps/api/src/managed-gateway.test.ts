import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import { describe, expect, it, vi } from "vitest";
import {
  AnthropicManagedPilotGateway,
  createAnthropicClient,
  MANAGED_BETAS,
  withPilotMcp,
} from "./managed-gateway.js";

function capturedRequest(fetcher: ReturnType<typeof vi.fn>, index = 0): Request {
  const call = fetcher.mock.calls[index];
  if (!call) throw new Error("fetch was not called");
  const [input, init] = call as [RequestInfo | URL, RequestInit | undefined];
  return input instanceof Request ? input : new Request(input, init);
}

/**
 * Connection cause-effect table at the sole Managed SDK wire seam:
 * C1 no bearer -> E1 local placeholder API key, no Authorization bearer.
 * C2 bearer present -> E2 Authorization: Bearer, no x-api-key.
 * C3 trailing slash base -> E3 one canonical /v1 route.
 * C4 Managed call -> E4 exact managed beta header supplied by the official SDK.
 * Rules R1=C1+C3+C4, R2=C2+C3+C4. The seam is server-only, so neither rule
 * enables browser credentials or a parallel wire implementation.
 */
describe("official SDK connection decision table", () => {
  it("R1 builds the local Managed request through the official SDK", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ data: [], has_more: false, next_page: null }), { status: 200, headers: { "content-type": "application/json" } }));
    const client = createAnthropicClient("https://awaken.example.test/", "", fetcher as unknown as typeof fetch);
    await client.beta.sessions.list({ betas: [...MANAGED_BETAS], limit: 1 });
    const request = capturedRequest(fetcher, fetcher.mock.calls.length - 1);
    expect(request.url).toContain("https://awaken.example.test/v1/sessions");
    expect(request.headers.get("anthropic-beta")).toContain(MANAGED_BETAS[0]);
    expect(request.headers.get("authorization")).toBeNull();
    expect(request.headers.get("x-api-key")).toBe("awaken-local");
  });

  it("R2 selects bearer authentication on the server", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ data: [], has_more: false, next_page: null }), { status: 200, headers: { "content-type": "application/json" } }));
    const client = createAnthropicClient("https://awaken.example.test/", "server-token", fetcher as unknown as typeof fetch);
    await client.beta.sessions.list({ betas: [...MANAGED_BETAS], limit: 1 });
    const request = capturedRequest(fetcher);
    expect(request.headers.get("authorization")).toBe("Bearer server-token");
    expect(request.headers.get("x-api-key")).toBeNull();
  });
});

const agentFixture = (): BetaManagedAgentsAgent => ({
  id: "agent_1",
  type: "agent",
  version: 3,
  name: "Builder",
  description: null,
  system: null,
  model: { id: "model" },
  mcp_servers: [{ name: "existing", type: "url", url: "https://existing.test/mcp" }],
  tools: [{
    type: "mcp_toolset",
    mcp_server_name: "existing",
    configs: [],
    default_config: { enabled: true, permission_policy: { type: "always_ask" } },
  }],
  skills: [],
  multiagent: null,
  metadata: {},
  archived_at: null,
  created_at: "2026-01-01T00:00:00Z",
  updated_at: "2026-01-01T00:00:00Z",
});

const projectFixture = (overrides: Partial<BetaManagedAgentsDeployment> = {}): BetaManagedAgentsDeployment => ({
  id: "deployment_1",
  type: "deployment",
  name: "Research desk",
  description: "Verify sources",
  agent: { id: "agent_1", type: "agent", version: 3 },
  environment_id: "env_1",
  initial_events: [{ type: "system.message", content: [{ type: "text", text: "Use primary sources." }] }],
  metadata: { application: "awaken-pilot", pilot_kind: "project" },
  resources: [
    { type: "file", file_id: "file_1" },
    { type: "memory_store", memory_store_id: "memstore_1", access: "read_write" },
  ],
  vault_ids: ["vlt_one", "vlt_two"],
  budget: { type: "limit", max_list_cost: { amount: "2500", currency: "USD" } },
  schedule: null,
  status: "active",
  paused_reason: null,
  archived_at: null,
  created_at: "2026-01-01T00:00:00Z",
  updated_at: "2026-01-01T00:00:00Z",
  ...overrides,
});

const agentProfileCommand = {
  name: "Manus agent",
  description: "Research and publish",
  model: "deepseek-v4-flash",
  system: "Complete the work.",
  tools: [
    { name: "read" as const, permission: "always_allow" as const },
    { name: "bash" as const, permission: "always_ask" as const },
  ],
  skills: [{ type: "anthropic" as const, skillId: "pptx", version: "latest" }],
  connectors: [{ name: "browser", url: "https://browser.example.test/mcp", permission: "always_ask" as const }],
  subagentIds: ["agent_research"],
  includeSelf: true,
};

/**
 * Agent-profile SDK cause/effect graph:
 * A1 valid product command -> E1 one tagged Awaken Agent with official built-in,
 * Skill, URL MCP/toolset and coordinator shapes; A2 update targets a Pilot-owned
 * profile with matching version -> E2 retrieve authority then issue one CAS full
 * replacement; A3 target lacks Pilot ownership tags -> E3 reject before update.
 * Decision rules: R1=A1; R2=A2; R3=A3. Agent versions remain the only profile truth.
 */
describe("Agent profile SDK decision table", () => {
  it("R1 creates one authoritative Agent capability profile", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify(agentFixture()), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await gateway.createAgentProfile(agentProfileCommand);
    const request = capturedRequest(fetcher);
    const body = await request.json() as Record<string, unknown>;
    expect(request.url).toContain("/v1/agents");
    expect(body).toEqual(expect.objectContaining({
      name: "Manus agent",
      model: "deepseek-v4-flash",
      metadata: { application: "awaken-pilot", pilot_kind: "agent_profile" },
      mcp_servers: [{ type: "url", name: "browser", url: "https://browser.example.test/mcp" }],
      skills: [{ type: "anthropic", skill_id: "pptx", version: "latest" }],
      multiagent: { type: "coordinator", agents: [{ type: "self" }, "agent_research"] },
    }));
    expect(body.tools).toEqual([
      {
        type: "agent_toolset_20260401",
        default_config: { enabled: false, permission_policy: { type: "always_ask" } },
        configs: [
          { name: "read", enabled: true, permission_policy: { type: "always_allow" } },
          { name: "bash", enabled: true, permission_policy: { type: "always_ask" } },
        ],
      },
      { type: "mcp_toolset", mcp_server_name: "browser", default_config: { enabled: true, permission_policy: { type: "always_ask" } } },
    ]);
  });

  it("R2 updates a Pilot-owned Agent with optimistic version control", async () => {
    const owned = agentFixture();
    owned.metadata = { application: "awaken-pilot", pilot_kind: "agent_profile" };
    const fetcher = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => new Response(JSON.stringify(owned), {
      status: init?.method === "POST" ? 200 : 200,
      headers: { "content-type": "application/json" },
    }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await gateway.updateAgentProfile("agent_1", { ...agentProfileCommand, version: 3 });
    expect(fetcher).toHaveBeenCalledTimes(2);
    expect(await capturedRequest(fetcher, 1).json()).toEqual(expect.objectContaining({ version: 3, name: "Manus agent" }));
  });

  it("R3 refuses to overwrite an Agent owned outside Pilot", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify(agentFixture()), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.updateAgentProfile("agent_1", { ...agentProfileCommand, version: 3 })).rejects.toMatchObject({ status: 404 });
    expect(fetcher).toHaveBeenCalledOnce();
  });
});

/**
 * Mission-create cause-effect table:
 * M1 valid Pilot Project -> E1 retrieve its Deployment and pinned Agent version.
 * M2 Pilot MCP present -> E2 retrieve the authoritative Agent snapshot, preserve
 * existing MCP servers/tools, and replace only the reserved `pilot` entries.
 * M3 goal valid -> E3 one Session create tagged with the Project ID.
 * M4 Project resources, Vault IDs, and budget present -> E4 project them into the
 * Session without a second configuration store.
 * M5 create response ambiguous -> E5 SDK error propagates; no duplicate retry path.
 * M6 ordinary create -> E6 the closed official SDK body contains no private
 * transcript-prefix extension. Rules R1=M1+M2+M3+M4+M6; R2 verifies capability
 * preservation independently.
 */
describe("Mission create decision table", () => {
  it("R2 preserves authored capabilities while replacing reserved Pilot entries", () => {
    const authored = agentFixture();
    authored.mcp_servers.push({ name: "pilot", type: "url", url: "https://old.test/mcp" });
    authored.tools.push({ type: "mcp_toolset", mcp_server_name: "pilot", configs: [], default_config: { enabled: false, permission_policy: { type: "always_ask" } } });
    const override = withPilotMcp(authored, "https://new.test/mcp");
    expect(override.mcp_servers).toEqual([
      { name: "existing", type: "url", url: "https://existing.test/mcp" },
      { name: "pilot", type: "url", url: "https://new.test/mcp" },
    ]);
    expect(override.tools?.map((tool) => tool.type === "mcp_toolset" ? tool.mcp_server_name : tool.type)).toEqual(["existing", "pilot"]);
  });

  it("R1 creates one atomic tagged Session without a duplicate retry mechanism", async () => {
    const fetcher = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      const body = url.includes("/v1/deployments/") ? projectFixture() : url.includes("/v1/agents/") ? agentFixture() : {
        id: "sesn_1", type: "session", status: "running", title: "Brief",
        metadata: { application: "awaken-pilot", pilot_project_id: "deployment_1" }, created_at: "now", updated_at: "now",
        archived_at: null, resources: [], outcome_evaluations: [], agent: agentFixture(),
      };
      return new Response(JSON.stringify(body), { status: 200, headers: { "content-type": "application/json" } });
    });
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "https://pilot.test/mcp", fetcher as unknown as typeof fetch);
    await gateway.createMission({
      projectId: "deployment_1",
      title: "Brief",
      goal: "Research and verify",
      mode: "plan",
      acceptanceCriteria: "",
      maxIterations: 3,
    });
    expect(fetcher).toHaveBeenCalledTimes(3);
    expect(capturedRequest(fetcher, 1).url).toContain("version=3");
    const create = capturedRequest(fetcher, 2);
    const body = await create.json() as Record<string, unknown>;
    expect(create.headers.get("idempotency-key")).toBeNull();
    expect(body.metadata).toEqual({ application: "awaken-pilot", pilot_project_id: "deployment_1", pilot_mode: "plan" });
    expect(body.vault_ids).toEqual(["vlt_one", "vlt_two"]);
    expect(body.resources).toEqual([
      { type: "file", file_id: "file_1" },
      { type: "memory_store", memory_store_id: "memstore_1", access: "read_write" },
    ]);
    expect(body.budget).toEqual({ type: "limit", max_list_cost: { amount: "2500", currency: "USD" } });
    expect(body.initial_events).toEqual([expect.objectContaining({ type: "user.message" })]);
    expect(body).not.toHaveProperty("x_awaken");
    expect(JSON.stringify(body.initial_events)).toContain("Plan this mission before acting");
    // Cause/FMECA rule O1: Workdir ACP (C1) receives a runtime-owned output
    // directory (C2) -> mission text names AWAKEN_OUTPUTS_DIR for writes and the
    // logical outputs/ path for publication (E1). The former relative-only text
    // wrote beside the canonical scan root, leaving a declared result with no
    // Session Artifact; one environment port plus one logical path mitigates it.
    expect(JSON.stringify(body.initial_events)).toContain("AWAKEN_OUTPUTS_DIR");
    expect(JSON.stringify(body.initial_events)).toContain("outputs/report.md");
    expect(JSON.stringify(body.initial_events)).not.toContain("user.define_outcome");
    expect(body.agent).toEqual(expect.objectContaining({
      id: "agent_1",
      type: "agent_with_overrides",
      system: expect.stringContaining("Project instructions:\nUse primary sources."),
    }));
  });
});

/**
 * Mission quality cause-effect table:
 * Q1 Execute Mode + non-empty criteria -> E1 one `user.define_outcome` event with
 * the exact text rubric and bounded revision count.
 * Q2 Plan Mode or empty criteria -> E2 ordinary user message; planning cannot begin
 * automatic evaluation before approval. Rules R1=Q1; R2=Q2. Outcome state remains
 * the Session's `outcome_evaluations`, never a Pilot quality table.
 */
describe("Mission outcome decision table", () => {
  it("R1 creates an evaluated outcome through the official Session event", async () => {
    const fetcher = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      const body = url.includes("/v1/deployments/") ? projectFixture() : url.includes("/v1/agents/") ? agentFixture() : {
        id: "sesn_quality", type: "session", status: "running", title: "Quality brief",
        metadata: {}, created_at: "now", updated_at: "now", archived_at: null,
        resources: [], outcome_evaluations: [], agent: agentFixture(),
      };
      return new Response(JSON.stringify(body), { headers: { "content-type": "application/json" } });
    });
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await gateway.createMission({
      projectId: "deployment_1", title: "Quality brief", goal: "Write the brief", mode: "execute",
      acceptanceCriteria: "Every claim cites a primary source.", maxIterations: 4,
    });
    const body = await capturedRequest(fetcher, 2).json() as { initial_events: unknown[] };
    expect(body.initial_events).toEqual([expect.objectContaining({
      type: "user.define_outcome",
      rubric: { type: "text", content: "Every claim cites a primary source." },
      max_iterations: 4,
    })]);
  });
});

describe("Managed child Thread event ownership", () => {
  it("uses the Anthropic SDK thread-events resource with both exact path identities", async () => {
    /* Causes: C1 Session id, C2 child Thread id, C3 paged child events.
     * Effects: E1 SDK request is /sessions/{C1}/threads/{C2}/events; E2 collect
     * returns the child events once. Decision R1 C1+C2+C3 -> E1+E2. FMECA:
     * using sessions.events.list would silently inspect the parent and let an E2E
     * pass without proving isolated child tool execution. */
    const fetcher = vi.fn(async () => new Response(JSON.stringify({
      data: [{ id: "evt_child", type: "agent.tool_use", name: "web_search" }],
      has_more: false,
      next_page: null,
    }), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.listThreadEvents("sesn_1", "sthr_1")).resolves.toEqual([
      expect.objectContaining({ id: "evt_child", name: "web_search" }),
    ]);
    const request = capturedRequest(fetcher);
    expect(request.url).toContain("/v1/sessions/sesn_1/threads/sthr_1/events");
  });
});

/**
 * Project ownership cause-effect table:
 * P1 Deployment carries both Pilot tags -> E1 expose it as a Project.
 * P2 either tag is absent -> E2 exclude it from the Project list.
 * P3 valid scheduled command -> E3 one official Deployment create containing cron,
 * resources, budget, and Pilot tags; Pilot creates no schedule or Project record.
 * Rules R1=P1+P2; R2=P3.
 */
describe("Project Deployment decision table", () => {
  it("R1 exposes only tagged Deployments", async () => {
    const page = {
      data: [projectFixture(), projectFixture({ id: "deployment_other", metadata: {} })],
      has_more: false,
      next_page: null,
    };
    const fetcher = vi.fn(async () => new Response(JSON.stringify(page), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.listProjects()).resolves.toEqual([expect.objectContaining({ id: "deployment_1" })]);
  });

  it("R2 creates one scheduled Deployment as the sole Project record", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify(projectFixture()), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await gateway.createProject({
      name: "Research desk",
      instruction: "Use primary sources.",
      agentId: "agent_1",
      environmentId: "env_1",
      vaultIds: ["vlt_one"],
      fileIds: ["file_1"],
      memoryStoreIds: ["memstore_1"],
      budgetUsdCents: 2500,
      schedule: { prompt: "Publish a weekly brief.", expression: "0 9 * * 1", timezone: "Asia/Shanghai" },
    });
    expect(fetcher).toHaveBeenCalledOnce();
    const body = await capturedRequest(fetcher).json() as Record<string, unknown>;
    expect(body.metadata).toEqual({ application: "awaken-pilot", pilot_kind: "project" });
    expect(body.schedule).toEqual({ type: "cron", expression: "0 9 * * 1", timezone: "Asia/Shanghai" });
    expect(body.budget).toEqual({ type: "limit", max_list_cost: { amount: "2500", currency: "USD" } });
    expect(body.resources).toHaveLength(2);
    expect(JSON.stringify(body.initial_events)).toContain("Publish a weekly brief.");
  });
});

/**
 * Project-resource cause-effect table:
 * K1 Files list contains workspace and Session-scoped files -> E1 expose only
 * workspace files as reusable Project knowledge.
 * K2 upload has bytes/name/media type -> E2 one official multipart Files upload.
 * K2a upload is a Buffer view into a larger slab -> E2 contains only the view;
 * neither prefix/suffix nor other pooled process bytes cross the SDK boundary.
 * K3 Memory Store command valid -> E3 one official create tagged for bookkeeping;
 * the returned upstream ID is the only identity.
 * K4 Vault list contains active and archived rows -> E4 expose only active,
 * secret-free upstream Vault metadata for Project selection.
 * Rules R1=K1; R2=K2+K2a; R3=K3; R4=K4.
 */
describe("Project resource SDK decision table", () => {
  it("R1 exposes reusable workspace Files but not Session artifacts", async () => {
    const page = {
      data: [
        { id: "file_workspace", type: "file", filename: "knowledge.pdf", mime_type: "application/pdf", size_bytes: 10, created_at: "now", scope: null },
        { id: "file_session", type: "file", filename: "result.md", mime_type: "text/markdown", size_bytes: 20, created_at: "now", scope: { type: "session", id: "sesn_1" } },
      ],
      has_more: false,
    };
    const fetcher = vi.fn(async () => new Response(JSON.stringify(page), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.listKnowledgeFiles()).resolves.toEqual([expect.objectContaining({ id: "file_workspace" })]);
  });

  it("R2 uploads exact file metadata through the official multipart client", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ id: "file_1", type: "file", filename: "资料.md", mime_type: "text/markdown", size_bytes: 8, created_at: "now" }), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    const slab = Buffer.from("prefixverifiedsuffix");
    await gateway.uploadKnowledgeFile("资料.md", "text/markdown", slab.subarray(6, 14));
    const request = capturedRequest(fetcher, fetcher.mock.calls.length - 1);
    expect(request.url).toContain("/v1/files");
    const form = await request.formData();
    const file = form.get("file");
    expect(file).toBeInstanceOf(File);
    expect((file as File).name).toBe("资料.md");
    expect((file as File).type).toBe("text/markdown");
    expect((file as File).size).toBe(8);
    expect(await (file as File).text()).toBe("verified");
  });

  it("R3 creates one tagged upstream Memory Store", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ id: "memstore_1", type: "memory_store", name: "Research memory", created_at: "now", updated_at: "now" }), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await gateway.createMemoryStore({ name: "Research memory", description: "Verified findings" });
    expect(await capturedRequest(fetcher).json()).toEqual(expect.objectContaining({
      name: "Research memory",
      description: "Verified findings",
      metadata: { application: "awaken-pilot", pilot_kind: "project_memory" },
    }));
  });

  it("R4 lists only active upstream Vault references", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({
      data: [
        { id: "vlt_active", type: "vault", display_name: "Publishing", metadata: {}, archived_at: null, created_at: "now", updated_at: "now" },
        { id: "vlt_archived", type: "vault", display_name: "Old", metadata: {}, archived_at: "now", created_at: "then", updated_at: "now" },
      ],
      has_more: false,
      next_page: null,
    }), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.listVaults()).resolves.toEqual([expect.objectContaining({ id: "vlt_active", display_name: "Publishing" })]);
    expect(capturedRequest(fetcher).url).toContain("/v1/vaults");
  });
});

/**
 * Vault/credential SDK cause/effect graph:
 * V1 create Vault -> E1 one tagged official Vault; V2 bearer/OAuth/environment
 * command -> E2 translate once into the official write-only auth union; V3 list
 * includes archived -> E3 expose active redacted rows only; V4 OAuth validation
 * requested -> E4 call the credential's canonical live MCP probe.
 * Decision rules: R1=V1; R2=each V2 variant; R3=V3; R4=V4. Pilot has no secret store.
 */
describe("Connector Vault SDK decision table", () => {
  it("R1 creates one tagged upstream Vault", async () => {
    const response = { id: "vlt_1", type: "vault", display_name: "Connectors", metadata: {}, archived_at: null, created_at: "now", updated_at: "now" };
    const fetcher = vi.fn(async () => new Response(JSON.stringify(response), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await gateway.createVault({ displayName: "Connectors" });
    expect(await capturedRequest(fetcher).json()).toEqual({
      display_name: "Connectors",
      metadata: { application: "awaken-pilot", pilot_kind: "connector_credentials" },
    });
  });

  it("R2 sends a bearer secret once and returns only the redacted credential", async () => {
    const redacted = {
      id: "vcrd_1", type: "vault_credential", vault_id: "vlt_1", display_name: "Browser",
      auth: { type: "static_bearer", mcp_server_url: "https://browser.example.test/mcp" },
      metadata: {}, archived_at: null, created_at: "now", updated_at: "now",
    };
    const fetcher = vi.fn(async () => new Response(JSON.stringify(redacted), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.createVaultCredential("vlt_1", {
      displayName: "Browser",
      auth: { type: "static_bearer", mcpServerUrl: "https://browser.example.test/mcp", token: "write-only-secret" },
    })).resolves.toEqual(redacted);
    const body = await capturedRequest(fetcher).json() as Record<string, unknown>;
    expect(body).toEqual({
      display_name: "Browser",
      auth: { type: "static_bearer", mcp_server_url: "https://browser.example.test/mcp", token: "write-only-secret" },
      metadata: { application: "awaken-pilot", pilot_kind: "connector_credential" },
    });
    expect(JSON.stringify(redacted)).not.toContain("write-only-secret");
  });

  it("R2 maps bounded environment-variable secret egress", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ id: "vcrd_env" }), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await gateway.createVaultCredential("vlt_1", {
      displayName: "Stripe",
      auth: {
        type: "environment_variable", secretName: "STRIPE_API_KEY", secretValue: "write-only-secret",
        allowedHosts: ["api.stripe.com"], unrestricted: false, injectHeader: true, injectBody: false,
      },
    });
    expect(await capturedRequest(fetcher).json()).toEqual(expect.objectContaining({
      auth: {
        type: "environment_variable",
        secret_name: "STRIPE_API_KEY",
        secret_value: "write-only-secret",
        networking: { type: "limited", allowed_hosts: ["api.stripe.com"] },
        injection_location: { header: true, body: false },
      },
    }));
  });

  it("R3 lists only active redacted credentials", async () => {
    const page = { data: [
      { id: "vcrd_active", archived_at: null },
      { id: "vcrd_old", archived_at: "now" },
    ], has_more: false, next_page: null };
    const fetcher = vi.fn(async () => new Response(JSON.stringify(page), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.listVaultCredentials("vlt_1")).resolves.toEqual([{ id: "vcrd_active", archived_at: null }]);
  });

  it("R4 invokes the official live MCP credential probe", async () => {
    const validation = { type: "vault_credential_validation", vault_id: "vlt_1", credential_id: "vcrd_1", status: "valid", has_refresh_token: false, refresh: null, mcp_probe: null, validated_at: "now" };
    const fetcher = vi.fn(async () => new Response(JSON.stringify(validation), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.validateVaultCredential("vlt_1", "vcrd_1")).resolves.toEqual(validation);
    expect(capturedRequest(fetcher).url).toContain("/v1/vaults/vlt_1/credentials/vcrd_1/mcp_oauth_validate");
  });
});

/**
 * Webhook config-plane cause-effect table:
 * W1 list -> E1 project the upstream workspace rows unchanged.
 * W2 PUT with empty event types -> E2 send one authored patch where empty means all.
 * W3 first create returns a secret -> E3 relay it once; Pilot never stores it.
 * W4 delete -> E4 issue one idempotent upstream DELETE.
 * W5 bearer configured -> E5 authenticate at the server edge, never in the browser.
 * Rule R1=W1+W2+W3+W4+W5. Delivery, retries, counters, and disable transitions have
 * no Pilot implementation and therefore no competing test path.
 */
describe("Awaken webhook config-plane decision table", () => {
  it("R1 adapts CRUD to the one upstream subscription authority", async () => {
    const fetcher = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const request = input instanceof Request ? input : new Request(input, init);
      if (request.method === "DELETE") return new Response(null, { status: 204 });
      if (request.method === "PUT") return new Response(JSON.stringify({
        id: "wh_1", workspace_id: "ws_1", url: "https://receiver.example/hook",
        event_types: [], disabled: false, secret: "whsec_once",
      }), { status: 201, headers: { "content-type": "application/json" } });
      return new Response(JSON.stringify({ data: [{
        id: "wh_1", workspace_id: "ws_1", url: "https://receiver.example/hook",
        event_types: [], disabled: false,
      }], has_more: false }), { headers: { "content-type": "application/json" } });
    });
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test/", "server-token", "", fetcher as unknown as typeof fetch);
    await expect(gateway.listWebhooks()).resolves.toEqual([expect.objectContaining({ id: "wh_1" })]);
    await expect(gateway.putWebhook("wh_1", {
      url: "https://receiver.example/hook", eventTypes: [], disabled: false,
    })).resolves.toEqual(expect.objectContaining({ secret: "whsec_once" }));
    await gateway.deleteWebhook("wh_1");

    expect(fetcher).toHaveBeenCalledTimes(3);
    for (let index = 0; index < 3; index += 1) {
      expect(capturedRequest(fetcher, index).headers.get("authorization")).toBe("Bearer server-token");
    }
    expect(capturedRequest(fetcher, 0).url).toBe("https://awaken.example.test/v1/config/webhook-subscriptions");
    expect(await capturedRequest(fetcher, 1).json()).toEqual({
      url: "https://receiver.example/hook", event_types: [], disabled: false,
    });
    expect(capturedRequest(fetcher, 2).method).toBe("DELETE");
  });
});

const filePage = {
  data: [{
    id: "file_1",
    type: "file",
    created_at: "2026-01-01T00:00:00Z",
    filename: "report.md",
    mime_type: "text/markdown",
    size_bytes: 6,
    downloadable: true,
    scope: { type: "session", id: "sesn_1" },
  }],
  has_more: false,
  next_page: null,
};

/**
 * Artifact-download cause-effect table at the SDK seam:
 * A1 requested file appears in the Session-scoped list and is downloadable ->
 * E1 issue one Files download and return its bytes/metadata.
 * A2 file is absent or non-downloadable -> E2 return undefined without a download.
 * Rules R1=A1; R2=A2. There is no unscoped direct-download compatibility path.
 */
describe("artifact download decision table", () => {
  it("R1 downloads a file only after resolving it in the Session scope", async () => {
    const fetcher = vi.fn(async (input: RequestInfo | URL) => String(input).includes("/content")
      ? new Response("report", { headers: { "content-type": "text/markdown" } })
      : new Response(JSON.stringify(filePage), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.downloadArtifact("sesn_1", "file_1")).resolves.toEqual({
      data: new TextEncoder().encode("report"),
      filename: "report.md",
      contentType: "text/markdown",
    });
    expect(fetcher).toHaveBeenCalledTimes(2);
    expect(capturedRequest(fetcher).url).toContain("scope_id=sesn_1");
  });

  it("R2 refuses an out-of-scope file without issuing a download", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify(filePage), { headers: { "content-type": "application/json" } }));
    const gateway = new AnthropicManagedPilotGateway("https://awaken.example.test", "", "", fetcher as unknown as typeof fetch);
    await expect(gateway.downloadArtifact("sesn_1", "file_other")).resolves.toBeUndefined();
    expect(fetcher).toHaveBeenCalledOnce();
  });
});
