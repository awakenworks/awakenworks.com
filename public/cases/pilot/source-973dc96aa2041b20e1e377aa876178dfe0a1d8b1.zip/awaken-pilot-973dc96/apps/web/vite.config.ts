import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: process.env.PILOT_DEV_API_URL ?? "http://127.0.0.1:4174",
        changeOrigin: true,
      },
    },
  },
});
