import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import { describe, expect, it } from "vitest";
import { agentCapabilityGroups } from "./agent-capabilities";

/**
 * Agent-capability projection cause-effect table:
 * A1 built-in default enabled plus explicit disabled override -> E1 include only
 * effective tools, split into research/workspace groups.
 * A2 Skills/MCP/custom/multi-agent configured -> E2 expose their upstream names and
 * roster count without reproducing definitions or execution logic.
 * A3 category empty -> E3 omit the empty category. Rules R1=A1; R2=A1+A2; R3=A3.
 */
describe("Agent capability projection decision table", () => {
  it("R1/R2 projects effective upstream capabilities", () => {
    const agent = {
      tools: [
        { type: "agent_toolset_20260401", default_config: { enabled: true }, configs: [{ name: "web_fetch", enabled: false }] },
        { type: "custom", name: "publish_site" },
      ],
      skills: [{ type: "anthropic", skill_id: "xlsx", version: "1" }],
      mcp_servers: [{ name: "notion", type: "url", url: "https://example.test/mcp" }],
      multiagent: { type: "coordinator", agents: [{ type: "agent", id: "agent_2", version: 1 }] },
    } as BetaManagedAgentsAgent;
    expect(agentCapabilityGroups(agent)).toEqual([
      { id: "research", label: "Web research", values: ["web_search"] },
      { id: "workspace", label: "Workspace tools", values: ["bash", "edit", "read", "write", "glob", "grep"] },
      { id: "skills", label: "Skills", values: ["xlsx@1"] },
      { id: "connectors", label: "MCP connectors", values: ["notion"] },
      { id: "custom", label: "Application tools", values: ["publish_site"] },
      { id: "multiagent", label: "Parallel agents", values: ["1 available profiles"] },
    ]);
  });

  it("R3 omits capabilities not authored on the Agent", () => {
    const agent = { tools: [], skills: [], mcp_servers: [], multiagent: null } as unknown as BetaManagedAgentsAgent;
    expect(agentCapabilityGroups(agent)).toEqual([]);
  });
});
