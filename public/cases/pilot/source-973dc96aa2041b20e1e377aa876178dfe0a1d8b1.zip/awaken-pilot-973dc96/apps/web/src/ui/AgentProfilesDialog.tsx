import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import { Button, CheckboxField, CheckPicker, Dialog, Field, InlineNotice, SelectField, TextAreaField, TextField } from "@awaken/ui";
import { useState } from "react";
import { agentCapabilityGroups } from "../domain/agent-capabilities";
import type { AgentProfileCommand } from "../infrastructure/gateway";

const TOOL_NAMES = ["bash", "edit", "read", "write", "glob", "grep", "web_fetch", "web_search"] as const;
const ANTHROPIC_SKILLS = ["pptx", "xlsx", "docx", "pdf"] as const;
const AUTO_ALLOW = new Set(["read", "glob", "grep", "web_fetch", "web_search"]);

interface ConnectorDraft {
  key: string;
  name: string;
  url: string;
  permission: "always_allow" | "always_ask";
}

function connectorDraft(): ConnectorDraft {
  return { key: crypto.randomUUID(), name: "", url: "", permission: "always_ask" };
}

function split(value: string): string[] {
  return value.split(",").map((item) => item.trim()).filter(Boolean);
}

export function AgentProfilesDialog({ open, agents, pending, error, onClose, onCreate }: {
  open: boolean;
  agents: BetaManagedAgentsAgent[];
  pending: boolean;
  error?: Error;
  onClose: () => void;
  onCreate: (input: AgentProfileCommand) => Promise<BetaManagedAgentsAgent>;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [model, setModel] = useState("");
  const [system, setSystem] = useState("");
  const [tools, setTools] = useState<string[]>([...TOOL_NAMES]);
  const [skills, setSkills] = useState<string[]>([...ANTHROPIC_SKILLS]);
  const [customSkills, setCustomSkills] = useState("");
  const [connectors, setConnectors] = useState<ConnectorDraft[]>([]);
  const [subagentIds, setSubagentIds] = useState<string[]>([]);
  const [includeSelf, setIncludeSelf] = useState(false);
  const completeConnectors = connectors.every((connector) => connector.name.trim() && connector.url.trim());
  const canSave = Boolean(name.trim() && model.trim() && completeConnectors);
  const create = async () => {
    if (!canSave) return;
    await onCreate({
      name,
      description,
      model,
      system,
      tools: tools.map((tool) => ({
        name: tool as AgentProfileCommand["tools"][number]["name"],
        permission: AUTO_ALLOW.has(tool) ? "always_allow" : "always_ask",
      })),
      skills: [
        ...skills.map((skillId) => ({ type: "anthropic" as const, skillId, version: "latest" })),
        ...split(customSkills).map((skillId) => ({ type: "custom" as const, skillId, version: "latest" })),
      ],
      connectors: connectors.map(({ name: connectorName, url, permission }) => ({ name: connectorName, url, permission })),
      subagentIds,
      includeSelf,
    });
  };
  const subagentOptions = agents.filter((agent) => !agent.archived_at && !agent.multiagent).map((agent) => ({
    id: agent.id,
    label: agent.name,
    description: `${agent.model.id} · v${agent.version}`,
  }));
  return <Dialog
    open={open}
    onOpenChange={(next) => { if (!next) onClose(); }}
    title="Agent and connectors"
    closeLabel="Close Agent profiles"
    description="This editor writes one versioned Awaken Agent. MCP execution, Skills, permissions, Vault matching, and multi-agent threads remain owned by Awaken."
    footer={<><Button variant="ghost" onClick={onClose}>Close</Button><Button variant="primary" onClick={create} loading={pending} disabled={!canSave}>Create agent profile</Button></>}
  >
    <div className="settings-grid">
      <section className="agent-profile-list" aria-label="Available Agent profiles">
        <h3>Available profiles</h3>
        {agents.length ? agents.map((agent) => <article key={agent.id}>
          <strong>{agent.name} · v{agent.version}</strong>
          <small>{agent.model.id}</small>
          <span>{agentCapabilityGroups(agent).flatMap((group) => group.values).join(" · ") || "No configured capabilities"}</span>
        </article>) : <p>No Agents are available.</p>}
      </section>
      <h3>Create an Awaken Agent</h3>
      {error ? <InlineNotice tone="danger" title="Agent request failed">{error.message}</InlineNotice> : null}
      <TextField label="Agent name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Research and publishing agent" />
      <TextField label="Model ID" value={model} onChange={(event) => setModel(event.target.value)} placeholder="deepseek-v4-flash or acp:codex" />
      <TextField label="Description (optional)" value={description} onChange={(event) => setDescription(event.target.value)} />
      <TextAreaField label="System instruction (optional)" value={system} onChange={(event) => setSystem(event.target.value)} rows={4} />
      <Field label="Built-in tools" labelAs="div" help="Read/research tools default to allow; mutating tools require approval.">
        {() => <CheckPicker options={TOOL_NAMES.map((tool) => ({ id: tool, label: tool, description: AUTO_ALLOW.has(tool) ? "Automatically allowed" : "Requires approval" }))} selected={tools} onChange={setTools} />}
      </Field>
      <Field label="Document Skills" labelAs="div" help="Official Anthropic-managed Skills are pinned by Awaken when the Agent version is created.">
        {() => <CheckPicker options={ANTHROPIC_SKILLS.map((skill) => ({ id: skill, label: skill, description: `Create and edit ${skill.toUpperCase()} artifacts` }))} selected={skills} onChange={setSkills} />}
      </Field>
      <TextField label="Custom Skill IDs (optional)" value={customSkills} onChange={(event) => setCustomSkills(event.target.value)} placeholder="skill_…, skill_…" help="Comma-separated Awaken Skill IDs." />
      <section className="connector-editor" aria-label="MCP connectors">
        <header><strong>MCP connectors</strong><Button variant="ghost" onClick={() => setConnectors((current) => [...current, connectorDraft()])}>Add connector</Button></header>
        {connectors.map((connector, index) => <div key={connector.key} className="connector-row">
          <TextField label={`Connector name ${index + 1}`} value={connector.name} onChange={(event) => setConnectors((current) => current.map((item) => item.key === connector.key ? { ...item, name: event.target.value } : item))} placeholder="browser" />
          <TextField label={`Connector URL ${index + 1}`} value={connector.url} onChange={(event) => setConnectors((current) => current.map((item) => item.key === connector.key ? { ...item, url: event.target.value } : item))} placeholder="https://connector.example/mcp" />
          <SelectField label={`Connector permission ${index + 1}`} value={connector.permission} onChange={(event) => setConnectors((current) => current.map((item) => item.key === connector.key ? { ...item, permission: event.target.value as ConnectorDraft["permission"] } : item))}>
            <option value="always_ask">Require approval</option>
            <option value="always_allow">Automatically allow</option>
          </SelectField>
          <Button variant="ghost" onClick={() => setConnectors((current) => current.filter((item) => item.key !== connector.key))}>Remove connector {index + 1}</Button>
        </div>)}
        {!connectors.length ? <p>No direct MCP servers. The reserved Pilot application MCP is injected only when a Mission starts.</p> : null}
      </section>
      <Field label="Parallel Agent roster" labelAs="div" help="Only non-coordinator Agents are eligible; Awaken enforces the one-level and 20-entry limits.">
        {() => <CheckPicker options={subagentOptions} selected={subagentIds} onChange={setSubagentIds} empty="No eligible subagents." />}
      </Field>
      <CheckboxField label="Allow this Agent to delegate recursively to itself" checked={includeSelf} onChange={(event) => setIncludeSelf(event.target.checked)} />
    </div>
  </Dialog>;
}
