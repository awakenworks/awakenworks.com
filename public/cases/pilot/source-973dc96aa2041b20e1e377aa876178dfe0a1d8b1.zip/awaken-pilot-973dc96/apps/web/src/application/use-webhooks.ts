import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { PilotGateway, WebhookCommand } from "../infrastructure/gateway";

export const webhookKeys = { all: ["webhooks"] as const };

export function useWebhooks(gateway: PilotGateway, enabled: boolean) {
  const cache = useQueryClient();
  const subscriptions = useQuery({
    queryKey: webhookKeys.all,
    queryFn: () => gateway.listWebhooks(),
    enabled,
  });
  const refresh = () => cache.invalidateQueries({ queryKey: webhookKeys.all });
  const put = useMutation({
    mutationFn: ({ id, input }: { id: string; input: WebhookCommand }) => gateway.putWebhook(id, input),
    onSuccess: refresh,
  });
  const remove = useMutation({ mutationFn: (id: string) => gateway.deleteWebhook(id), onSuccess: refresh });
  return { subscriptions, put, remove };
}
