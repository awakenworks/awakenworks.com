import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { PilotGateway, VaultCommand, VaultCredentialCommand } from "../infrastructure/gateway";
import { projectKeys } from "./use-projects";

const credentialKey = (vaultId: string) => ["vaults", vaultId, "credentials"] as const;

export function useConnectorCredentials(gateway: PilotGateway, selectedVaultId: string | undefined) {
  const cache = useQueryClient();
  const vaults = useQuery({ queryKey: projectKeys.vaults, queryFn: () => gateway.listVaults() });
  const credentials = useQuery({
    queryKey: credentialKey(selectedVaultId ?? "none"),
    queryFn: () => gateway.listVaultCredentials(selectedVaultId ?? ""),
    enabled: Boolean(selectedVaultId),
  });
  const createVault = useMutation({
    mutationFn: (input: VaultCommand) => gateway.createVault(input),
    onSuccess: () => cache.invalidateQueries({ queryKey: projectKeys.vaults }),
  });
  const createCredential = useMutation({
    mutationFn: ({ vaultId, input }: { vaultId: string; input: VaultCredentialCommand }) => gateway.createVaultCredential(vaultId, input),
    onSuccess: (_credential, variables) => cache.invalidateQueries({ queryKey: credentialKey(variables.vaultId) }),
  });
  const validateCredential = useMutation({
    mutationFn: ({ vaultId, credentialId }: { vaultId: string; credentialId: string }) => gateway.validateVaultCredential(vaultId, credentialId),
  });
  return { vaults, credentials, createVault, createCredential, validateCredential };
}
