import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ConnectorCredentialsDialog } from "./ConnectorCredentialsDialog";

afterEach(cleanup);

/**
 * Credential UI cause/effect graph:
 * C1 selected official Vault + complete bearer fields -> E1 send the secret once
 * to the BFF and clear local secret state after redacted success; C2 no Vault or
 * incomplete secret boundary -> E2 disable mutation; C3 redacted OAuth row ->
 * E3 expose validation command without rendering token material.
 * Decision rules: R1=C1; R2=C2; R3=C3.
 */
describe("Connector credential UI decision table", () => {
  it("R1/R2 stores one write-only bearer and clears the browser copy", async () => {
    const user = userEvent.setup();
    const onCreateCredential = vi.fn(async () => ({
      id: "vcrd_1", type: "vault_credential", vault_id: "vlt_1", display_name: "Browser",
      auth: { type: "static_bearer", mcp_server_url: "https://browser.example.test/mcp" },
    }) as never);
    render(<ConnectorCredentialsDialog
      open
      vaults={[{ id: "vlt_1", display_name: "Connectors" }] as never[]}
      selectedVaultId="vlt_1"
      credentials={[]}
      pending={false}
      onSelectVault={vi.fn()}
      onClose={vi.fn()}
      onCreateVault={vi.fn(async () => ({ id: "vlt_2" }) as never)}
      onCreateCredential={onCreateCredential}
      onValidate={vi.fn()}
    />);
    const save = screen.getByRole("button", { name: "Store credential in Awaken" });
    expect(save).toBeDisabled();
    await user.type(screen.getByLabelText("Credential name"), "Browser");
    await user.type(screen.getByLabelText("MCP server URL"), "https://browser.example.test/mcp");
    await user.type(screen.getByLabelText("Bearer token"), "write-only-secret");
    await user.click(save);
    expect(onCreateCredential).toHaveBeenCalledWith("vlt_1", {
      displayName: "Browser",
      auth: { type: "static_bearer", mcpServerUrl: "https://browser.example.test/mcp", token: "write-only-secret" },
    });
    await waitFor(() => expect(screen.getByLabelText("Bearer token")).toHaveValue(""));
    expect(screen.queryByText("write-only-secret")).not.toBeInTheDocument();
  });

  it("R3 validates a redacted OAuth credential", async () => {
    const user = userEvent.setup();
    const onValidate = vi.fn(async () => ({ status: "valid" }) as never);
    render(<ConnectorCredentialsDialog
      open
      vaults={[{ id: "vlt_1", display_name: "Connectors" }] as never[]}
      selectedVaultId="vlt_1"
      credentials={[{
        id: "vcrd_oauth", display_name: "GitHub", auth: { type: "mcp_oauth", mcp_server_url: "https://github.example/mcp" },
      }] as never[]}
      pending={false}
      onSelectVault={vi.fn()}
      onClose={vi.fn()}
      onCreateVault={vi.fn()}
      onCreateCredential={vi.fn()}
      onValidate={onValidate}
    />);
    await user.click(screen.getByRole("button", { name: "Validate GitHub" }));
    expect(onValidate).toHaveBeenCalledWith("vlt_1", "vcrd_oauth");
  });
});
