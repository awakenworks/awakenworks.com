import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import {
  EMPTY_LIVE_PREVIEW,
  isCommittedStreamEvent,
  mergeCommittedEvents,
  reduceLivePreview,
  type LivePreview,
} from "@awaken/managed-session-projection";
import {
  projectMission,
  type MissionEvent,
} from "../domain/mission";
import type { ApprovalDecision, PilotGateway } from "../infrastructure/gateway";
import { missionKeys } from "./use-missions";

export function useMission(id: string, gateway: PilotGateway) {
  const cache = useQueryClient();
  const [preview, setPreview] = useState<LivePreview>(EMPTY_LIVE_PREVIEW);
  const mission = useQuery({ queryKey: missionKeys.detail(id), queryFn: () => gateway.getMission(id), refetchInterval: 10_000 });
  const events = useQuery({ queryKey: missionKeys.events(id), queryFn: () => gateway.listEvents(id), refetchInterval: 5_000 });
  const threads = useQuery({ queryKey: missionKeys.threads(id), queryFn: () => gateway.listThreads(id), refetchInterval: 10_000 });
  const artifacts = useQuery({ queryKey: missionKeys.artifacts(id), queryFn: () => gateway.listArtifacts(id), refetchInterval: 15_000 });

  useEffect(() => {
    const controller = new AbortController();
    const receive = (event: Parameters<PilotGateway["followEvents"]>[1] extends (event: infer E) => void ? E : never) => {
      setPreview((current) => reduceLivePreview(current, event));
      if (isCommittedStreamEvent(event)) {
        cache.setQueryData<MissionEvent[]>(missionKeys.events(id), (current = []) => mergeCommittedEvents(current, [event]));
      }
    };
    void gateway.followEvents(id, receive, controller.signal).catch((error: unknown) => {
      if (!(error instanceof DOMException && error.name === "AbortError")) void events.refetch();
    });
    return () => controller.abort();
  }, [cache, gateway, id]);

  const refresh = () => Promise.all([mission.refetch(), events.refetch(), threads.refetch(), artifacts.refetch()]);
  const mutationOptions = { onSuccess: refresh };
  const send = useMutation({ mutationFn: (text: string) => gateway.sendMessage(id, text), ...mutationOptions });
  const interrupt = useMutation({ mutationFn: () => gateway.interrupt(id), ...mutationOptions });
  const decide = useMutation({ mutationFn: (decision: ApprovalDecision) => gateway.decide(id, decision), ...mutationOptions });
  const archive = useMutation({ mutationFn: () => gateway.archive(id), onSuccess: async () => {
    await refresh();
    await cache.invalidateQueries({ queryKey: missionKeys.all });
  } });
  const projection = useMemo(() => projectMission(events.data ?? []), [events.data]);

  return { mission, events, threads, artifacts, projection, preview, send, interrupt, decide, archive, refresh };
}
