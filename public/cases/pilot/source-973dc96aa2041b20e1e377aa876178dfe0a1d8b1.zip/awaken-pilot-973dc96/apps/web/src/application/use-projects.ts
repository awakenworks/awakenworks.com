import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { MemoryStoreCommand, PilotGateway, ProjectCommand } from "../infrastructure/gateway";
import { missionKeys } from "./use-missions";

export const projectKeys = {
  all: ["projects"] as const,
  agents: ["catalog", "agents"] as const,
  environments: ["catalog", "environments"] as const,
  files: ["catalog", "files"] as const,
  memoryStores: ["catalog", "memory-stores"] as const,
  vaults: ["catalog", "vaults"] as const,
  runs: (id: string) => ["projects", id, "runs"] as const,
};

export function useProjects(gateway: PilotGateway, selectedProjectId: string | undefined) {
  const cache = useQueryClient();
  const projects = useQuery({ queryKey: projectKeys.all, queryFn: () => gateway.listProjects() });
  const agents = useQuery({ queryKey: projectKeys.agents, queryFn: () => gateway.listAgents() });
  const environments = useQuery({ queryKey: projectKeys.environments, queryFn: () => gateway.listEnvironments() });
  const files = useQuery({ queryKey: projectKeys.files, queryFn: () => gateway.listKnowledgeFiles() });
  const memoryStores = useQuery({ queryKey: projectKeys.memoryStores, queryFn: () => gateway.listMemoryStores() });
  const vaults = useQuery({ queryKey: projectKeys.vaults, queryFn: () => gateway.listVaults() });
  const runs = useQuery({
    queryKey: projectKeys.runs(selectedProjectId ?? "none"),
    queryFn: () => gateway.listProjectRuns(selectedProjectId ?? ""),
    enabled: Boolean(selectedProjectId),
  });
  const refresh = () => cache.invalidateQueries({ queryKey: projectKeys.all });
  const create = useMutation({ mutationFn: (input: ProjectCommand) => gateway.createProject(input), onSuccess: refresh });
  const update = useMutation({ mutationFn: ({ id, input }: { id: string; input: ProjectCommand }) => gateway.updateProject(id, input), onSuccess: refresh });
  const archive = useMutation({ mutationFn: (id: string) => gateway.archiveProject(id), onSuccess: refresh });
  const pause = useMutation({ mutationFn: (id: string) => gateway.pauseProject(id), onSuccess: refresh });
  const unpause = useMutation({ mutationFn: (id: string) => gateway.unpauseProject(id), onSuccess: refresh });
  const uploadFile = useMutation({
    mutationFn: (file: File) => gateway.uploadKnowledgeFile(file),
    onSuccess: () => cache.invalidateQueries({ queryKey: projectKeys.files }),
  });
  const createMemoryStore = useMutation({
    mutationFn: (input: MemoryStoreCommand) => gateway.createMemoryStore(input),
    onSuccess: () => cache.invalidateQueries({ queryKey: projectKeys.memoryStores }),
  });
  const createAgentProfile = useMutation({
    mutationFn: (input: import("../infrastructure/gateway").AgentProfileCommand) => gateway.createAgentProfile(input),
    onSuccess: () => cache.invalidateQueries({ queryKey: projectKeys.agents }),
  });
  const run = useMutation({
    mutationFn: (id: string) => gateway.runProject(id),
    onSuccess: async () => {
      await refresh();
      if (selectedProjectId) await cache.invalidateQueries({ queryKey: projectKeys.runs(selectedProjectId) });
      await cache.invalidateQueries({ queryKey: missionKeys.all });
    },
  });
  return {
    projects, agents, environments, files, memoryStores, vaults, runs,
    create, update, archive, pause, unpause, uploadFile, createMemoryStore, createAgentProfile, run,
  };
}
