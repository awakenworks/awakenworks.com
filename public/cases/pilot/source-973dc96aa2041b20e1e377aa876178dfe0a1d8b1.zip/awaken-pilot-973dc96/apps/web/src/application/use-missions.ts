import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { CreateMissionInput, PilotGateway } from "../infrastructure/gateway";

export const missionKeys = {
  all: ["missions"] as const,
  detail: (id: string) => ["missions", id] as const,
  events: (id: string) => ["missions", id, "events"] as const,
  threads: (id: string) => ["missions", id, "threads"] as const,
  artifacts: (id: string) => ["missions", id, "artifacts"] as const,
};

export function useMissions(gateway: PilotGateway) {
  const cache = useQueryClient();
  const list = useQuery({ queryKey: missionKeys.all, queryFn: () => gateway.listMissions() });
  const create = useMutation({
    mutationFn: (input: CreateMissionInput) => gateway.createMission(input),
    onSuccess: (mission) => {
      cache.setQueryData(missionKeys.detail(mission.id), mission);
      void cache.invalidateQueries({ queryKey: missionKeys.all });
    },
  });
  return { list, create };
}
