import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
import { createElement } from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { awakenPilotReferenceCase } from "./reference-case";
import { ReferenceCaseLink } from "./ui/ReferenceCaseLink";

afterEach(cleanup);

/**
 * Reference-case decision table.
 * Causes: C1 Pilot is presented as a first-party thin application; C2 one
 * Mission maps to one Awaken Managed Session; C3 a reader follows the case
 * link; C4 the link names a useful reason to inspect the case. Effects: E1
 * Pilot is not presented as another runtime; E2 execution
 * ownership stays with Awaken; E3 the reader reaches the canonical portfolio
 * page where the other adoption paths are visible. Constraint: this metadata
 * is presentation only and must not introduce a runtime or persistence path.
 * Rule R1: C1+C2+C3+C4 => E1+E2+E3.
 */
describe("Awaken Pilot reference-case contract", () => {
  it("R1 identifies the thin-app boundary and canonical case route", () => {
    expect(awakenPilotReferenceCase).toMatchObject({
      kind: "First-party Reference App",
      adoption: "Thin Agent application",
      summary: "One Mission is one Awaken Managed Session.",
      readerPromise: "See how a person can step in without splitting the Session.",
      caseUrl: "https://awakenworks.com/cases/pilot",
      portfolioUrl: "https://awakenworks.com/cases",
    });
    expect(awakenPilotReferenceCase.awakenTruth).toContain("execution");
    expect(awakenPilotReferenceCase.applicationTruth).not.toContain("execution");

    render(createElement(ReferenceCaseLink));
    const link = screen.getByRole("link", { name: "Read the Awaken Pilot reference case" });
    expect(link).toHaveAttribute("href", awakenPilotReferenceCase.caseUrl);
    expect(link).toHaveTextContent("See how a person can step in without splitting the Session.");
  });
});

/**
 * Fixed-source build-input graph: C1 source archive has no Git or sibling
 * checkout; C2 each admitted shared archive is included; C3 bytes match the
 * recorded SHA-256; C4 the consumer resolves to the archive via package/lock.
 * E1 all shared owners remain build inputs; E2 a changed/missing archive fails
 * qualification; E3 no copied reducer/UI source becomes an alternate owner.
 * R-P1 C1+C2+C3+C4 -> install/typecheck/test/build in an isolated source archive;
 * R-P2 !C2 or !C3 -> reject here. The real clean-install qualification runs the
 * same existing pnpm checks outside the worktree; this assertion keeps the
 * recorded input evidence bound to bytes on later changes.
 */
it("R-P2 binds every shared build archive to its recorded digest", () => {
  const record = readFileSync(resolve(process.cwd(), "../../vendor/README.md"), "utf8");
  const rows = [...record.matchAll(/\| `([^`]+\.tgz)` \|[^\n]+\| `([a-f0-9]{64})` \|/g)];
  expect(rows.length).toBeGreaterThanOrEqual(2);
  for (const [, filename, expected] of rows) {
    const bytes = readFileSync(resolve(process.cwd(), "../../vendor", filename!));
    expect(createHash("sha256").update(bytes).digest("hex"), filename).toBe(expected);
  }
});
