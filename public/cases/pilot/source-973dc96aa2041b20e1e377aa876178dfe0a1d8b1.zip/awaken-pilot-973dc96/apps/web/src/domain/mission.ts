import {
  mergeCommittedEvents,
  type ManagedEvent,
  type ManagedStreamEvent,
} from "@awaken/managed-session-projection";

export type MissionEvent = ManagedEvent;
export type StreamEvent = ManagedStreamEvent;
export type MissionStatus = "idle" | "running" | "rescheduling" | "terminated" | "error" | "unknown";
export type PlanStepStatus = "pending" | "in_progress" | "completed" | "blocked";

export interface PlanStep {
  id: string;
  title: string;
  status: PlanStepStatus;
  detail?: string;
}

export interface MissionPlan {
  summary: string;
  steps: PlanStep[];
  eventId: string;
}

export interface MissionResult {
  summary: string;
  artifacts: Array<{ path: string; description?: string }>;
  eventId: string;
}

export interface MissionNotification {
  level: "info" | "warning" | "success";
  message: string;
  eventId: string;
}

export interface PendingApproval {
  id: string;
  name: string;
  input: unknown;
  sessionThreadId?: string;
}

export interface TranscriptMessage {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  processedAt?: string;
}

export interface TranscriptTool {
  id: string;
  name: string;
  input: unknown;
  output?: unknown;
  state: "running" | "done" | "error";
  processedAt?: string;
}

export interface MissionProjection {
  status: MissionStatus;
  messages: TranscriptMessage[];
  tools: TranscriptTool[];
  pendingApprovals: PendingApproval[];
  notifications: MissionNotification[];
  plan?: MissionPlan;
  planApproved: boolean;
  result?: MissionResult;
  error?: string;
}

export const PLAN_APPROVAL_MESSAGE = "Approve this plan and execute it.";

type ObjectValue = Record<string, unknown>;

const asObject = (value: unknown): ObjectValue | undefined =>
  typeof value === "object" && value !== null && !Array.isArray(value) ? value as ObjectValue : undefined;

export function textContent(content: unknown): string {
  if (!Array.isArray(content)) return "";
  return content.flatMap((block) => {
    const item = asObject(block);
    return item?.type === "text" && typeof item.text === "string" ? [item.text] : [];
  }).join("\n");
}

function isPlanStep(value: unknown): value is PlanStep {
  const item = asObject(value);
  return Boolean(
    item && typeof item.id === "string" && typeof item.title === "string" &&
    ["pending", "in_progress", "completed", "blocked"].includes(String(item.status)) &&
    (item.detail === undefined || typeof item.detail === "string"),
  );
}

function planFrom(input: unknown, eventId: string): MissionPlan | undefined {
  const value = asObject(input);
  if (!value || typeof value.summary !== "string" || !Array.isArray(value.steps) || !value.steps.every(isPlanStep)) return undefined;
  return { summary: value.summary, steps: value.steps, eventId };
}

function resultFrom(input: unknown, eventId: string): MissionResult | undefined {
  const value = asObject(input);
  if (!value || typeof value.summary !== "string") return undefined;
  const artifacts = Array.isArray(value.artifacts) ? value.artifacts.flatMap((raw) => {
    const artifact = asObject(raw);
    if (!artifact || typeof artifact.path !== "string") return [];
    return [{ path: artifact.path, ...(typeof artifact.description === "string" ? { description: artifact.description } : {}) }];
  }) : [];
  return { summary: value.summary, artifacts, eventId };
}

function notificationFrom(input: unknown, eventId: string): MissionNotification | undefined {
  const value = asObject(input);
  if (!value || !["info", "warning", "success"].includes(String(value.level)) || typeof value.message !== "string") return undefined;
  return { level: value.level as MissionNotification["level"], message: value.message, eventId };
}

function toolResultId(event: ObjectValue): string | undefined {
  if (typeof event.tool_use_id === "string") return event.tool_use_id;
  if (typeof event.mcp_tool_use_id === "string") return event.mcp_tool_use_id;
  return undefined;
}

function isPilotTool(name: string, tool: string): boolean {
  return name === tool || name === `mcp__pilot__${tool}` || name === `mcp.pilot.${tool}`;
}

function pilotToolInput(name: string, tool: string, input: unknown): unknown {
  if (name !== `mcp.pilot.${tool}`) return input;
  const envelope = asObject(input);
  return envelope?.server === "pilot" && envelope.tool === tool ? envelope.arguments : input;
}

export function projectMission(events: readonly MissionEvent[]): MissionProjection {
  const committed = mergeCommittedEvents([], events);
  const resultByTool = new Map<string, ObjectValue>();
  const confirmations = new Set<string>();
  for (const event of committed) {
    const value = event as unknown as ObjectValue;
    const id = toolResultId(value);
    if (id) resultByTool.set(id, value);
    if (event.type === "user.tool_confirmation" && typeof value.tool_use_id === "string") confirmations.add(value.tool_use_id);
  }

  let status: MissionStatus = "unknown";
  let plan: MissionPlan | undefined;
  let planApproved = false;
  let result: MissionResult | undefined;
  let error: string | undefined;
  const messages: TranscriptMessage[] = [];
  const tools: TranscriptTool[] = [];
  const pendingApprovals: PendingApproval[] = [];
  const notifications: MissionNotification[] = [];

  for (const event of committed) {
    const value = event as unknown as ObjectValue;
    if (event.type === "session.status_running") status = "running";
    else if (event.type === "session.status_idle") status = "idle";
    else if (event.type === "session.status_rescheduled") status = "rescheduling";
    else if (event.type === "session.status_terminated") status = "terminated";
    else if (event.type === "session.error") {
      status = "error";
      const nested = asObject(value.error);
      error = typeof nested?.message === "string" ? nested.message : "The mission failed without an error message.";
    }

    if (["user.message", "agent.message", "system.message"].includes(event.type)) {
      const text = textContent(value.content);
      if (event.type === "user.message" && plan && text.trim() === PLAN_APPROVAL_MESSAGE) planApproved = true;
      if (text) messages.push({
        id: event.id,
        role: event.type === "user.message" ? "user" : event.type === "agent.message" ? "assistant" : "system",
        text,
        ...(typeof value.processed_at === "string" ? { processedAt: value.processed_at } : {}),
      });
    }

    if (event.type === "agent.tool_use" || event.type === "agent.mcp_tool_use" || event.type === "agent.custom_tool_use") {
      const name = typeof value.name === "string" ? value.name : "tool";
      const matched = resultByTool.get(event.id);
      const failed = matched?.is_error === true;
      tools.push({
        id: event.id,
        name,
        input: value.input,
        ...(matched ? { output: matched.content } : {}),
        state: matched ? failed ? "error" : "done" : "running",
        ...(typeof value.processed_at === "string" ? { processedAt: value.processed_at } : {}),
      });
      if (value.evaluated_permission === "ask" && !confirmations.has(event.id)) {
        pendingApprovals.push({
          id: event.id,
          name,
          input: value.input,
          ...(typeof value.session_thread_id === "string" ? { sessionThreadId: value.session_thread_id } : {}),
        });
      }
      if (matched && !failed && isPilotTool(name, "set_plan")) {
        const nextPlan = planFrom(pilotToolInput(name, "set_plan", value.input), event.id);
        if (nextPlan) {
          plan = nextPlan;
          planApproved = false;
        }
      }
      if (matched && !failed && isPilotTool(name, "notify_user")) {
        const notification = notificationFrom(pilotToolInput(name, "notify_user", value.input), event.id);
        if (notification) notifications.push(notification);
      }
      if (matched && !failed && isPilotTool(name, "publish_result")) {
        result = resultFrom(pilotToolInput(name, "publish_result", value.input), event.id) ?? result;
      }
    }
  }

  return {
    status,
    messages,
    tools,
    pendingApprovals,
    notifications,
    planApproved,
    ...(plan ? { plan } : {}),
    ...(result ? { result } : {}),
    ...(error ? { error } : {}),
  };
}
