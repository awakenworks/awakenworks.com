export const awakenPilotReferenceCase = Object.freeze({
  kind: "First-party Reference App",
  adoption: "Thin Agent application",
  label: "Built on Awaken",
  summary: "One Mission is one Awaken Managed Session.",
  readerPromise: "See how a person can step in without splitting the Session.",
  caseUrl: "https://awakenworks.com/cases/pilot",
  portfolioUrl: "https://awakenworks.com/cases",
  applicationTruth: ["Mission interaction", "acceptance criteria", "product projections"],
  awakenTruth: ["Session", "execution", "Worker", "Sandbox", "recovery"],
});
