import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { PLAN_APPROVAL_MESSAGE } from "../domain/mission";
import { useMission } from "../application/use-mission";
import { MissionDetail } from "./MissionDetail";

vi.mock("../application/use-mission", () => ({ useMission: vi.fn() }));
afterEach(cleanup);

/**
 * Plan review UI cause-effect table:
 * P1 Mission metadata is Plan Mode + current plan unapproved -> E1 expose one
 * approval action that appends the canonical user event.
 * P2 current plan already approved -> E2 hide the action, preventing duplicate
 * approval events. P3 Session outcome evaluation exists -> E3 display its exact
 * upstream result, iteration and explanation. Rules R1=P1; R2=P1+P2; R3=P3. Approval state is projected only from
 * the Session event log; this component owns no review-status store. P4 an
 * authenticated Workspace route supplies sharing -> E4 expose one team-link copy
 * action; authorization still happens when the recipient loads the Session. P5
 * IAM-backed public controls supplied -> E5 create/rotate and revoke through the
 * application service, never local component state.
 */
describe("Plan Mode review decision table", () => {
  const state = (planApproved: boolean) => ({
    mission: { isLoading: false, error: null, data: { id: "sesn_1", title: "Plan", status: "idle", archived_at: null, metadata: { pilot_mode: "plan" }, outcome_evaluations: [] } },
    events: { isLoading: false, error: null },
    projection: {
      status: "idle", messages: [], tools: [], pendingApprovals: [], notifications: [],
      plan: { summary: "Safe rollout", eventId: "plan_1", steps: [{ id: "one", title: "Canary", status: "pending" }] },
      planApproved,
    },
    preview: { text: "", thinking: false },
    threads: { data: [] }, artifacts: { data: [] },
    send: { isPending: false, mutate: vi.fn() },
    archive: { mutate: vi.fn() }, interrupt: { mutate: vi.fn() }, decide: { isPending: false, mutate: vi.fn() },
    refresh: vi.fn(),
  });

  it("R1 records approval as the canonical user event", async () => {
    const current = state(false);
    vi.mocked(useMission).mockReturnValue(current as never);
    render(<MissionDetail id="sesn_1" gateway={{} as never} />);
    await userEvent.setup().click(screen.getByRole("button", { name: "Approve and execute" }));
    expect(current.send.mutate).toHaveBeenCalledWith(PLAN_APPROVAL_MESSAGE);
  });

  it("R2 hides approval after the event-log projection marks it approved", () => {
    vi.mocked(useMission).mockReturnValue(state(true) as never);
    render(<MissionDetail id="sesn_1" gateway={{} as never} />);
    expect(screen.queryByRole("button", { name: "Approve and execute" })).not.toBeInTheDocument();
  });

  it("R3 projects the upstream outcome evaluation without a quality store", () => {
    const current = state(true);
    current.mission.data.outcome_evaluations = [{
      outcome_id: "outc_1", result: "needs_revision", iteration: 1,
      description: "Write the brief", explanation: "One claim lacks a source.",
    }] as never;
    vi.mocked(useMission).mockReturnValue(current as never);
    render(<MissionDetail id="sesn_1" gateway={{} as never} />);
    expect(screen.getByText("needs revision")).toBeInTheDocument();
    expect(screen.getByText("One claim lacks a source.")).toBeInTheDocument();
  });

  it("R4 exposes the Workspace team link without copying Mission state", async () => {
    const onShare = vi.fn(async () => undefined);
    vi.mocked(useMission).mockReturnValue(state(true) as never);
    render(<MissionDetail id="sesn_1" gateway={{} as never} onShare={onShare} />);
    await userEvent.setup().click(screen.getByRole("button", { name: "Copy team link" }));
    expect(onShare).toHaveBeenCalledOnce();
  });

  it("R5 delegates public-link rotation and revocation without storing authority", async () => {
    const onPublicShare = vi.fn(async () => undefined);
    const onRevokePublicShare = vi.fn(async () => undefined);
    vi.mocked(useMission).mockReturnValue(state(true) as never);
    render(<MissionDetail id="sesn_1" gateway={{} as never} onPublicShare={onPublicShare} onRevokePublicShare={onRevokePublicShare} />);
    await userEvent.setup().click(screen.getByRole("button", { name: "Copy public link" }));
    await userEvent.setup().click(screen.getByRole("button", { name: "Revoke public link" }));
    expect(onPublicShare).toHaveBeenCalledOnce();
    expect(onRevokePublicShare).toHaveBeenCalledOnce();
  });
});
