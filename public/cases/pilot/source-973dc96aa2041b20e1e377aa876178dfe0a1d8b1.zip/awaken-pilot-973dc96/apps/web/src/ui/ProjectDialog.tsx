import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import type { FileMetadata } from "@anthropic-ai/sdk/resources/beta/files";
import type { BetaEnvironment } from "@anthropic-ai/sdk/resources/beta/environments/environments";
import type { BetaManagedAgentsMemoryStore } from "@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores";
import type { BetaManagedAgentsVault } from "@anthropic-ai/sdk/resources/beta/vaults/vaults";
import { Button, CheckboxField, CheckPicker, Dialog, Field, InlineNotice, SelectField, TextAreaField, TextField } from "@awaken/ui";
import { useState } from "react";
import { projectCommandFrom } from "../domain/project";
import { agentCapabilityGroups } from "../domain/agent-capabilities";
import type { MemoryStoreCommand, ProjectCommand } from "../infrastructure/gateway";

interface ProjectDraft {
  name: string;
  instruction: string;
  agentId: string;
  environmentId: string;
  vaultIds: string[];
  fileIds: string[];
  memoryStoreIds: string[];
  budgetUsd: string;
  scheduled: boolean;
  scheduledPrompt: string;
  cronExpression: string;
  timezone: string;
}

function initialDraft(project: BetaManagedAgentsDeployment | undefined): ProjectDraft {
  const command = project ? projectCommandFrom(project) : undefined;
  return {
    name: command?.name ?? "",
    instruction: command?.instruction ?? "",
    agentId: command?.agentId ?? "",
    environmentId: command?.environmentId ?? "",
    vaultIds: command?.vaultIds ?? [],
    fileIds: command?.fileIds ?? [],
    memoryStoreIds: command?.memoryStoreIds ?? [],
    budgetUsd: command?.budgetUsdCents ? String(command.budgetUsdCents / 100) : "",
    scheduled: Boolean(command?.schedule),
    scheduledPrompt: command?.schedule?.prompt ?? "",
    cronExpression: command?.schedule?.expression ?? "0 9 * * 1-5",
    timezone: command?.schedule?.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone ?? "UTC",
  };
}

function toCommand(draft: ProjectDraft): ProjectCommand {
  const budget = draft.budgetUsd.trim() ? Number(draft.budgetUsd) : null;
  return {
    name: draft.name,
    instruction: draft.instruction,
    agentId: draft.agentId,
    environmentId: draft.environmentId,
    vaultIds: draft.vaultIds,
    fileIds: draft.fileIds,
    memoryStoreIds: draft.memoryStoreIds,
    budgetUsdCents: budget === null ? null : Math.round(budget * 100),
    schedule: draft.scheduled ? {
      prompt: draft.scheduledPrompt,
      expression: draft.cronExpression,
      timezone: draft.timezone,
    } : null,
  };
}

function pickerOptions<T extends { id: string }>(items: T[], selected: string[], label: (item: T) => string, description: (item: T) => string) {
  const known = new Set(items.map((item) => item.id));
  return [
    ...items.map((item) => ({ id: item.id, label: label(item), description: description(item) })),
    ...selected.filter((id) => !known.has(id)).map((id) => ({ id, label: id, description: "Referenced by this Project; metadata is unavailable." })),
  ];
}

export function ProjectDialog({ open, project, agents, environments, files, memoryStores, vaults, pending, onClose, onSave, onUploadFile, onCreateMemoryStore, onArchive }: {
  open: boolean;
  project?: BetaManagedAgentsDeployment;
  agents: BetaManagedAgentsAgent[];
  environments: BetaEnvironment[];
  files: FileMetadata[];
  memoryStores: BetaManagedAgentsMemoryStore[];
  vaults: BetaManagedAgentsVault[];
  pending: boolean;
  onClose: () => void;
  onSave: (command: ProjectCommand) => void;
  onUploadFile: (file: File) => Promise<FileMetadata>;
  onCreateMemoryStore: (input: MemoryStoreCommand) => Promise<BetaManagedAgentsMemoryStore>;
  onArchive?: () => void;
}) {
  const [draft, setDraft] = useState(() => initialDraft(project));
  const [memoryName, setMemoryName] = useState("");
  const [memoryDescription, setMemoryDescription] = useState("");
  const [resourceError, setResourceError] = useState<string>();
  const update = (field: keyof ProjectDraft) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setDraft((current) => ({ ...current, [field]: event.target.value }));
  const validBudget = !draft.budgetUsd.trim() || (Number.isFinite(Number(draft.budgetUsd)) && Number(draft.budgetUsd) > 0);
  const validSchedule = !draft.scheduled || Boolean(draft.scheduledPrompt.trim() && draft.cronExpression.trim() && draft.timezone.trim());
  const canSave = Boolean(draft.name.trim() && draft.instruction.trim() && draft.agentId && draft.environmentId && validBudget && validSchedule);
  const selectedAgent = agents.find((agent) => agent.id === draft.agentId);
  const capabilityGroups = selectedAgent ? agentCapabilityGroups(selectedAgent) : [];
  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setResourceError(undefined);
    try {
      const uploaded = await onUploadFile(file);
      setDraft((current) => ({ ...current, fileIds: [...new Set([...current.fileIds, uploaded.id])] }));
    } catch (error) {
      setResourceError(error instanceof Error ? error.message : "File upload failed");
    }
  };
  const createMemory = async () => {
    if (!memoryName.trim()) return;
    setResourceError(undefined);
    try {
      const store = await onCreateMemoryStore({ name: memoryName, description: memoryDescription });
      setDraft((current) => ({ ...current, memoryStoreIds: [...new Set([...current.memoryStoreIds, store.id])] }));
      setMemoryName("");
      setMemoryDescription("");
    } catch (error) {
      setResourceError(error instanceof Error ? error.message : "Memory Store creation failed");
    }
  };
  return <Dialog
    open={open}
    onOpenChange={(next) => { if (!next) onClose(); }}
    title={project ? "Edit project" : "New project"}
    closeLabel="Close project editor"
    description="A Project is one Awaken Deployment: shared instructions, capabilities, resources, budget, and optional schedule stay in one authoritative configuration."
    footer={<>
      {onArchive ? <Button variant="ghost" onClick={onArchive} disabled={pending}>Archive</Button> : null}
      <Button variant="ghost" onClick={onClose}>Cancel</Button>
      <Button variant="primary" onClick={() => onSave(toCommand(draft))} loading={pending} disabled={!canSave}>Save project</Button>
    </>}
  >
    <div className="settings-grid">
      <TextField label="Project name" value={draft.name} onChange={update("name")} placeholder="Weekly competitive intelligence" />
      <TextAreaField label="Master instruction" value={draft.instruction} onChange={update("instruction")} rows={5} placeholder="Define the standing context, standards, and constraints for every mission." />
      <SelectField label="Agent" value={draft.agentId} onChange={update("agentId")}>
        <option value="">Choose an agent</option>
        {agents.map((agent) => <option key={agent.id} value={agent.id}>{agent.name} · v{agent.version}</option>)}
      </SelectField>
      {selectedAgent ? <section className="agent-capabilities" aria-label="Agent capabilities">
        <header><strong>{selectedAgent.name} capabilities</strong><small>Version {selectedAgent.version} · owned and executed by Awaken</small></header>
        {capabilityGroups.length ? <dl>{capabilityGroups.map((group) => <div key={group.id}><dt>{group.label}</dt><dd>{group.values.map((value) => <span key={value}>{value}</span>)}</dd></div>)}</dl>
          : <p>No tools, Skills, connectors, or parallel-agent roster are configured.</p>}
      </section> : null}
      <SelectField label="Environment" value={draft.environmentId} onChange={update("environmentId")}>
        <option value="">Choose an environment</option>
        {environments.map((environment) => <option key={environment.id} value={environment.id}>{environment.name}</option>)}
      </SelectField>
      <Field label="Connector credentials" labelAs="div" help="Select Awaken Vaults whose credentials match this Agent's MCP servers. Pilot receives only secret-free metadata.">
        {() => <CheckPicker
          options={pickerOptions(vaults, draft.vaultIds, (vault) => vault.display_name, (vault) => vault.id)}
          selected={draft.vaultIds}
          onChange={(vaultIds) => setDraft((current) => ({ ...current, vaultIds }))}
          empty="No active Awaken Vaults are available. Configure connector credentials in Awaken first."
        />}
      </Field>
      {resourceError ? <InlineNotice tone="danger" title="Could not update Project resources">{resourceError}</InlineNotice> : null}
      <Field label="Knowledge files" labelAs="div" help="Workspace Files selected here are mounted into every new mission." action={<label className="file-upload-action">Upload file<input aria-label="Upload knowledge file" type="file" onChange={upload} disabled={pending} /></label>}>
        {() => <CheckPicker
          options={pickerOptions(files, draft.fileIds, (file) => file.filename, (file) => `${file.mime_type} · ${file.size_bytes.toLocaleString()} bytes`)}
          selected={draft.fileIds}
          onChange={(fileIds) => setDraft((current) => ({ ...current, fileIds }))}
          empty="No reusable workspace files yet."
        />}
      </Field>
      <Field label="Project memory" labelAs="div" help="Awaken Memory Stores are mounted read/write; Pilot keeps no parallel memory database.">
        {() => <CheckPicker
          options={pickerOptions(memoryStores, draft.memoryStoreIds, (store) => store.name, (store) => store.description || store.id)}
          selected={draft.memoryStoreIds}
          onChange={(memoryStoreIds) => setDraft((current) => ({ ...current, memoryStoreIds }))}
          empty="No Memory Stores yet."
        />}
      </Field>
      <div className="memory-store-create">
        <TextField label="New Memory Store name" value={memoryName} onChange={(event) => setMemoryName(event.target.value)} placeholder="Research desk memory" />
        <TextField label="Memory guidance (optional)" value={memoryDescription} onChange={(event) => setMemoryDescription(event.target.value)} placeholder="Facts and preferences shared across this Project" />
        <Button variant="ghost" onClick={createMemory} loading={pending} disabled={!memoryName.trim()}>Create and select memory</Button>
      </div>
      <TextField label="Per-mission budget in USD (optional)" type="number" min="0.01" step="0.01" value={draft.budgetUsd} onChange={update("budgetUsd")} error={validBudget ? undefined : "Enter a positive amount."} />
      <CheckboxField label="Run on a schedule" checked={draft.scheduled} onChange={(event) => setDraft((current) => ({ ...current, scheduled: event.target.checked }))} help="Awaken owns the durable cron, wakeup, retries, and run history." />
      {draft.scheduled ? <div className="schedule-fields">
        <TextAreaField label="Scheduled direction" value={draft.scheduledPrompt} onChange={update("scheduledPrompt")} rows={3} placeholder="Describe the recurring work and expected output." />
        <TextField label="Cron expression" value={draft.cronExpression} onChange={update("cronExpression")} placeholder="0 9 * * 1-5" help="Five-field POSIX cron: minute, hour, day, month, weekday." />
        <TextField label="Timezone" value={draft.timezone} onChange={update("timezone")} placeholder="Asia/Shanghai" />
      </div> : null}
    </div>
  </Dialog>;
}
