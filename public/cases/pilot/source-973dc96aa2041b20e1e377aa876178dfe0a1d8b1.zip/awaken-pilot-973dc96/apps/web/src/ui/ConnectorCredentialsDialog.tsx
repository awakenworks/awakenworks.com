import type { BetaManagedAgentsCredential, BetaManagedAgentsCredentialValidation } from "@anthropic-ai/sdk/resources/beta/vaults/credentials";
import type { BetaManagedAgentsVault } from "@anthropic-ai/sdk/resources/beta/vaults/vaults";
import { Button, CheckboxField, Dialog, InlineNotice, SelectField, TextField } from "@awaken/ui";
import { useState } from "react";
import type { VaultCommand, VaultCredentialCommand } from "../infrastructure/gateway";

type CredentialType = VaultCredentialCommand["auth"]["type"];
type OAuthAuthType = "none" | "client_secret_basic" | "client_secret_post";

function credentialTarget(credential: BetaManagedAgentsCredential): string {
  if (credential.auth.type === "environment_variable") return credential.auth.secret_name;
  return credential.auth.mcp_server_url;
}

export function ConnectorCredentialsDialog({ open, vaults, selectedVaultId, credentials, pending, error, validation, onSelectVault, onClose, onCreateVault, onCreateCredential, onValidate }: {
  open: boolean;
  vaults: BetaManagedAgentsVault[];
  selectedVaultId?: string;
  credentials: BetaManagedAgentsCredential[];
  pending: boolean;
  error?: Error;
  validation?: BetaManagedAgentsCredentialValidation;
  onSelectVault: (id: string | undefined) => void;
  onClose: () => void;
  onCreateVault: (input: VaultCommand) => Promise<BetaManagedAgentsVault>;
  onCreateCredential: (vaultId: string, input: VaultCredentialCommand) => Promise<BetaManagedAgentsCredential>;
  onValidate: (vaultId: string, credentialId: string) => Promise<BetaManagedAgentsCredentialValidation>;
}) {
  const [vaultName, setVaultName] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [type, setType] = useState<CredentialType>("static_bearer");
  const [mcpServerUrl, setMcpServerUrl] = useState("");
  const [secret, setSecret] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [refreshEnabled, setRefreshEnabled] = useState(false);
  const [clientId, setClientId] = useState("");
  const [refreshToken, setRefreshToken] = useState("");
  const [tokenEndpoint, setTokenEndpoint] = useState("");
  const [oauthAuthType, setOauthAuthType] = useState<OAuthAuthType>("none");
  const [clientSecret, setClientSecret] = useState("");
  const [scope, setScope] = useState("");
  const [resource, setResource] = useState("");
  const [secretName, setSecretName] = useState("");
  const [allowedHosts, setAllowedHosts] = useState("");
  const [unrestricted, setUnrestricted] = useState(false);
  const [injectHeader, setInjectHeader] = useState(true);
  const [injectBody, setInjectBody] = useState(false);
  const canCreate = Boolean(selectedVaultId && displayName.trim() && secret && (type === "environment_variable" ? secretName.trim() : mcpServerUrl.trim()));
  const createVault = async () => {
    const vault = await onCreateVault({ displayName: vaultName });
    setVaultName("");
    onSelectVault(vault.id);
  };
  const createCredential = async () => {
    if (!selectedVaultId || !canCreate) return;
    let auth: VaultCredentialCommand["auth"];
    if (type === "static_bearer") {
      auth = { type, mcpServerUrl, token: secret };
    } else if (type === "mcp_oauth") {
      const tokenEndpointAuth = oauthAuthType === "none"
        ? { type: "none" as const }
        : { type: oauthAuthType, clientSecret };
      auth = {
        type,
        mcpServerUrl,
        accessToken: secret,
        expiresAt: expiresAt.trim() ? new Date(expiresAt).toISOString() : null,
        refresh: refreshEnabled ? {
          clientId,
          refreshToken,
          tokenEndpoint,
          tokenEndpointAuth,
          scope: scope.trim() || null,
          resource: resource.trim() || null,
        } : null,
      };
    } else {
      auth = {
        type,
        secretName,
        secretValue: secret,
        allowedHosts: allowedHosts.split(",").map((host) => host.trim()).filter(Boolean),
        unrestricted,
        injectHeader,
        injectBody,
      };
    }
    await onCreateCredential(selectedVaultId, { displayName, auth });
    setDisplayName("");
    setSecret("");
    setRefreshToken("");
    setClientSecret("");
  };
  return <Dialog
    open={open}
    onOpenChange={(next) => { if (!next) onClose(); }}
    title="Connector credentials"
    closeLabel="Close Connector credentials"
    description="Secrets are sent once to the official Awaken Vault API. Pilot stores no credential material and receives only redacted metadata."
    footer={<Button variant="ghost" onClick={onClose}>Close</Button>}
  >
    <div className="settings-grid">
      {error ? <InlineNotice tone="danger" title="Credential request failed">{error.message}</InlineNotice> : null}
      {validation ? <InlineNotice tone={validation.status === "valid" ? "success" : "warning"} title={`Live validation: ${validation.status}`}>
        {validation.mcp_probe ? `Failed at ${validation.mcp_probe.method}.` : "The MCP credential probe completed."}
      </InlineNotice> : null}
      <section className="vault-create" aria-label="Create Vault">
        <TextField label="New Vault name" value={vaultName} onChange={(event) => setVaultName(event.target.value)} placeholder="Business connectors" />
        <Button variant="ghost" onClick={createVault} loading={pending} disabled={!vaultName.trim()}>Create Vault</Button>
      </section>
      <SelectField label="Vault" value={selectedVaultId ?? ""} onChange={(event) => onSelectVault(event.target.value || undefined)}>
        <option value="">Choose a Vault</option>
        {vaults.map((vault) => <option key={vault.id} value={vault.id}>{vault.display_name}</option>)}
      </SelectField>
      {selectedVaultId ? <>
        <section className="credential-list" aria-label="Vault credentials">
          <h3>Redacted credentials</h3>
          {credentials.length ? credentials.map((credential) => <article key={credential.id}>
            <span><strong>{credential.display_name || credential.id}</strong><small>{credential.auth.type} · {credentialTarget(credential)}</small></span>
            {credential.auth.type === "mcp_oauth" ? <Button variant="ghost" onClick={() => onValidate(selectedVaultId, credential.id)} loading={pending}>Validate {credential.display_name || credential.id}</Button> : null}
          </article>) : <p>No active credentials in this Vault.</p>}
        </section>
        <h3>Add write-only credential</h3>
        <TextField label="Credential name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
        <SelectField label="Credential type" value={type} onChange={(event) => setType(event.target.value as CredentialType)}>
          <option value="static_bearer">MCP static bearer</option>
          <option value="mcp_oauth">MCP OAuth token</option>
          <option value="environment_variable">Environment variable</option>
        </SelectField>
        {type === "environment_variable" ? <>
          <TextField label="Secret environment name" value={secretName} onChange={(event) => setSecretName(event.target.value)} placeholder="STRIPE_API_KEY" />
          <TextField label="Allowed hosts" value={allowedHosts} onChange={(event) => setAllowedHosts(event.target.value)} placeholder="api.stripe.com" help="Comma-separated hostnames; leave empty only with unrestricted enabled." />
          <CheckboxField label="Allow on every host permitted by the Environment" checked={unrestricted} onChange={(event) => setUnrestricted(event.target.checked)} />
          <CheckboxField label="Substitute in request headers" checked={injectHeader} onChange={(event) => setInjectHeader(event.target.checked)} />
          <CheckboxField label="Substitute in request bodies" checked={injectBody} onChange={(event) => setInjectBody(event.target.checked)} />
        </> : <TextField label="MCP server URL" value={mcpServerUrl} onChange={(event) => setMcpServerUrl(event.target.value)} placeholder="https://connector.example/mcp" />}
        <TextField label={type === "mcp_oauth" ? "OAuth access token" : type === "static_bearer" ? "Bearer token" : "Secret value"} type="password" value={secret} onChange={(event) => setSecret(event.target.value)} autoComplete="new-password" />
        {type === "mcp_oauth" ? <>
          <TextField label="Token expiry (optional)" type="datetime-local" value={expiresAt} onChange={(event) => setExpiresAt(event.target.value)} />
          <CheckboxField label="Configure refresh token" checked={refreshEnabled} onChange={(event) => setRefreshEnabled(event.target.checked)} />
          {refreshEnabled ? <>
            <TextField label="OAuth client ID" value={clientId} onChange={(event) => setClientId(event.target.value)} />
            <TextField label="OAuth refresh token" type="password" value={refreshToken} onChange={(event) => setRefreshToken(event.target.value)} autoComplete="new-password" />
            <TextField label="OAuth token endpoint" value={tokenEndpoint} onChange={(event) => setTokenEndpoint(event.target.value)} />
            <SelectField label="Token endpoint authentication" value={oauthAuthType} onChange={(event) => setOauthAuthType(event.target.value as OAuthAuthType)}>
              <option value="none">Public client</option>
              <option value="client_secret_basic">Client secret basic</option>
              <option value="client_secret_post">Client secret post</option>
            </SelectField>
            {oauthAuthType !== "none" ? <TextField label="OAuth client secret" type="password" value={clientSecret} onChange={(event) => setClientSecret(event.target.value)} autoComplete="new-password" /> : null}
            <TextField label="OAuth scope (optional)" value={scope} onChange={(event) => setScope(event.target.value)} />
            <TextField label="OAuth resource (optional)" value={resource} onChange={(event) => setResource(event.target.value)} />
          </> : null}
        </> : null}
        <Button variant="primary" onClick={createCredential} loading={pending} disabled={!canCreate}>Store credential in Awaken</Button>
      </> : null}
    </div>
  </Dialog>;
}
