import { describe, expect, it, vi } from "vitest";
import { purgeLegacyMissionDefaults } from "./legacy-settings";

/**
 * Legacy consolidation causes and effects:
 * L1 obsolete v1/v2 Mission-default keys may exist -> E1 remove both.
 * L2 unrelated browser state exists -> E2 leave it untouched.
 * Rule R1=L1+L2. The cleanup is deliberately write-only: it cannot revive or
 * migrate the deleted parallel configuration path.
 */
describe("legacy Mission-default consolidation rule", () => {
  it("R1 removes only obsolete duplicate configuration keys", () => {
    const storage = { removeItem: vi.fn() } as unknown as Storage;
    purgeLegacyMissionDefaults(storage);
    expect(storage.removeItem).toHaveBeenNthCalledWith(1, "awaken.pilot.settings.v1");
    expect(storage.removeItem).toHaveBeenNthCalledWith(2, "awaken.pilot.settings.v2");
    expect(storage.removeItem).toHaveBeenCalledTimes(2);
  });
});
