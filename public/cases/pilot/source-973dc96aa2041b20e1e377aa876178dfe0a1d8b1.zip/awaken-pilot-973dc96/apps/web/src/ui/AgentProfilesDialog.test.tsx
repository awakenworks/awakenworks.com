import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { AgentProfilesDialog } from "./AgentProfilesDialog";

afterEach(cleanup);

/**
 * Agent authoring cause/effect graph:
 * C1 name/model present, capability selections valid, Connector rows complete ->
 * E1 emit one complete Agent command; C2 missing identity or partial Connector ->
 * E2 disable create; C3 mutating vs read/research tool -> E3 always_ask vs
 * always_allow; C4 eligible subagent selected -> E4 preserve its upstream ID.
 * Decision rules: R1=C1+C3+C4; R2=C2.
 */
describe("Agent profile editor decision table", () => {
  it("R1 creates one complete Agent/Connector command", async () => {
    const user = userEvent.setup();
    const onCreate = vi.fn(async () => ({ id: "agent_new" }) as never);
    const agents = [{ id: "agent_research", name: "Researcher", version: 2, model: { id: "deepseek-v4-flash" }, tools: [], skills: [], mcp_servers: [], multiagent: null, archived_at: null }] as never[];
    render(<AgentProfilesDialog open agents={agents} pending={false} onClose={vi.fn()} onCreate={onCreate} />);
    const create = screen.getByRole("button", { name: "Create agent profile" });
    expect(create).toBeDisabled();
    await user.type(screen.getByLabelText("Agent name"), "Manus agent");
    await user.type(screen.getByLabelText("Model ID"), "deepseek-v4-flash");
    await user.click(screen.getByRole("button", { name: "Add connector" }));
    expect(create).toBeDisabled();
    await user.type(screen.getByLabelText("Connector name 1"), "browser");
    await user.type(screen.getByLabelText("Connector URL 1"), "https://browser.example.test/mcp");
    await user.click(screen.getByRole("checkbox", { name: /Researcher/ }));
    await user.click(create);
    expect(onCreate).toHaveBeenCalledOnce();
    expect(onCreate).toHaveBeenCalledWith(expect.objectContaining({
      name: "Manus agent",
      model: "deepseek-v4-flash",
      connectors: [{ name: "browser", url: "https://browser.example.test/mcp", permission: "always_ask" }],
      subagentIds: ["agent_research"],
      skills: expect.arrayContaining([{ type: "anthropic", skillId: "pptx", version: "latest" }]),
      tools: expect.arrayContaining([
        { name: "read", permission: "always_allow" },
        { name: "bash", permission: "always_ask" },
      ]),
    }));
  });
});
