import { describe, expect, it } from "vitest";
import type { MissionEvent } from "./mission";
import { PLAN_APPROVAL_MESSAGE, projectMission } from "./mission";

const event = (value: Record<string, unknown>): MissionEvent => value as unknown as MissionEvent;

/**
 * Cause-effect graph for committed Mission projection:
 * C1 status event order -> E1 last committed status wins.
 * C2 message content has text/non-text -> E2 only text becomes transcript.
 * C3 tool use has matching successful result -> E3 tool done; Pilot plan/notification/result eligible.
 * C4 tool use has no result / failed result -> E4 running/error; no Pilot snapshot mutation.
 * C5 permission=ask and no/yes confirmation -> E5 approval present/absent.
 * C6 identical replay -> E6 one canonical event, processing enrichment only.
 * C9 same ID with changed immutable content or recorded processing time -> E9 reject.
 * C7 exact approval message follows a successful plan -> E7 approved; a newer plan
 * resets approval because the event log now contains a different review target.
 * C8 official SDK/ACP MCP events use canonical/dotted names and flat/enveloped
 * inputs -> E8 both exact Pilot shapes project; lookalike servers never project.
 * Constraints: plan/result derive only from complete tool input; projection is not persisted.
 * Decision rules: R1=C1+C2 baseline, R2=C3 valid plan, R3=C4 failed plan,
 * R4=C5 pending, R5=C5 confirmed, R6=C6 duplicate replay, R7=C7, R8=C8.
 */
describe("Mission committed-event decision table", () => {
  it("R1 projects the last status and text transcript", () => {
    const result = projectMission([
      event({ id: "1", type: "user.message", processed_at: "2026-01-01T00:00:00Z", content: [{ type: "text", text: "go" }, { type: "image", source: {} }] }),
      event({ id: "2", type: "session.status_running", processed_at: "2026-01-01T00:00:01Z" }),
      event({ id: "3", type: "agent.message", processed_at: "2026-01-01T00:00:02Z", content: [{ type: "text", text: "done" }] }),
      event({ id: "4", type: "session.status_idle", processed_at: "2026-01-01T00:00:03Z" }),
    ]);
    expect(result.status).toBe("idle");
    expect(result.messages.map(({ role, text }) => ({ role, text }))).toEqual([
      { role: "user", text: "go" }, { role: "assistant", text: "done" },
    ]);
  });

  it("R2 accepts only a successfully recorded complete plan snapshot", () => {
    const result = projectMission([
      event({ id: "plan-1", type: "agent.mcp_tool_use", name: "mcp__pilot__set_plan", input: { summary: "Ship", steps: [{ id: "one", title: "Do it", status: "in_progress" }] } }),
      event({ id: "result-1", type: "agent.mcp_tool_result", mcp_tool_use_id: "plan-1", content: [{ type: "text", text: "ok" }] }),
    ]);
    expect(result.plan?.summary).toBe("Ship");
    expect(result.tools[0]?.state).toBe("done");
  });

  it("R3 never projects a failed plan call", () => {
    const result = projectMission([
      event({ id: "plan-1", type: "agent.mcp_tool_use", name: "set_plan", input: { summary: "Bad", steps: [{ id: "one", title: "No", status: "completed" }] } }),
      event({ id: "result-1", type: "agent.mcp_tool_result", mcp_tool_use_id: "plan-1", is_error: true, content: [{ type: "text", text: "rejected" }] }),
    ]);
    expect(result.plan).toBeUndefined();
    expect(result.tools[0]?.state).toBe("error");
  });

  it("R2 projects successful notifications and terminal results from their recorded inputs", () => {
    const result = projectMission([
      event({ id: "notify-1", type: "agent.mcp_tool_use", name: "mcp__pilot__notify_user", input: { level: "warning", message: "Approval may be needed" } }),
      event({ id: "notify-result", type: "agent.mcp_tool_result", mcp_tool_use_id: "notify-1", content: [{ type: "text", text: "ok" }] }),
      event({ id: "publish-1", type: "agent.mcp_tool_use", name: "mcp__pilot__publish_result", input: { summary: "Delivered", artifacts: [{ path: "outputs/brief.md", description: "Brief" }] } }),
      event({ id: "publish-result", type: "agent.mcp_tool_result", mcp_tool_use_id: "publish-1", content: [{ type: "text", text: "ok" }] }),
    ]);
    expect(result.notifications).toEqual([{ level: "warning", message: "Approval may be needed", eventId: "notify-1" }]);
    expect(result.result).toEqual({ summary: "Delivered", artifacts: [{ path: "outputs/brief.md", description: "Brief" }], eventId: "publish-1" });
  });

  it("R8 projects the exact ACP Pilot envelope and rejects lookalike servers", () => {
    const events = [
      event({ id: "plan-acp", type: "agent.tool_use", name: "mcp.pilot.set_plan", input: { server: "pilot", tool: "set_plan", arguments: { summary: "Real ACP", steps: [{ id: "one", title: "Run it", status: "completed" }] } } }),
      event({ id: "plan-acp-result", type: "agent.tool_result", tool_use_id: "plan-acp", content: [{ type: "text", text: "ok" }] }),
      event({ id: "result-acp", type: "agent.tool_use", name: "mcp.pilot.publish_result", input: { server: "pilot", tool: "publish_result", arguments: { summary: "E2E_REAL_AGENT_OK", artifacts: [{ path: "real-codex" }] } } }),
      event({ id: "result-acp-result", type: "agent.tool_result", tool_use_id: "result-acp", content: [{ type: "text", text: "ok" }] }),
      event({ id: "spoof", type: "agent.tool_use", name: "mcp__other__publish_result", input: { summary: "spoofed" } }),
      event({ id: "spoof-result", type: "agent.tool_result", tool_use_id: "spoof", content: [{ type: "text", text: "ok" }] }),
    ];

    const result = projectMission(events);
    expect(result.plan?.summary).toBe("Real ACP");
    expect(result.result).toEqual({ summary: "E2E_REAL_AGENT_OK", artifacts: [{ path: "real-codex" }], eventId: "result-acp" });
  });

  it("R4/R5 exposes approval until its confirmation is committed", () => {
    const request = event({ id: "tool-1", type: "agent.tool_use", name: "bash", evaluated_permission: "ask", input: { command: "deploy" }, session_thread_id: "sthr_1" });
    expect(projectMission([request]).pendingApprovals).toEqual([{ id: "tool-1", name: "bash", input: { command: "deploy" }, sessionThreadId: "sthr_1" }]);
    expect(projectMission([request, event({ id: "confirm-1", type: "user.tool_confirmation", tool_use_id: "tool-1", result: "deny" })]).pendingApprovals).toEqual([]);
  });

  // Fixed-archive consumer rules: R6 same ID+same payload+new processed_at
  // -> one row; R9 same ID+changed content or recorded timestamp -> reject.
  // The packaged shared owner enforces this boundary; Pilot never repairs a
  // committed event using live text or a last-write-wins local transcript.
  it("R6 deduplicates immutable replay with processing enrichment", () => {
    const committed = event({ id: "same", type: "agent.message", content: [{ type: "text", text: "final" }] });
    const result = projectMission([committed, event({ ...committed, processed_at: "2026-10-10T00:00:00Z" })]);
    expect(result.messages).toHaveLength(1);
    expect(result.messages[0]?.text).toBe("final");
  });

  it("R9 rejects changed committed payload or processing time", () => {
    const committed = event({ id: "same", type: "agent.message", content: [{ type: "text", text: "final" }], processed_at: "2026-10-10T00:00:00Z" });
    expect(() => projectMission([committed, event({ ...committed, content: [] })])).toThrow(/immutable projection/);
    expect(() => projectMission([committed, event({ ...committed, processed_at: "2026-10-10T00:00:01Z" })])).toThrow(/processed_at changed/);
  });

  it("R7 derives Plan Mode approval only from the event log after the current plan", () => {
    const plan = (id: string) => [
      event({ id, type: "agent.mcp_tool_use", name: "set_plan", input: { summary: id, steps: [{ id: "one", title: "Do it", status: "pending" }] } }),
      event({ id: `${id}-result`, type: "agent.mcp_tool_result", mcp_tool_use_id: id, content: [{ type: "text", text: "ok" }] }),
    ];
    const approval = event({ id: "approve", type: "user.message", content: [{ type: "text", text: PLAN_APPROVAL_MESSAGE }] });
    expect(projectMission([...plan("plan-1"), approval]).planApproved).toBe(true);
    expect(projectMission([...plan("plan-1"), approval, ...plan("plan-2")]).planApproved).toBe(false);
  });
});
