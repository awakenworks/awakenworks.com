import { awakenPilotReferenceCase } from "../reference-case";

export function ReferenceCaseLink() {
  return <a className="reference-case-link" href={awakenPilotReferenceCase.caseUrl} target="_blank" rel="noreferrer" aria-label="Read the Awaken Pilot reference case">
    <span>{awakenPilotReferenceCase.label}</span>
    <small>{awakenPilotReferenceCase.readerPromise}</small>
  </a>;
}
