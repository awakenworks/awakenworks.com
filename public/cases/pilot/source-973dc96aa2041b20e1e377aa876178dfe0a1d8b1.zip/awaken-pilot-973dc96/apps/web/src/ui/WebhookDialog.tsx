import { Button, CheckboxField, Dialog, InlineNotice, TextField } from "@awaken/ui";
import { useState } from "react";
import type { WebhookCommand, WebhookSubscription } from "../infrastructure/gateway";

interface WebhookDraft {
  id: string;
  url: string;
  eventTypes: string;
  disabled: boolean;
}

function webhookId(): string {
  return `wh_${globalThis.crypto.randomUUID().replaceAll("-", "")}`;
}

function draftFrom(subscription?: WebhookSubscription): WebhookDraft {
  return {
    id: subscription?.id ?? webhookId(),
    url: subscription?.url ?? "",
    eventTypes: subscription?.event_types.join(", ") ?? "",
    disabled: subscription?.disabled ?? false,
  };
}

function commandFrom(draft: WebhookDraft): WebhookCommand {
  return {
    url: draft.url,
    eventTypes: draft.eventTypes.split(",").map((event) => event.trim()).filter(Boolean),
    disabled: draft.disabled,
  };
}

export function WebhookDialog({ open, subscriptions, pending, error, onClose, onPut, onDelete }: {
  open: boolean;
  subscriptions: WebhookSubscription[];
  pending: boolean;
  error?: Error;
  onClose: () => void;
  onPut: (id: string, input: WebhookCommand) => Promise<WebhookSubscription>;
  onDelete: (id: string) => Promise<void>;
}) {
  const [draft, setDraft] = useState<WebhookDraft>(() => draftFrom());
  const [editing, setEditing] = useState(false);
  const [secret, setSecret] = useState<string>();
  const update = (field: "url" | "eventTypes") => (event: React.ChangeEvent<HTMLInputElement>) =>
    setDraft((current) => ({ ...current, [field]: event.target.value }));
  const start = (subscription?: WebhookSubscription) => {
    setDraft(draftFrom(subscription));
    setEditing(Boolean(subscription));
    setSecret(undefined);
  };
  const save = async () => {
    try {
      const subscription = await onPut(draft.id, commandFrom(draft));
      setSecret(subscription.secret);
      setEditing(true);
    } catch {
      // The mutation owns the surfaced error. Keep the authored draft available.
    }
  };
  const remove = (id: string) => {
    if (!globalThis.confirm("Delete this webhook subscription? Awaken will stop future deliveries.")) return;
    void onDelete(id).catch(() => {
      // The mutation owns the surfaced error and the upstream row remains authoritative.
    });
  };
  return <Dialog
    open={open}
    onOpenChange={(next) => { if (!next) onClose(); }}
    title="Outbound webhooks"
    closeLabel="Close webhook settings"
    description="Pilot configures Awaken’s workspace subscriptions. Awaken remains the only owner of signing secrets, delivery retries, failure counters, and automatic disabling."
    footer={<><Button variant="ghost" onClick={onClose}>Close</Button></>}
  >
    <div className="webhook-settings">
      <section className="webhook-list" aria-label="Webhook subscriptions">
        <header><strong>Subscriptions</strong><Button variant="ghost" onClick={() => start()}>New endpoint</Button></header>
        {subscriptions.length ? subscriptions.map((subscription) => <article key={subscription.id}>
          <div><strong>{subscription.url}</strong><small>{subscription.event_types.length ? subscription.event_types.join(", ") : "All lifecycle events"} · {subscription.disabled ? "Disabled" : "Active"}</small></div>
          <span>
            <Button variant="ghost" onClick={() => start(subscription)}>Edit</Button>
            <Button variant="ghost" onClick={() => remove(subscription.id)} loading={pending}>Delete</Button>
          </span>
        </article>) : <p>No webhook subscriptions are configured.</p>}
      </section>
      <section className="webhook-editor" aria-label={editing ? "Edit webhook" : "New webhook"}>
        <h3>{editing ? "Edit endpoint" : "Register endpoint"}</h3>
        {error ? <InlineNotice tone="danger" title="Webhook request failed">{error.message}</InlineNotice> : null}
        {secret ? <InlineNotice tone="warning" title="Copy the signing secret now"><code aria-label="Webhook signing secret">{secret}</code><br />Awaken will not return this secret again.</InlineNotice> : null}
        <TextField label="HTTPS endpoint" value={draft.url} onChange={update("url")} placeholder="https://example.com/awaken-events" />
        <TextField label="Event types (optional)" value={draft.eventTypes} onChange={update("eventTypes")} placeholder="session.status_idled, session.status_terminated" help="Comma-separated. Leave empty to receive every lifecycle event." />
        <CheckboxField label="Disable delivery" checked={draft.disabled} onChange={(event) => setDraft((current) => ({ ...current, disabled: event.target.checked }))} />
        <Button variant="primary" onClick={save} loading={pending} disabled={!draft.url.trim()}>{editing ? "Save changes" : "Register endpoint"}</Button>
      </section>
    </div>
  </Dialog>;
}
