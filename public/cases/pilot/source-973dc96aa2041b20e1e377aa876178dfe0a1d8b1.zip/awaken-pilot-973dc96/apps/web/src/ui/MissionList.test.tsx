import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { MissionList } from "./MissionList";

afterEach(cleanup);

const props = () => ({
  projects: [],
  projectRuns: [],
  selectedProjectId: undefined,
  missions: [],
  selectedId: undefined,
  loading: false,
  error: undefined,
  creating: false,
  onSelect: vi.fn(),
  onProjectSelect: vi.fn(),
  onConfigure: vi.fn(),
  onCreate: vi.fn(),
});

/**
 * Mission launch UI causes and effects:
 * U1 Project absent -> E1 launch disabled and Project creation action exposed.
 * U2 Project selected + title/goal blank -> E2 launch disabled.
 * U3 Project selected + title/goal nonblank -> E3 exactly one create command with
 * the Deployment ID as its Project reference.
 * U4 create pending -> E4 duplicate launch prevented by disabled button.
 * U5 scheduled run has a Session -> E5 selecting it opens that authoritative
 * Session; a failed run remains non-navigable.
 * U6 Plan-first selected -> E6 create command explicitly requests Plan Mode.
 * U7 Execute Mode criteria + valid revision bound -> E7 include one outcome rubric;
 * invalid bound disables launch. U8 selected Mission -> E8 no private Branch
 * control; a new direction remains an ordinary Project-backed Session create.
 * Rules R1=U1, R2=U2, R3=U3, R4=U3+U4, R5=U5, R6=U3+U6,
 * R7=U3+U7, R8=U8. Server admission remains authoritative;
 * this test covers only the product interaction contract owned by Pilot.
 */
describe("Mission launch decision table", () => {
  it("R1/R2 requires a Project and complete direction", async () => {
    const user = userEvent.setup();
    const callbacks = props();
    render(<MissionList {...callbacks} />);
    expect(screen.getByRole("button", { name: "Launch mission" })).toBeDisabled();
    await user.click(screen.getByRole("button", { name: "Create project" }));
    expect(callbacks.onConfigure).toHaveBeenCalledOnce();
  });

  it("R3 emits one create command for a complete direction", async () => {
    const user = userEvent.setup();
    const callbacks = props();
    render(<MissionList {...callbacks} projects={[{ id: "deployment_1", name: "Research desk" } as never]} selectedProjectId="deployment_1" />);
    await user.type(screen.getByLabelText("Title"), "Launch brief");
    await user.type(screen.getByLabelText("Direction"), "Research, draft, and verify the brief.");
    await user.click(screen.getByRole("button", { name: "Launch mission" }));
    expect(callbacks.onCreate).toHaveBeenCalledOnce();
    expect(callbacks.onCreate).toHaveBeenCalledWith({ projectId: "deployment_1", title: "Launch brief", goal: "Research, draft, and verify the brief.", mode: "execute", acceptanceCriteria: "", maxIterations: 3 });
  });

  it("R4 prevents duplicate activation while creation is pending", () => {
    render(<MissionList {...props()} projects={[{ id: "deployment_1", name: "Research desk" } as never]} selectedProjectId="deployment_1" creating />);
    expect(screen.getByRole("button", { name: "Launch mission" })).toBeDisabled();
  });

  it("R5 navigates from run history only when Awaken supplied a Session", async () => {
    const user = userEvent.setup();
    const callbacks = props();
    render(<MissionList
      {...callbacks}
      projects={[{ id: "deployment_1", name: "Research desk", status: "active", schedule: { expression: "0 9 * * 1", timezone: "UTC" } } as never]}
      selectedProjectId="deployment_1"
      projectRuns={[
        { id: "run_ok", session_id: "sesn_1", error: null, trigger_context: { type: "cron" }, created_at: "2026-01-01T00:00:00Z" } as never,
        { id: "run_failed", session_id: null, error: { message: "Agent archived" }, trigger_context: { type: "cron" }, created_at: "2026-01-02T00:00:00Z" } as never,
      ]}
    />);
    expect(screen.getByText("Agent archived")).toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: /cron/i }));
    expect(callbacks.onSelect).toHaveBeenCalledWith("sesn_1");
  });

  it("R6 launches Plan Mode explicitly", async () => {
    const user = userEvent.setup();
    const callbacks = props();
    render(<MissionList {...callbacks} projects={[{ id: "deployment_1", name: "Research desk" } as never]} selectedProjectId="deployment_1" />);
    await user.type(screen.getByLabelText("Title"), "Risky migration");
    await user.type(screen.getByLabelText("Direction"), "Plan the migration and identify rollback gates.");
    await user.selectOptions(screen.getByLabelText("Launch mode"), "plan");
    await user.click(screen.getByRole("button", { name: "Launch mission" }));
    expect(callbacks.onCreate).toHaveBeenCalledWith(expect.objectContaining({ mode: "plan" }));
  });

  it("R7 launches an evaluated outcome with a bounded revision count", async () => {
    const user = userEvent.setup();
    const callbacks = props();
    render(<MissionList {...callbacks} projects={[{ id: "deployment_1", name: "Research desk" } as never]} selectedProjectId="deployment_1" />);
    await user.type(screen.getByLabelText("Title"), "Verified brief");
    await user.type(screen.getByLabelText("Direction"), "Write the brief.");
    await user.type(screen.getByLabelText("Acceptance criteria (optional)"), "Every claim has a primary source.");
    const iterations = screen.getByLabelText("Maximum revision cycles");
    await user.clear(iterations);
    await user.type(iterations, "4");
    await user.click(screen.getByRole("button", { name: "Launch mission" }));
    expect(callbacks.onCreate).toHaveBeenCalledWith(expect.objectContaining({
      acceptanceCriteria: "Every claim has a primary source.", maxIterations: 4,
    }));
  });

  it("R8 does not expose the removed private Branch command", () => {
    render(<MissionList
      {...props()}
      projects={[{ id: "deployment_1", name: "Research desk" } as never]}
      selectedProjectId="deployment_1"
      selectedId="sesn_source"
    />);
    expect(screen.queryByLabelText("Branch from the selected Mission")).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Launch mission" })).toBeInTheDocument();
  });

});
