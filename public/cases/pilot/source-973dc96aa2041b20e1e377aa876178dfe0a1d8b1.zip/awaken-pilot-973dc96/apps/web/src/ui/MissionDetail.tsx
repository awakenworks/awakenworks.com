import {
  Button,
  ChatApproval,
  ChatComposer,
  ChatMarkdown,
  ChatMessage,
  ChatMessageList,
  EmptyState,
  InlineNotice,
  LoadingState,
  StatusPill,
  ToolCallCard,
} from "@awaken/ui";
import { useState } from "react";
import type { PilotGateway } from "../infrastructure/gateway";
import { useMission } from "../application/use-mission";
import { PLAN_APPROVAL_MESSAGE } from "../domain/mission";

const json = (value: unknown): string => value === undefined ? "" : JSON.stringify(value, null, 2);
const markdownLabels = { copyCodeLabel: "Copy code", copiedCodeLabel: "Copied", copyFailedLabel: "Copy failed" };
const Markdown = ({ body }: { body: string }) => <ChatMarkdown body={body} {...markdownLabels} />;

export function MissionDetail({ id, gateway, onShare, onPublicShare, onRevokePublicShare }: { id: string; gateway: PilotGateway; onShare?: () => Promise<void>; onPublicShare?: () => Promise<void>; onRevokePublicShare?: () => Promise<void> }) {
  const state = useMission(id, gateway);
  const [message, setMessage] = useState("");
  const [denyNotes, setDenyNotes] = useState<Record<string, string>>({});
  if (state.mission.isLoading || state.events.isLoading) return <main className="mission-detail"><LoadingState label="Loading mission…" /></main>;
  if (state.mission.error || state.events.error) {
    const error = state.mission.error ?? state.events.error;
    return <main className="mission-detail"><InlineNotice tone="danger" title="Could not load this mission" actions={<Button onClick={() => void state.refresh()}>Retry</Button>}>{error instanceof Error ? error.message : "Unknown error"}</InlineNotice></main>;
  }
  const mission = state.mission.data;
  if (!mission) return <main className="mission-detail"><EmptyState title="Mission not found" /></main>;
  const displayStatus = state.projection.status === "unknown" && ["idle", "running", "rescheduling", "terminated"].includes(mission.status)
    ? mission.status as "idle" | "running" | "rescheduling" | "terminated"
    : state.projection.status;
  const running = displayStatus === "running" || displayStatus === "rescheduling";
  const submit = () => {
    if (!message.trim()) return;
    state.send.mutate(message, { onSuccess: () => setMessage("") });
  };
  return <main className="mission-detail">
    <header className="mission-header">
      <div><div className="eyebrow">Mission · {mission.id}</div><h1>{mission.title || "Untitled mission"}</h1></div>
      <div className="mission-actions"><StatusPill tone={running ? "info" : displayStatus === "error" ? "danger" : "success"}>{displayStatus}</StatusPill>{onShare ? <Button variant="ghost" onClick={() => void onShare()}>Copy team link</Button> : null}{onPublicShare ? <Button variant="ghost" onClick={() => void onPublicShare()}>Copy public link</Button> : null}{onRevokePublicShare ? <Button variant="ghost" onClick={() => void onRevokePublicShare()}>Revoke public link</Button> : null}<Button variant="ghost" onClick={() => state.archive.mutate()} disabled={Boolean(mission.archived_at)}>Archive</Button></div>
    </header>
    {state.projection.error ? <InlineNotice tone="danger" title="Mission failed">{state.projection.error}</InlineNotice> : null}
    {mission.metadata.pilot_mode === "plan" && state.projection.plan && !state.projection.planApproved ? <InlineNotice
      tone="warning"
      title="Plan ready for review"
      actions={<Button variant="primary" loading={state.send.isPending} onClick={() => state.send.mutate(PLAN_APPROVAL_MESSAGE)}>Approve and execute</Button>}
    >Review the plan snapshot below. Approval is recorded as a user event in this same Mission.</InlineNotice> : null}
    {state.projection.result ? <InlineNotice tone="success" title="Result published"><Markdown body={state.projection.result.summary} /></InlineNotice> : null}
    <div className="mission-workspace">
      <section className="transcript-panel">
        <ChatMessageList ariaLabel="Mission transcript" jumpLabel="Jump to latest" busy={running}>
          {state.projection.messages.map((item) => <ChatMessage key={item.id} role={item.role} authorLabel={item.role === "assistant" ? "Pilot" : item.role === "user" ? "You" : "System"} {...(item.processedAt ? { timestamp: item.processedAt } : {})} body={<Markdown body={item.text} />} />)}
          {state.projection.tools.map((tool) => <ToolCallCard key={tool.id} name={tool.name} statusLabel={tool.state} tone={tool.state === "error" ? "error" : tool.state === "done" ? "done" : "running"} input={json(tool.input)} output={json(tool.output)} labels={{ input: "Input", output: "Output", inputAriaLabel: `${tool.name} input`, outputAriaLabel: `${tool.name} output` }} />)}
          {state.projection.pendingApprovals.map((approval) => <ChatApproval key={approval.id} title={`Allow ${approval.name}?`} description={<pre>{json(approval.input)}</pre>} note={denyNotes[approval.id] ?? ""} onNoteChange={(note) => setDenyNotes((current) => ({ ...current, [approval.id]: note }))} noteLabel="Reason if denied" approveLabel="Allow" rejectLabel="Deny" pending={state.decide.isPending} onApprove={() => state.decide.mutate({ toolUseId: approval.id, allow: true, ...(approval.sessionThreadId ? { sessionThreadId: approval.sessionThreadId } : {}) })} onReject={() => { const reason = denyNotes[approval.id]; state.decide.mutate({ toolUseId: approval.id, allow: false, ...(reason ? { reason } : {}), ...(approval.sessionThreadId ? { sessionThreadId: approval.sessionThreadId } : {}) }); }} />)}
          {state.preview.thinking ? <div className="live-preview" role="status">Pilot is thinking…</div> : null}
          {state.preview.text ? <ChatMessage role="assistant" authorLabel="Pilot" body={<Markdown body={state.preview.text} />} /> : null}
        </ChatMessageList>
        <ChatComposer value={message} onChange={setMessage} onSubmit={submit} onStop={() => state.interrupt.mutate()} busy={running} disabled={state.send.isPending} sendMode="enter" placeholder="Add direction or answer a question…" ariaLabel="Message Pilot" sendLabel="Send" stopLabel="Interrupt current run" hint="Enter to send · Shift+Enter for a new line" />
      </section>
      <aside className="mission-context">
        <ContextSection title="Plan">
          {state.projection.plan ? <><p className="plan-summary">{state.projection.plan.summary}</p><ol className="plan-list">{state.projection.plan.steps.map((step) => <li key={step.id} data-status={step.status}><span>{step.status === "completed" ? "✓" : step.status === "in_progress" ? "●" : step.status === "blocked" ? "!" : "○"}</span><div><strong>{step.title}</strong>{step.detail ? <small>{step.detail}</small> : null}</div></li>)}</ol></> : <p className="muted">No plan snapshot. Connect the Pilot MCP to expose structured progress.</p>}
        </ContextSection>
        <ContextSection title={`Updates (${state.projection.notifications.length})`}>
          {state.projection.notifications.length ? <ul className="update-list">{state.projection.notifications.slice(-5).reverse().map((notification) => <li key={notification.eventId} data-level={notification.level}>{notification.message}</li>)}</ul> : <p className="muted">No material updates yet.</p>}
        </ContextSection>
        <ContextSection title={`Agents (${state.threads.data?.length ?? 0})`}>
          {(state.threads.data ?? []).length ? <ul className="context-list">{state.threads.data?.map((thread) => <li key={thread.id}><strong>{thread.agent.type === "agent" ? thread.agent.name : `Advisor · ${thread.agent.model}`}</strong><StatusPill tone={thread.status === "running" ? "info" : "neutral"}>{thread.status}</StatusPill></li>)}</ul> : <p className="muted">No sub-agent threads.</p>}
        </ContextSection>
        <ContextSection title={`Artifacts (${state.artifacts.data?.length ?? 0})`}>
          {(state.artifacts.data ?? []).length ? <ul className="context-list">{state.artifacts.data?.map((file) => <li key={file.id}><span><strong>{file.filename}</strong><small>{Math.ceil(file.size_bytes / 1024)} KB</small></span><Button variant="ghost" disabled={file.downloadable === false} onClick={() => gateway.downloadArtifact(id, file)}>Download</Button></li>)}</ul> : <p className="muted">Outputs saved by workers appear here.</p>}
        </ContextSection>
        <ContextSection title={`Quality (${mission.outcome_evaluations.length})`}>
          {mission.outcome_evaluations.length ? <ul className="context-list">{mission.outcome_evaluations.map((outcome) => <li key={outcome.outcome_id}><span><strong>{outcome.result.replaceAll("_", " ")}</strong><small>Revision {outcome.iteration + 1} · {outcome.description}</small>{outcome.explanation ? <small>{outcome.explanation}</small> : null}</span></li>)}</ul> : <p className="muted">No automatic outcome rubric was requested.</p>}
        </ContextSection>
      </aside>
    </div>
  </main>;
}

function ContextSection({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="context-section"><h2>{title}</h2>{children}</section>;
}
