import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import type { BetaManagedAgentsDeploymentRun } from "@anthropic-ai/sdk/resources/beta/deployment-runs";
import type { BetaManagedAgentsSession } from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import { Button, EmptyState, InlineNotice, LoadingState, SelectField, StatusPill, TextAreaField, TextField } from "@awaken/ui";
import { useState } from "react";
import type { CreateMissionInput } from "../infrastructure/gateway";

function statusTone(status: string): "neutral" | "success" | "warning" | "danger" | "info" {
  if (status === "running") return "info";
  if (status === "idle") return "success";
  if (status === "terminated") return "warning";
  if (status === "error") return "danger";
  return "neutral";
}

export function MissionList({ projects, projectRuns, selectedProjectId, missions, selectedId, loading, error, creating, onCreate, onSelect, onProjectSelect, onConfigure }: {
  projects: BetaManagedAgentsDeployment[];
  projectRuns: BetaManagedAgentsDeploymentRun[];
  selectedProjectId: string | undefined;
  missions: BetaManagedAgentsSession[];
  selectedId: string | undefined;
  loading: boolean;
  error: Error | undefined;
  creating: boolean;
  onCreate: (input: CreateMissionInput) => void;
  onSelect: (id: string) => void;
  onProjectSelect: (id: string) => void;
  onConfigure: () => void;
}) {
  const [title, setTitle] = useState("");
  const [goal, setGoal] = useState("");
  const [mode, setMode] = useState<"execute" | "plan">("execute");
  const [acceptanceCriteria, setAcceptanceCriteria] = useState("");
  const [maxIterations, setMaxIterations] = useState(3);
  const validIterations = Number.isInteger(maxIterations) && maxIterations >= 1 && maxIterations <= 20;
  const submit = () => {
    if (!selectedProjectId || !title.trim() || !goal.trim() || creating || !validIterations) return;
    const input = { title, goal, mode, acceptanceCriteria: mode === "execute" ? acceptanceCriteria : "", maxIterations };
    onCreate({ projectId: selectedProjectId, ...input });
  };
  const project = projects.find((item) => item.id === selectedProjectId);
  return <aside className="mission-sidebar">
    <form className="new-mission" onSubmit={(event) => { event.preventDefault(); submit(); }}>
      <h2>New mission</h2>
      {!projects.length ? <InlineNotice tone="warning" title="Project required" actions={<Button onClick={onConfigure}>Create project</Button>}>
        Projects keep instructions, capabilities, resources, and schedules in one Awaken Deployment.
      </InlineNotice> : <SelectField label="Project" value={selectedProjectId ?? ""} onChange={(event) => onProjectSelect(event.target.value)}>
        {projects.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
      </SelectField>}
      {project?.schedule ? <div className="project-schedule"><span><strong>{project.status === "paused" ? "Paused" : "Scheduled"}</strong><small>{project.schedule.expression} · {project.schedule.timezone}</small></span>{project.schedule.upcoming_runs_at?.[0] ? <time>{new Date(project.schedule.upcoming_runs_at[0]).toLocaleString()}</time> : null}</div> : null}
      <TextField label="Title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Research and draft a launch brief" />
      <TextAreaField label="Direction" value={goal} onChange={(event) => setGoal(event.target.value)} rows={5} placeholder="Describe the outcome, constraints, and acceptance criteria…" />
      <SelectField label="Launch mode" value={mode} onChange={(event) => setMode(event.target.value as "execute" | "plan")}>
        <option value="execute">Execute autonomously</option>
        <option value="plan">Plan first, wait for approval</option>
      </SelectField>
      {mode === "execute" ? <TextAreaField label="Acceptance criteria (optional)" value={acceptanceCriteria} onChange={(event) => setAcceptanceCriteria(event.target.value)} rows={3} placeholder="State how Awaken should evaluate a satisfactory result…" help="Awaken evaluates and may revise the outcome against this rubric." /> : null}
      {acceptanceCriteria.trim() && mode === "execute" ? <TextField label="Maximum revision cycles" type="number" min="1" max="20" value={maxIterations} onChange={(event) => setMaxIterations(Number(event.target.value))} error={validIterations ? undefined : "Enter an integer from 1 to 20."} /> : null}
      <Button type="submit" variant="primary" loading={creating} disabled={!selectedProjectId || !title.trim() || !goal.trim() || !validIterations}>Launch mission</Button>
    </form>
    {project?.schedule && projectRuns.length ? <section className="project-runs" aria-label="Recent scheduled runs">
      <div className="mission-list-heading"><h2>Scheduled runs</h2><span>{projectRuns.length}</span></div>
      <ul>{projectRuns.slice(0, 3).map((run) => <li key={run.id}>
        {run.session_id ? <button type="button" onClick={() => onSelect(run.session_id ?? "")}><strong>{run.trigger_context.type}</strong><time>{new Date(run.created_at).toLocaleString()}</time></button>
          : <span><strong>Failed</strong><small>{run.error?.message ?? "Session creation failed"}</small></span>}
      </li>)}</ul>
    </section> : null}
    <div className="mission-list-heading"><h2>Missions</h2><span>{missions.length}</span></div>
    {loading ? <LoadingState label="Loading missions…" /> : error ? <InlineNotice tone="danger" title="Could not load workspace">{error.message}</InlineNotice> : missions.length === 0 ? <EmptyState title="No missions yet" body="Set a direction above to start." /> : <nav aria-label="Missions" className="mission-list">
      {missions.map((mission) => <button key={mission.id} type="button" className="mission-row" data-current={mission.id === selectedId || undefined} onClick={() => onSelect(mission.id)}>
        <span className="mission-row__title">{mission.title || "Untitled mission"}</span>
        <span className="mission-row__meta"><StatusPill tone={statusTone(mission.status)}>{mission.status}</StatusPill><time>{new Date(mission.updated_at).toLocaleDateString()}</time></span>
      </button>)}
    </nav>}
  </aside>;
}
