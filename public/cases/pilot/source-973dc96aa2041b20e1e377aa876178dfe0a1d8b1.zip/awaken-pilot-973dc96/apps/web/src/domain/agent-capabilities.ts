import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";

const BUILT_INS = ["bash", "edit", "read", "write", "glob", "grep", "web_fetch", "web_search"] as const;

export interface AgentCapabilityGroup {
  id: "research" | "workspace" | "skills" | "connectors" | "custom" | "multiagent";
  label: string;
  values: string[];
}

export function agentCapabilityGroups(agent: BetaManagedAgentsAgent): AgentCapabilityGroup[] {
  const builtIn = agent.tools.find((tool) => tool.type === "agent_toolset_20260401");
  const enabledBuiltIns = builtIn ? BUILT_INS.filter((name) =>
    builtIn.configs.find((config) => config.name === name)?.enabled ?? builtIn.default_config.enabled) : [];
  const group = (id: AgentCapabilityGroup["id"], label: string, values: string[]): AgentCapabilityGroup[] =>
    values.length ? [{ id, label, values }] : [];
  return [
    ...group("research", "Web research", enabledBuiltIns.filter((name) => name.startsWith("web_"))),
    ...group("workspace", "Workspace tools", enabledBuiltIns.filter((name) => !name.startsWith("web_"))),
    ...group("skills", "Skills", agent.skills.map((skill) => `${skill.skill_id}@${skill.version}`)),
    ...group("connectors", "MCP connectors", agent.mcp_servers.map((server) => server.name)),
    ...group("custom", "Application tools", agent.tools.flatMap((tool) => tool.type === "custom" ? [tool.name] : [])),
    ...group("multiagent", "Parallel agents", agent.multiagent ? [`${agent.multiagent.agents.length} available profiles`] : []),
  ];
}
