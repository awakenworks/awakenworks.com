import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import { Button, ToastProvider } from "@awaken/ui";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { useMissions } from "./application/use-missions";
import { useProjects } from "./application/use-projects";
import { useConnectorCredentials } from "./application/use-connector-credentials";
import { useWebhooks } from "./application/use-webhooks";
import { PilotApiGateway, type ProjectCommand } from "./infrastructure/gateway";
import { browserIdentity, missionFromPath, productLoginUrl, workspaceMissionPath } from "./infrastructure/identity";
import { purgeLegacyMissionDefaults } from "./infrastructure/legacy-settings";
import { MissionDetail } from "./ui/MissionDetail";
import { AgentProfilesDialog } from "./ui/AgentProfilesDialog";
import { ConnectorCredentialsDialog } from "./ui/ConnectorCredentialsDialog";
import { MissionList } from "./ui/MissionList";
import { ProjectDialog } from "./ui/ProjectDialog";
import { PublicMission } from "./ui/PublicMission";
import { ReferenceCaseLink } from "./ui/ReferenceCaseLink";
import { WebhookDialog } from "./ui/WebhookDialog";

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 2_000 } } });

export function App() {
  const content = globalThis.location.pathname === "/public" ? <PublicMission /> : <PilotApp />;
  return <QueryClientProvider client={queryClient}><ToastProvider dismissLabel="Dismiss" regionLabel="Notifications">{content}</ToastProvider></QueryClientProvider>;
}

function PilotApp() {
  const identity = browserIdentity();
  const [selectedId, setSelectedId] = useState<string | undefined>(() => missionFromPath(globalThis.location.pathname));
  const [selectedProjectId, setSelectedProjectId] = useState<string>();
  const [projectEditor, setProjectEditor] = useState<"new" | "edit">();
  const [webhookEditor, setWebhookEditor] = useState(false);
  const [agentEditor, setAgentEditor] = useState(false);
  const [credentialEditor, setCredentialEditor] = useState(false);
  const [selectedVaultId, setSelectedVaultId] = useState<string>();
  const gateway = useMemo(() => new PilotApiGateway(), []);
  const missions = useMissions(gateway);
  const projectState = useProjects(gateway, selectedProjectId);
  const credentialState = useConnectorCredentials(gateway, selectedVaultId);
  const webhookState = useWebhooks(gateway, webhookEditor);
  const webhookError = webhookState.subscriptions.error ?? webhookState.put.error ?? webhookState.remove.error;
  const credentialError = [credentialState.vaults.error, credentialState.credentials.error, credentialState.createVault.error, credentialState.createCredential.error, credentialState.validateCredential.error]
    .find((candidate) => candidate instanceof Error);
  const projects = projectState.projects.data ?? [];
  const selectedProject = projects.find((project) => project.id === selectedProjectId);
  const visibleMissions = (missions.list.data ?? []).filter((mission) =>
    !selectedProjectId || mission.metadata.pilot_project_id === selectedProjectId);

  useEffect(() => purgeLegacyMissionDefaults(), []);
  useEffect(() => {
    if (!selectedProjectId || !projects.some((project) => project.id === selectedProjectId)) {
      const missionProject = (missions.list.data ?? []).find((mission) => mission.id === selectedId)?.metadata.pilot_project_id;
      setSelectedProjectId(missionProject || projects[0]?.id);
    }
  }, [missions.list.data, projects, selectedId, selectedProjectId]);

  const selectMission = (id: string | undefined) => {
    setSelectedId(id);
    if (!identity.workspaceId) return;
    globalThis.history.replaceState(null, "", workspaceMissionPath(identity.workspaceId, id));
  };

  const saveProject = (input: ProjectCommand) => {
    if (projectEditor === "edit" && selectedProject) {
      projectState.update.mutate({ id: selectedProject.id, input }, { onSuccess: () => setProjectEditor(undefined) });
      return;
    }
    projectState.create.mutate(input, { onSuccess: (project) => {
      setSelectedProjectId(project.id);
      setProjectEditor(undefined);
    } });
  };
  const archiveProject = () => {
    if (!selectedProject || !globalThis.confirm(`Archive project “${selectedProject.name}”? Existing missions remain available.`)) return;
    projectState.archive.mutate(selectedProject.id, { onSuccess: () => setProjectEditor(undefined) });
  };
  const toggleProject = (project: BetaManagedAgentsDeployment) => {
    if (project.status === "paused") projectState.unpause.mutate(project.id);
    else projectState.pause.mutate(project.id);
  };
  const runProject = (project: BetaManagedAgentsDeployment) => {
    projectState.run.mutate(project.id, { onSuccess: (run) => {
      if (run.session_id) selectMission(run.session_id);
    } });
  };

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="/"><span className="brand-mark">A</span><span>Awaken Pilot<small>Set the direction. It gets the work done.</small></span></a>
      <ReferenceCaseLink />
      <div className="topbar-actions">
        {identity.workspaceId && !identity.token ? <Button variant="ghost" onClick={() => globalThis.location.assign(productLoginUrl(globalThis.location))}>Sign in</Button> : null}
        <Button variant="ghost" onClick={() => setWebhookEditor(true)}>Webhooks</Button>
        <Button variant="ghost" onClick={() => setAgentEditor(true)}>Agents & connectors</Button>
        <Button variant="ghost" onClick={() => setCredentialEditor(true)}>Credentials</Button>
        {selectedProject ? <>
          {selectedProject.schedule ? <Button variant="ghost" onClick={() => runProject(selectedProject)} loading={projectState.run.isPending}>Run schedule now</Button> : null}
          {selectedProject.schedule ? <Button variant="ghost" onClick={() => toggleProject(selectedProject)} loading={projectState.pause.isPending || projectState.unpause.isPending}>{selectedProject.status === "paused" ? "Resume schedule" : "Pause schedule"}</Button> : null}
          <Button variant="ghost" onClick={() => setProjectEditor("edit")}>Edit project</Button>
        </> : null}
        <Button variant="primary" onClick={() => setProjectEditor("new")}>New project</Button>
      </div>
    </header>
    <div className="app-body">
      <MissionList
        projects={projects}
        projectRuns={projectState.runs.data ?? []}
        selectedProjectId={selectedProjectId}
        missions={visibleMissions}
        selectedId={selectedId}
        loading={missions.list.isLoading || projectState.projects.isLoading}
        error={(missions.list.error ?? projectState.projects.error) instanceof Error ? missions.list.error ?? projectState.projects.error as Error : undefined}
        creating={missions.create.isPending}
        onProjectSelect={(id) => { setSelectedProjectId(id); selectMission(undefined); }}
        onConfigure={() => setProjectEditor("new")}
        onSelect={selectMission}
        onCreate={(input) => missions.create.mutate(input, { onSuccess: (mission) => selectMission(mission.id) })}
      />
      {selectedId ? <MissionDetail id={selectedId} gateway={gateway} {...(identity.workspaceId ? {
        onShare: () => navigator.clipboard.writeText(globalThis.location.href),
        onPublicShare: async () => {
          const link = await gateway.createPublicLink(selectedId);
          await navigator.clipboard.writeText(`${globalThis.location.origin}/public#w=${encodeURIComponent(link.workspaceId)}&m=${encodeURIComponent(link.missionId)}&token=${encodeURIComponent(link.token)}`);
        },
        onRevokePublicShare: () => gateway.revokePublicLink(selectedId),
      } : {})} /> : <main className="welcome"><div><span className="brand-mark brand-mark--large">A</span><h1>Where should we go?</h1><p>Choose a Project, give Pilot a clear direction, and Awaken’s managed agents will plan, delegate, act, and bring back the result.</p></div></main>}
    </div>
    {projectEditor ? <ProjectDialog
      key={`${projectEditor}:${selectedProject?.id ?? "new"}`}
      open
      {...(projectEditor === "edit" && selectedProject ? { project: selectedProject } : {})}
      agents={projectState.agents.data ?? []}
      environments={projectState.environments.data ?? []}
      files={projectState.files.data ?? []}
      memoryStores={projectState.memoryStores.data ?? []}
      vaults={projectState.vaults.data ?? []}
      pending={projectState.create.isPending || projectState.update.isPending || projectState.archive.isPending || projectState.uploadFile.isPending || projectState.createMemoryStore.isPending}
      onClose={() => setProjectEditor(undefined)}
      onSave={saveProject}
      onUploadFile={(file) => projectState.uploadFile.mutateAsync(file)}
      onCreateMemoryStore={(input) => projectState.createMemoryStore.mutateAsync(input)}
      {...(projectEditor === "edit" ? { onArchive: archiveProject } : {})}
    /> : null}
    {webhookEditor ? <WebhookDialog
      open
      subscriptions={webhookState.subscriptions.data ?? []}
      pending={webhookState.put.isPending || webhookState.remove.isPending}
      {...(webhookError instanceof Error ? { error: webhookError } : {})}
      onClose={() => setWebhookEditor(false)}
      onPut={(id, input) => webhookState.put.mutateAsync({ id, input })}
      onDelete={(id) => webhookState.remove.mutateAsync(id)}
    /> : null}
    {agentEditor ? <AgentProfilesDialog
      open
      agents={projectState.agents.data ?? []}
      pending={projectState.createAgentProfile.isPending}
      {...(projectState.createAgentProfile.error instanceof Error ? { error: projectState.createAgentProfile.error } : {})}
      onClose={() => setAgentEditor(false)}
      onCreate={(input) => projectState.createAgentProfile.mutateAsync(input)}
    /> : null}
    {credentialEditor ? <ConnectorCredentialsDialog
      open
      vaults={credentialState.vaults.data ?? []}
      {...(selectedVaultId ? { selectedVaultId } : {})}
      credentials={credentialState.credentials.data ?? []}
      pending={credentialState.createVault.isPending || credentialState.createCredential.isPending || credentialState.validateCredential.isPending}
      {...(credentialError instanceof Error ? { error: credentialError } : {})}
      {...(credentialState.validateCredential.data ? { validation: credentialState.validateCredential.data } : {})}
      onSelectVault={setSelectedVaultId}
      onClose={() => setCredentialEditor(false)}
      onCreateVault={(input) => credentialState.createVault.mutateAsync(input)}
      onCreateCredential={(vaultId, input) => credentialState.createCredential.mutateAsync({ vaultId, input })}
      onValidate={(vaultId, credentialId) => credentialState.validateCredential.mutateAsync({ vaultId, credentialId })}
    /> : null}
  </div>;
}
