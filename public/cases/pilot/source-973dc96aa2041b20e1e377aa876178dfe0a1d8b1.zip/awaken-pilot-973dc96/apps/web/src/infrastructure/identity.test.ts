import { beforeEach, describe, expect, it } from "vitest";
import { browserIdentity, missionFromPath, productLoginUrl, PRODUCT_SESSION_TOKEN_KEY, workspaceFromPath, workspaceMissionPath } from "./identity";

/**
 * Browser identity cause-effect table:
 * B1 canonical IAM product token present -> E1 expose it to the same-origin BFF.
 * B2 `/w/{workspace}` route -> E2 select that opaque Workspace; `default`/bad
 * encoding -> E3 no caller-selected scope.
 * B3 login requested -> E4 navigate to IAM's product-origin PKCE adapter with an
 * exact callback and return URL; Pilot never implements PKCE.
 * Rules R1=B1; R2=B2; R3=default/bad; R4=B3.
 */
describe("canonical browser identity adapter", () => {
  beforeEach(() => sessionStorage.clear());

  it("R1 reads only the IAM-owned short-lived product token", () => {
    sessionStorage.setItem(PRODUCT_SESSION_TOKEN_KEY, "product-token");
    expect(browserIdentity().token).toBe("product-token");
  });

  it("R2/R3 derives only a real Workspace route", () => {
    expect(workspaceFromPath("/w/workspace%20team/missions/sesn_1")).toBe("workspace team");
    expect(workspaceFromPath("/w/default/missions/sesn_1")).toBe("");
    expect(workspaceFromPath("/w/%GG/missions/sesn_1")).toBe("");
    expect(workspaceFromPath("/missions/sesn_1")).toBe("");
    expect(missionFromPath("/w/workspace_team/missions/sesn%2Fone")).toBe("sesn/one");
    expect(workspaceMissionPath("workspace team", "sesn/one")).toBe("/w/workspace%20team/missions/sesn%2Fone");
  });

  it("R4 delegates login to the canonical product-origin PKCE route", () => {
    const url = new URL(productLoginUrl({
      origin: "https://pilot.example",
      href: "https://pilot.example/w/workspace_team/missions/sesn_1",
    } as Location));
    expect(url.pathname).toBe("/v1/oauth/browser/start");
    expect(url.searchParams.get("client_id")).toBe("awaken-runtime");
    expect(url.searchParams.get("redirect_uri")).toBe("https://pilot.example/v1/oauth/browser/callback");
    expect(url.searchParams.get("return_to")).toBe("https://pilot.example/w/workspace_team/missions/sesn_1");
  });
});
