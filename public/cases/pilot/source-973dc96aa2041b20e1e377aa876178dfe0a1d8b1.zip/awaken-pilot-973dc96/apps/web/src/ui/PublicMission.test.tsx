import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { PublicMission } from "./PublicMission";

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  globalThis.history.replaceState(null, "", "/");
});

/**
 * Public read-only projection causes/effects:
 * V1 fragment has Workspace+Mission+capability and API accepts -> exact committed
 * transcript/result plus non-mutating context controls; V2 capability absent ->
 * local invalid-link state and zero requests. These rules prove the fragment is
 * sent only as the dedicated header and no composer/approval/archive action is
 * rendered for an anonymous viewer.
 */
describe("public Mission view", () => {
  it("V1 renders the committed projection read-only", async () => {
    globalThis.history.replaceState(null, "", "/public#w=ws_1&m=sesn_1&token=capability");
    const fetcher = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
      expect(new Headers(init?.headers).get("x-pilot-public-token")).toBe("capability");
      return new Response(JSON.stringify({
        mission: { id: "sesn_1", title: "Shared research", status: "idle" },
        events: [{ id: "evt_1", type: "agent.message", content: [{ type: "text", text: "Finished safely" }] }],
        threads: [],
        artifacts: [],
      }), { status: 200, headers: { "Content-Type": "application/json" } });
    });
    vi.stubGlobal("fetch", fetcher);
    render(<PublicMission />);
    expect(await screen.findByRole("heading", { name: "Shared research" })).toBeInTheDocument();
    expect(screen.getByText("Finished safely")).toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /archive|approve|send/i })).not.toBeInTheDocument();
  });

  it("V2 rejects a fragment without the capability before network access", async () => {
    globalThis.history.replaceState(null, "", "/public#w=ws_1&m=sesn_1");
    const fetcher = vi.fn();
    vi.stubGlobal("fetch", fetcher);
    render(<PublicMission />);
    expect(screen.getByText("Invalid public link")).toBeInTheDocument();
    await waitFor(() => expect(fetcher).not.toHaveBeenCalled());
  });
});
