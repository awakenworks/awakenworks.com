import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { WebhookDialog } from "./WebhookDialog";

afterEach(cleanup);

/**
 * Webhook editor cause-effect table:
 * U1 new HTTPS endpoint + empty event filter -> E1 one stable-ID command where
 * empty means all lifecycle events.
 * U2 create response contains signing secret -> E2 show it once in volatile UI.
 * U3 edit + disable -> E3 patch the same upstream ID; no local status transition.
 * U4 existing list row -> E4 display only the secret-free upstream projection.
 * Rules R1=U1+U2; R2=U3+U4. Closing the dialog discards E2, so Pilot cannot become
 * a signing-secret store.
 */
describe("Webhook editor decision table", () => {
  it("R1 registers all events and exposes the one-time upstream secret", async () => {
    const user = userEvent.setup();
    const onPut = vi.fn(async (id: string) => ({
      id, workspace_id: "ws_1", url: "https://receiver.example/hook",
      event_types: [], disabled: false, secret: "whsec_once",
    }));
    render(<WebhookDialog
      open subscriptions={[]} pending={false} onClose={vi.fn()} onDelete={vi.fn()}
      onPut={onPut}
    />);
    await user.type(screen.getByLabelText("HTTPS endpoint"), "https://receiver.example/hook");
    await user.click(screen.getByRole("button", { name: "Register endpoint" }));
    expect(onPut).toHaveBeenCalledOnce();
    expect(onPut).toHaveBeenCalledWith(expect.stringMatching(/^wh_/), {
      url: "https://receiver.example/hook", eventTypes: [], disabled: false,
    });
    expect(screen.getByLabelText("Webhook signing secret")).toHaveTextContent("whsec_once");
    expect(screen.getByText(/will not return this secret again/i)).toBeInTheDocument();
  });

  it("R2 edits the authoritative row without inventing delivery state", async () => {
    const user = userEvent.setup();
    const onPut = vi.fn(async () => ({
      id: "wh_existing", workspace_id: "ws_1", url: "https://old.example/hook",
      event_types: ["session.status_idled"], disabled: true,
    }));
    render(<WebhookDialog
      open pending={false} onClose={vi.fn()} onDelete={vi.fn()} onPut={onPut}
      subscriptions={[{
        id: "wh_existing", workspace_id: "ws_1", url: "https://old.example/hook",
        event_types: ["session.status_idled"], disabled: false,
      }]}
    />);
    expect(screen.getByText(/session.status_idled · Active/)).toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: "Edit" }));
    await user.click(screen.getByRole("checkbox", { name: "Disable delivery" }));
    await user.click(screen.getByRole("button", { name: "Save changes" }));
    expect(onPut).toHaveBeenCalledWith("wh_existing", {
      url: "https://old.example/hook", eventTypes: ["session.status_idled"], disabled: true,
    });
    expect(screen.queryByLabelText("Webhook signing secret")).not.toBeInTheDocument();
  });
});
