export const PRODUCT_SESSION_TOKEN_KEY = "awaken.product.session-bearer";

export interface PilotIdentityContext {
  token: string;
  workspaceId: string;
}

function sessionToken(): string {
  try {
    return globalThis.sessionStorage?.getItem(PRODUCT_SESSION_TOKEN_KEY) ?? "";
  } catch {
    return "";
  }
}

export function workspaceFromPath(pathname: string): string {
  const encoded = pathname.match(/^\/w\/([^/]+)/)?.[1];
  if (!encoded || encoded === "default") return "";
  try {
    return decodeURIComponent(encoded);
  } catch {
    return "";
  }
}

export function missionFromPath(pathname: string): string | undefined {
  const encoded = pathname.match(/^\/w\/[^/]+\/missions\/([^/]+)$/)?.[1];
  if (!encoded) return undefined;
  try {
    return decodeURIComponent(encoded);
  } catch {
    return undefined;
  }
}

export function workspaceMissionPath(workspaceId: string, missionId?: string): string {
  const base = `/w/${encodeURIComponent(workspaceId)}`;
  return missionId ? `${base}/missions/${encodeURIComponent(missionId)}` : base;
}

export function browserIdentity(): PilotIdentityContext {
  return {
    token: sessionToken(),
    workspaceId: workspaceFromPath(globalThis.location?.pathname ?? ""),
  };
}

/** The IAM-owned browser PKCE route is reverse-proxied at the product origin. */
export function productLoginUrl(location: Pick<Location, "origin" | "href">): string {
  const redirectUri = `${location.origin}/v1/oauth/browser/callback`;
  const query = new URLSearchParams({
    client_id: "awaken-runtime",
    redirect_uri: redirectUri,
    return_to: location.href,
  });
  return `${location.origin}/v1/oauth/browser/start?${query}`;
}
