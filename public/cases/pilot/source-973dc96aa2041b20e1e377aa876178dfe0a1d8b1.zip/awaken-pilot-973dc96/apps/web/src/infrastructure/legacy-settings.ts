const LEGACY_KEYS = ["awaken.pilot.settings.v1", "awaken.pilot.settings.v2"];

export function purgeLegacyMissionDefaults(storage: Storage = sessionStorage): void {
  for (const key of LEGACY_KEYS) storage.removeItem(key);
}
