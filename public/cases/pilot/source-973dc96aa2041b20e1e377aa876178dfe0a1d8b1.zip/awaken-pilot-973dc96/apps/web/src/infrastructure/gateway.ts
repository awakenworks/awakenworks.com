import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaManagedAgentsDeploymentRun } from "@anthropic-ai/sdk/resources/beta/deployment-runs";
import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import type { BetaEnvironment } from "@anthropic-ai/sdk/resources/beta/environments/environments";
import type { FileMetadata } from "@anthropic-ai/sdk/resources/beta/files";
import type { BetaManagedAgentsMemoryStore } from "@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores";
import type { BetaManagedAgentsSession } from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import type { BetaManagedAgentsSessionThread } from "@anthropic-ai/sdk/resources/beta/sessions/threads/threads";
import type { BetaManagedAgentsVault } from "@anthropic-ai/sdk/resources/beta/vaults/vaults";
import type { BetaManagedAgentsCredential, BetaManagedAgentsCredentialValidation } from "@anthropic-ai/sdk/resources/beta/vaults/credentials";
import type {
  ApprovalDecision,
  AgentProfileCommand,
  CreateMissionRequest,
  MemoryStoreCommand,
  ProjectCommand,
  PublicMissionLink,
  WebhookCommand,
  WebhookSubscription,
  UpdateAgentProfileCommand,
  VaultCommand,
  VaultCredentialCommand,
} from "@awaken/pilot-contracts";
import { PILOT_WORKSPACE_HEADER } from "@awaken/pilot-contracts/headers";
import type { MissionEvent, StreamEvent } from "../domain/mission";
import { browserIdentity, type PilotIdentityContext } from "./identity";

export type {
  ApprovalDecision,
  AgentProfileCommand,
  MemoryStoreCommand,
  ProjectCommand,
  WebhookCommand,
  WebhookSubscription,
  UpdateAgentProfileCommand,
  VaultCommand,
  VaultCredentialCommand,
} from "@awaken/pilot-contracts";

export interface MissionLaunchInput {
  title: string;
  goal: string;
  mode: "execute" | "plan";
  acceptanceCriteria: string;
  maxIterations: number;
}

export interface CreateMissionInput extends MissionLaunchInput {
  projectId: string;
}

export interface PilotGateway {
  listProjects(): Promise<BetaManagedAgentsDeployment[]>;
  getProject(id: string): Promise<BetaManagedAgentsDeployment>;
  createProject(input: ProjectCommand): Promise<BetaManagedAgentsDeployment>;
  updateProject(id: string, input: ProjectCommand): Promise<BetaManagedAgentsDeployment>;
  archiveProject(id: string): Promise<void>;
  pauseProject(id: string): Promise<BetaManagedAgentsDeployment>;
  unpauseProject(id: string): Promise<BetaManagedAgentsDeployment>;
  runProject(id: string): Promise<BetaManagedAgentsDeploymentRun>;
  listProjectRuns(id: string): Promise<BetaManagedAgentsDeploymentRun[]>;
  listAgents(): Promise<BetaManagedAgentsAgent[]>;
  createAgentProfile(input: AgentProfileCommand): Promise<BetaManagedAgentsAgent>;
  updateAgentProfile(id: string, input: UpdateAgentProfileCommand): Promise<BetaManagedAgentsAgent>;
  listEnvironments(): Promise<BetaEnvironment[]>;
  listKnowledgeFiles(): Promise<FileMetadata[]>;
  uploadKnowledgeFile(file: File): Promise<FileMetadata>;
  listMemoryStores(): Promise<BetaManagedAgentsMemoryStore[]>;
  createMemoryStore(input: MemoryStoreCommand): Promise<BetaManagedAgentsMemoryStore>;
  listVaults(): Promise<BetaManagedAgentsVault[]>;
  createVault(input: VaultCommand): Promise<BetaManagedAgentsVault>;
  listVaultCredentials(vaultId: string): Promise<BetaManagedAgentsCredential[]>;
  createVaultCredential(vaultId: string, input: VaultCredentialCommand): Promise<BetaManagedAgentsCredential>;
  validateVaultCredential(vaultId: string, credentialId: string): Promise<BetaManagedAgentsCredentialValidation>;
  listWebhooks(): Promise<WebhookSubscription[]>;
  putWebhook(id: string, input: WebhookCommand): Promise<WebhookSubscription>;
  deleteWebhook(id: string): Promise<void>;
  listMissions(): Promise<BetaManagedAgentsSession[]>;
  createMission(input: CreateMissionInput): Promise<BetaManagedAgentsSession>;
  createPublicLink(id: string): Promise<PublicMissionLink>;
  revokePublicLink(id: string): Promise<void>;
  getMission(id: string): Promise<BetaManagedAgentsSession>;
  listEvents(id: string): Promise<MissionEvent[]>;
  followEvents(id: string, receive: (event: StreamEvent) => void, signal: AbortSignal): Promise<void>;
  sendMessage(id: string, text: string): Promise<void>;
  interrupt(id: string): Promise<void>;
  decide(id: string, decision: ApprovalDecision): Promise<void>;
  listThreads(id: string): Promise<BetaManagedAgentsSessionThread[]>;
  listArtifacts(id: string): Promise<FileMetadata[]>;
  downloadArtifact(id: string, file: FileMetadata): Promise<void>;
  archive(id: string): Promise<void>;
}

function pathPart(value: string): string {
  return encodeURIComponent(value);
}

async function errorMessage(response: Response): Promise<string> {
  try {
    const body = await response.json() as { error?: unknown };
    if (typeof body.error === "string") return body.error;
  } catch {
    // The status text is the stable fallback for non-JSON proxy/server failures.
  }
  return response.statusText || `Request failed (${response.status})`;
}

async function requireOk(response: Response): Promise<Response> {
  if (!response.ok) throw new Error(await errorMessage(response));
  return response;
}

async function json<T>(response: Promise<Response>): Promise<T> {
  return requireOk(await response).then((result) => result.json() as Promise<T>);
}

async function noContent(response: Promise<Response>): Promise<void> {
  await requireOk(await response);
}

export async function consumeJsonEventStream(
  body: ReadableStream<Uint8Array>,
  receive: (event: StreamEvent) => void,
): Promise<void> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const consumeFrame = (frame: string) => {
    const data = frame.split(/\r?\n/)
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).replace(/^ /, ""))
      .join("\n");
    if (data) receive(JSON.parse(data) as StreamEvent);
  };
  try {
    while (true) {
      const { done, value } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });
      const frames = buffer.split(/\r?\n\r?\n/);
      buffer = frames.pop() ?? "";
      for (const frame of frames) consumeFrame(frame);
      if (done) {
        if (buffer.trim()) consumeFrame(buffer);
        return;
      }
    }
  } finally {
    reader.releaseLock();
  }
}

export class PilotApiGateway implements PilotGateway {
  constructor(
    private readonly fetcher: typeof fetch = fetch,
    private readonly identity: () => PilotIdentityContext = browserIdentity,
  ) {}

  private request(input: RequestInfo | URL, init: RequestInit = {}): Promise<Response> {
    const context = this.identity();
    const headers = new Headers(init.headers);
    if (context.token) headers.set("Authorization", `Bearer ${context.token}`);
    if (context.workspaceId) headers.set(PILOT_WORKSPACE_HEADER, context.workspaceId);
    // Browser fetch is a Web-IDL method and rejects a class instance as its
    // receiver. Keep this one request boundary authoritative while preserving
    // injected fetchers used by tests and embedders.
    return this.fetcher.call(globalThis, input, { ...init, headers, credentials: "same-origin" });
  }

  listProjects(): Promise<BetaManagedAgentsDeployment[]> {
    return json(this.request("/api/projects"));
  }

  getProject(id: string): Promise<BetaManagedAgentsDeployment> {
    return json(this.request(`/api/projects/${pathPart(id)}`));
  }

  createProject(input: ProjectCommand): Promise<BetaManagedAgentsDeployment> {
    return json(this.request("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  updateProject(id: string, input: ProjectCommand): Promise<BetaManagedAgentsDeployment> {
    return json(this.request(`/api/projects/${pathPart(id)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  archiveProject(id: string): Promise<void> {
    return noContent(this.request(`/api/projects/${pathPart(id)}/archive`, { method: "POST" }));
  }

  pauseProject(id: string): Promise<BetaManagedAgentsDeployment> {
    return json(this.request(`/api/projects/${pathPart(id)}/pause`, { method: "POST" }));
  }

  unpauseProject(id: string): Promise<BetaManagedAgentsDeployment> {
    return json(this.request(`/api/projects/${pathPart(id)}/unpause`, { method: "POST" }));
  }

  runProject(id: string): Promise<BetaManagedAgentsDeploymentRun> {
    return json(this.request(`/api/projects/${pathPart(id)}/run`, { method: "POST" }));
  }

  listProjectRuns(id: string): Promise<BetaManagedAgentsDeploymentRun[]> {
    return json(this.request(`/api/projects/${pathPart(id)}/runs`));
  }

  listAgents(): Promise<BetaManagedAgentsAgent[]> {
    return json(this.request("/api/catalog/agents"));
  }

  createAgentProfile(input: AgentProfileCommand): Promise<BetaManagedAgentsAgent> {
    return json(this.request("/api/agents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  updateAgentProfile(id: string, input: UpdateAgentProfileCommand): Promise<BetaManagedAgentsAgent> {
    return json(this.request(`/api/agents/${pathPart(id)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  listEnvironments(): Promise<BetaEnvironment[]> {
    return json(this.request("/api/catalog/environments"));
  }

  listKnowledgeFiles(): Promise<FileMetadata[]> {
    return json(this.request("/api/catalog/files"));
  }

  uploadKnowledgeFile(file: File): Promise<FileMetadata> {
    return json(this.request("/api/files", {
      method: "POST",
      headers: {
        "Content-Type": "application/octet-stream",
        "X-Pilot-Filename": encodeURIComponent(file.name),
        "X-Pilot-Mime-Type": file.type || "application/octet-stream",
      },
      body: file,
    }));
  }

  listMemoryStores(): Promise<BetaManagedAgentsMemoryStore[]> {
    return json(this.request("/api/catalog/memory-stores"));
  }

  createMemoryStore(input: MemoryStoreCommand): Promise<BetaManagedAgentsMemoryStore> {
    return json(this.request("/api/memory-stores", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  listVaults(): Promise<BetaManagedAgentsVault[]> {
    return json(this.request("/api/catalog/vaults"));
  }

  createVault(input: VaultCommand): Promise<BetaManagedAgentsVault> {
    return json(this.request("/api/vaults", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  listVaultCredentials(vaultId: string): Promise<BetaManagedAgentsCredential[]> {
    return json(this.request(`/api/vaults/${pathPart(vaultId)}/credentials`));
  }

  createVaultCredential(vaultId: string, input: VaultCredentialCommand): Promise<BetaManagedAgentsCredential> {
    return json(this.request(`/api/vaults/${pathPart(vaultId)}/credentials`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  validateVaultCredential(vaultId: string, credentialId: string): Promise<BetaManagedAgentsCredentialValidation> {
    return json(this.request(`/api/vaults/${pathPart(vaultId)}/credentials/${pathPart(credentialId)}/validate`, { method: "POST" }));
  }

  listWebhooks(): Promise<WebhookSubscription[]> {
    return json(this.request("/api/webhooks"));
  }

  putWebhook(id: string, input: WebhookCommand): Promise<WebhookSubscription> {
    return json(this.request(`/api/webhooks/${pathPart(id)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }));
  }

  deleteWebhook(id: string): Promise<void> {
    return noContent(this.request(`/api/webhooks/${pathPart(id)}`, { method: "DELETE" }));
  }

  listMissions(): Promise<BetaManagedAgentsSession[]> {
    return json(this.request("/api/missions"));
  }

  createMission(input: CreateMissionInput): Promise<BetaManagedAgentsSession> {
    const body: CreateMissionRequest = input;
    return json(this.request("/api/missions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }));
  }

  createPublicLink(id: string): Promise<PublicMissionLink> {
    return json(this.request(`/api/missions/${pathPart(id)}/public-link`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ expiresInDays: 7 }),
    }));
  }

  revokePublicLink(id: string): Promise<void> {
    return noContent(this.request(`/api/missions/${pathPart(id)}/public-link`, { method: "DELETE" }));
  }

  getMission(id: string): Promise<BetaManagedAgentsSession> {
    return json(this.request(`/api/missions/${pathPart(id)}`));
  }

  listEvents(id: string): Promise<MissionEvent[]> {
    return json(this.request(`/api/missions/${pathPart(id)}/events`));
  }

  async followEvents(id: string, receive: (event: StreamEvent) => void, signal: AbortSignal): Promise<void> {
    const response = await requireOk(await this.request(`/api/missions/${pathPart(id)}/events/stream`, {
      headers: { Accept: "text/event-stream" },
      signal,
    }));
    if (!response.body) throw new Error("Event stream response has no body");
    await consumeJsonEventStream(response.body, receive);
  }

  sendMessage(id: string, text: string): Promise<void> {
    return noContent(this.request(`/api/missions/${pathPart(id)}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    }));
  }

  interrupt(id: string): Promise<void> {
    return noContent(this.request(`/api/missions/${pathPart(id)}/interrupt`, { method: "POST" }));
  }

  decide(id: string, decision: ApprovalDecision): Promise<void> {
    return noContent(this.request(`/api/missions/${pathPart(id)}/decisions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(decision),
    }));
  }

  listThreads(id: string): Promise<BetaManagedAgentsSessionThread[]> {
    return json(this.request(`/api/missions/${pathPart(id)}/threads`));
  }

  listArtifacts(id: string): Promise<FileMetadata[]> {
    return json(this.request(`/api/missions/${pathPart(id)}/artifacts`));
  }

  async downloadArtifact(id: string, file: FileMetadata): Promise<void> {
    const response = await requireOk(await this.request(`/api/missions/${pathPart(id)}/artifacts/${pathPart(file.id)}/content`));
    const url = URL.createObjectURL(await response.blob());
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = file.filename;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  archive(id: string): Promise<void> {
    return noContent(this.request(`/api/missions/${pathPart(id)}/archive`, { method: "POST" }));
  }
}
