import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import { describe, expect, it } from "vitest";
import { projectCommandFrom, projectInstruction, projectSchedulePrompt } from "./project";

function deployment(overrides: Partial<BetaManagedAgentsDeployment> = {}): BetaManagedAgentsDeployment {
  return {
    id: "deployment_1",
    type: "deployment",
    name: "Research desk",
    description: null,
    agent: { id: "agent_1", type: "agent", version: 3 },
    environment_id: "env_1",
    initial_events: [{ type: "system.message", content: [{ type: "text", text: "Use primary sources." }] }],
    metadata: { application: "awaken-pilot", pilot_kind: "project" },
    resources: [],
    vault_ids: [],
    budget: null,
    schedule: null,
    status: "active",
    paused_reason: null,
    archived_at: null,
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

/**
 * Project projection cause-effect table:
 * P1 system event exists -> E1 it is the only standing-instruction source.
 * P2 scheduled user event uses Pilot mission envelope -> E2 expose only its goal.
 * P3 Deployment has file/memory/budget/schedule -> E3 losslessly produce the edit
 * command; unrelated resource variants do not become a second product model.
 * P4 schedule absent -> E4 command schedule remains null.
 * Rules R1=P1+P4; R2=P1+P2+P3.
 */
describe("Project Deployment projection decision table", () => {
  it("R1 projects an unscheduled Project without consulting description", () => {
    const project = deployment({ description: "stale duplicate that must be ignored" });
    expect(projectInstruction(project)).toBe("Use primary sources.");
    expect(projectCommandFrom(project).schedule).toBeNull();
  });

  it("R2 losslessly projects scheduled resources and the goal", () => {
    const project = deployment({
      initial_events: [
        { type: "system.message", content: [{ type: "text", text: "Use primary sources." }] },
        { type: "user.message", content: [{ type: "text", text: "Execute autonomously.\n\nMission goal:\n\nPublish the weekly brief." }] },
      ],
      resources: [
        { type: "file", file_id: "file_1" },
        { type: "memory_store", memory_store_id: "memstore_1", access: "read_write" },
      ],
      vault_ids: ["vlt_1"],
      budget: { type: "limit", max_list_cost: { amount: "2500", currency: "USD" } },
      schedule: { type: "cron", expression: "0 9 * * 1", timezone: "Asia/Shanghai", upcoming_runs_at: [] },
    });
    expect(projectSchedulePrompt(project)).toBe("Publish the weekly brief.");
    expect(projectCommandFrom(project)).toEqual({
      name: "Research desk",
      instruction: "Use primary sources.",
      agentId: "agent_1",
      environmentId: "env_1",
      vaultIds: ["vlt_1"],
      fileIds: ["file_1"],
      memoryStoreIds: ["memstore_1"],
      budgetUsdCents: 2500,
      schedule: { prompt: "Publish the weekly brief.", expression: "0 9 * * 1", timezone: "Asia/Shanghai" },
    });
  });
});
