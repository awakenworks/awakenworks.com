import type { BetaManagedAgentsDeployment } from "@anthropic-ai/sdk/resources/beta/deployments";
import type { ProjectCommand } from "@awaken/pilot-contracts";

function eventText(project: BetaManagedAgentsDeployment, type: "system.message" | "user.message"): string {
  return project.initial_events.flatMap((event) => event.type === type
    ? event.content.flatMap((block) => block.type === "text" ? [block.text] : [])
    : []).join("\n").trim();
}

export function projectInstruction(project: BetaManagedAgentsDeployment): string {
  return eventText(project, "system.message");
}

export function projectSchedulePrompt(project: BetaManagedAgentsDeployment): string {
  const prompt = eventText(project, "user.message");
  const marker = "Mission goal:\n\n";
  return prompt.includes(marker) ? prompt.slice(prompt.lastIndexOf(marker) + marker.length).trim() : prompt;
}

export function projectCommandFrom(project: BetaManagedAgentsDeployment): ProjectCommand {
  return {
    name: project.name,
    instruction: projectInstruction(project),
    agentId: project.agent.id,
    environmentId: project.environment_id,
    vaultIds: project.vault_ids,
    fileIds: project.resources.flatMap((resource) => resource.type === "file" ? [resource.file_id] : []),
    memoryStoreIds: project.resources.flatMap((resource) => resource.type === "memory_store" ? [resource.memory_store_id] : []),
    budgetUsdCents: project.budget ? Number(project.budget.max_list_cost.amount) : null,
    schedule: project.schedule ? {
      prompt: projectSchedulePrompt(project),
      expression: project.schedule.expression,
      timezone: project.schedule.timezone,
    } : null,
  };
}
