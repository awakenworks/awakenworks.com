import type { BetaManagedAgentsSession } from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import type { BetaManagedAgentsSessionThread } from "@anthropic-ai/sdk/resources/beta/sessions/threads/threads";
import type { FileMetadata } from "@anthropic-ai/sdk/resources/beta/files";
import { Button, ChatMarkdown, ChatMessage, ChatMessageList, EmptyState, InlineNotice, LoadingState, StatusPill } from "@awaken/ui";
import { useEffect, useMemo, useState } from "react";
import { projectMission, type MissionEvent } from "../domain/mission";

interface PublicSnapshot {
  mission: BetaManagedAgentsSession;
  events: MissionEvent[];
  threads: BetaManagedAgentsSessionThread[];
  artifacts: FileMetadata[];
}

function coordinates(): { workspaceId: string; missionId: string; token: string } | undefined {
  const fragment = new URLSearchParams(globalThis.location.hash.slice(1));
  const workspaceId = fragment.get("w") ?? "";
  const missionId = fragment.get("m") ?? "";
  const token = fragment.get("token") ?? "";
  return workspaceId && missionId && token ? { workspaceId, missionId, token } : undefined;
}

export function PublicMission() {
  const coordinate = useMemo(coordinates, []);
  const [snapshot, setSnapshot] = useState<PublicSnapshot>();
  const [error, setError] = useState<string>();
  useEffect(() => {
    if (!coordinate) return;
    const controller = new AbortController();
    void fetch(`/api/public/workspaces/${encodeURIComponent(coordinate.workspaceId)}/missions/${encodeURIComponent(coordinate.missionId)}`, {
      headers: { "X-Pilot-Public-Token": coordinate.token },
      signal: controller.signal,
    }).then(async (response) => {
      if (!response.ok) throw new Error(response.status === 403 ? "This public link has been revoked." : "This public link is invalid or expired.");
      setSnapshot(await response.json() as PublicSnapshot);
    }).catch((reason: unknown) => {
      if (!(reason instanceof DOMException && reason.name === "AbortError")) setError(reason instanceof Error ? reason.message : "Could not load this Mission.");
    });
    return () => controller.abort();
  }, [coordinate]);

  if (!coordinate) return <main className="mission-detail"><EmptyState title="Invalid public link" body="The link is missing its read-only capability." /></main>;
  if (error) return <main className="mission-detail"><InlineNotice tone="danger" title="Mission unavailable">{error}</InlineNotice></main>;
  if (!snapshot) return <main className="mission-detail"><LoadingState label="Loading shared Mission…" /></main>;
  const projection = projectMission(snapshot.events);
  const download = async (file: FileMetadata) => {
    const response = await fetch(`/api/public/workspaces/${encodeURIComponent(coordinate.workspaceId)}/missions/${encodeURIComponent(coordinate.missionId)}/artifacts/${encodeURIComponent(file.id)}/content`, {
      headers: { "X-Pilot-Public-Token": coordinate.token },
    });
    if (!response.ok) return;
    const url = URL.createObjectURL(await response.blob());
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = file.filename;
    anchor.click();
    URL.revokeObjectURL(url);
  };
  return <main className="mission-detail public-mission">
    <header className="mission-header"><div><div className="eyebrow">Public read-only Mission</div><h1>{snapshot.mission.title || "Untitled mission"}</h1></div><StatusPill tone="neutral">{projection.status}</StatusPill></header>
    {projection.result ? <InlineNotice tone="success" title="Result published"><ChatMarkdown body={projection.result.summary} copyCodeLabel="Copy code" copiedCodeLabel="Copied" copyFailedLabel="Copy failed" /></InlineNotice> : null}
    <div className="mission-workspace">
      <section className="transcript-panel"><ChatMessageList ariaLabel="Mission transcript" jumpLabel="Jump to latest">{projection.messages.map((message) => <ChatMessage key={message.id} role={message.role} authorLabel={message.role === "assistant" ? "Pilot" : message.role === "user" ? "User" : "System"} body={<ChatMarkdown body={message.text} copyCodeLabel="Copy code" copiedCodeLabel="Copied" copyFailedLabel="Copy failed" />} />)}</ChatMessageList></section>
      <aside className="mission-context">
        <section className="context-section"><h2>Plan</h2>{projection.plan ? <><p className="plan-summary">{projection.plan.summary}</p><ol className="plan-list">{projection.plan.steps.map((step) => <li key={step.id} data-status={step.status}><span>{step.status === "completed" ? "✓" : "○"}</span><div><strong>{step.title}</strong>{step.detail ? <small>{step.detail}</small> : null}</div></li>)}</ol></> : <p className="muted">No structured plan.</p>}</section>
        <section className="context-section"><h2>Agents ({snapshot.threads.length})</h2>{snapshot.threads.length ? <ul className="context-list">{snapshot.threads.map((thread) => <li key={thread.id}><strong>{thread.agent.type === "agent" ? thread.agent.name : `Advisor · ${thread.agent.model}`}</strong></li>)}</ul> : <p className="muted">No sub-agent threads.</p>}</section>
        <section className="context-section"><h2>Artifacts ({snapshot.artifacts.length})</h2>{snapshot.artifacts.length ? <ul className="context-list">{snapshot.artifacts.map((file) => <li key={file.id}><span><strong>{file.filename}</strong></span><Button variant="ghost" disabled={file.downloadable === false} onClick={() => void download(file)}>Download</Button></li>)}</ul> : <p className="muted">No artifacts.</p>}</section>
      </aside>
    </div>
  </main>;
}
