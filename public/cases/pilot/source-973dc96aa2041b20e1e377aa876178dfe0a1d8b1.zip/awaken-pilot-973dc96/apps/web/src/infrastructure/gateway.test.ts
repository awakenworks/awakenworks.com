import { describe, expect, it, vi } from "vitest";
import { consumeJsonEventStream, PilotApiGateway } from "./gateway";

/**
 * Browser API-adapter cause-effect table:
 * C1 valid mission input + 2xx JSON -> E1 one /api request containing only the
 * Project reference and mission direction; the returned Session is unchanged.
 * C9 public-link create/revoke -> E9 same encoded Mission subresource, with
 * the fixed seven-day product policy only on create.
 * C4 valid Project command -> E4 one Deployment-backed /api/projects request.
 * C5 browser File -> E5 raw same-origin upload with encoded name and no Awaken credential.
 * C6 webhook command -> E6 same-origin Pilot route with camel-case product input.
 * C7 IAM product identity + Workspace route -> E7 attach both only to the BFF.
 * C10 native browser fetch requires the Window/global receiver -> E10 every
 * request preserves that receiver through the gateway method.
 * C11 Vault catalog requested -> E11 use the same-origin catalog route and
 * return secret-free upstream metadata without a direct Managed API call.
 * C12 Agent profile command -> E12 use one same-origin create/update route and
 * preserve the complete validated capability body.
 * C13 write-only credential command -> E13 send it once to the encoded Vault
 * subresource; the browser never calls the Managed Vault API directly.
 * C2 API non-2xx JSON -> E2 the stable API error becomes the operation error.
 * C3 Session ID contains reserved path bytes -> E3 bytes are encoded in one path segment.
 * Rules R1=C1; R1c=C9; R2=C2+C3; R3=C4; R4=C5; R5=C6;
 * R6=C7; R7=C10; R8=C11; R9=C12; R10=C13. No rule calls /v1 directly.
 */
describe("Pilot API request decision table", () => {
  it("R1 creates a mission through the Pilot API", async () => {
    const mission = { id: "sesn_1", type: "session" };
    const fetcher = vi.fn(async () => new Response(JSON.stringify(mission), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    await expect(gateway.createMission({ projectId: "deployment_1", title: "Brief", goal: "Verify it", mode: "plan", acceptanceCriteria: "", maxIterations: 3 })).resolves.toEqual(mission);
    const [url, init] = fetcher.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe("/api/missions");
    expect(init.method).toBe("POST");
    expect(JSON.parse(String(init.body))).toEqual({ projectId: "deployment_1", title: "Brief", goal: "Verify it", mode: "plan", acceptanceCriteria: "", maxIterations: 3 });
  });

  it("R1c creates and revokes a public link through one Mission subresource", async () => {
    const link = { missionId: "sesn/share", workspaceId: "ws_1", token: "capability", expiresAt: "2026-08-20T00:00:00.000Z" };
    const fetcher = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => new Response(
      init?.method === "DELETE" ? null : JSON.stringify(link),
      { status: init?.method === "DELETE" ? 204 : 201, headers: { "content-type": "application/json" } },
    ));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);

    await expect(gateway.createPublicLink("sesn/share")).resolves.toEqual(link);
    await expect(gateway.revokePublicLink("sesn/share")).resolves.toBeUndefined();

    expect(fetcher).toHaveBeenNthCalledWith(1, "/api/missions/sesn%2Fshare/public-link", expect.objectContaining({
      method: "POST",
      body: JSON.stringify({ expiresInDays: 7 }),
      credentials: "same-origin",
    }));
    expect(fetcher).toHaveBeenNthCalledWith(2, "/api/missions/sesn%2Fshare/public-link", expect.objectContaining({
      method: "DELETE",
      credentials: "same-origin",
    }));
  });

  it("R3 sends a Project command only to the Pilot Projects endpoint", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ id: "deployment_1" }), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    const command = {
      name: "Research desk", instruction: "Verify sources", agentId: "agent_1", environmentId: "env_1",
      vaultIds: [], fileIds: [], memoryStoreIds: [], budgetUsdCents: null, schedule: null,
    };
    await gateway.createProject(command);
    expect(fetcher).toHaveBeenCalledWith("/api/projects", expect.objectContaining({
      method: "POST",
      body: JSON.stringify(command),
    }));
  });

  it("R4 sends file bytes through the same-origin Pilot API", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ id: "file_1" }), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    const file = new File(["verified"], "资料.md", { type: "text/markdown" });
    await gateway.uploadKnowledgeFile(file);
    const [url, init] = fetcher.mock.calls[0] as unknown as [string, RequestInit];
    const headers = new Headers(init.headers);
    expect(url).toBe("/api/files");
    expect(init).toEqual(expect.objectContaining({ method: "POST", body: file, credentials: "same-origin" }));
    expect(headers.get("content-type")).toBe("application/octet-stream");
    expect(headers.get("x-pilot-filename")).toBe(encodeURIComponent("资料.md"));
    expect(headers.get("x-pilot-mime-type")).toBe("text/markdown");
  });

  it("R5 manages webhooks only through the same-origin Pilot API", async () => {
    const fetcher = vi.fn(async (_input: RequestInfo | URL, _init?: RequestInit) => new Response(JSON.stringify({ id: "wh_1" }), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    const command = { url: "https://receiver.example/hook", eventTypes: [], disabled: false };
    await gateway.putWebhook("wh/one", command);
    const [url, init] = fetcher.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe("/api/webhooks/wh%2Fone");
    expect(init).toEqual(expect.objectContaining({ method: "PUT", body: JSON.stringify(command), credentials: "same-origin" }));
    expect(new Headers(init.headers).get("content-type")).toBe("application/json");
    expect(String(fetcher.mock.calls[0]?.[0])).not.toContain("/v1/");
  });

  it("R6 sends the IAM identity and Workspace only to the same-origin BFF", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ data: [], has_more: false }), { headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch, () => ({ token: "product-token", workspaceId: "workspace_team" }));
    await gateway.listProjects();
    const [url, init] = fetcher.mock.calls[0] as unknown as [string, RequestInit];
    const headers = new Headers(init.headers);
    expect(url).toBe("/api/projects");
    expect(headers.get("authorization")).toBe("Bearer product-token");
    expect(headers.get("x-pilot-workspace-id")).toBe("workspace_team");
    expect(init.credentials).toBe("same-origin");
  });

  it("R7 invokes a browser-compatible fetcher with the global receiver", async () => {
    let receiver: unknown;
    const fetcher = function (this: unknown) {
      receiver = this;
      return Promise.resolve(new Response(JSON.stringify([]), {
        headers: { "content-type": "application/json" },
      }));
    } as typeof fetch;
    const gateway = new PilotApiGateway(fetcher);

    await expect(gateway.listProjects()).resolves.toEqual([]);
    expect(receiver).toBe(globalThis);
  });

  it("R8 reads Vault metadata only through the Pilot catalog", async () => {
    const vaults = [{ id: "vlt_1", type: "vault", display_name: "Connectors", archived_at: null }];
    const fetcher = vi.fn(async () => new Response(JSON.stringify(vaults), { headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    await expect(gateway.listVaults()).resolves.toEqual(vaults);
    expect(fetcher).toHaveBeenCalledWith("/api/catalog/vaults", expect.objectContaining({ credentials: "same-origin" }));
  });

  it("R9 creates an Agent profile only through the Pilot API", async () => {
    const profile = {
      name: "Manus", description: "", model: "deepseek-v4-flash", system: "",
      tools: [], skills: [], connectors: [], subagentIds: [], includeSelf: false,
    };
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ id: "agent_1" }), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    await gateway.createAgentProfile(profile);
    expect(fetcher).toHaveBeenCalledWith("/api/agents", expect.objectContaining({
      method: "POST",
      body: JSON.stringify(profile),
      credentials: "same-origin",
    }));
  });

  it("R10 writes a credential once through its Vault subresource", async () => {
    const command = {
      displayName: "Browser",
      auth: { type: "static_bearer" as const, mcpServerUrl: "https://browser.example.test/mcp", token: "write-only-secret" },
    };
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ id: "vcrd_1" }), { status: 201, headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    await gateway.createVaultCredential("vlt/one", command);
    expect(fetcher).toHaveBeenCalledWith("/api/vaults/vlt%2Fone/credentials", expect.objectContaining({
      method: "POST",
      body: JSON.stringify(command),
      credentials: "same-origin",
    }));
  });

  it("R2 encodes the Session path and exposes only the stable API error", async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ error: "Mission unavailable", internal: "secret" }), { status: 404, headers: { "content-type": "application/json" } }));
    const gateway = new PilotApiGateway(fetcher as unknown as typeof fetch);
    await expect(gateway.getMission("sesn/one")).rejects.toThrow("Mission unavailable");
    expect(fetcher).toHaveBeenCalledWith("/api/missions/sesn%2Fone", expect.objectContaining({ credentials: "same-origin" }));
  });
});

/**
 * SSE parser cause-effect table:
 * S1 comments/heartbeats -> E1 ignored.
 * S2 JSON data split across transport chunks -> E2 exactly one reconstructed event.
 * S3 multiple complete frames -> E3 ordered, once-only delivery.
 * S4 malformed data -> E4 reject so the committed-event query can recover.
 * Rules R1=S1+S2+S3; R2=S4.
 */
describe("SSE parsing decision table", () => {
  it("R1 reconstructs split frames and ignores heartbeats", async () => {
    const chunks = [": connected\n\ndata: {\"type\":\"agent.", "message_delta\",\"delta\":\"hello\"}\n\n: heartbeat\n\ndata: {\"type\":\"session.end\"}\n\n"];
    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        for (const chunk of chunks) controller.enqueue(new TextEncoder().encode(chunk));
        controller.close();
      },
    });
    const received: unknown[] = [];
    await consumeJsonEventStream(body, (event) => received.push(event));
    expect(received).toEqual([
      { type: "agent.message_delta", delta: "hello" },
      { type: "session.end" },
    ]);
  });

  it("R2 rejects malformed data", async () => {
    const body = new Response("data: {broken}\n\n").body;
    if (!body) throw new Error("test body missing");
    await expect(consumeJsonEventStream(body, vi.fn())).rejects.toBeInstanceOf(SyntaxError);
  });
});
