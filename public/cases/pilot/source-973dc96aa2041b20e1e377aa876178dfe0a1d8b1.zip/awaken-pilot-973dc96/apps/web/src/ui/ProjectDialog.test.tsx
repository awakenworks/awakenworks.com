import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ProjectDialog } from "./ProjectDialog";

afterEach(cleanup);

const catalog = {
  agents: [{ id: "agent_1", name: "Builder", version: 3, tools: [], skills: [], mcp_servers: [], multiagent: null }] as never[],
  environments: [{ id: "env_1", name: "Cloud" }] as never[],
  files: [{ id: "file_1", filename: "brief.pdf", mime_type: "application/pdf", size_bytes: 1024 }] as never[],
  memoryStores: [{ id: "memstore_1", name: "Research memory", description: "Shared findings" }] as never[],
  vaults: [{ id: "vlt_1", display_name: "Publishing credentials", archived_at: null }] as never[],
};

const resourceCallbacks = {
  onUploadFile: vi.fn(async () => ({ id: "file_uploaded" }) as never),
  onCreateMemoryStore: vi.fn(async () => ({ id: "memstore_created" }) as never),
};

/**
 * Project editor cause-effect table:
 * U1 required identity/instruction/catalog choices incomplete -> E1 save disabled.
 * U2 schedule enabled but recurring direction missing -> E2 save remains disabled.
 * U3 all fields valid -> E3 emit exactly one normalized Project command, including
 * minor-unit budget and split opaque resource IDs.
 * U4 upload/create succeeds -> E4 select the returned official File/Memory Store ID;
 * U5 active Vault catalog entry selected -> E5 emit only its official ID; an
 * unavailable ID already attached to an edited Project remains representable.
 * no local resource identity is created.
 * Rules R1=U1; R2=U1 false + U2; R3=U1 false + U2 false + U3; R4=U4; R5=U5.
 */
describe("Project editor decision table", () => {
  it("R1/R2 prevents incomplete Project and schedule commands", async () => {
    const user = userEvent.setup();
    render(<ProjectDialog open {...catalog} {...resourceCallbacks} pending={false} onClose={vi.fn()} onSave={vi.fn()} />);
    const save = screen.getByRole("button", { name: "Save project" });
    expect(save).toBeDisabled();
    await user.type(screen.getByLabelText("Project name"), "Research desk");
    await user.type(screen.getByLabelText("Master instruction"), "Verify every claim.");
    await user.selectOptions(screen.getByLabelText("Agent"), "agent_1");
    await user.selectOptions(screen.getByLabelText("Environment"), "env_1");
    expect(screen.getByRole("region", { name: "Agent capabilities" })).toHaveTextContent("owned and executed by Awaken");
    expect(save).toBeEnabled();
    await user.click(screen.getByRole("checkbox", { name: "Run on a schedule" }));
    expect(save).toBeDisabled();
  });

  it("R3 emits one normalized scheduled Deployment command", async () => {
    const user = userEvent.setup();
    const onSave = vi.fn();
    render(<ProjectDialog open {...catalog} {...resourceCallbacks} pending={false} onClose={vi.fn()} onSave={onSave} />);
    await user.type(screen.getByLabelText("Project name"), "Research desk");
    await user.type(screen.getByLabelText("Master instruction"), "Verify every claim.");
    await user.selectOptions(screen.getByLabelText("Agent"), "agent_1");
    await user.selectOptions(screen.getByLabelText("Environment"), "env_1");
    await user.click(screen.getByRole("checkbox", { name: /Publishing credentials/i }));
    await user.click(screen.getByRole("checkbox", { name: /brief\.pdf/i }));
    await user.click(screen.getByRole("checkbox", { name: /Research memory/i }));
    await user.type(screen.getByLabelText("Per-mission budget in USD (optional)"), "25.50");
    await user.click(screen.getByRole("checkbox", { name: "Run on a schedule" }));
    await user.type(screen.getByLabelText("Scheduled direction"), "Publish the weekly brief.");
    await user.click(screen.getByRole("button", { name: "Save project" }));
    expect(onSave).toHaveBeenCalledOnce();
    expect(onSave).toHaveBeenCalledWith(expect.objectContaining({
      name: "Research desk",
      agentId: "agent_1",
      environmentId: "env_1",
      vaultIds: ["vlt_1"],
      fileIds: ["file_1"],
      memoryStoreIds: ["memstore_1"],
      budgetUsdCents: 2550,
      schedule: expect.objectContaining({ prompt: "Publish the weekly brief.", expression: "0 9 * * 1-5" }),
    }));
  });

  it("R4 selects IDs returned by official resource creation", async () => {
    const user = userEvent.setup();
    const onUploadFile = vi.fn(async () => ({ id: "file_uploaded", filename: "new.txt", mime_type: "text/plain", size_bytes: 3 }) as never);
    const onCreateMemoryStore = vi.fn(async () => ({ id: "memstore_created", name: "New memory" }) as never);
    render(<ProjectDialog open {...catalog} pending={false} onClose={vi.fn()} onSave={vi.fn()} onUploadFile={onUploadFile} onCreateMemoryStore={onCreateMemoryStore} />);
    await user.upload(screen.getByLabelText("Upload knowledge file"), new File(["new"], "new.txt", { type: "text/plain" }));
    await user.type(screen.getByLabelText("New Memory Store name"), "New memory");
    await user.click(screen.getByRole("button", { name: "Create and select memory" }));
    expect(onUploadFile).toHaveBeenCalledOnce();
    expect(onCreateMemoryStore).toHaveBeenCalledWith({ name: "New memory", description: "" });
    expect(screen.getByRole("checkbox", { name: /file_uploaded/i })).toBeChecked();
    expect(screen.getByRole("checkbox", { name: /memstore_created/i })).toBeChecked();
  });
});
