export const PILOT_WORKSPACE_HEADER = "X-Pilot-Workspace-Id";
