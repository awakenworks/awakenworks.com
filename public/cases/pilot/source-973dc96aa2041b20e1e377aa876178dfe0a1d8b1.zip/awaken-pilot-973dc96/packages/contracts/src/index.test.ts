import { describe, expect, it } from "vitest";
import { parseAgentProfileCommand, parseVaultCredentialCommand, RequestValidationError } from "./index.js";

const valid = {
  name: "Manus profile",
  description: "Research and publish",
  model: "deepseek-v4-flash",
  system: "Complete the requested work.",
  tools: [{ name: "web_search", permission: "always_allow" }],
  skills: [{ type: "anthropic", skillId: "pptx", version: "latest" }],
  connectors: [{ name: "browser", url: "https://browser.example.test/mcp", permission: "always_ask" }],
  subagentIds: ["agent_research"],
  includeSelf: false,
};

/**
 * Agent-profile cause/effect graph:
 * C1 known tools/Skills plus unique Connector/roster identities and safe HTTP(S)
 * targets -> E1 one normalized command; C2 unknown prebuilt Skill, duplicate
 * identity, credential-bearing/fragment URL, invalid version, or roster >20 ->
 * E2 atomic rejection before any Agent/Vault mutation.
 * Decision rules: R1=C1; R2=each independent C2 partition.
 */
describe("Agent profile contract decision table", () => {
  it("R1 accepts one complete authoritative Agent configuration", () => {
    expect(parseAgentProfileCommand(valid)).toEqual(valid);
  });

  it.each([
    { tools: [...valid.tools, ...valid.tools] },
    { skills: [{ type: "anthropic", skillId: "video", version: "latest" }] },
    { skills: [{ type: "custom", skillId: "skill_1", version: "zero" }] },
    { connectors: [{ ...valid.connectors[0], url: "https://user:secret@example.test/mcp" }] },
    { connectors: [valid.connectors[0], { ...valid.connectors[0] }] },
    { subagentIds: Array.from({ length: 20 }, (_, index) => `agent_${index}`), includeSelf: true },
  ])("R2 rejects an invalid or ambiguous capability partition", (override) => {
    expect(() => parseAgentProfileCommand({ ...valid, ...override })).toThrow(RequestValidationError);
  });
});

/**
 * Credential cause/effect graph:
 * V1 write-only bearer/OAuth/environment secret plus exact target boundary ->
 * E1 normalized command; V2 credential-bearing target URL, limited mode without
 * hosts, no injection location, or incomplete OAuth refresh client -> E2 reject
 * before secret egress. Decision rules: R1=V1 per auth variant; R2=V2.
 */
describe("Vault credential contract decision table", () => {
  it.each([
    { type: "static_bearer", mcpServerUrl: "https://mcp.example.test", token: "secret" },
    { type: "mcp_oauth", mcpServerUrl: "https://mcp.example.test", accessToken: "access", expiresAt: null, refresh: null },
    { type: "environment_variable", secretName: "STRIPE_API_KEY", secretValue: "secret", allowedHosts: ["api.stripe.com"], unrestricted: false, injectHeader: true, injectBody: false },
  ])("R1 accepts a bounded write-only credential variant", (auth) => {
    expect(parseVaultCredentialCommand({ displayName: "Connector", auth })).toEqual({ displayName: "Connector", auth });
  });

  it.each([
    { type: "static_bearer", mcpServerUrl: "https://user:secret@mcp.example.test", token: "secret" },
    { type: "environment_variable", secretName: "KEY", secretValue: "secret", allowedHosts: [], unrestricted: false, injectHeader: true, injectBody: false },
    { type: "environment_variable", secretName: "KEY", secretValue: "secret", allowedHosts: ["api.example.test"], unrestricted: false, injectHeader: false, injectBody: false },
  ])("R2 rejects an unsafe or incomplete secret boundary", (auth) => {
    expect(() => parseVaultCredentialCommand({ displayName: "Connector", auth })).toThrow(RequestValidationError);
  });
});
