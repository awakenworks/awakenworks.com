import { z } from "zod";

const identifier = z.string().trim().min(1).max(500);
const identifierList = z.array(identifier).max(500);
const toolPermissionSchema = z.enum(["always_allow", "always_ask"]);
const agentToolNameSchema = z.enum(["bash", "edit", "read", "write", "glob", "grep", "web_fetch", "web_search"]);

const agentToolCommandSchema = z.object({
  name: agentToolNameSchema,
  permission: toolPermissionSchema,
});

const agentSkillCommandSchema = z.object({
  type: z.enum(["anthropic", "custom"]),
  skillId: identifier,
  version: z.string().trim().refine(
    (value) => value === "latest" || /^[1-9]\d*$/.test(value),
    "Skill version must be latest or a positive integer",
  ),
}).superRefine((skill, context) => {
  if (skill.type === "anthropic" && !["pptx", "xlsx", "docx", "pdf"].includes(skill.skillId)) {
    context.addIssue({ code: "custom", path: ["skillId"], message: "Unknown Anthropic Skill" });
  }
});

function validMcpUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password && !url.hash;
  } catch {
    return false;
  }
}

const agentConnectorCommandSchema = z.object({
  name: z.string().trim().min(1).max(255).regex(/^[A-Za-z0-9._-]+$/),
  url: z.string().trim().min(1).max(2_048).refine(validMcpUrl, "Connector URL must be HTTP(S) without credentials or a fragment"),
  permission: toolPermissionSchema,
});

export const agentProfileCommandSchema = z.object({
  name: z.string().trim().min(1).max(200),
  description: z.string().trim().max(1_000),
  model: identifier,
  system: z.string().trim().max(100_000),
  tools: z.array(agentToolCommandSchema).max(8),
  skills: z.array(agentSkillCommandSchema).max(500),
  connectors: z.array(agentConnectorCommandSchema).max(20),
  subagentIds: identifierList.max(20),
  includeSelf: z.boolean(),
}).superRefine((profile, context) => {
  const unique = <T>(values: T[]) => new Set(values).size === values.length;
  if (!unique(profile.tools.map((tool) => tool.name))) {
    context.addIssue({ code: "custom", path: ["tools"], message: "Tool names must be unique" });
  }
  if (!unique(profile.skills.map((skill) => `${skill.type}:${skill.skillId}`))) {
    context.addIssue({ code: "custom", path: ["skills"], message: "Skill identities must be unique" });
  }
  if (!unique(profile.connectors.map((connector) => connector.name))) {
    context.addIssue({ code: "custom", path: ["connectors"], message: "Connector names must be unique" });
  }
  if (!unique(profile.subagentIds)) {
    context.addIssue({ code: "custom", path: ["subagentIds"], message: "Subagent IDs must be unique" });
  }
  if (profile.subagentIds.length + Number(profile.includeSelf) > 20) {
    context.addIssue({ code: "custom", path: ["subagentIds"], message: "Multi-agent roster supports at most 20 entries" });
  }
});

export const updateAgentProfileCommandSchema = agentProfileCommandSchema.extend({
  version: z.number().int().positive(),
});

export type AgentProfileCommand = z.infer<typeof agentProfileCommandSchema>;
export type UpdateAgentProfileCommand = z.infer<typeof updateAgentProfileCommandSchema>;

export const vaultCommandSchema = z.object({
  displayName: z.string().trim().min(1).max(255),
});

const mcpTargetUrl = z.string().trim().min(1).max(2_048).refine(validMcpUrl, "MCP URL must be HTTP(S) without credentials or a fragment");
const tokenEndpointUrl = z.string().trim().min(1).max(2_048).refine(validMcpUrl, "Token endpoint must be HTTP(S) without credentials or a fragment");
const oauthRefreshSchema = z.object({
  clientId: identifier,
  refreshToken: z.string().min(1).max(100_000),
  tokenEndpoint: tokenEndpointUrl,
  tokenEndpointAuth: z.discriminatedUnion("type", [
    z.object({ type: z.literal("none") }),
    z.object({ type: z.literal("client_secret_basic"), clientSecret: z.string().min(1).max(100_000) }),
    z.object({ type: z.literal("client_secret_post"), clientSecret: z.string().min(1).max(100_000) }),
  ]),
  scope: z.string().trim().max(4_000).nullable(),
  resource: z.string().trim().max(2_048).nullable(),
});

const credentialAuthSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("static_bearer"),
    mcpServerUrl: mcpTargetUrl,
    token: z.string().min(1).max(100_000),
  }),
  z.object({
    type: z.literal("mcp_oauth"),
    mcpServerUrl: mcpTargetUrl,
    accessToken: z.string().min(1).max(100_000),
    expiresAt: z.iso.datetime({ offset: true }).nullable(),
    refresh: oauthRefreshSchema.nullable(),
  }),
  z.object({
    type: z.literal("environment_variable"),
    secretName: z.string().trim().min(1).max(255).regex(/^[A-Za-z_][A-Za-z0-9_]*$/),
    secretValue: z.string().min(1).max(100_000),
    allowedHosts: z.array(z.string().trim().min(1).max(253)).max(16),
    unrestricted: z.boolean(),
    injectHeader: z.boolean(),
    injectBody: z.boolean(),
  }).superRefine((auth, context) => {
    if (!auth.unrestricted && !auth.allowedHosts.length) {
      context.addIssue({ code: "custom", path: ["allowedHosts"], message: "Limited credentials require at least one allowed host" });
    }
    if (!auth.injectHeader && !auth.injectBody) {
      context.addIssue({ code: "custom", path: ["injectHeader"], message: "Select at least one injection location" });
    }
  }),
]);

export const vaultCredentialCommandSchema = z.object({
  displayName: z.string().trim().min(1).max(255),
  auth: credentialAuthSchema,
});

export type VaultCommand = z.infer<typeof vaultCommandSchema>;
export type VaultCredentialCommand = z.infer<typeof vaultCredentialCommandSchema>;

export const projectScheduleSchema = z.object({
  prompt: z.string().trim().min(1).max(100_000),
  expression: z.string().trim().refine(
    (value) => value.split(/\s+/).length === 5,
    "Must be a 5-field POSIX cron expression",
  ),
  timezone: z.string().trim().min(1).max(100).refine((value) => {
    try {
      new Intl.DateTimeFormat("en", { timeZone: value });
      return true;
    } catch {
      return false;
    }
  }, "Must be an IANA timezone"),
});

export type ProjectSchedule = z.infer<typeof projectScheduleSchema>;

export const projectCommandSchema = z.object({
  name: z.string().trim().min(1).max(200),
  instruction: z.string().trim().min(1).max(100_000),
  agentId: identifier,
  environmentId: identifier,
  vaultIds: identifierList.max(50),
  fileIds: identifierList,
  memoryStoreIds: identifierList,
  budgetUsdCents: z.number().int().positive().max(1_000_000_000).nullable(),
  schedule: projectScheduleSchema.nullable(),
});

export type ProjectCommand = z.infer<typeof projectCommandSchema>;

export const memoryStoreCommandSchema = z.object({
  name: z.string().trim().min(1).max(255),
  description: z.string().trim().max(1_024),
});

export type MemoryStoreCommand = z.infer<typeof memoryStoreCommandSchema>;

export const webhookCommandSchema = z.object({
  url: z.string().trim().min(1).max(2_048),
  eventTypes: z.array(z.string().trim().min(1).max(500)).max(100),
  disabled: z.boolean(),
});

export type WebhookCommand = z.infer<typeof webhookCommandSchema>;

export interface WebhookSubscription {
  id: string;
  workspace_id: string;
  url: string;
  event_types: string[];
  disabled: boolean;
  secret?: string;
}

const missionLaunchFields = {
  title: z.string().trim().min(1).max(500),
  goal: z.string().trim().min(1).max(100_000),
  mode: z.enum(["execute", "plan"]),
  acceptanceCriteria: z.string().trim().max(100_000),
  maxIterations: z.number().int().min(1).max(20),
};

function validateMissionLaunch(
  request: { mode: "execute" | "plan"; acceptanceCriteria: string },
  context: z.RefinementCtx,
) {
  if (request.mode === "plan" && request.acceptanceCriteria) {
    context.addIssue({
      code: "custom",
      path: ["acceptanceCriteria"],
      message: "Plan Mode cannot start automatic outcome evaluation before approval",
    });
  }
}

export const createMissionRequestSchema = z.object({
  projectId: identifier,
  ...missionLaunchFields,
}).superRefine(validateMissionLaunch);

export type CreateMissionRequest = z.infer<typeof createMissionRequestSchema>;

export const publicMissionLinkRequestSchema = z.object({
  expiresInDays: z.number().int().min(1).max(30).default(7),
});

export type PublicMissionLinkRequest = z.infer<typeof publicMissionLinkRequestSchema>;

export interface PublicMissionLink {
  missionId: string;
  workspaceId: string;
  token: string;
  expiresAt: string;
}

export const messageRequestSchema = z.object({
  text: z.string().trim().min(1).max(100_000),
});

export const approvalDecisionSchema = z.object({
  toolUseId: z.string().trim().min(1),
  allow: z.boolean(),
  reason: z.string().trim().min(1).max(4_000).optional(),
  sessionThreadId: z.string().trim().min(1).optional(),
}).superRefine((decision, context) => {
  if (decision.allow && decision.reason !== undefined) {
    context.addIssue({ code: "custom", path: ["reason"], message: "An allowed decision cannot include a denial reason" });
  }
});

export type ApprovalDecision = z.infer<typeof approvalDecisionSchema>;

export class RequestValidationError extends Error {
  constructor(readonly issues: readonly unknown[]) {
    super("Invalid request");
  }
}

function parseRequest<T>(schema: z.ZodType<T>, input: unknown): T {
  const result = schema.safeParse(input);
  if (!result.success) throw new RequestValidationError(result.error.issues);
  return result.data;
}

export function parseCreateMissionRequest(input: unknown): CreateMissionRequest {
  return parseRequest(createMissionRequestSchema, input);
}

export function parsePublicMissionLinkRequest(input: unknown): PublicMissionLinkRequest {
  return parseRequest(publicMissionLinkRequestSchema, input);
}

export function parseProjectCommand(input: unknown): ProjectCommand {
  return parseRequest(projectCommandSchema, input);
}

export function parseAgentProfileCommand(input: unknown): AgentProfileCommand {
  return parseRequest(agentProfileCommandSchema, input);
}

export function parseUpdateAgentProfileCommand(input: unknown): UpdateAgentProfileCommand {
  return parseRequest(updateAgentProfileCommandSchema, input);
}

export function parseVaultCommand(input: unknown): VaultCommand {
  return parseRequest(vaultCommandSchema, input);
}

export function parseVaultCredentialCommand(input: unknown): VaultCredentialCommand {
  return parseRequest(vaultCredentialCommandSchema, input);
}

export function parseMemoryStoreCommand(input: unknown): MemoryStoreCommand {
  return parseRequest(memoryStoreCommandSchema, input);
}

export function parseWebhookCommand(input: unknown): WebhookCommand {
  return parseRequest(webhookCommandSchema, input);
}

export function parseMessageRequest(input: unknown): { text: string } {
  return parseRequest(messageRequestSchema, input);
}

export function parseApprovalDecision(input: unknown): ApprovalDecision {
  return parseRequest(approvalDecisionSchema, input);
}
