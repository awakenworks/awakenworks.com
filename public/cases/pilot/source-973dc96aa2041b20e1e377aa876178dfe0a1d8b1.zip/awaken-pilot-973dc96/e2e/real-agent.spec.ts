import { createHash, randomUUID } from "node:crypto";
import { expect, test, type APIRequestContext, type Page } from "@playwright/test";

const enabled = process.env.PILOT_E2E_RUN === "1";
const baseUrl = process.env.PILOT_E2E_BASE_URL ?? "http://127.0.0.1:18773";
const workspaceId = process.env.PILOT_E2E_WORKSPACE_ID ?? "pilot_e2e";
const iamUrl = process.env.PILOT_E2E_IAM_URL ?? "http://127.0.0.1:18776";
const iamAdminToken = process.env.PILOT_E2E_IAM_ADMIN_TOKEN ?? "";
const browserFixtureUrl = process.env.PILOT_E2E_BROWSER_FIXTURE_URL ?? "";
const agentRuntime = process.env.PILOT_E2E_AGENT_RUNTIME ?? "acp";
const nistResearchAgentId = process.env.PILOT_E2E_NIST_AGENT_ID ?? "";
const w3cResearchAgentId = process.env.PILOT_E2E_W3C_AGENT_ID ?? "";
const agentId = process.env.PILOT_E2E_AGENT_ID ?? "";
const environmentName = process.env.PILOT_E2E_ENVIRONMENT_NAME ?? "Pilot Real Cloud";

test.skip(!enabled, "Run through `pnpm e2e:real` with built Awaken and IAM binaries.");

function publicGrantId(missionId: string): string {
  return `pilot-public:${createHash("sha256").update(JSON.stringify([workspaceId, missionId])).digest("hex")}`;
}

async function expectCreated(response: Awaited<ReturnType<APIRequestContext["post"]>>, label: string) {
  expect(response.status(), `${label}: ${await response.text()}`).toBe(201);
  return response.json();
}

async function expectApplied(response: Awaited<ReturnType<APIRequestContext["post"]>>, label: string) {
  expect(response.ok(), `${label}: ${await response.text()}`).toBeTruthy();
}

async function createPublicCapability(request: APIRequestContext, missionId: string): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const subject = `pilot-browser-e2e-${randomUUID()}`;
  const headers = { Authorization: `Bearer ${iamAdminToken}` };
  const issued = await expectCreated(await request.post(`${iamUrl}/v1/admin/capabilities`, {
    headers,
    data: {
      issuer: iamUrl,
      subject,
      audience: "awaken-pilot-public",
      token_id: `cap-${randomUUID()}`,
      issued_at: now,
      expires_at: now + 600,
      scopes: ["pilot.mission.read"],
    },
  }), "capability mint");
  await expectApplied(await request.post(`${iamUrl}/v1/admin/grants`, {
    headers,
    data: {
      id: publicGrantId(missionId),
      subject: { kind: "principal", principal: { kind: "service", service_id: subject } },
      action_pattern: "pilot.mission.read",
      scope: {
        kind: "resource",
        resource_type: "pilot_mission",
        resource_id: JSON.stringify([workspaceId, missionId]),
      },
      effect: "allow",
    },
  }), "exact Mission grant");
  return issued.token as string;
}

async function waitForPublishedResult(page: Page, marker: string, timeoutMs = 180_000) {
  // Each Project keeps prior Session summaries visible in the left rail. Scope
  // terminal-state polling to the authoritative selected Session projection so
  // R2 cannot satisfy R9 (or any later rule) with an earlier Session's result.
  const selectedMission = page.locator("main.mission-detail");
  // Result-effect locator rule: C1 the committed publish_result projection is
  // rendered as the selected Mission's notice; C2 model-authored transcript
  // text may repeat the same copy. R1 C1+C2 -> select only the notice title so
  // model wording cannot create a strict-locator false negative.
  const result = selectedMission.locator(".ui-inline-notice__title").getByText("Result published", { exact: true });
  const failed = selectedMission.getByText("Mission failed", { exact: true });
  const unexpectedApproval = selectedMission.getByRole("button", { name: "Allow", exact: true });
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await result.isVisible().catch(() => false)
      && (await result.locator("xpath=..").innerText()).includes(marker)) return;
    if (await failed.isVisible().catch(() => false)) throw new Error(await failed.locator("xpath=..").innerText());
    if (await unexpectedApproval.isVisible().catch(() => false)
      && await unexpectedApproval.isEnabled().catch(() => false)) {
      throw new Error("Mission requested an unexpected tool confirmation");
    }
    await page.waitForTimeout(1_000);
  }
  await expect(result).toBeVisible();
  await expect(result.locator("xpath=..")).toContainText(marker);
}

function selectedMissionId(page: Page): string {
  return decodeURIComponent(new URL(page.url()).pathname.split("/").at(-1) ?? "");
}

test("real stack accepts research, desktop/mobile web, scheduled resources, Plan, Outcome, artifacts, and IAM", async ({ page, request }) => {
  /* Cause/effect graph:
   * C1 real declared Agent runtime has Pilot MCP plus read/glob allow and bash ask;
   * C1a native-deepseek selects an active write-only BYOK route and an exact
   * on_tool_use Hand Environment; C1b acp selects the compatibility runner;
   * C2 browser creates one scheduled Project with official File + Memory IDs,
   * then removes File from the same Deployment before BackendOwned execution;
   * C3 manual schedule fire; C4 Plan Mode publishes a plan; C5 user approves;
   * C6 a fresh Outcome Session requests bash; C7 user allows; C8 rubric is
   * satisfied; C9 IAM exact Grant;
   * C11 Grant revoked; C12 official Playwright MCP reaches and mutates a real page;
   * C13 transcript preserves the selected runtime's native tool identifier;
   * C14 the acceptance runner requests successful-run video retention;
   * C15 two published Native research delegates are each invoked once by their
   * exact executable Agent IDs and use live web_search/web_fetch;
   * C16 desktop and iPhone-emulated Connectors reach the same responsive fixture;
   * C17 the DeepSeek secret is imported only through Awaken's write-only config API.
   * Effects: E1 one authoritative Deployment contains both
   * Resources and cron, while the later update removes only the File; E2 scheduled
   * DeploymentRun with Memory reaches a real Session/result;
   * E3 Plan stops before result and resumes in the same Session after approval;
   * E4 bash approval, artifact harvest, rubric evaluation, MCP plan/result all
   * reach the UI once; E6 public projection reads the committed result; E7 revoke
   * fails closed; E8 browser accessibility navigation/form/click result is committed;
   * E9 audit projection shows `mcp__...` for Native or `mcp....` for ACP unchanged;
   * E10 Playwright retains the same successful browser context as visual evidence;
   * E11 two child threads synthesize official NIST/W3C URLs; E12 the fixture
   * reports desktop/no-touch and mobile/touch device facts independently; E13
   * Native inference succeeds without provider-key environment fallback.
   *
   * Decision table:
   * Constraints: exactly one of C1a/C1b is true. Native acceptance requires C1a;
   * the compatibility regression requires C1b. R1 C1+C2 -> E1.
   * R2 C1+C2+C3 -> E2. R3 C1+C4+!C5 -> plan review only.
   * R4 R3+C5 -> E3. R5 C6+!C7 -> one requires_action and no Outcome.
   * R6 R5+C7+C8 -> E4. R7 E4+C9 -> E6. R8 E4+C9+C11 -> E7.
   * R9 C1+C12 -> E8 through the same Agent/Session/MCP event path.
   * R10 R9+C13+C1a -> E9(native); R11 R9+C13+C1b -> E9(acp);
   * R12 R1..R11+C14 -> E10 (verified by the harness output artifact);
   * R13 C15 -> E11; R14 C16(desktop) -> E12(desktop); R15 C16(mobile)
   * -> E12(mobile); R16 C17 -> E13. FMECA: a single-agent cached answer, a second MCP alias
   * pointing at the desktop server, or viewport-only resizing could otherwise
   * be reported as deep research/mobile operation without the claimed effect;
   * provider-key inheritance is critical and must stop setup before services;
   * passing display names to agent_run must not be mistaken for an executable
   * roster test because the stable Agent ID is the authoritative target; retrying
   * a completed delegate would duplicate research cost and hide orchestration drift.
   */
  await page.goto(`${baseUrl}/w/${encodeURIComponent(workspaceId)}`);
  await page.getByRole("button", { name: "New project" }).click();
  const dialog = page.getByRole("dialog", { name: "New project" });
  await dialog.getByLabel("Project name").fill(`Full Manus acceptance ${Date.now()}`);
  await dialog.getByLabel("Master instruction").fill("Use mounted knowledge as authoritative context. Use the Pilot MCP for structured plans, progress, and final results.");
  await dialog.getByLabel("Agent").selectOption(agentId);
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("pilot");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("browser");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("mobile");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("web_search");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("web_fetch");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("pptx@latest");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("xlsx@latest");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("docx@latest");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("pdf@latest");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("read");
  await expect(dialog.getByLabel("Agent capabilities")).toContainText("bash");
  await dialog.getByLabel("Environment").selectOption({ label: environmentName });
  await dialog.getByLabel("Upload knowledge file").setInputFiles({
    name: "acceptance-knowledge.txt",
    mimeType: "text/plain",
    buffer: Buffer.from("The authoritative resource token is RESOURCE_ALPHA_7319."),
  });
  await dialog.getByLabel("New Memory Store name").fill(`Acceptance memory ${Date.now()}`);
  await dialog.getByLabel("Memory guidance (optional)").fill("Retain verified acceptance findings.");
  await dialog.getByRole("button", { name: "Create and select memory" }).click();
  await expect(dialog.locator('input[type="checkbox"]:checked')).toHaveCount(2);
  await dialog.getByLabel("Run on a schedule").check();
  await dialog.getByLabel("Scheduled direction").fill("Call pilot set_plan, then pilot publish_result with summary exactly E2E_SCHEDULE_OK. Do not use filesystem tools.");
  await dialog.getByLabel("Cron expression").fill("0 9 * * 1-5");
  await dialog.getByLabel("Timezone").fill("UTC");
  const projectCreated = page.waitForResponse((response) => response.url().endsWith("/api/projects") && response.request().method() === "POST");
  await dialog.getByRole("button", { name: "Save project" }).click();
  const projectResponse = await projectCreated;
  expect(projectResponse.status(), await projectResponse.text()).toBe(201);
  const project = await projectResponse.json() as {
    id: string;
    schedule: { expression: string; timezone: string } | null;
    resources: Array<{ type: string; file_id?: string; memory_store_id?: string }>;
  };
  expect(project.schedule).toMatchObject({ expression: "0 9 * * 1-5", timezone: "UTC" });
  const fileId = project.resources.find((resource) => resource.type === "file")?.file_id;
  expect(fileId).toMatch(/^file_/);
  expect(project.resources.some((resource) => resource.type === "memory_store" && resource.memory_store_id?.startsWith("memstore_"))).toBeTruthy();
  await expect(dialog).toBeHidden();
  await expect(page.getByText("Scheduled", { exact: true })).toBeVisible();

  // Preserve one provider-neutral Project path. Removing only the File mount
  // proves the update without making this business E2E a second filesystem
  // isolation authority; Awaken's Hand matrix owns that complementary proof.
  await page.getByRole("button", { name: "Edit project" }).click();
  const editor = page.getByRole("dialog", { name: "Edit project" });
  await editor.getByRole("checkbox", { name: /acceptance-knowledge\.txt/ }).uncheck();
  const projectUpdated = page.waitForResponse((response) => response.url().endsWith(`/api/projects/${project.id}`) && response.request().method() === "PUT");
  await editor.getByRole("button", { name: "Save project" }).click();
  const updateResponse = await projectUpdated;
  expect(updateResponse.ok(), await updateResponse.text()).toBeTruthy();
  const executableProject = await updateResponse.json() as { resources: Array<{ type: string }> };
  expect(executableProject.resources.some((resource) => resource.type === "file")).toBeFalsy();
  expect(executableProject.resources.some((resource) => resource.type === "memory_store")).toBeTruthy();
  await expect(editor).toBeHidden();

  const scheduledRunCreated = page.waitForResponse((response) => response.url().endsWith(`/api/projects/${project.id}/run`) && response.request().method() === "POST");
  await page.getByRole("button", { name: "Run schedule now" }).click();
  const scheduledRunResponse = await scheduledRunCreated;
  expect(scheduledRunResponse.status(), await scheduledRunResponse.text()).toBe(201);
  const scheduledRun = await scheduledRunResponse.json() as { session_id: string | null };
  expect(scheduledRun.session_id).toMatch(/^sesn_/);
  await waitForPublishedResult(page, "E2E_SCHEDULE_OK");
  await expect(page.getByRole("region", { name: "Recent scheduled runs" })).toContainText("manual");

  const browserMarker = `E2E_DESKTOP_${Date.now()}`;
  const browserTitle = `Desktop web operation ${Date.now()}`;
  await page.getByLabel("Title").fill(browserTitle);
  await page.getByLabel("Direction").fill(`Use only the desktop browser MCP to navigate to ${browserFixtureUrl}. Fill the Order reference field with ${browserMarker}, click Submit, and read the resulting status. It must start DESKTOP_CONFIRMED_. Then call pilot publish_result with a summary beginning E2E_DESKTOP_OK ${browserMarker} followed by that exact observed status. Do not use mobile, bash, filesystem, web_fetch, web_search, or delegates.`);
  await page.getByLabel("Launch mode").selectOption("execute");
  await page.getByRole("button", { name: "Launch mission" }).click();
  await expect(page.getByRole("heading", { name: browserTitle })).toBeVisible({ timeout: 30_000 });
  await waitForPublishedResult(page, `E2E_DESKTOP_OK ${browserMarker}`, 240_000);
  await expect(page.getByText("Result published", { exact: true }).locator("xpath=..")).toContainText(`DESKTOP_CONFIRMED_${browserMarker}`);
  const browserTranscript = page.getByRole("log", { name: "Mission transcript" });
  // Native and Managed Agents intentionally use their own wire identifiers.
  // The Awaken permission proof above owns alias normalization; the transcript
  // must retain that actual wire fact rather than rewriting audit history.
  const browserToolPattern = agentRuntime === "native-deepseek"
    ? /mcp__browser__browser_(navigate|type|fill_form|click)/
    : /mcp\.(browser|playwright)\.browser_(navigate|fill_form|click)/;
  await expect(browserTranscript.getByText(browserToolPattern).first()).toBeVisible();

  const mobileMarker = `E2E_MOBILE_${Date.now()}`;
  const mobileTitle = `Mobile web operation ${Date.now()}`;
  await page.getByLabel("Title").fill(mobileTitle);
  await page.getByLabel("Direction").fill(`Use only the mobile MCP to navigate to ${browserFixtureUrl}. Fill the Order reference field with ${mobileMarker}, tap Submit, and read the resulting status. It must start MOBILE_CONFIRMED_ and include a positive touch count. Then call pilot publish_result with a summary beginning E2E_MOBILE_OK ${mobileMarker} followed by that exact observed status. Do not use browser, bash, filesystem, web_fetch, web_search, or delegates.`);
  await page.getByLabel("Launch mode").selectOption("execute");
  await page.getByRole("button", { name: "Launch mission" }).click();
  await expect(page.getByRole("heading", { name: mobileTitle })).toBeVisible({ timeout: 30_000 });
  await waitForPublishedResult(page, `E2E_MOBILE_OK ${mobileMarker}`, 240_000);
  const mobileResult = page.getByText("Result published", { exact: true }).locator("xpath=..");
  await expect(mobileResult).toContainText(`MOBILE_CONFIRMED_${mobileMarker}`);
  await expect(mobileResult).toContainText(/_W[1-4]\d{2}_T[1-9]\d*/);
  const mobileTranscript = page.getByRole("log", { name: "Mission transcript" });
  const mobileToolPattern = agentRuntime === "native-deepseek"
    ? /mcp__mobile__browser_(navigate|type|fill_form|click)/
    : /mcp\.mobile\.browser_(navigate|fill_form|click)/;
  await expect(mobileTranscript.getByText(mobileToolPattern).first()).toBeVisible();

  const researchMarker = `E2E_RESEARCH_${Date.now()}`;
  const researchTitle = `Deep research ${Date.now()}`;
  await page.getByLabel("Title").fill(researchTitle);
  expect(nistResearchAgentId, "the runner must expose the exact published NIST Agent ID").not.toBe("");
  expect(w3cResearchAgentId, "the runner must expose the exact published W3C Agent ID").not.toBe("");
  await page.getByLabel("Direction").fill(`Perform live multi-agent research about phishing-resistant authentication. Invoke agent_run exactly once with exact agent_id ${nistResearchAgentId} for the Pilot NIST Researcher subquestion and exactly once with exact agent_id ${w3cResearchAgentId} for the Pilot W3C Researcher subquestion, then wait for both child Runs; do not retry either delegate. Agent IDs, not display names, are the executable roster contract. Each delegate must call web_search and then web_fetch its official source. Use https://pages.nist.gov/800-63-4/sp800-63b.html for the NIST evidence and https://www.w3.org/TR/webauthn-3/ for W3C evidence, but still require live search discovery before fetching. Synthesize agreements and differences without inventing claims. Call pilot publish_result with a summary that begins E2E_RESEARCH_OK ${researchMarker}, includes both exact official URLs, and attributes findings to both child Agents. Do not use browser, mobile, bash, or filesystem tools.`);
  await page.getByLabel("Launch mode").selectOption("execute");
  await page.getByRole("button", { name: "Launch mission" }).click();
  await expect(page.getByRole("heading", { name: researchTitle })).toBeVisible({ timeout: 30_000 });
  await waitForPublishedResult(page, `E2E_RESEARCH_OK ${researchMarker}`, 360_000);
  const researchResult = page.getByText("Result published", { exact: true }).locator("xpath=..");
  await expect(researchResult).toContainText("https://pages.nist.gov/800-63-4/sp800-63b.html");
  await expect(researchResult).toContainText("https://www.w3.org/TR/webauthn-3/");
  const agentRegion = page.getByRole("heading", { name: /Agents \([2-9]\d*\)/ }).locator("xpath=..");
  await expect(agentRegion).toContainText("Pilot NIST Researcher", { timeout: 120_000 });
  await expect(agentRegion).toContainText("Pilot W3C Researcher");
  const researchTranscript = page.getByRole("log", { name: "Mission transcript" });
  await expect(researchTranscript.getByRole("button", { name: "agent_run done", exact: true }).first()).toBeVisible();
  await expect.poll(() => researchTranscript.getByRole("button", { name: "agent_run done", exact: true }).count()).toBeGreaterThanOrEqual(2);
  const researchMissionId = (await page.locator(".eyebrow").first().textContent())?.replace(/^Mission · /, "").trim();
  expect(researchMissionId, "Mission heading must expose the upstream Session ID").toBeTruthy();
  const threadsResponse = await request.get(`${baseUrl}/api/missions/${encodeURIComponent(researchMissionId!)}/threads`);
  expect(threadsResponse.status(), await threadsResponse.text()).toBe(200);
  const childThreads = (await threadsResponse.json() as Array<{ id: string; parent_thread_id: string | null }>).filter((thread) => thread.parent_thread_id);
  expect(childThreads.length).toBeGreaterThanOrEqual(2);
  const childEvents = (await Promise.all(childThreads.map(async (thread) => {
    const response = await request.get(`${baseUrl}/api/missions/${encodeURIComponent(researchMissionId!)}/threads/${encodeURIComponent(thread.id)}/events`);
    expect(response.status(), await response.text()).toBe(200);
    return response.json() as Promise<Array<{ type: string; name?: string }>>;
  }))).flat();
  expect(childEvents.some((event) => event.type === "agent.tool_use" && event.name === "web_search")).toBe(true);
  expect(childEvents.some((event) => event.type === "agent.tool_use" && event.name === "web_fetch")).toBe(true);

  const planTitle = `Plan approval ${Date.now()}`;
  const planMarker = `E2E_PLAN_${Date.now()}`;
  await page.getByLabel("Title").fill(planTitle);
  await page.getByLabel("Direction").fill(`Call pilot set_plan with summary E2E_PLAN_READY and at least two steps, then stop and wait. Do not call publish_result until a later user message approves. After approval call pilot publish_result with summary exactly E2E_PLAN_APPROVED_OK ${planMarker}.`);
  await page.getByLabel("Launch mode").selectOption("plan");
  await page.getByRole("button", { name: "Launch mission" }).click();
  await expect(page.getByRole("heading", { name: planTitle })).toBeVisible({ timeout: 30_000 });
  await expect(page.getByText("Plan ready for review", { exact: true })).toBeVisible({ timeout: 180_000 });
  await expect(page.getByText("Result published", { exact: true })).toBeHidden();
  await expect(page.getByRole("heading", { name: "Plan", exact: true }).locator("xpath=..")).toContainText("E2E_PLAN_READY");
  await page.getByRole("button", { name: "Approve and execute" }).click();
  await waitForPublishedResult(page, planMarker);
  expect(selectedMissionId(page)).toMatch(/^sesn_/);

  const outcomeMarker = `E2E_OUTCOME_${Date.now()}`;
  const outcomeTitle = `Outcome artifact ${Date.now()}`;
  await page.getByLabel("Title").fill(outcomeTitle);
  await page.getByLabel("Direction").fill(`Call pilot set_plan, then immediately invoke bash exactly once to create $AWAKEN_OUTPUTS_DIR/outcome-result.txt containing E2E_OUTCOME_OK ${outcomeMarker}. Do not wait before invoking bash: the bash permission request itself is the required approval boundary. After that same bash Run resumes and succeeds, call pilot publish_result with summary exactly E2E_OUTCOME_OK ${outcomeMarker} and artifacts exactly [{\"path\":\"outputs/outcome-result.txt\"}]. Never use artifact_path.`);
  await page.getByLabel("Launch mode").selectOption("execute");
  await page.getByLabel("Acceptance criteria (optional)").fill(`The committed deliverable contains E2E_OUTCOME_OK ${outcomeMarker}.`);
  await page.getByLabel("Maximum revision cycles").fill("3");
  await page.getByRole("button", { name: "Launch mission" }).click();
  await expect(page.getByRole("heading", { name: outcomeTitle })).toBeVisible({ timeout: 30_000 });
  const transcript = page.getByRole("log", { name: "Mission transcript" });
  // Permission cards expose tool identity/state in the button and arguments in
  // adjacent text. FMECA PF20: concatenating both into one accessible-name
  // assertion false-fails while the real approval is already awaiting. The
  // boundary therefore proves `bash` plus the intended artifact path; the
  // terminal result and rubric below own exact-token/content proof.
  await expect(transcript.getByRole("button", { name: "bash running", exact: true })).toBeVisible({ timeout: 180_000 });
  await expect(transcript).toContainText("outcome-result.txt");
  const allow = page.getByRole("button", { name: "Allow", exact: true });
  await expect(allow).toBeVisible();
  await allow.click();
  await expect(allow).toBeHidden({ timeout: 30_000 });
  await waitForPublishedResult(page, `E2E_OUTCOME_OK ${outcomeMarker}`, 240_000);
  await expect(page.getByRole("heading", { name: /Quality \([1-9]/ })).toBeVisible({ timeout: 120_000 });
  await expect(page.getByRole("heading", { name: /Quality \([1-9]/ }).locator("xpath=..")).toContainText("satisfied");
  // PF21: the same canonical filename is legitimately rendered in the MCP
  // transcript and the Files projection. Scope this rule to the Artifacts
  // region so strict-locator uniqueness proves E5 without treating duplicate
  // presentation of one upstream fact as duplicate storage.
  const artifacts = page.getByRole("heading", { name: /Artifacts \([1-9]/ }).locator("xpath=..");
  await expect(artifacts.getByText("outcome-result.txt", { exact: true })).toBeVisible({ timeout: 120_000 });
  // R6/FMECA PF5: an Outcome revision or replay-safe projection may expose more
  // than one legitimate MCP card (C7-C9); the required effect is existence in
  // the selected Session transcript, not a second call-count authority. Scoping
  // to the canonical transcript and selecting one match eliminates strict-locator
  // false failures while the terminal result/rubric assertions own completion.
  const pilotToolPrefix = agentRuntime === "native-deepseek" ? "mcp__pilot__" : "mcp.pilot.";
  await expect(transcript.getByRole("button", { name: `${pilotToolPrefix}set_plan done`, exact: true }).first()).toBeVisible();
  await expect(transcript.getByRole("button", { name: `${pilotToolPrefix}publish_result done`, exact: true }).first()).toBeVisible();
  const missionId = selectedMissionId(page);
  expect(missionId).toMatch(/^sesn_/);
  const token = await createPublicCapability(request, missionId);
  await page.goto(`${baseUrl}/public#w=${encodeURIComponent(workspaceId)}&m=${encodeURIComponent(missionId)}&token=${encodeURIComponent(token)}`);
  await expect(page.getByText("Public read-only Mission")).toBeVisible();
  await expect(page.getByRole("heading", { name: outcomeTitle })).toBeVisible();
  // PF25: model-authored plan text may independently contain the words
  // "Result published". The committed marker selects the one result projection
  // without relying on presentation order or hiding a duplicated durable fact.
  const publicResult = page.getByText("Result published", { exact: true })
    .locator("xpath=..").filter({ hasText: outcomeMarker });
  await expect(publicResult).toContainText(`E2E_OUTCOME_OK ${outcomeMarker}`);

  const revoked = await request.delete(`${iamUrl}/v1/admin/grants/${encodeURIComponent(publicGrantId(missionId))}`, {
    headers: { Authorization: `Bearer ${iamAdminToken}` },
  });
  expect(revoked.ok(), `grant revoke: ${await revoked.text()}`).toBeTruthy();
  await page.reload();
  await expect(page.getByText("Mission unavailable", { exact: true })).toBeVisible();
  await expect(page.getByText("This public link has been revoked.")).toBeVisible();
  expect(agentRuntime).toMatch(/^(acp|native-deepseek)$/);
});
