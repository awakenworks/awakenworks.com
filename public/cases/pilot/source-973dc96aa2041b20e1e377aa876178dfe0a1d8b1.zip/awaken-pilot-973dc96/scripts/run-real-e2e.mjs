import { execFileSync, spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream, createWriteStream, existsSync, mkdtempSync, readFileSync, readdirSync, realpathSync, rmSync, statSync } from "node:fs";
import { createServer as createHttpServer } from "node:http";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import process from "node:process";
import { createServer as createNetServer } from "node:net";
import Anthropic from "@anthropic-ai/sdk";
import { withAwakenWorkspace } from "../apps/api/dist/managed-gateway.js";

const root = resolve(import.meta.dirname, "..");
let workspaceId = process.env.PILOT_E2E_WORKSPACE_ID ?? "";
const agentRuntime = process.env.PILOT_E2E_AGENT_RUNTIME ?? "acp";
if (!new Set(["acp", "native-deepseek"]).has(agentRuntime)) {
  throw new Error("PILOT_E2E_AGENT_RUNTIME must be acp or native-deepseek");
}
const nativeDeepSeek = agentRuntime === "native-deepseek";
const agentModelId = nativeDeepSeek ? "deepseek-v4-flash" : "acp:codex";
const environmentName = nativeDeepSeek ? "Pilot Real Native Hand" : "Pilot Real Cloud";
const deepSeekSecret = nativeDeepSeek ? readManagedDeepSeekSecret() : undefined;
const ports = {
  iam: Number(process.env.PILOT_E2E_IAM_PORT ?? 18776),
  awaken: Number(process.env.PILOT_E2E_AWAKEN_PORT ?? 18777),
  mcp: Number(process.env.PILOT_E2E_MCP_PORT ?? 18788),
  browserMcp: Number(process.env.PILOT_E2E_BROWSER_MCP_PORT ?? 18789),
  mobileMcp: Number(process.env.PILOT_E2E_MOBILE_MCP_PORT ?? 18791),
  browserFixture: Number(process.env.PILOT_E2E_BROWSER_FIXTURE_PORT ?? 18790),
  api: Number(process.env.PILOT_E2E_API_PORT ?? 18774),
  web: Number(process.env.PILOT_E2E_WEB_PORT ?? 18773),
};
const awakenBin = requiredExecutable("PILOT_E2E_AWAKEN_BIN");
const awakenSourceRoot = process.env.PILOT_E2E_AWAKEN_SOURCE_ROOT
  ? requiredDirectory("PILOT_E2E_AWAKEN_SOURCE_ROOT")
  : undefined;
const expectedAwakenSha256 = process.env.PILOT_E2E_AWAKEN_SHA256?.trim().toLowerCase();
const iamBin = requiredExecutable("PILOT_E2E_IAM_BIN");
const chromeBin = requiredExecutable("PILOT_E2E_CHROME_BIN", "/usr/bin/google-chrome");
const runDir = mkdtempSync(join(tmpdir(), "awaken-pilot-real-e2e-"));
const iamAdminToken = `pilot-e2e-admin-${process.pid}`;
const children = [];
const listeners = [];
let cleaning = false;

function requiredExecutable(name, fallback) {
  const value = process.env[name] || fallback;
  if (!value) throw new Error(`${name} must point to a built executable`);
  const path = resolve(value);
  if (!existsSync(path)) throw new Error(`${name} does not exist: ${path}`);
  return path;
}

function requiredDirectory(name) {
  const path = resolve(process.env[name]);
  if (!existsSync(path) || !statSync(path).isDirectory()) throw new Error(`${name} is not a directory: ${path}`);
  return path;
}

function readManagedDeepSeekSecret() {
  if (process.env.DEEPSEEK_API_KEY) {
    throw new Error("Do not inject DEEPSEEK_API_KEY through the process environment; use PILOT_E2E_DEEPSEEK_IMPORT_FILE for one-time Awaken management import");
  }
  const importFile = process.env.PILOT_E2E_DEEPSEEK_IMPORT_FILE;
  delete process.env.PILOT_E2E_DEEPSEEK_IMPORT_FILE;
  if (!importFile) {
    throw new Error("native-deepseek acceptance requires PILOT_E2E_DEEPSEEK_IMPORT_FILE");
  }
  const path = resolve(importFile);
  let secret;
  try {
    const mode = statSync(path).mode & 0o777;
    if ((mode & 0o077) !== 0) {
      throw new Error(`DeepSeek import file must not be accessible by group/other (mode ${mode.toString(8)})`);
    }
    secret = readFileSync(path, "utf8").trim();
  } finally {
    rmSync(path, { force: true });
  }
  if (!secret) throw new Error("the DeepSeek credential import file is empty");
  return secret;
}

function newestBuildInputMtime(rootPath) {
  let newest = 0;
  const visit = (directory) => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      if (entry.name === ".git" || entry.name === "target" || entry.name === "node_modules") continue;
      const path = join(directory, entry.name);
      if (entry.isDirectory()) visit(path);
      else if (entry.isFile() && (entry.name.endsWith(".rs") || entry.name.endsWith(".toml") || entry.name === "Cargo.lock")) {
        newest = Math.max(newest, statSync(path).mtimeMs);
      }
    }
  };
  visit(rootPath);
  return newest;
}

async function sha256(path) {
  const hash = createHash("sha256");
  await new Promise((resolvePromise, reject) => {
    const stream = createReadStream(path);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.once("error", reject);
    stream.once("end", resolvePromise);
  });
  return hash.digest("hex");
}

async function verifyAwakenBinaryProvenance() {
  if (!awakenSourceRoot && !expectedAwakenSha256) {
    throw new Error("Set PILOT_E2E_AWAKEN_SOURCE_ROOT for a local build or PILOT_E2E_AWAKEN_SHA256 for a released binary");
  }
  const executable = realpathSync(awakenBin);
  const digest = await sha256(executable);
  if (expectedAwakenSha256 && digest !== expectedAwakenSha256) {
    throw new Error(`Awaken binary checksum mismatch: expected ${expectedAwakenSha256}, received ${digest}`);
  }
  let source = "checksum-only";
  if (awakenSourceRoot) {
    const canonicalSourceRoot = realpathSync(awakenSourceRoot);
    // Provenance cause/effect rule: a fresh binary plus an unrelated source
    // tree must fail before services start. Cargo's depfile is the build-owned
    // evidence that at least one compiled input came from the declared root;
    // mtime alone cannot distinguish adjacent Awaken worktrees.
    const depfile = `${executable}.d`;
    if (!existsSync(depfile)
      || !readFileSync(depfile, "utf8").includes(`${canonicalSourceRoot}/`)) {
      throw new Error(`Awaken binary dependency manifest does not reference ${canonicalSourceRoot}`);
    }
    const newestInput = newestBuildInputMtime(canonicalSourceRoot);
    const binaryMtime = statSync(executable).mtimeMs;
    if (binaryMtime < newestInput) {
      throw new Error(`Awaken binary is older than its Rust/Cargo inputs; rebuild ${executable}`);
    }
    const revision = execFileSync("git", ["rev-parse", "HEAD"], { cwd: canonicalSourceRoot, encoding: "utf8" }).trim();
    const dirty = execFileSync("git", ["status", "--short"], { cwd: canonicalSourceRoot, encoding: "utf8" }).trim() !== "";
    source = `${canonicalSourceRoot}@${revision}${dirty ? "+dirty" : ""}`;
  }
  console.log(`Awaken acceptance binary ${executable} sha256=${digest} source=${source}`);
}

function service(name, command, args, environment = {}) {
  const log = createWriteStream(join(runDir, `${name}.log`), { flags: "a" });
  // Credential-import cause/effect + FMECA rule: C1 the driver holds a one-time
  // import value; C2 it starts Awaken/Worker/Pilot/Connector processes. C1+C2
  // => E1 children receive neither provider keys nor import descriptors; E2 only
  // Awaken's write-only configuration API receives the value. Leaking C1 is
  // critical, so direct environment injection fails above and all children use
  // this one scrubbed boundary.
  const childEnvironment = { ...process.env, ...environment };
  for (const name of Object.keys(childEnvironment)) {
    if (name.toUpperCase() === "API_KEY" || name.toUpperCase().endsWith("_API_KEY")) {
      delete childEnvironment[name];
    }
  }
  delete childEnvironment.PILOT_E2E_DEEPSEEK_IMPORT_FILE;
  const child = spawn(command, args, {
    cwd: root,
    env: childEnvironment,
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stdout.pipe(log);
  child.stderr.pipe(log);
  child.once("exit", (code, signal) => {
    if (!cleaning && code !== 0) {
      console.error(`${name} exited before acceptance completed (${signal ?? code}); log: ${join(runDir, `${name}.log`)}`);
    }
  });
  children.push(child);
  return child;
}

async function waitFor(url, label, timeoutMs = 60_000) {
  const deadline = Date.now() + timeoutMs;
  let last = "not reachable";
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
      last = `${response.status} ${response.statusText}`;
    } catch (error) {
      last = error instanceof Error ? error.message : String(error);
    }
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 250));
  }
  throw new Error(`${label} did not become ready: ${last}`);
}

async function assertPortAvailable(port) {
  await new Promise((resolvePromise, reject) => {
    const probe = createNetServer();
    probe.once("error", () => reject(new Error(`E2E port ${port} is already in use`)));
    probe.listen(port, "127.0.0.1", () => probe.close(resolvePromise));
  });
}

function browserFixture() {
  const server = createHttpServer((request, response) => {
    if (request.url !== "/browser-fixture") {
      response.writeHead(404).end("not found");
      return;
    }
    response.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    response.end(`<!doctype html><html><head><title>Pilot browser acceptance</title><meta name="viewport" content="width=device-width, initial-scale=1"></head><body>
      <main><h1>Browser connector acceptance</h1>
      <label>Order reference <input aria-label="Order reference"></label>
      <button type="button" onclick="{const mobile=innerWidth<=500&&navigator.maxTouchPoints>0;document.querySelector('output').textContent=(mobile?'MOBILE':'DESKTOP')+'_CONFIRMED_'+document.querySelector('input').value+'_W'+innerWidth+'_T'+navigator.maxTouchPoints}">Submit</button>
      <output role="status" aria-live="polite"></output></main></body></html>`);
  });
  server.listen(ports.browserFixture, "127.0.0.1");
  listeners.push(server);
}

async function waitForReachable(url, label, timeoutMs = 60_000) {
  const deadline = Date.now() + timeoutMs;
  let last = "not reachable";
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url);
      if (response.status < 500) return;
      last = `${response.status} ${response.statusText}`;
    } catch (error) {
      last = error instanceof Error ? error.message : String(error);
    }
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 250));
  }
  throw new Error(`${label} did not become reachable: ${last}`);
}

async function waitForFile(path, label, timeoutMs = 10_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (existsSync(path)) return;
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 50));
  }
  throw new Error(`${label} was not created: ${path}`);
}

async function awakenJson(awakenUrl, method, path, body) {
  const headers = new Headers({ Accept: "application/json", "X-Api-Key": "awaken-local-e2e" });
  if (body !== undefined) headers.set("Content-Type", "application/json");
  const response = await withAwakenWorkspace(fetch, workspaceId)(`${awakenUrl}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  if (!response.ok) throw new Error(`${method} ${path}: ${response.status} ${text}`);
  return text ? JSON.parse(text) : undefined;
}

async function provisionNativeDeepSeek(awakenUrl, secret) {
  const connection = await awakenJson(awakenUrl, "POST", "/v1/config/provider-connections", {
    idempotency_key: "pilot-real-native-deepseek",
    workspace_id: workspaceId,
    provider_id: "deepseek",
    display_name: "DeepSeek",
    dialect: "open_ai_chat",
    base_url: "https://api.deepseek.com",
    timeout_secs: 90,
    secret,
  });
  if (JSON.stringify(connection).includes(secret)) throw new Error("Awaken exposed the write-only DeepSeek credential");
  const catalog = await awakenJson(awakenUrl, "GET", "/v1/config/catalog");
  const offering = catalog.offerings.find((candidate) => candidate.provider_id === "deepseek"
    && candidate.model_id === agentModelId && (candidate.status ?? "active") === "active");
  if (!offering) throw new Error(`${agentModelId} is not an active DeepSeek offering`);
  await awakenJson(awakenUrl, "PUT", "/v1/config/inference-profiles/pilot-real-native", {
    workspace_id: workspaceId,
    primary: {
      target: {
        model_id: offering.model_id,
        provider_id: offering.provider_id,
        protocol_endpoint_id: offering.protocol_endpoint_id,
      },
      credential_binding: { type: "exact", credential_source_id: connection.credential.id },
    },
    fallbacks: [],
    disabled_endpoint_ids: [],
  });
  console.log(`Provisioned Awaken Native model ${agentModelId} from ${connection.sync.discovered} discovered DeepSeek offering(s)`);
}

const researchToolset = {
  type: "agent_toolset_20260401",
  configs: [
    { name: "grep", enabled: true, permission_policy: { type: "always_allow" } },
    { name: "web_search", enabled: true, permission_policy: { type: "always_allow" } },
    { name: "web_fetch", enabled: true, permission_policy: { type: "always_allow" } },
  ],
  default_config: { enabled: false, permission_policy: { type: "always_ask" } },
};

async function listedAgents(client, betas) {
  const agents = [];
  for await (const agent of client.beta.agents.list({ betas, limit: 100 })) agents.push(agent);
  return agents;
}

async function configureAgentPublication(awakenUrl, agentId) {
  // One ConfigPlane revision owns Awaken-only publication settings. Managed
  // Agent fields stay Anthropic-shaped; this extension mutates neither a mirror
  // Agent nor a second runtime profile.
  const path = `/v1/config/agents/${encodeURIComponent(agentId)}`;
  const config = await awakenJson(awakenUrl, "GET", path);
  config.plugins = [...new Set([...(config.plugins ?? []), "web_search"])];
  config.plugin_config = {
    ...(config.plugin_config ?? {}),
    web_search: { provider_id: "duckduckgo", options: {} },
  };
  const validation = await awakenJson(awakenUrl, "POST", `${path}/validate`, config);
  if (!validation.valid) throw new Error(`Agent ${agentId} WebSearch config is invalid: ${JSON.stringify(validation.issues)}`);
  const write = await awakenJson(awakenUrl, "PUT", path, config);
  await awakenJson(awakenUrl, "POST", `${path}/publish`, { source_revision: write.generation });
}

function requireAnthropicShapedAgent(agent) {
  if (agent.x_awaken !== undefined && agent.x_awaken !== null) {
    throw new Error(`Agent ${agent.id} unexpectedly projects x_awaken`);
  }
  return agent;
}

async function provisionResearchAgents(awakenUrl) {
  const client = new Anthropic({
    baseURL: awakenUrl,
    apiKey: "awaken-local-e2e",
    fetch: withAwakenWorkspace(fetch, workspaceId),
  });
  const betas = ["managed-agents-2026-04-01"];
  // Research cause/effect rule RE1: search + primary fetch + optional bounded
  // grep => cited final synthesis within the Managed default step budget. A
  // repeated read/grep chase => MaxSteps and no parent result. FMECA mitigation:
  // expose only the needed tools and bound evidence extraction in the Agent's
  // authoritative instructions; never add a Pilot poller or x_awaken override.
  const roles = [
    ["nist", "Pilot NIST Researcher", "Research the supplied NIST question. Call web_search exactly once with the broad query NIST, then web_fetch the relevant official nist.gov source exactly once. If the fetch is spilled, call grep at most twice on the returned relative path with broad patterns covering phishing resistance, authenticator types, and AAL requirements; never call read, refetch, or search again. Then immediately return concise findings with the exact source URL."],
    ["w3c", "Pilot W3C Researcher", "Research the supplied W3C question. Call web_search exactly once with the broad query WebAuthn, then web_fetch the relevant official w3.org source exactly once. If the fetch is spilled, call grep at most twice on the returned relative path with broad patterns covering phishing, origin or relying-party binding, passkeys, challenges, and user verification; never call read, refetch, or search again. Then immediately return concise findings with the exact source URL."],
  ];
  const provisioned = [];
  for (const [role, name, system] of roles) {
    const owned = (await listedAgents(client, betas)).filter((agent) =>
      agent.metadata.pilot_profile === "real-research-agent-e2e" && agent.metadata.pilot_research_role === role);
    if (owned.length > 1) throw new Error(`multiple ${role} research Agents exist in the E2E Workspace`);
    if (owned.length === 1) {
      const agent = owned[0];
      const tools = agent.tools.find((tool) => tool.type === "agent_toolset_20260401");
      const enabled = new Set(tools?.configs.filter((tool) => tool.enabled).map((tool) => tool.name));
      if (agent.name !== name || agent.model.id !== agentModelId || !enabled.has("grep") || !enabled.has("web_search")
        || !enabled.has("web_fetch")) {
        throw new Error(`existing ${role} research Agent differs from the declared Native research profile`);
      }
      await configureAgentPublication(awakenUrl, agent.id);
      provisioned.push(requireAnthropicShapedAgent(await client.beta.agents.retrieve(agent.id, { betas })));
      continue;
    }
    const agent = await client.beta.agents.create({
      betas,
      name,
      description: `Awaken Native live-web ${role.toUpperCase()} research delegate.`,
      model: agentModelId,
      system,
      metadata: {
        pilot_profile: "real-research-agent-e2e",
        pilot_research_role: role,
        pilot_runtime: agentRuntime,
      },
      tools: [researchToolset],
    });
    await configureAgentPublication(awakenUrl, agent.id);
    provisioned.push(requireAnthropicShapedAgent(await client.beta.agents.retrieve(agent.id, { betas })));
  }
  return provisioned;
}

async function provisionAgent(awakenUrl, mcpUrl, browserMcpUrl, mobileMcpUrl, researchAgents) {
  const client = new Anthropic({
    baseURL: awakenUrl,
    apiKey: "awaken-local-e2e",
    fetch: withAwakenWorkspace(fetch, workspaceId),
  });
  const betas = ["managed-agents-2026-04-01"];
  const expectedName = "Pilot Real Manus";
  const documentSkills = ["pptx", "xlsx", "docx", "pdf"];
  for (let attempt = 0; attempt < 120; attempt += 1) {
    const agents = await listedAgents(client, betas);
    const owned = agents.filter((agent) => agent.metadata.pilot_profile === "real-agent-e2e");
    if (owned.length > 1) throw new Error("multiple real-agent-e2e Agents exist in the E2E Workspace");
    if (owned.length === 1) {
      const agent = owned[0];
      const connector = agent.mcp_servers.find((server) => server.name === "pilot");
      const browser = agent.mcp_servers.find((server) => server.name === "browser");
      const mobile = agent.mcp_servers.find((server) => server.name === "mobile");
      const toolset = agent.tools.find((tool) => tool.type === "mcp_toolset" && tool.mcp_server_name === "pilot");
      const browserTools = agent.tools.find((tool) => tool.type === "mcp_toolset" && tool.mcp_server_name === "browser");
      const mobileTools = agent.tools.find((tool) => tool.type === "mcp_toolset" && tool.mcp_server_name === "mobile");
      const workspaceTools = agent.tools.find((tool) => tool.type === "agent_toolset_20260401");
      const workspaceTool = (name) => workspaceTools?.configs.find((tool) => tool.name === name);
      const configuredSkills = new Set(agent.skills.map((skill) => `${skill.type}:${skill.skill_id}:${skill.version}`));
      const configuredDelegates = new Set(agent.multiagent?.agents.filter((entry) => typeof entry === "string"));
      if (agent.name !== expectedName || agent.model.id !== agentModelId || agent.metadata.pilot_runtime !== agentRuntime
        || connector?.type !== "url" || connector.url !== mcpUrl || !toolset
        || browser?.type !== "url" || browser.url !== browserMcpUrl || !browserTools
        || mobile?.type !== "url" || mobile.url !== mobileMcpUrl || !mobileTools
        || workspaceTool("read")?.permission_policy.type !== "always_allow"
        || workspaceTool("glob")?.permission_policy.type !== "always_allow"
        || workspaceTool("bash")?.permission_policy.type !== "always_ask"
        || workspaceTool("web_search")?.permission_policy.type !== "always_allow"
        || workspaceTool("web_fetch")?.permission_policy.type !== "always_allow"
        || !researchAgents.every((delegate) => configuredDelegates.has(delegate.id))
        || !documentSkills.every((skill) => configuredSkills.has(`anthropic:${skill}:latest`))) {
        throw new Error("existing real-agent-e2e Agent differs from the declared runtime/Pilot connector profile");
      }
      await configureAgentPublication(awakenUrl, agent.id);
      return requireAnthropicShapedAgent(await client.beta.agents.retrieve(agent.id, { betas }));
    }
    try {
      const agent = await client.beta.agents.create({
        betas,
        name: expectedName,
        description: `${nativeDeepSeek ? "Awaken Native DeepSeek" : "Host-login Codex"} agent connected to Pilot and the official Playwright browser MCP.`,
        model: agentModelId,
        system: "Use Pilot MCP tools for structured plans, progress, and final results. The browser MCP is desktop web and the mobile MCP is iPhone-emulated mobile web; use only the one explicitly requested. For deep research, delegate the named independent subquestions to every configured research Agent and synthesize their live web_search/web_fetch evidence. Use bash only when explicitly asked for an output artifact. Never use edit or unrequested filesystem mutations.",
        metadata: { pilot_profile: "real-agent-e2e", pilot_runtime: agentRuntime },
        skills: documentSkills.map((skill_id) => ({ type: "anthropic", skill_id, version: "latest" })),
        mcp_servers: [
          { type: "url", name: "pilot", url: mcpUrl },
          { type: "url", name: "browser", url: browserMcpUrl },
          { type: "url", name: "mobile", url: mobileMcpUrl },
        ],
        tools: [
          {
            type: "agent_toolset_20260401",
            configs: [
              { name: "read", enabled: true, permission_policy: { type: "always_allow" } },
              { name: "glob", enabled: true, permission_policy: { type: "always_allow" } },
              { name: "bash", enabled: true, permission_policy: { type: "always_ask" } },
              { name: "web_search", enabled: true, permission_policy: { type: "always_allow" } },
              { name: "web_fetch", enabled: true, permission_policy: { type: "always_allow" } },
            ],
            default_config: { enabled: false, permission_policy: { type: "always_ask" } },
          },
          {
            type: "mcp_toolset",
            mcp_server_name: "pilot",
            configs: [],
            default_config: { enabled: true, permission_policy: { type: "always_allow" } },
          },
          {
            type: "mcp_toolset",
            mcp_server_name: "browser",
            configs: [],
            default_config: { enabled: true, permission_policy: { type: "always_allow" } },
          },
          {
            type: "mcp_toolset",
            mcp_server_name: "mobile",
            configs: [],
            default_config: { enabled: true, permission_policy: { type: "always_allow" } },
          },
        ],
        multiagent: { type: "coordinator", agents: researchAgents.map((agent) => agent.id) },
      });
      await configureAgentPublication(awakenUrl, agent.id);
      return requireAnthropicShapedAgent(await client.beta.agents.retrieve(agent.id, { betas }));
    } catch (error) {
      if (attempt === 119) throw error;
      await new Promise((resolvePromise) => setTimeout(resolvePromise, 500));
    }
  }
  throw new Error("Agent provisioning exhausted its readiness window");
}

async function provisionEnvironment(awakenUrl) {
  const client = new Anthropic({
    baseURL: awakenUrl,
    apiKey: "awaken-local-e2e",
    fetch: withAwakenWorkspace(fetch, workspaceId),
  });
  const betas = ["managed-agents-2026-04-01"];
  const environments = [];
  for await (const environment of client.beta.environments.list({ betas, limit: 100 })) environments.push(environment);
  const owned = environments.filter((environment) => environment.metadata.pilot_profile === "real-environment-e2e");
  if (owned.length > 1) throw new Error("multiple real-environment-e2e Environments exist in the E2E Workspace");
  if (owned.length === 1) {
    const environment = owned[0];
    const matches = nativeDeepSeek
      ? environment.name === environmentName && environment.config.type === "self_hosted"
      : environment.name === environmentName && environment.config.type === "cloud"
        && environment.config.networking.type === "unrestricted";
    if (!matches || environment.metadata.pilot_runtime !== agentRuntime) {
      throw new Error("existing real-environment-e2e Environment differs from the declared runtime profile");
    }
    return environment;
  }
  const environment = await client.beta.environments.create({
    betas,
    name: environmentName,
    description: nativeDeepSeek
      ? "Real-stack Awaken Native Environment with on-tool-use Hand placement."
      : "Real-stack acceptance Environment without the self-hosted single-Session Work lease.",
    metadata: { pilot_profile: "real-environment-e2e", pilot_runtime: agentRuntime },
    config: nativeDeepSeek
      ? { type: "self_hosted" }
      : { type: "cloud", networking: { type: "unrestricted" } },
  });
  if (nativeDeepSeek) {
    const policy = await awakenJson(awakenUrl, "POST", "/v1/awaken/sandbox-execution-policies", {
      id: "pilot-real-native-hand",
      config: {},
      provisioning: "on_tool_use",
      disabled: false,
    });
    await awakenJson(
      awakenUrl,
      "POST",
      `/v1/awaken/environments/${encodeURIComponent(environment.id)}/sandbox-execution-policy`,
      { policy_id: policy.id, version: policy.version },
    );
  }
  return environment;
}

async function cleanup() {
  if (cleaning) return;
  cleaning = true;
  for (const child of children.toReversed()) {
    if (child.exitCode === null && child.signalCode === null) child.kill("SIGTERM");
  }
  await Promise.all(children.map((child) => child.exitCode !== null || child.signalCode !== null
    ? Promise.resolve()
    : new Promise((resolvePromise) => {
      const timer = setTimeout(() => {
        if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
        resolvePromise();
      }, 5_000);
      child.once("exit", () => {
        clearTimeout(timer);
        resolvePromise();
      });
    })));
  await Promise.all(listeners.map((listener) => new Promise((resolvePromise) => listener.close(() => resolvePromise()))));
  if (process.env.PILOT_E2E_KEEP_RUN_DIR !== "1") rmSync(runDir, { recursive: true, force: true });
  else console.log(`E2E service logs retained at ${runDir}`);
}

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.once(signal, () => void cleanup().finally(() => process.exit(128 + (signal === "SIGINT" ? 2 : 15))));
}

const iamUrl = `http://127.0.0.1:${ports.iam}`;
const awakenUrl = `http://127.0.0.1:${ports.awaken}`;
const mcpUrl = `http://127.0.0.1:${ports.mcp}/mcp`;
const browserMcpUrl = `http://127.0.0.1:${ports.browserMcp}/mcp`;
const mobileMcpUrl = `http://127.0.0.1:${ports.mobileMcp}/mcp`;
const browserFixtureUrl = `http://127.0.0.1:${ports.browserFixture}/browser-fixture`;
const apiUrl = `http://127.0.0.1:${ports.api}`;
const webUrl = `http://127.0.0.1:${ports.web}`;

let exitCode = 1;
try {
  await verifyAwakenBinaryProvenance();
  await Promise.all(Object.values(ports).map(assertPortAvailable));
  browserFixture();
  service("iam", iamBin, [], {
    IAM_BIND_ADDR: `127.0.0.1:${ports.iam}`,
    IAM_ADMIN_TOKEN: iamAdminToken,
    IAM_DATABASE_PATH: join(runDir, "iam.sqlite"),
  });
  service("awaken", awakenBin, [
    "all-in-one", "--port", String(ports.awaken), "--data-dir", join(runDir, "awaken"),
    "--no-browser", "--identity-mode", "no-login",
  ]);
  service("pilot-mcp", process.execPath, ["apps/application-mcp/dist/index.js"], {
    PILOT_MCP_HOST: "127.0.0.1",
    PILOT_MCP_PORT: String(ports.mcp),
  });
  service("playwright-mcp", "pnpm", [
    "exec", "playwright-mcp", "--headless", "--browser", "chrome",
    "--executable-path", chromeBin, "--host", "127.0.0.1", "--port", String(ports.browserMcp),
    // The Native MCP client preserves its logical server authority in the Host
    // header. This fixture is loopback-bound and disposable, so allow that
    // authority explicitly instead of weakening the production Connector.
    "--allowed-hosts", "*", "--isolated", "--output-dir", join(runDir, "playwright-mcp"),
  ]);
  service("playwright-mobile-mcp", "pnpm", [
    "exec", "playwright-mcp", "--headless", "--browser", "chrome", "--device", "iPhone 15",
    "--executable-path", chromeBin, "--host", "127.0.0.1", "--port", String(ports.mobileMcp),
    "--allowed-hosts", "*", "--isolated", "--output-dir", join(runDir, "playwright-mobile-mcp"),
  ]);

  await Promise.all([
    waitFor(`${iamUrl}/healthz`, "IAM"),
    waitFor(`${awakenUrl}/`, "Awaken", 90_000),
    waitFor(`http://127.0.0.1:${ports.mcp}/healthz`, "Pilot MCP"),
    waitForReachable(browserMcpUrl, "Playwright MCP"),
    waitForReachable(mobileMcpUrl, "Playwright mobile MCP"),
    waitFor(browserFixtureUrl, "browser fixture"),
  ]);
  if (!workspaceId) {
    const workspaceFile = join(runDir, "awaken", "platform-workspace-id");
    await waitForFile(workspaceFile, "Awaken local Workspace coordinate");
    workspaceId = readFileSync(workspaceFile, "utf8").trim();
  }
  if (!workspaceId) throw new Error("Awaken did not publish its local Workspace coordinate");
  if (nativeDeepSeek) await provisionNativeDeepSeek(awakenUrl, deepSeekSecret);
  const researchAgents = await provisionResearchAgents(awakenUrl);
  const [agent, environment] = await Promise.all([
    provisionAgent(awakenUrl, mcpUrl, browserMcpUrl, mobileMcpUrl, researchAgents),
    provisionEnvironment(awakenUrl),
  ]);
  console.log(`Provisioned real Agent ${agent.id} (${agent.model.id}) with Pilot ${mcpUrl}, desktop ${browserMcpUrl}, mobile ${mobileMcpUrl}, ${researchAgents.length} research delegates, and Environment ${environment.id}`);

  service("pilot-api", process.execPath, ["apps/api/dist/index.js"], {
    PILOT_API_HOST: "127.0.0.1",
    PILOT_API_PORT: String(ports.api),
    PILOT_AWAKEN_API_URL: awakenUrl,
    PILOT_AWAKEN_AUTH_TOKEN: "awaken-local-e2e",
    PILOT_IAM_API_URL: iamUrl,
    PILOT_IAM_ADMIN_TOKEN: iamAdminToken,
    PILOT_APPLICATION_MCP_URL: mcpUrl,
    PILOT_DEFAULT_WORKSPACE_ID: workspaceId,
  });
  service("pilot-web", "pnpm", ["--filter", "@awaken/pilot-web", "exec", "vite", "--host", "127.0.0.1", "--port", String(ports.web)], {
    PILOT_DEV_API_URL: apiUrl,
  });
  await Promise.all([
    waitFor(`${apiUrl}/healthz`, "Pilot API"),
    waitFor(`${webUrl}/w/${encodeURIComponent(workspaceId)}`, "Pilot Web"),
  ]);

  const playwright = service("playwright", "pnpm", ["exec", "playwright", "test", "--config", "playwright.config.ts"], {
    PILOT_E2E_RUN: "1",
    PILOT_E2E_BASE_URL: webUrl,
    PILOT_E2E_WORKSPACE_ID: workspaceId,
    PILOT_E2E_IAM_URL: iamUrl,
    PILOT_E2E_IAM_ADMIN_TOKEN: iamAdminToken,
    PILOT_E2E_CHROME_BIN: chromeBin,
    PILOT_E2E_BROWSER_FIXTURE_URL: browserFixtureUrl,
    PILOT_E2E_AGENT_RUNTIME: agentRuntime,
    PILOT_E2E_AGENT_ID: agent.id,
    PILOT_E2E_NIST_AGENT_ID: researchAgents.find((candidate) => candidate.metadata.pilot_research_role === "nist")?.id ?? "",
    PILOT_E2E_W3C_AGENT_ID: researchAgents.find((candidate) => candidate.metadata.pilot_research_role === "w3c")?.id ?? "",
    PILOT_E2E_ENVIRONMENT_NAME: environmentName,
  });
  exitCode = await new Promise((resolvePromise) => playwright.once("exit", (code) => resolvePromise(code ?? 1)));
  if (exitCode !== 0) throw new Error(`Playwright acceptance failed; service logs: ${runDir}`);
} catch (error) {
  console.error(error instanceof Error ? error.stack : error);
} finally {
  const keep = exitCode !== 0;
  if (keep) process.env.PILOT_E2E_KEEP_RUN_DIR = "1";
  await cleanup();
}
process.exitCode = exitCode;
