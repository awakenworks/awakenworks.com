import { defineConfig } from "@playwright/test";

const recordSuccessfulVideo = process.env.PILOT_E2E_RECORD_VIDEO === "1";

export default defineConfig({
  testDir: "./e2e",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 600_000,
  expect: { timeout: 20_000 },
  outputDir: "test-results/real-e2e",
  reporter: [["list"], ["html", { open: "never" }]],
  use: {
    browserName: "chromium",
    headless: true,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    /* Recording cause/effect decision:
     * C1 PILOT_E2E_RECORD_VIDEO=1; C2 the scenario succeeds. E1 retain the
     * successful run as acceptance evidence; E2 retain only a failed run for
     * diagnosis. R1 C1+any(C2) -> E1 (`on`); R2 !C1+C2 -> discard; R3
     * !C1+!C2 -> E2 (`retain-on-failure`). FMECA: always recording bloats every
     * routine run, while failure-only recording cannot substantiate a green
     * Native business acceptance when a reviewer requests visual evidence. */
    video: recordSuccessfulVideo ? "on" : "retain-on-failure",
    launchOptions: {
      executablePath: process.env.PILOT_E2E_CHROME_BIN ?? "/usr/bin/google-chrome",
    },
  },
});
