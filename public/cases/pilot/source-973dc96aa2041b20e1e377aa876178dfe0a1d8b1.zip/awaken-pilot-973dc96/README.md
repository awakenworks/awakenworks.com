# Awaken Pilot

Give Pilot a Mission. One Awaken Managed Session carries it through.

Awaken Pilot is the thin-application case in the [Built on Awaken](https://awakenworks.com/cases) portfolio. It gives product teams a Mission-oriented interface for long-running work without adding another Agent runtime. Every Mission is one Managed Session. Awaken owns Workers, execution, orchestration, tools, Sandboxes, memory, approvals, and execution-stage artifacts.

Pilot owns the part users see: Project setup, Mission interaction, acceptance criteria, and product projections. That boundary is the point of the example. Read the [Pilot case](https://awakenworks.com/cases/pilot) for the short version, or continue here for the implementation details and reproducible checks.

Choose Pilot when your product idea is already clear and you do not want its first prototype to grow a second task engine. Start with one Mission and one visible acceptance criterion. Interrupt or approve the work once; the useful proof is that the same Managed Session continues and still produces an inspectable result.

## Prove the boundary first

For a first evaluation, ignore the full feature surface and follow one Mission:

1. create it with one result a person can inspect;
2. interrupt or approve the work once;
3. confirm that the same Awaken Session resumes and produces that result.

The evaluation succeeds when Pilot stays a product projection over one durable Session. If Pilot needs its own task engine, transcript store, or recovery state to finish the Mission, the example has failed its main claim.

## Full capability inventory

- create a Mission and start it atomically with an initial goal;
- launch in Execute Mode or Plan Mode, reviewing and approving a structured plan inside the same Session event log;
- define acceptance criteria and bounded automatic revision using Managed Session outcome evaluation;
- create and edit Projects backed one-for-one by Awaken Deployments;
- configure standing instructions, Agent, Environment, resources, Vault references and a per-Mission budget on a Project;
- create versioned Awaken Agent profiles with built-in tool permissions, the four managed document Skills, URL MCP Connectors and an optional parallel-Agent roster;
- create Awaken Vaults and write-only bearer, OAuth-refresh or connector environment credentials, validate MCP OAuth metadata, and attach only opaque Vault IDs to Projects;
- upload reusable knowledge through Awaken Files and create/select Awaken Memory Stores without a Pilot-side knowledge database;
- inspect the selected Agent's effective web/workspace tools, Skills, MCP connectors, custom tools and parallel-agent roster;
- create, pause, resume and manually trigger recurring work through Awaken's official Deployment schedule and run history;
- configure workspace-scoped outbound webhooks while Awaken owns signing secrets, delivery retries, failure state, and automatic disabling;
- open `/w/{workspace}/missions/{session}` team links: each recipient is re-authorized by Awaken IAM against the same Workspace and Session;
- continue, interrupt, approve, or deny work through Managed Session events;
- follow committed events and live message deltas over the official SDK stream;
- project a transcript, current plan, completion result, sub-agent threads, and output artifacts;
- download produced files through a Session-scoped Pilot API route;
- expose stateless `set_plan`, `notify_user`, and `publish_result` tools through a TypeScript MCP server;
- connect the Pilot server to either local Awaken or Awaken Cloud through the official Managed Agents SDK.
- run release acceptance through either a real host-login Codex Agent or Awaken Native with an Awaken-managed Provider Connection, including delegated live research and separate desktop/mobile Playwright MCP navigation, input, click and DOM-result verification.

## Source-archive installation qualification (2026-10-10)

`pnpm install --frozen-lockfile` and `pnpm check` passed in a fresh source
archive without Git metadata, a sibling Awaken checkout or a Git UI fetch.
The reference-case test checks the included shared archive digests. This
qualifies installation, local checks and the build. Real-Agent acceptance still
requires the separate endpoint and provenance inputs documented below.

## Prerequisites

- Node.js 22+, pnpm 11;
- an Awaken endpoint for real execution;
- fixed shared build archives are included under `vendor/`, so installation
  requires no sibling source tree or Git UI fetch;
- an existing Agent and Environment configured in Awaken.

```sh
pnpm install
pnpm check
pnpm dev
```

The archives preserve the existing projection, SDK-oracle and UI owners.
Exact source revisions and hashes are recorded in [`vendor/README.md`](vendor/README.md).
The lockfile binds those versioned build inputs; Pilot introduces no duplicate
reducer or component implementation.

The web app runs at `http://localhost:4173` and proxies `/api` to the Pilot API at `http://127.0.0.1:4174`. The API connects to local Awaken at `http://127.0.0.1:8080` by default. Configure its server-side connection when needed:

```sh
PILOT_AWAKEN_API_URL=https://awaken.example.com \
PILOT_AWAKEN_AUTH_TOKEN=server-side-token \
PILOT_IAM_API_URL=https://iam.example.com \
PILOT_IAM_ADMIN_TOKEN=iam-admin-service-token \
PILOT_APPLICATION_MCP_URL=https://pilot.example.com/mcp \
pnpm dev
```

`PILOT_API_HOST` and `PILOT_API_PORT` control the API listener. `PILOT_DEV_API_URL` changes the Web development proxy target. `PILOT_APPLICATION_MCP_URL` is a server-side capability injection; the browser stores no Agent/Environment defaults, MCP URL, Vault reference, schedule, or server automation credential.

For a hosted multi-user deployment, set `PILOT_REQUIRE_REQUEST_IDENTITY=true`. Optionally set `PILOT_DEFAULT_WORKSPACE_ID` only when the deployment deliberately fixes every request to one Workspace. Cloud must add the Pilot origin's exact callback to the existing `awaken-runtime` relying party, proxy `/v1/oauth/*` at the Pilot origin to IAM's canonical browser PKCE adapter, and launch users at `/w/{workspace}`. The browser then sends the IAM-owned `awaken.product.session-bearer` to the same-origin BFF; the BFF forwards it through Awaken's Workspace path, where Awaken verifies identity and membership on every operation.

External API clients use the same boundary: `Authorization: Bearer <IAM product token>` plus `X-Pilot-Workspace-Id: <workspace>`. Pilot never evaluates grants. In strict mode a missing identity or Workspace fails before upstream access, and an anonymous caller cannot steer the server credential into another Workspace.

Anonymous Mission links additionally require `PILOT_IAM_API_URL`, `PILOT_IAM_ADMIN_TOKEN`, and `PILOT_AWAKEN_AUTH_TOKEN`. The admin credential only mints IAM capabilities and upserts/revokes the one exact-Mission Grant after the requesting user passes IAM `workspace.write`; it is never sent to the browser. Public URLs carry their short-lived capability after `#`, default to seven days, and expose only committed read-only Mission data and artifacts.

The application MCP runs at `http://127.0.0.1:8788/mcp` by default. A sandboxed or cloud worker must receive a URL that it can reach; publish or tunnel the MCP endpoint, protect it with `PILOT_MCP_BEARER_TOKEN`, store that credential in an Awaken Vault, and attach the opaque Vault ID to the Project. Pilot never reads the secret.

The real-Agent acceptance starts separate services and drives them through a browser. Its repeatable procedure is in
[`docs/real-stack-acceptance.md`](docs/real-stack-acceptance.md).

Model-provider API keys are never Awaken process configuration. Import them
through Awaken's write-only Provider Connection API; Awaken service and Worker
entry points refuse to start when `API_KEY` or any case-insensitive `*_API_KEY`
environment name is present. Connector secrets remain sealed Awaken Vault
credentials and must not be confused with ambient process variables.

The generic MCP/Vault path supports provider connectors such as Gmail, Slack,
Stripe, publishing and analytics when their real endpoint and account credentials
are supplied. Pilot does not bundle or pretend to validate vendor accounts: each
provider needs its own OAuth/account/sandbox acceptance before that business
effect is reported as working.

Pilot never calculates price from `session.usage`; Awaken Cloud owns billing and cost presentation. Pilot does not integrate Awaken Flow. A future handoff would be an explicit, idempotent command/result exchange, never a synchronized task copy.

See [architecture](docs/architecture.md) for boundaries and runtime flow.
