import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const repository = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const awaken = path.resolve(process.env.AWAKEN_SOURCE_DIR || path.join(repository, "..", "awaken-1.0.0-dev"));
const executable = path.join(awaken, "target", "debug", "awaken");

assert.ok(process.env.DEEPSEEK_API_KEY, "verify:live requires DEEPSEEK_API_KEY");
assert.ok(fs.statSync(path.join(awaken, "e2e", "harness.mjs"), { throwIfNoEntry: false })?.isFile(),
  `AWAKEN_SOURCE_DIR is not an Awaken source tree: ${awaken}`);

// These gates reuse Awaken's authoritative process fixtures. Cause/effect
// ownership remains in the referenced tests: real BYOK execution, typed
// client-tool ownership, published-model inheritance, typed model overrides,
// restart recovery, malformed/concurrent input resilience, secret non-leak,
// and Workspace isolation must all pass. The orchestrator adds ordering only
// and contains no duplicate protocol behavior.
const gates = [
  "provider_connection_deepseek_real_e2e.mjs",
  "managed_custom_e2e.mjs",
  "managed_agent_model_inherit_e2e.mjs",
  "managed_model_override_e2e.mjs",
  "managed_session_config_restart_e2e.mjs",
  "managed_resilience_e2e.mjs",
  "secret_nonleak_e2e.mjs",
  "management_workspace_fence_e2e.mjs",
];

for (const gate of gates) {
  process.stdout.write(`\n=== Awaken gate: ${gate} ===\n`);
  const result = spawnSync(process.execPath, [path.join(awaken, "e2e", gate)], {
    cwd: awaken,
    env: {
      ...process.env,
      ...(fs.statSync(executable, { throwIfNoEntry: false })?.isFile()
        ? { AWAKEN_E2E_AWAKEN_BIN: executable }
        : {}),
    },
    stdio: "inherit",
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}

process.stdout.write("\nAll authoritative Awaken live gates passed.\n");
