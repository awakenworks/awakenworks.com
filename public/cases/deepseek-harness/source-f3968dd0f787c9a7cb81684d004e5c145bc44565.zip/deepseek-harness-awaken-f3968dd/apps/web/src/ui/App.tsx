import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaEnvironment } from "@anthropic-ai/sdk/resources/beta/environments/environments";
import type { BetaModelInfo } from "@anthropic-ai/sdk/resources/beta/models";
import type { BetaManagedAgentsSession } from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import type { SkillListResponse } from "@anthropic-ai/sdk/resources/beta/skills/skills";
import { isHarnessV1Preset, permissionModeFromTools, presetCatalog, type HarnessPreset } from "@harness/contracts";
import type { ManagedEvent } from "@awaken/managed-session-projection";
import { projectSession, type ToolView } from "@harness/session-domain";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState, type CSSProperties, type FormEvent } from "react";
import { useSession, sessionKeys } from "../application/use-session";
import { BrowserHarnessApi, type Identity } from "../infrastructure/api";
import { deepSeekHarnessReferenceCase } from "../reference-case";
import { GoalBar, Popover, SessionActivity, SettingsDialog } from "./DeepSeekSurfaces";
import { effortDisplay, modelDisplay } from "./model-display";
import { loadPreferences, savePreferences, type UiPreferences } from "./preferences";
import { QuestionComposer } from "./QuestionComposer";

function loadIdentity(): Identity {
  return {
    token: localStorage.getItem("harness.token") ?? "",
    workspaceId: localStorage.getItem("harness.workspace") ?? "",
  };
}

function saveIdentity(identity: Identity): void {
  localStorage.setItem("harness.token", identity.token);
  localStorage.setItem("harness.workspace", identity.workspaceId);
}

function statusLabel(status: string): string {
  return status.replace("rescheduled", "queued").replace(/^./, (letter) => letter.toUpperCase());
}

function sessionQueue(value: string | undefined): Array<{ id: string; text: string }> {
  try {
    const rows = JSON.parse(value ?? "[]") as unknown;
    return Array.isArray(rows) ? rows.flatMap((row) => typeof row === "object" && row !== null && "id" in row && "text" in row && typeof row.id === "string" && typeof row.text === "string" ? [{ id: row.id.slice(0, 8), text: row.text.slice(0, 96) }] : []).slice(0, 2) : [];
  } catch { return []; }
}

function encodedSessionQueue(rows: Array<{ id: string; text: string }>): string | null {
  const bounded = rows.slice(-2).map((row) => ({ id: row.id.slice(0, 8), text: row.text.trim().slice(0, 96) })).filter((row) => row.text);
  return bounded.length ? JSON.stringify(bounded) : null;
}

function feedbackRating(metadata: Record<string, string> | undefined, eventId: string): "up" | "down" | undefined {
  const value = metadata?.[`feedback_${eventId.slice(-20)}`];
  return value === "up" || value === "down" ? value : undefined;
}

function Json({ value }: { value: unknown }) {
  return <pre className="json-view">{JSON.stringify(value, null, 2)}</pre>;
}

function Logo() {
  return <div className="brand-mark" aria-label="DeepSeek Harness"><span>⌁</span></div>;
}

interface CreateDialogProps {
  agents: BetaManagedAgentsAgent[];
  environments: BetaEnvironment[];
  defaultPermission: "safe" | "full";
  onClose(): void;
  onCreate(input: {
    title: string; prompt: string; agentId: string; agentVersion: number;
    environmentId: string; preset: HarnessPreset; mode: "execute" | "plan";
    permission: "safe" | "full"; acknowledgedRisk: boolean;
  }): Promise<void>;
}

function CreateDialog({ agents, environments, defaultPermission, onClose, onCreate }: CreateDialogProps) {
  const [title, setTitle] = useState("Explore the repository");
  const [prompt, setPrompt] = useState("Inspect the project, explain its architecture, and identify the highest-impact improvement.");
  const [preset, setPreset] = useState<HarnessPreset>("standard");
  const [mode, setMode] = useState<"execute" | "plan">("execute");
  const [permission, setPermission] = useState<"safe" | "full">(defaultPermission);
  const [agentId, setAgentId] = useState(agents.find((candidate) => isHarnessV1Preset(candidate.metadata, "standard"))?.id ?? "");
  const [environmentId, setEnvironmentId] = useState(environments[0]?.id ?? "");
  const [submitting, setSubmitting] = useState(false);
  const agent = agents.find((candidate) => candidate.id === agentId);
  const compatibleAgents = agents.filter((candidate) => isHarnessV1Preset(candidate.metadata, preset));
  const selectPreset = (next: HarnessPreset) => {
    setPreset(next);
    const matching = agents.find((candidate) => isHarnessV1Preset(candidate.metadata, next));
    setAgentId(matching?.id ?? "");
  };
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!agent || !environmentId) return;
    const acknowledgedRisk = permission !== "full" || window.confirm("Full access automatically approves execution tool calls. Continue?");
    if (!acknowledgedRisk) return;
    setSubmitting(true);
    try {
      await onCreate({ title, prompt, preset, mode, permission, acknowledgedRisk, agentId, agentVersion: agent.version, environmentId });
    } finally {
      setSubmitting(false);
    }
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
    <form className="modal create-dialog" onSubmit={(event) => void submit(event)} data-testid="create-session-dialog">
      <div className="modal-head"><div><span className="eyebrow">NEW SESSION</span><h2>What should the agent do?</h2></div><button type="button" className="icon-button" onClick={onClose}>×</button></div>
      <label>Title<input value={title} onChange={(event) => setTitle(event.target.value)} required data-testid="session-title" /></label>
      <label>Request<textarea rows={5} value={prompt} onChange={(event) => setPrompt(event.target.value)} required data-testid="session-prompt" /></label>
      <div className="preset-grid">
        {presetCatalog.map((item) => <button type="button" key={item.id} className={`preset-card ${preset === item.id ? "selected" : ""}`} onClick={() => selectPreset(item.id)} data-testid={`preset-${item.id}`}>
          <span className="preset-mark">{item.mark}</span><span><strong>{item.name}</strong><small>{item.description}</small></span>
        </button>)}
      </div>
      <div className="form-row">
        <label>Agent<select value={agentId} onChange={(event) => setAgentId(event.target.value)}>{compatibleAgents.map((item) => <option key={item.id} value={item.id}>{item.name} · v{item.version}</option>)}</select></label>
        <label>Environment<select value={environmentId} onChange={(event) => setEnvironmentId(event.target.value)}>{environments.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label>Mode<select value={mode} onChange={(event) => setMode(event.target.value as "execute" | "plan")}><option value="execute">Execute</option><option value="plan">Plan first</option></select></label>
        <label>Permission<select value={permission} onChange={(event) => setPermission(event.target.value as "safe" | "full")}><option value="safe">Safe</option><option value="full">Full access</option></select></label>
      </div>
      {(!compatibleAgents.length || !environments.length) && <p className="callout warning">Publish one Harness v1 {preset} Agent and an Environment in Awaken before creating this Session.</p>}
      <div className="modal-actions"><button type="button" className="button secondary" onClick={onClose}>Cancel</button><button className="button primary" disabled={submitting || !compatibleAgents.length || !environments.length} data-testid="create-session-submit">{submitting ? "Creating…" : "Start session"}</button></div>
    </form>
  </div>;
}

function Sidebar({ sessions, selected, workspace, onSelect, onNew, onSettings, onArchive, onRename, onFork, onExport, onMove, onCollapse, onResize }: { sessions: BetaManagedAgentsSession[]; selected: string | undefined; workspace: string; onSelect(id: string): void; onNew(): void; onSettings(): void; onArchive(id: string): void; onRename(id: string, title: string): void; onFork(id: string, title: string): void; onExport(id: string): void; onMove(id: string, direction: -1 | 1): void; onCollapse(): void; onResize(): void }) {
  const [search, setSearch] = useState("");
  const [menu, setMenu] = useState<string>();
  const [sort, setSort] = useState<"recent" | "title" | "manual">("recent");
  const [group, setGroup] = useState<"none" | "status" | "preset">("none");
  const filtered = sessions.filter((session) => (session.title ?? "Untitled Session").toLowerCase().includes(search.toLowerCase())).sort((left, right) => sort === "title" ? (left.title ?? "").localeCompare(right.title ?? "") : sort === "manual" ? Number(left.metadata.harness_order ?? Number.MAX_SAFE_INTEGER) - Number(right.metadata.harness_order ?? Number.MAX_SAFE_INTEGER) : Date.parse(right.updated_at) - Date.parse(left.updated_at));
  const groups = [...filtered.reduce((values, session) => { const key = group === "status" ? statusLabel(session.status) : group === "preset" ? session.metadata.harness_preset ?? "standard" : "RECENT · LAST UPDATED"; values.set(key, [...values.get(key) ?? [], session]); return values; }, new Map<string, BetaManagedAgentsSession[]>())];
  return <aside className="sidebar">
    <div className="brand"><Logo /><div><strong>DeepSeek Harness</strong><small>{deepSeekHarnessReferenceCase.summary}</small></div><button className="collapse-control" aria-label="Collapse sidebar" onClick={onCollapse}>‹</button></div>
    <a className="reference-case-link" href={deepSeekHarnessReferenceCase.caseUrl} target="_blank" rel="noreferrer" aria-label="Read the independent DeepSeek Harness reference reimplementation">
      <strong>{deepSeekHarnessReferenceCase.kind}</strong>
      <span>{deepSeekHarnessReferenceCase.readerPromise}</span>
      <small>{deepSeekHarnessReferenceCase.disclosure}</small>
    </a>
    <button className="workspace-picker" onClick={onSettings}><span>▣</span><div><strong>{workspace || "Local workspace"}</strong><small>Cloud Workspace</small></div><span>⌄</span></button>
    <button className="new-session" onClick={onNew} data-testid="new-session"><span>＋</span> New session <kbd>⌘K</kbd></button>
    <div className="search"><span>⌕</span><input aria-label="Search sessions" placeholder="Search sessions" value={search} onChange={(event) => setSearch(event.target.value)} /></div>
    <div className="section-label"><select aria-label="Session grouping" value={group} onChange={(event) => setGroup(event.target.value as typeof group)}><option value="none">RECENT</option><option value="status">STATUS</option><option value="preset">PRESET</option></select><select aria-label="Session sorting" value={sort} onChange={(event) => setSort(event.target.value as typeof sort)}><option value="recent">Last updated</option><option value="title">Title</option><option value="manual">Manual</option></select><span>{filtered.length}</span></div>
    <nav className="session-list" aria-label="Sessions">
      {groups.map(([label, rows]) => <section className="session-group" key={label}><small>{label.toUpperCase()}</small>{rows.map((session) => <div className="session-row" key={session.id}><button className={`session-item ${selected === session.id ? "active" : ""}`} onClick={() => onSelect(session.id)} data-testid={`session-${session.id}`}>
        <span className={`status-dot ${session.status}`} /><span className="session-copy"><strong>{session.title ?? "Untitled Session"}</strong><small>{statusLabel(session.status)} · {session.metadata.harness_preset ?? "standard"}</small></span><span className="chevron">›</span>
      </button><button className="session-more" aria-label={`Actions for ${session.title ?? "Session"}`} onClick={() => setMenu(menu === session.id ? undefined : session.id)}>•••</button>{menu === session.id && <div className="session-menu"><button onClick={() => { const title = window.prompt("Rename Session", session.title ?? "")?.trim(); if (title) onRename(session.id, title); setMenu(undefined); }}>Rename</button><button onClick={() => { const title = window.prompt("Fork Session title", `${session.title ?? "Session"} — branch`)?.trim(); if (title) onFork(session.id, title); setMenu(undefined); }}>Fork from tail</button><button onClick={() => { onMove(session.id, -1); setSort("manual"); setMenu(undefined); }}>Move up</button><button onClick={() => { onMove(session.id, 1); setSort("manual"); setMenu(undefined); }}>Move down</button><button onClick={() => { void navigator.clipboard.writeText(session.id); setMenu(undefined); }}>Copy Session ID</button><button onClick={() => { onExport(session.id); setMenu(undefined); }}>Download log</button><button className="danger" onClick={() => { onArchive(session.id); setMenu(undefined); }}>Archive</button></div>}</div>)}</section>)}
      {!filtered.length && <p className="empty-small">No Sessions yet.<br />Start with a request.</p>}
    </nav>
    <div className="sidebar-foot"><button onClick={onSettings}>⚙ <span>Settings</span></button><div className="cloud-online"><i /> Cloud connected</div></div><div className="column-resizer sidebar-resizer" onPointerDown={onResize} />
  </aside>;
}

function ToolCard({ tool, selected, onSelect }: { tool: ToolView; selected: boolean; onSelect(tool: ToolView): void }) {
  const input = tool.input as Record<string, unknown> | undefined;
  const kind = ["bash", "shell", "pwsh"].includes(tool.name) ? "terminal" : ["edit", "write"].includes(tool.name) ? "diff" : ["grep", "glob"].includes(tool.name) ? "search" : tool.name === "read" ? "read" : tool.name.includes("web") ? "web" : tool.name === "skill" ? "skill" : ["question", "review_plan", "agent_proposal"].includes(tool.name) ? "question" : "tool";
  const summary = kind === "terminal" ? String(input?.command ?? "") : kind === "diff" ? String(input?.path ?? "File change") : kind === "search" ? String(input?.pattern ?? "Search workspace") : kind === "read" ? String(input?.path ?? "Read file") : kind === "web" ? String(input?.url ?? input?.query ?? "Web result") : kind === "skill" ? String(input?.name ?? "Skill instructions") : kind === "question" ? String(input?.question ?? input?.name ?? tool.name) : Object.values(input ?? {})[0];
  const icons: Record<string, string> = { terminal: ">_", diff: "±", search: "⌕", read: "▤", web: "↗", skill: "✦", question: "?", tool: "◇" };
  return <div className={`tool-card ${tool.state} ${selected ? "selected" : ""}`}>
    <button className="tool-main" onClick={() => onSelect(tool)}>
      <span className={`tool-icon ${kind}`}>{icons[kind]}</span>
      <span className="tool-copy"><strong>{tool.name}</strong><small>{typeof summary === "string" ? summary : "Structured tool call"}</small></span>
      <span className={`tool-state ${tool.state}`}>{tool.state === "running" ? "Running" : tool.state === "waiting" ? "Approval" : tool.state === "error" ? "Failed" : "Done"}</span>
    </button>
  </div>;
}

function ChatView({ sessionId, projection, preview, selectedTool, onSelectTool, send, interrupt, decide, answerTool, skills, forkAt, feedback, ratingFor, queue, enqueue, editQueue, deleteQueue, dispatchQueue, decidePlanReview, decideAgentProposal, enterBehavior, context }: {
  sessionId: string;
  projection: ReturnType<typeof import("@harness/session-domain").projectSession>;
  preview: { text: string; thinking: boolean };
  selectedTool: ToolView | undefined;
  onSelectTool(tool: ToolView): void;
  send(command: { text: string; images: Array<{ name: string; mediaType: "image/png" | "image/jpeg" | "image/gif" | "image/webp"; data: string }> }): Promise<unknown>;
  interrupt(): Promise<unknown>;
  decide(toolUseId: string, allow: boolean): Promise<unknown>;
  answerTool(toolUseId: string, text: string, cancelled?: boolean): Promise<unknown>;
  skills: SkillListResponse[];
  forkAt(eventId: string): Promise<unknown>;
  feedback(eventId: string, rating: "up" | "down"): Promise<unknown>;
  ratingFor(eventId: string): "up" | "down" | undefined;
  queue: Array<{ id: string; text: string }>;
  enqueue(text: string): Promise<unknown>;
  editQueue(id: string, text: string): Promise<unknown>;
  deleteQueue(id: string): Promise<unknown>;
  dispatchQueue(id: string, strict: boolean): Promise<unknown>;
  decidePlanReview(toolUseId: string, decision: "approve" | "revise" | "cancel", feedback?: string): Promise<unknown>;
  decideAgentProposal(toolUseId: string, decision: "approve" | "revise" | "cancel", feedback?: string): Promise<unknown>;
  enterBehavior: UiPreferences["enterBehavior"];
  context: { percent: number; used: number; maximum?: number };
}) {
  const [draft, setDraft] = useState("");
  const [lightbox, setLightbox] = useState<{ url: string; alt: string }>();
  const [images, setImages] = useState<Array<{ name: string; mediaType: "image/png" | "image/jpeg" | "image/gif" | "image/webp"; data: string; preview: string }>>([]);
  const [dragging, setDragging] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const addFiles = async (files: FileList | File[]) => {
    const allowed = new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]);
    const added = await Promise.all([...files].filter((file) => allowed.has(file.type)).slice(0, 20 - images.length).map(async (file) => {
      const dataUrl = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(file); });
      return { name: file.name, mediaType: file.type as "image/png" | "image/jpeg" | "image/gif" | "image/webp", data: dataUrl.slice(dataUrl.indexOf(",") + 1), preview: dataUrl };
    }));
    setImages((current) => [...current, ...added]);
  };
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setDraft(""); setImages([]);
    if (projection.status === "running" && images.length === 0) await enqueue(text);
    else await send({ text, images: images.map(({ preview: _preview, ...image }) => image) });
  };
  const roots = projection.tools;
  const approval = projection.approvals[0];
  const question = roots.find((tool) => tool.name === "question" && tool.state === "running");
  const slashOpen = draft.startsWith("/") && !draft.includes(" ");
  const mentionOpen = draft.startsWith("@") && !draft.includes(" ");
  return <div className="chat-stage" onDragEnter={(event) => { if ([...event.dataTransfer.types].includes("Files")) setDragging(true); }} onDragOver={(event) => event.preventDefault()} onDragLeave={(event) => { if (event.currentTarget === event.target) setDragging(false); }} onDrop={(event) => { event.preventDefault(); setDragging(false); void addFiles(event.dataTransfer.files); }}>
    <div className="conversation" data-testid="conversation">
      {projection.messages.map((message) => <article key={message.id} className={`message ${message.role}`}>
        <div className="avatar">{message.role === "assistant" ? "⌁" : message.role === "user" ? "Y" : "i"}</div>
        <div className="message-body"><div className="message-meta"><strong>{message.role === "assistant" ? "DeepSeek" : message.role === "user" ? "You" : "System"}</strong>{message.at && <time>{new Date(message.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</time>}</div>{message.text && <div className="message-text">{message.text}</div>}{message.images.length > 0 && <div className={`message-images ${message.images.length === 1 ? "single" : "tiles"}`}>{message.images.map((image) => <button key={image.id} onClick={() => setLightbox(image)}><img src={image.url} alt={image.alt} /></button>)}</div>}<div className="message-actions"><button onClick={() => void navigator.clipboard.writeText(message.text)}>Copy</button><button onClick={() => void forkAt(message.id)}>Branch</button>{message.role === "assistant" && <><button className={ratingFor(message.id) === "up" ? "selected" : ""} aria-label="Helpful" onClick={() => void feedback(message.id, "up")}>♡</button><button className={ratingFor(message.id) === "down" ? "selected" : ""} aria-label="Not helpful" onClick={() => void feedback(message.id, "down")}>◇</button></>}</div></div>
      </article>)}
      {projection.markers.map((marker) => marker.kind === "compaction" ? <div className="checkpoint" key={marker.id}><span>↻</span><div><strong>Context compacted</strong><small>A durable checkpoint summarizes earlier context.</small></div></div> : <details className="thinking-block" key={marker.id}><summary>Thought process</summary><p>Extended thinking progress was committed without exposing private reasoning text.</p></details>)}
      {roots.map((tool) => <ToolCard key={tool.id} tool={tool} selected={selectedTool?.id === tool.id} onSelect={onSelectTool} />)}
      {(preview.thinking || preview.text) && <article className="message assistant live"><div className="avatar">⌁</div><div className="message-body"><div className="message-meta"><strong>{preview.thinking ? "Thinking" : "DeepSeek"}</strong><span className="pulse" /></div><div className="message-text">{preview.text || "Reasoning through the next step…"}</div></div></article>}
      {projection.error && <div className="callout error">{projection.error}</div>}
      {projection.result && <section className="deliverable-row"><span>▤</span><div><strong>Produced files</strong><small>{projection.result.summary}</small></div>{projection.result.artifacts.map((artifact) => <code key={artifact.path}>{artifact.path}</code>)}</section>}
    </div>
    {queue.length > 0 && <div className="queue-list" data-testid="message-queue"><span className="eyebrow">QUEUED STEERING</span>{queue.map((item) => <div className="queue-row" key={item.id}><span>≡</span><p>{item.text}</p><button onClick={() => { const text = window.prompt("Edit queued message", item.text)?.trim(); if (text) void editQueue(item.id, text); }}>Edit</button><button onClick={() => void deleteQueue(item.id)}>Delete</button><button onClick={() => void dispatchQueue(item.id, true)}>Strict steer</button><button className="allow" onClick={() => void dispatchQueue(item.id, false)}>Send now</button></div>)}</div>}
    {projection.plan && <div className="todo-strip"><span>☷</span><strong>{projection.plan.steps.filter((step) => step.status === "completed").length}/{projection.plan.steps.length}</strong><span>{projection.plan.steps.find((step) => step.status === "in_progress")?.title ?? projection.plan.summary}</span><button type="button" onClick={() => document.querySelector('[data-testid="plan-panel"]')?.scrollIntoView({ behavior: "smooth" })}>View plan</button></div>}
    {approval ? <section className="composer approval takeover" data-testid="approval-card"><div><span className="approval-icon">!</span><div><strong>Permission required</strong><p><code>{approval.name}</code> wants to run with the supplied input.</p></div></div><Json value={approval.input} /><div className="approval-actions"><button onClick={() => void decide(approval.id, false)}>Deny</button><button className="allow" onClick={() => void decide(approval.id, true)}>Allow once</button></div></section> : question ? <QuestionComposer toolId={question.id} input={question.input} answer={(text, cancelled = false) => answerTool(question.id, text, cancelled)} /> : projection.planReview && projection.plan ? <section className="composer plan-review" data-testid="plan-review"><span className="eyebrow">PLAN READY FOR REVIEW</span><h3>{projection.plan.summary}</h3><p>Revision {projection.planReview.revision} is durably waiting for a correlated decision.</p><div className="approval-actions"><button onClick={() => void decidePlanReview(projection.planReview!.id, "cancel")}>Cancel</button><button onClick={() => { const feedback = window.prompt("How should the plan change?")?.trim(); if (feedback) void decidePlanReview(projection.planReview!.id, "revise", feedback); }}>Request changes</button><button className="allow" onClick={() => void decidePlanReview(projection.planReview!.id, "approve")}>Approve plan</button></div></section> : projection.agentProposal ? <section className="composer plan-review" data-testid="agent-proposal-review"><span className="eyebrow">AGENT PROPOSAL READY</span><h3>{String((projection.agentProposal.input as { name?: unknown } | undefined)?.name ?? "Agent composition")}</h3><Json value={projection.agentProposal.input} /><p>Publication always requires this explicit business approval, even in Full access.</p><div className="approval-actions"><button onClick={() => void decideAgentProposal(projection.agentProposal!.id, "cancel")}>Cancel</button><button onClick={() => { const feedback = window.prompt("How should the Agent proposal change?")?.trim(); if (feedback) void decideAgentProposal(projection.agentProposal!.id, "revise", feedback); }}>Request changes</button><button className="allow" onClick={() => void decideAgentProposal(projection.agentProposal!.id, "approve")}>Publish Agent</button></div></section> : <form className="composer" onSubmit={(event) => void submit(event)}>
      {images.length > 0 && <div className="attachment-rail">{images.map((image, index) => <div className="attachment" key={`${image.name}-${index}`}><img src={image.preview} alt={image.name} /><button type="button" aria-label={`Remove ${image.name}`} onClick={() => setImages((current) => current.filter((_, item) => item !== index))}>×</button></div>)}</div>}
      {slashOpen && <div className="input-menu" data-testid="slash-menu"><small>COMMANDS</small>{[["/plan", "Enter plan mode"], ["/model", "Choose model and effort"], ["/compact", "Compact context"], ["/help", "Show commands"]].map(([name, note]) => <button type="button" key={name} onClick={() => setDraft(`${name} `)}><code>{name}</code><span>{note}</span></button>)}</div>}
      {mentionOpen && <div className="input-menu" data-testid="mention-menu"><small>REFERENCES & SKILLS</small><button type="button" onClick={() => setDraft("@Provider researcher ")}><code>@Provider researcher</code><span>Running subagent</span></button>{skills.map((skill) => { const reference = skill.id.replace(/^skill_/, ""); return <button type="button" key={skill.id} onClick={() => setDraft(`@skill:${reference} `)}><code>@skill:{reference}</code><span>{skill.display_title ?? skill.id} · {skill.source} · {skill.latest_version ?? "latest"}</span></button>; })}</div>}
      <textarea aria-label="Message" placeholder="Ask DeepSeek to inspect, change, or verify…" rows={2} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { const sendKey = event.key === "Enter" && !event.shiftKey && (enterBehavior === "send" ? !event.metaKey && !event.ctrlKey : event.metaKey || event.ctrlKey); if (sendKey) { event.preventDefault(); event.currentTarget.form?.requestSubmit(); } }} data-testid="composer" />
      <input ref={input} type="file" accept="image/png,image/jpeg,image/gif,image/webp" multiple hidden onChange={(event) => event.target.files && void addFiles(event.target.files)} />
      <div className="composer-bottom"><div><button type="button" className="composer-tool" title="Attach images" onClick={() => input.current?.click()}>＋</button><button type="button" className="composer-chip" disabled title="Change permission from the Session header">♢ Session</button><button type="button" className="composer-chip" disabled title="Model is frozen at Session admission">◇ DeepSeek</button><span className="context-indicator" title="Cumulative Session input and cache-read usage"><i style={{ "--w": `${context.percent}%` } as CSSProperties} /> {context.maximum ? `${context.used.toLocaleString()} / ${context.maximum.toLocaleString()}` : `${context.used.toLocaleString()} tokens`}</span></div><div>{projection.status === "running" && <button type="button" className="stop" onClick={() => void interrupt()}>■ Stop</button>}<button className="send" disabled={!draft.trim()} aria-label="Send message">↑</button></div></div>
    </form>}
    {dragging && <div className="drop-overlay"><span>⇧</span><strong>Drop images to attach</strong><small>PNG, JPEG, GIF or WebP · up to 20 images</small></div>}
    {lightbox && <div className="image-lightbox" role="dialog" aria-modal="true" aria-label="Image preview" onMouseDown={(event) => event.target === event.currentTarget && setLightbox(undefined)}><button aria-label="Close image preview" onClick={() => setLightbox(undefined)}>×</button><img src={lightbox.url} alt={lightbox.alt} /></div>}
    <small className="composer-hint">Session {sessionId.slice(-8)} · committed events are authoritative</small>
  </div>;
}

function Trajectory({ projection, events, usage, onSelect }: { projection: ReturnType<typeof import("@harness/session-domain").projectSession>; events: ManagedEvent[]; usage?: unknown; onSelect(tool: ToolView): void }) {
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState<"all" | "messages" | "tools" | "markers">("all");
  const [zoom, setZoom] = useState(100);
  const [inspected, setInspected] = useState<unknown>();
  const total = projection.messages.length + projection.tools.length + projection.markers.length;
  const query = search.toLowerCase();
  const markers = kind === "all" || kind === "markers" ? projection.markers.filter((marker) => marker.kind.includes(query)) : [];
  const messages = kind === "all" || kind === "messages" ? projection.messages.filter((message) => `${message.role} ${message.text}`.toLowerCase().includes(query)) : [];
  const tools = kind === "all" || kind === "tools" ? projection.tools.filter((tool) => `${tool.name} ${JSON.stringify(tool.input)}`.toLowerCase().includes(query)) : [];
  const requests = events.filter((event) => event.type === "span.model_request_end").length;
  return <div className="trajectory" data-testid="trajectory"><section className="trajectory-overview"><div><span className="eyebrow">OVERVIEW</span><strong>{total} committed records</strong></div><div className="timeline" style={{ width: `${zoom}%` }}><i className="user" style={{ width: "12%" }} /><i className="thinking" style={{ width: "8%" }} /><i className="tool" style={{ width: "54%" }} /><i className="assistant" style={{ width: "26%" }} /></div><div className="timeline-controls"><small>Turn window · {requests} model request{requests === 1 ? "" : "s"}</small><label>Zoom <input type="range" min="100" max="300" value={zoom} onChange={(event) => setZoom(Number(event.target.value))} /></label></div></section><div className="trajectory-toolbar"><label>⌕ <input aria-label="Search trajectory" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search loaded records" /></label><select aria-label="Trajectory record type" value={kind} onChange={(event) => setKind(event.target.value as typeof kind)}><option value="all">All records</option><option value="messages">Messages</option><option value="tools">Tools</option><option value="markers">Markers</option></select><span>{usage ? `Usage snapshot · ${JSON.stringify(usage).length} bytes` : "Committed window"}</span></div>{inspected !== undefined && <section className="trajectory-inspector"><div><strong>Record inspector</strong><button onClick={() => setInspected(undefined)}>×</button></div><Json value={inspected} /></section>}<div className="trajectory-head"><span>EVENT</span><span>DETAIL</span><span>STATE</span></div>
    {markers.map((marker) => <button className="trajectory-row" key={marker.id} onClick={() => setInspected(events.find((event) => event.id === marker.id))}><span className="event-badge assistant">{marker.kind}</span><span>{marker.kind === "compaction" ? "Between turns · context checkpoint" : "Extended thinking progress"}</span><span>Committed</span></button>)}
    {messages.map((message) => <button className="trajectory-row" key={message.id} onClick={() => setInspected(events.find((event) => event.id === message.id))}><span className={`event-badge ${message.role}`}>{message.role}</span><span>{message.text.slice(0, 110) || `${message.images.length} image(s)`}</span><span>Committed</span></button>)}
    {tools.map((tool) => <button className="trajectory-row tool" key={tool.id} onClick={() => { onSelect(tool); setInspected(events.find((event) => event.id === tool.id) ?? tool); }}><span className="event-badge tool">{tool.kind}</span><span><strong>{tool.name}</strong> · {JSON.stringify(tool.input).slice(0, 100)}</span><span>{tool.state}</span></button>)}
    {!markers.length && !messages.length && !tools.length && <p className="empty-small">No matching trajectory records.</p>}
  </div>;
}

function DetailsPanel({ selectedTool, projection, threads, artifacts, onDownload, loadThread, archiveThread }: {
  selectedTool: ToolView | undefined;
  projection: ReturnType<typeof import("@harness/session-domain").projectSession>;
  threads: Array<{ id: string; name?: string; status?: string; stats?: { duration_seconds?: number; active_seconds?: number } | null; usage?: { input_tokens?: number; output_tokens?: number } | null }>;
  artifacts: Array<{ id: string; filename: string; size_bytes?: number }>;
  onDownload(file: { id: string; filename: string; size_bytes?: number }): Promise<void>;
  loadThread(threadId: string): Promise<ManagedEvent[]>;
  archiveThread(threadId: string): Promise<unknown>;
}) {
  const [tab, setTab] = useState<"summary" | "payload" | "result">("summary");
  const [threadId, setThreadId] = useState<string>();
  const threadEvents = useQuery({ queryKey: ["thread-events", threadId], queryFn: () => loadThread(threadId!), enabled: Boolean(threadId) });
  const threadProjection = useMemo(() => projectSession(threadEvents.data ?? []), [threadEvents.data]);
  const activeThread = threads.find((thread) => thread.id === threadId);
  return <aside className="details">
    <div className="details-title"><span>DETAILS</span>{selectedTool && <code>{selectedTool.name}</code>}</div>
    {selectedTool ? <>
      <div className="detail-tabs"><button className={tab === "summary" ? "active" : ""} onClick={() => setTab("summary")}>Summary</button><button className={tab === "payload" ? "active" : ""} onClick={() => setTab("payload")}>Payload</button><button className={tab === "result" ? "active" : ""} onClick={() => setTab("result")}>Result</button></div>
      <div className="detail-content">{tab === "summary" ? <><div className="kv"><span>Status</span><strong className={selectedTool.state}>{selectedTool.state}</strong></div><div className="kv"><span>Kind</span><strong>{selectedTool.kind}</strong></div><div className="kv"><span>Call ID</span><code>{selectedTool.id}</code></div></> : tab === "payload" ? <Json value={selectedTool.input} /> : <Json value={selectedTool.output ?? { pending: true }} />}</div>
    </> : <div className="detail-content overview">
      <section><span className="eyebrow">SESSION</span><div className="kv"><span>Status</span><strong className={projection.status}>{statusLabel(projection.status)}</strong></div><div className="kv"><span>Messages</span><strong>{projection.messages.length}</strong></div><div className="kv"><span>Tool calls</span><strong>{projection.tools.length}</strong></div></section>
      {projection.plan && <section data-testid="plan-panel"><span className="eyebrow">PLAN</span><h3>{projection.plan.summary}</h3>{projection.plan.steps.map((step) => <div className="plan-step" key={step.id}><i className={step.status} /><span><strong>{step.title}</strong>{step.detail && <small>{step.detail}</small>}</span></div>)}</section>}
      <section><span className="eyebrow">SUBAGENTS</span>{threadId ? <div className="thread-transcript"><button onClick={() => setThreadId(undefined)}>← Catalog</button>{activeThread && <p className="thread-stats">{activeThread.status ?? "active"} · {(activeThread.usage?.input_tokens ?? 0) + (activeThread.usage?.output_tokens ?? 0)} tokens · {activeThread.stats?.duration_seconds ?? 0}s elapsed</p>}{threadEvents.isLoading ? <p className="muted">Loading child transcript…</p> : threadProjection.messages.map((message) => <article key={message.id}><strong>{message.role === "assistant" ? "Subagent" : "Parent"}</strong><p>{message.text}</p></article>)}<button className="thread-archive" onClick={() => void archiveThread(threadId).then(() => setThreadId(undefined))}>Stop / archive child</button></div> : threads.length ? threads.map((thread) => <button className="thread" key={thread.id} onClick={() => setThreadId(thread.id)}><span className={thread.status === "running" ? "activity-dot live" : "activity-dot"} /><div><strong>{thread.name ?? "Worker thread"}</strong><small>{thread.status ?? "active"} · {(thread.usage?.input_tokens ?? 0) + (thread.usage?.output_tokens ?? 0)} tokens · {thread.stats?.duration_seconds ?? 0}s</small></div><span>›</span></button>) : <p className="muted">No delegated threads</p>}</section>
      <section><span className="eyebrow">ARTIFACTS</span>{artifacts.length ? artifacts.map((artifact) => <button className="artifact" key={artifact.id} onClick={() => void onDownload(artifact)}><span>▤</span><div><strong>{artifact.filename}</strong><small>{artifact.size_bytes ? `${Math.ceil(artifact.size_bytes / 1024)} KB` : "Session output"}</small></div></button>) : <p className="muted">Outputs appear here</p>}</section>
    </div>}
  </aside>;
}

function SessionScreen({ id, api, skills, models, enterBehavior, detailsCollapsed, onToggleDetails, onResizeDetails, onForked }: { id: string; api: BrowserHarnessApi; skills: SkillListResponse[]; models: BetaModelInfo[]; enterBehavior: UiPreferences["enterBehavior"]; detailsCollapsed: boolean; onToggleDetails(): void; onResizeDetails(): void; onForked(id: string): void }) {
  const cache = useQueryClient();
  const state = useSession(id, api);
  const [view, setView] = useState<"chat" | "trajectory">("chat");
  const [selectedTool, setSelectedTool] = useState<ToolView>();
  useEffect(() => {
    setSelectedTool(undefined);
    setView("chat");
  }, [id]);
  const session = state.session.data;
  if (state.session.isLoading || state.events.isLoading) return <main className="loading"><Logo /><span>Opening committed Session…</span></main>;
  if (state.session.error) return <main className="loading error"><span>Could not open Session</span><small>{state.session.error.message}</small></main>;
  const threads = (state.threads.data ?? []) as Array<{ id: string; name?: string; status?: string; stats?: { duration_seconds?: number; active_seconds?: number } | null; usage?: { input_tokens?: number; output_tokens?: number } | null }>;
  const runningTools = state.projection.tools.filter((tool) => tool.state === "running").length;
  const usage = session?.usage;
  const contextUsed = (usage?.input_tokens ?? 0) + (usage?.cache_read_input_tokens ?? 0);
  const contextMaximum = models.find((model) => model.id === modelDisplay(session?.agent.model))?.max_input_tokens;
  const context = { percent: contextMaximum ? Math.min(100, contextUsed / contextMaximum * 100) : 0, used: contextUsed, ...(contextMaximum ? { maximum: contextMaximum } : {}) };
  const permissionMode = permissionModeFromTools(session?.agent.tools ?? []);
  const queue = sessionQueue(session?.metadata.harness_queue);
  const persistQueue = async (next: Array<{ id: string; text: string }>) => {
    await api.updateSession(id, { metadata: { harness_queue: encodedSessionQueue(next) } });
    await state.session.refetch();
  };
  return <>
    <main className="main-panel">
      <header className="session-header"><div><div className="title-line"><h1>{session?.title ?? "Session"}</h1><span className="preset-label">{session?.metadata.harness_preset ?? "standard"}</span><span className={`status-pill ${state.projection.status}`}><i />{statusLabel(state.projection.status)}</span></div><div className="session-meta"><span>{modelDisplay(session?.agent.model)}</span><b>·</b><span>{effortDisplay(session?.agent.model)} effort</span><b>·</b><span>{session?.metadata.harness_mode ?? "execute"} mode</span><b>·</b><span>{state.projection.phase.replaceAll("_", " ")}</span></div></div><div className="header-actions">
        <Popover label="Model and reasoning effort" trigger={<>◇ Model</>}><div className="popover-title"><strong>Model & effort</strong><small>Frozen by the published Agent</small></div><div className="menu-row selected"><span>◇</span><div><strong>{modelDisplay(session?.agent.model)}</strong><small>DeepSeek · current Session</small></div><span>✓</span></div><div className="effort-row"><button disabled>Low</button><button className="active" disabled>{effortDisplay(session?.agent.model)}</button><button disabled>High</button></div></Popover>
        <Popover label="Permission mode" trigger={<>♢ {permissionMode === "full" ? "Full" : "Safe"}</>}><div className="popover-title"><strong>Permission mode</strong><small>Derived from the effective Session tool policy</small></div><button className={`menu-row ${permissionMode === "safe" ? "selected" : ""}`} onClick={() => void api.setPermissionMode(id, { mode: "safe", acknowledgedRisk: false }).then(() => state.session.refetch())}><span>◈</span><div><strong>Safe mode</strong><small>Restore the published Agent policy</small></div><span>{permissionMode === "safe" ? "✓" : ""}</span></button><button className={`menu-row ${permissionMode === "full" ? "selected" : ""}`} onClick={() => { if (window.confirm("Full access automatically approves execution tool calls. Continue?")) void api.setPermissionMode(id, { mode: "full", acknowledgedRisk: true }).then(() => state.session.refetch()); }}><span>!</span><div><strong>Full access</strong><small>Automatically approve execution tool calls</small></div><span>{permissionMode === "full" ? "✓" : ""}</span></button></Popover>
        <SessionActivity threads={threads} runningTools={runningTools} />
        <Popover label="Subagents" trigger={<>↳ {threads.length}</>}><div className="popover-title"><strong>Subagents</strong><small>Durable child Session catalog</small></div>{threads.map((thread) => <div className="menu-row" key={thread.id}><span className={thread.status === "running" ? "activity-dot live" : "activity-dot"} /><div><strong>{thread.name ?? "Worker"}</strong><small>{thread.status ?? "inactive"} · {thread.id}</small></div></div>)}</Popover>
        <div className="segmented"><button className={view === "chat" ? "active" : ""} onClick={() => setView("chat")} data-testid="chat-tab">Chat</button><button className={view === "trajectory" ? "active" : ""} onClick={() => setView("trajectory")} data-testid="trajectory-tab">Trajectory</button></div></div></header>
      <GoalBar value={session?.metadata.harness_goal ?? "Modernize the provider path without duplicate ownership"} onSave={async (goal) => { await api.updateSession(id, { metadata: { harness_goal: goal || null } }); await state.session.refetch(); }} />
      {view === "chat" ? <ChatView sessionId={id} projection={state.projection} preview={state.preview} selectedTool={selectedTool} onSelectTool={setSelectedTool} send={(command) => state.send.mutateAsync(command)} interrupt={() => state.interrupt.mutateAsync()} decide={(toolUseId, allow) => state.decide.mutateAsync({ toolUseId, allow })} answerTool={(toolUseId, text, cancelled = false) => state.answerTool.mutateAsync({ toolUseId, text, cancelled })} skills={skills} forkAt={async (throughEventId) => { const forked = await api.forkSession(id, { title: `${session?.title ?? "Session"} — branch`, throughEventId }); onForked(forked.id); }} feedback={async (eventId, rating) => { await api.updateSession(id, { metadata: { [`feedback_${eventId.slice(-20)}`]: rating } }); await state.session.refetch(); }} ratingFor={(eventId) => feedbackRating(session?.metadata, eventId)} queue={queue} enqueue={(text) => persistQueue([...queue, { id: crypto.randomUUID().slice(0, 8), text }])} editQueue={(queueId, text) => persistQueue(queue.map((item) => item.id === queueId ? { ...item, text } : item))} deleteQueue={(queueId) => persistQueue(queue.filter((item) => item.id !== queueId))} dispatchQueue={async (queueId, strict) => { const item = queue.find((candidate) => candidate.id === queueId); if (!item) return; await state.send.mutateAsync({ text: strict ? `[STRICT STEER]\n${item.text}` : item.text, images: [] }); await persistQueue(queue.filter((candidate) => candidate.id !== queueId)); }} decidePlanReview={async (toolUseId, decision, feedback) => { await api.decidePlanReview(id, { toolUseId, decision, ...(feedback ? { feedback } : {}) }); await state.refresh(); }} decideAgentProposal={async (toolUseId, decision, feedback) => { await api.decideAgentProposal(id, { toolUseId, decision, ...(feedback ? { feedback } : {}) }); await Promise.all([state.refresh(), cache.invalidateQueries({ queryKey: ["agents"] })]); }} enterBehavior={enterBehavior} context={context} /> : <Trajectory projection={state.projection} events={state.events.data ?? []} usage={session?.usage} onSelect={setSelectedTool} />}
    </main>
    {detailsCollapsed ? <button className="details-restore" aria-label="Show details" onClick={onToggleDetails}>‹</button> : <div className="details-wrap"><div className="column-resizer details-resizer" onPointerDown={onResizeDetails} /><button className="details-collapse" aria-label="Hide details" onClick={onToggleDetails}>›</button><DetailsPanel selectedTool={selectedTool} projection={state.projection} threads={threads} artifacts={state.artifacts.data ?? []} onDownload={(file) => api.downloadArtifact(id, file as Parameters<typeof api.downloadArtifact>[1])} loadThread={(threadId) => api.listThreadEvents(id, threadId)} archiveThread={async (threadId) => { await api.archiveThread(id, threadId); await state.threads.refetch(); }} /></div>}
  </>;
}

export function App() {
  const cache = useQueryClient();
  const [identity, setIdentity] = useState(loadIdentity);
  const [preferences, setPreferences] = useState<UiPreferences>(() => loadPreferences(loadIdentity().workspaceId));
  const api = useMemo(() => new BrowserHarnessApi(() => identity), [identity]);
  const sessions = useQuery({ queryKey: sessionKeys.all, queryFn: () => api.listSessions(), refetchInterval: 10_000 });
  const agents = useQuery({ queryKey: ["agents"], queryFn: () => api.listAgents() });
  const environments = useQuery({ queryKey: ["environments"], queryFn: () => api.listEnvironments() });
  const models = useQuery({ queryKey: ["models"], queryFn: () => api.listModels() });
  const skills = useQuery({ queryKey: ["skills"], queryFn: () => api.listSkills() });
  const [selected, setSelected] = useState<string>();
  const [creating, setCreating] = useState(false);
  const [settings, setSettings] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [detailsCollapsed, setDetailsCollapsed] = useState(false);
  const [sidebarWidth, setSidebarWidth] = useState(254);
  const [detailsWidth, setDetailsWidth] = useState(310);
  const [resizing, setResizing] = useState<"sidebar" | "details">();
  useEffect(() => { document.documentElement.lang = preferences.locale === "zh" ? "zh-CN" : "en"; }, [preferences.locale]);
  useEffect(() => {
    if (!selected && sessions.data?.[0]) setSelected(sessions.data[0].id);
  }, [selected, sessions.data]);
  const create = useMutation({ mutationFn: (input: Parameters<typeof api.createSession>[0]) => api.createSession(input), onSuccess: async (session) => {
    await cache.invalidateQueries({ queryKey: sessionKeys.all });
    setCreating(false);
    setSelected(session.id);
  } });
  const moveSession = async (id: string, direction: -1 | 1) => {
    const ordered = [...sessions.data ?? []].sort((left, right) => Number(left.metadata.harness_order ?? Number.MAX_SAFE_INTEGER) - Number(right.metadata.harness_order ?? Number.MAX_SAFE_INTEGER) || Date.parse(right.updated_at) - Date.parse(left.updated_at));
    const index = ordered.findIndex((session) => session.id === id);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= ordered.length) return;
    [ordered[index], ordered[target]] = [ordered[target]!, ordered[index]!];
    await Promise.all(ordered.map((session, order) => api.updateSession(session.id, { metadata: { harness_order: String(order) } })));
    await cache.invalidateQueries({ queryKey: sessionKeys.all });
  };
  const connectionError = sessions.error ?? agents.error ?? environments.error;
  return <div className={`app-shell theme-${preferences.theme} locale-${preferences.locale} ${resizing ? "resizing" : ""} ${sidebarCollapsed ? "sidebar-collapsed" : ""} ${detailsCollapsed ? "details-collapsed" : ""}`} style={{ "--sidebar-width": `${sidebarWidth}px`, "--details-width": `${detailsWidth}px` } as CSSProperties} onPointerMove={(event) => { if (resizing === "sidebar") setSidebarWidth(Math.min(420, Math.max(190, event.clientX))); if (resizing === "details") setDetailsWidth(Math.min(520, Math.max(240, window.innerWidth - event.clientX))); }} onPointerUp={() => setResizing(undefined)} onPointerCancel={() => setResizing(undefined)}>
    {sidebarCollapsed ? <button className="sidebar-restore" aria-label="Show sidebar" onClick={() => setSidebarCollapsed(false)}><Logo />›</button> : <Sidebar sessions={sessions.data ?? []} selected={selected} workspace={identity.workspaceId} onSelect={setSelected} onNew={() => setCreating(true)} onSettings={() => setSettings(true)} onRename={(id, title) => { void api.updateSession(id, { title }).then(() => cache.invalidateQueries({ queryKey: sessionKeys.all })); }} onFork={(id, title) => { void api.forkSession(id, { title }).then(async (forked) => { await cache.invalidateQueries({ queryKey: sessionKeys.all }); setSelected(forked.id); }); }} onArchive={(id) => { void api.archive(id).then(async () => { if (selected === id) setSelected(undefined); await cache.invalidateQueries({ queryKey: sessionKeys.all }); }); }} onExport={(id) => { void api.exportSession(id); }} onMove={(id, direction) => { void moveSession(id, direction); }} onCollapse={() => setSidebarCollapsed(true)} onResize={() => setResizing("sidebar")} />}
    {connectionError ? <main className="welcome"><Logo /><span className="eyebrow">CONNECTION REQUIRED</span><h1>Connect to Awaken Cloud</h1><p>{connectionError.message}</p><button className="button primary" onClick={() => setSettings(true)}>Open settings</button></main> : selected ? <SessionScreen id={selected} api={api} skills={skills.data ?? []} models={models.data ?? []} enterBehavior={preferences.enterBehavior} detailsCollapsed={detailsCollapsed} onToggleDetails={() => setDetailsCollapsed(!detailsCollapsed)} onResizeDetails={() => setResizing("details")} onForked={(forkedId) => { void cache.invalidateQueries({ queryKey: sessionKeys.all }); setSelected(forkedId); }} /> : <main className="welcome"><div className="welcome-orbit"><Logo /></div><span className="eyebrow">DEEPSEEK · AWAKEN CLOUD</span><h1>What will you build?</h1><p>Start a durable coding Session with tools, trajectory, plans, subagents, and human approval.</p><button className="button primary large" onClick={() => setCreating(true)}>＋ New session</button><div className="feature-row"><span>◇ Sandboxed tools</span><span>⌁ Live trajectory</span><span>↳ Multi-agent</span></div></main>}
    {creating && <CreateDialog agents={agents.data ?? []} environments={environments.data ?? []} defaultPermission={preferences.defaultPermission} onClose={() => setCreating(false)} onCreate={(input) => create.mutateAsync(input).then(() => undefined)} />}
    {settings && <SettingsDialog identity={identity} preferences={preferences} agents={agents.data ?? []} models={models.data ?? []} skills={skills.data ?? []} onClose={() => setSettings(false)} onSave={(value, nextPreferences) => { if (preferences.defaultPermission !== "full" && nextPreferences.defaultPermission === "full" && !window.confirm("New Sessions will automatically allow tool calls. Save Full access as the default?")) return; saveIdentity(value); savePreferences(nextPreferences); setIdentity(value); setPreferences(nextPreferences); document.documentElement.lang = nextPreferences.locale === "zh" ? "zh-CN" : "en"; setSettings(false); void cache.invalidateQueries(); }} onCopyAgent={async (id, name) => { await api.copyAgent(id, { name }); await cache.invalidateQueries({ queryKey: ["agents"] }); }} onArchiveAgent={async (id) => { await api.archiveAgent(id); await cache.invalidateQueries({ queryKey: ["agents"] }); }} />}
  </div>;
}
