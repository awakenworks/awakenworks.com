import { expect, test } from "@playwright/test";

test("cloud Harness executes the critical Session interaction path", async ({ page, request }) => {
  /**
   * Cause/effect decision table:
   * R1 valid Workspace + SDK catalogs -> existing Session is projected;
   * R2 committed plan and official tool facts -> plan and flat calls render;
   * R3 permission=ask without confirmation -> approval blocks the tool;
   * R4 allow command -> canonical user confirmation, tool result, and idle fact;
   * R5 create command -> SDK retrieves the versioned Agent then creates one Session;
   * R6 independent reimplementation identity -> canonical case link and
   * non-endorsement disclosure remain visible beside the Harness UX.
   * The test covers every effect through the real Browser -> BFF -> Anthropic SDK
   * -> fixture Managed API path; the fixture owns no production code path.
   */
  await request.post("http://127.0.0.1:4283/__fixture/reset");
  await page.goto("/");
  const referenceCase = page.getByRole("link", { name: "Read the independent DeepSeek Harness reference reimplementation" });
  await expect(referenceCase).toHaveAttribute("href", "https://awakenworks.com/cases/deepseek-harness");
  await expect(referenceCase).toContainText("Build a Harness-class workbench without rebuilding the Agent runtime");
  await expect(referenceCase).toContainText("No partnership or endorsement is implied");
  await expect(page.getByRole("heading", { name: "Modernize the agent runtime" })).toBeVisible();
  await expect(page.getByText("authoritative provider boundary")).toBeVisible();
  await expect(page.getByTestId("plan-panel")).toContainText("Inspect, update, and verify");
  await expect(page.getByText("glob", { exact: true })).toBeVisible();
  await expect(page.getByText("grep", { exact: true })).toBeVisible();
  await expect(page.getByTestId("approval-card")).toBeVisible();
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: /provider-verification\.md/ }).click();
  await expect((await download).suggestedFilename()).toBe("provider-verification.md");

  await page.getByTestId("trajectory-tab").click();
  await expect(page.getByTestId("trajectory")).toContainText("builtin");
  await expect(page.getByTestId("trajectory")).toContainText("grep");

  await page.getByTestId("chat-tab").click();
  await page.getByRole("button", { name: "Allow once" }).click();
  await expect(page.getByText("focused change is applied")).toBeVisible();
  await expect(page.getByText("Idle", { exact: true }).first()).toBeVisible();

  await page.getByTestId("new-session").click();
  await page.getByTestId("session-title").fill("Review the cloud workspace");
  await page.getByTestId("session-prompt").fill("Review the repository and report the critical execution path.");
  await page.getByTestId("preset-code").click();
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByRole("heading", { name: "Review the cloud workspace" })).toBeVisible();
  await expect(page.getByText("Code mode completed through the official Awaken Managed toolset.")).toBeVisible();
  await expect(page.getByText("Call ID", { exact: true })).toHaveCount(0);
  await expect(page.getByText("No delegated threads")).toBeVisible();
});

test("all four published Harness presets execute their bounded contracts", async ({ page, request }) => {
  /**
   * Cause/effect decision table:
   * S Standard Agent + Execute -> published coordinator/Skill completion;
   * C Code Agent + Execute -> official grep call and coding completion;
   * M Minimal Agent + Execute -> official read call with no expanded capability;
   * A Creator Agent + Execute -> pending proposal, explicit approval, one new
   * official Agent, and correlated result. Each rule starts at atomic admission
   * and verifies its distinct terminal outcome through Browser -> BFF -> SDK.
   */
  await request.post("http://127.0.0.1:4283/__fixture/reset");
  await page.goto("/");

  const create = async (preset: "standard" | "code" | "minimal" | "creator", title: string) => {
    await page.getByTestId("new-session").click();
    await page.getByTestId(`preset-${preset}`).click();
    await page.getByTestId("session-title").fill(title);
    await page.getByTestId("session-prompt").fill(`Verify the bounded ${preset} contract.`);
    await page.getByTestId("create-session-submit").click();
    await expect(page.getByRole("heading", { name: title, exact: true })).toBeVisible();
  };

  await create("standard", "Standard contract verification");
  await expect(page.getByTestId("conversation")).toContainText("Standard mode completed through its published skills and coordinator composition.");

  await create("code", "Code contract verification");
  await expect(page.getByTestId("conversation")).toContainText("grep");
  await expect(page.getByTestId("conversation")).toContainText("Code mode completed through the official Awaken Managed toolset.");

  await create("minimal", "Minimal contract verification");
  await expect(page.getByTestId("conversation")).toContainText("read");
  await expect(page.getByTestId("conversation")).toContainText("Minimal mode completed without web, skills, or subagents.");

  await create("creator", "Creator contract verification");
  await expect(page.getByTestId("agent-proposal-review")).toContainText("Creator contract verification Agent");
  await page.getByRole("button", { name: "Publish Agent" }).click();
  await expect(page.getByTestId("conversation")).toContainText("correlated Agent proposal decision was recorded");
  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("button", { name: "Agent presets" }).click();
  await expect(page.locator(".composition").filter({ hasText: "Creator contract verification Agent" })).toBeVisible();
});

test("DeepSeek UI management and discovery surfaces stay on canonical owners", async ({ page, request }) => {
  /**
   * Cause/effect decision table:
   * R1 committed running work + child Threads -> Jobs/Subagents menus project it;
   * R2 a goal/title patch -> one SDK Session update and refreshed durable chrome;
   * R3 approval settled -> ordinary composer exposes slash and @ discovery;
   * R4 Settings tabs -> connection, Agent model, plugin owner and preset
   * inventories remain separate; copying/archiving uses the SDK Agent owner;
   * R5 collapse controls -> layout changes without altering Session selection.
   */
  await request.post("http://127.0.0.1:4283/__fixture/reset");
  await page.goto("/");
  await page.getByRole("button", { name: "Background jobs" }).click();
  await expect(page.getByRole("dialog", { name: "Background jobs" })).toContainText("E2E verifier");
  await page.getByRole("button", { name: "Background jobs" }).click();
  await page.getByRole("button", { name: "Subagents" }).click();
  await expect(page.getByRole("dialog", { name: "Subagents" })).toContainText("Provider researcher");
  await page.getByRole("button", { name: "Subagents" }).click();
  await page.getByTestId("goal-bar").click();
  await page.getByTestId("goal-editor").getByRole("textbox").fill("Ship one canonical cloud Harness");
  await page.getByTestId("goal-editor").getByRole("button", { name: "Save" }).click();
  await expect(page.getByTestId("goal-bar")).toContainText("Ship one canonical cloud Harness");

  await page.getByRole("button", { name: "Allow once" }).click();
  await page.getByTestId("composer").fill("/");
  await expect(page.getByTestId("slash-menu")).toContainText("/plan");
  await page.getByTestId("composer").fill("@");
  await expect(page.getByTestId("mention-menu")).toContainText("@skill:testing");

  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("button", { name: "Models" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText("deepseek/deepseek-chat");
  await page.getByRole("button", { name: "Plugins" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText("Managed Agents bridge");
  await page.getByRole("button", { name: "Agent presets" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText("Creator");
  page.once("dialog", (dialog) => dialog.accept("E2E preset copy"));
  await page.locator(".management-card").first().getByRole("button", { name: "Copy" }).click();
  const copiedComposition = page.locator(".composition").filter({ hasText: "E2E preset copy" });
  await expect(copiedComposition).toBeVisible();
  await copiedComposition.locator("summary").click();
  await expect(copiedComposition).toContainText("harness_copied_from");
  page.once("dialog", (dialog) => dialog.accept());
  await copiedComposition.getByRole("button", { name: "Archive copy" }).click();
  await expect(copiedComposition).toHaveCount(0);
  await page.getByRole("button", { name: "Cancel" }).click();
  await page.getByRole("button", { name: "Hide details" }).click();
  await expect(page.getByRole("button", { name: "Show details" })).toBeVisible();
  await page.getByRole("button", { name: "Collapse sidebar" }).click();
  await expect(page.getByRole("button", { name: "Show sidebar" })).toBeVisible();
});

test("plan review and custom user-question takeovers commit through Managed events", async ({ page, request }) => {
  /**
   * Cause/effect decision table:
   * R1 create(mode=plan) + committed set_plan -> plan-review takeover;
   * R2 approve -> a correlated custom-tool result resumes execution;
   * R3 running custom question + recommended option -> user.custom_tool_result;
   * R4 the correlated result -> question leaves the takeover chain and the Agent
   * response appears. These rules cover every takeover terminal outcome used here.
   */
  await request.post("http://127.0.0.1:4283/__fixture/reset");
  await page.goto("/");
  await page.getByTestId("new-session").click();
  await page.getByTestId("session-title").fill("Plan cloud change");
  await page.getByTestId("session-prompt").fill("Plan the bounded cloud change.");
  await page.getByTestId("create-session-dialog").locator("label").filter({ hasText: /^Mode/ }).locator("select").selectOption("plan");
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByTestId("plan-review")).toContainText("Review and execute the cloud change");
  await page.getByRole("button", { name: "Approve plan" }).click();
  await expect(page.getByText("correlated plan decision was recorded")).toBeVisible();

  await page.getByTestId("new-session").click();
  await page.getByTestId("session-title").fill("Question rollout scope");
  await page.getByTestId("session-prompt").fill("Ask me which rollout scope to use.");
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByTestId("question-composer")).toContainText("Which rollout scope");
  await page.getByRole("button", { name: /Canary/ }).click();
  await expect(page.getByText("recorded the rollout answer")).toBeVisible();
});

test("native catalogs, permission, fork, thread transcript and trajectory controls remain cloud-backed", async ({ page, request }) => {
  /**
   * Cause/effect decision table:
   * R1 SDK model/skill catalogs -> Settings renders their real identifiers;
   * R2 acknowledged Full permission -> the Session Agent tool policy is updated;
   * R3 selected child Thread -> its official event list projects a transcript;
   * R4 trajectory query/type/zoom -> only matching committed records remain;
   * R5 exact message branch -> a new Session is created with source/boundary metadata;
   * R6 assistant rating -> one Session metadata value survives a refresh.
   * The effects share the official Session/Thread/Model/Skill owners and exercise
   * every new BFF route without a browser-side domain database.
   */
  await request.post("http://127.0.0.1:4283/__fixture/reset");
  await page.goto("/");

  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("button", { name: "Models" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText("DeepSeek Chat");
  await page.getByRole("button", { name: "Plugins" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText("Frontend design");
  await page.getByRole("button", { name: "Cancel" }).click();

  await page.getByRole("button", { name: "Permission mode" }).click();
  page.once("dialog", (dialog) => dialog.accept());
  await page.getByRole("dialog", { name: "Permission mode" }).getByRole("button", { name: /Full access/ }).click();
  await expect(page.getByRole("button", { name: "Permission mode" })).toContainText("Full");

  await page.getByRole("button", { name: /Provider researcher/ }).click();
  await expect(page.getByText("I inspected the assigned boundary")).toBeVisible();
  await expect(page.getByText(/1540 tokens/)).toBeVisible();
  await page.getByRole("button", { name: "Catalog" }).click();

  await page.getByTestId("trajectory-tab").click();
  await page.getByLabel("Search trajectory").fill("ProviderConnection");
  await page.getByLabel("Trajectory record type").selectOption("tools");
  await expect(page.getByTestId("trajectory")).toContainText("grep");
  await expect(page.getByTestId("trajectory")).not.toContainText("web_search");
  await page.getByLabel("Zoom").fill("180");

  await page.getByTestId("chat-tab").click();
  await page.getByRole("button", { name: "Helpful" }).first().click();
  await page.reload();
  await expect(page.getByRole("button", { name: "Helpful" }).first()).toHaveClass(/selected/);
  await page.getByRole("button", { name: "Branch" }).first().click();
  await expect(page.getByRole("heading", { name: /branch/ })).toBeVisible();
  await expect(page.getByText("Continue from this committed Session branch")).toBeVisible();
});

test("queue, image history, multi-question answers, workspace preferences and resizing behave end to end", async ({ page, request }) => {
  /**
   * Cause/effect decision table:
   * R1 running Session + text steering -> bounded Session-metadata queue;
   * R2 strict dispatch -> canonical user event and queue deletion;
   * R3 idle Session + PNG attachment -> native image block and projected thumbnail;
   * R4 two structured questions + single/multiple selections -> one correlated
   * custom-tool result only after both questions are complete;
   * R5 workspace add/rename/order plus theme/input preferences -> the connection
   * registry persists only presentation/identity state;
   * R6 pointer drag on a column boundary -> layout width changes without changing
   * the selected durable Session.
   */
  await request.post("http://127.0.0.1:4283/__fixture/reset");
  await page.goto("/");

  await page.getByTestId("new-session").click();
  await page.getByTestId("session-title").fill("Queue steering demo");
  await page.getByTestId("session-prompt").fill("Run a long verification.");
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByRole("heading", { name: "Queue steering demo" })).toBeVisible();
  await page.getByTestId("composer").fill("Apply the queued correction");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(page.getByTestId("message-queue")).toContainText("Apply the queued correction");
  page.once("dialog", (dialog) => dialog.accept("Apply the edited correction"));
  await page.getByTestId("message-queue").getByRole("button", { name: "Edit" }).click();
  await expect(page.getByTestId("message-queue")).toContainText("Apply the edited correction");
  await page.getByTestId("message-queue").getByRole("button", { name: "Delete" }).click();
  await expect(page.getByTestId("message-queue")).toHaveCount(0);
  await page.getByTestId("composer").fill("Apply the strict correction");
  await page.getByRole("button", { name: "Send message" }).click();
  await page.getByRole("button", { name: "Strict steer" }).click();
  await expect(page.getByTestId("message-queue")).toHaveCount(0);
  await expect(page.getByText("[STRICT STEER]")).toBeVisible();

  await page.getByTestId("new-session").click();
  await page.getByTestId("session-title").fill("Image inspection");
  await page.getByTestId("session-prompt").fill("Wait for an image.");
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByRole("heading", { name: "Image inspection" })).toBeVisible();
  await page.locator('input[type="file"]').setInputFiles({ name: "pixel.png", mimeType: "image/png", buffer: Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB", "base64") });
  await page.getByTestId("composer").fill("Inspect this pixel");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(page.getByRole("img", { name: "Attached image 1" })).toBeVisible();

  await page.getByTestId("new-session").click();
  await page.getByTestId("session-title").fill("Multi question rollout");
  await page.getByTestId("session-prompt").fill("Ask all rollout questions.");
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByRole("heading", { name: "Multi question rollout" })).toBeVisible();
  await expect(page.getByTestId("question-composer")).toContainText("QUESTION 1 OF 2");
  await page.getByTestId("question-composer").getByRole("button", { name: "Skip", exact: true }).click();
  await expect(page.getByTestId("question-composer")).toContainText("QUESTION 2 OF 2");
  await page.getByTestId("question-composer").getByRole("button", { name: "Back", exact: true }).click();
  await page.getByRole("button", { name: /Canary/ }).click();
  await page.getByRole("button", { name: "Unit" }).click();
  await page.getByRole("button", { name: "E2E" }).click();
  await page.getByRole("button", { name: "Continue" }).click();
  await expect(page.getByText("recorded the rollout answer")).toBeVisible();

  const shell = page.locator(".app-shell");
  const before = await shell.evaluate((element) => getComputedStyle(element).getPropertyValue("--sidebar-width"));
  const grip = page.locator(".sidebar-resizer");
  const box = await grip.boundingBox();
  if (!box) throw new Error("Sidebar resize handle unavailable");
  await page.mouse.move(box.x + 1, box.y + 20);
  await page.mouse.down();
  await page.mouse.move(330, box.y + 20);
  await page.mouse.up();
  const after = await shell.evaluate((element) => getComputedStyle(element).getPropertyValue("--sidebar-width"));
  expect(after).not.toBe(before);

  await page.getByRole("button", { name: "Settings" }).click();
  page.once("dialog", (dialog) => dialog.accept("workspace-primary"));
  await page.getByRole("button", { name: "Add workspace connection" }).click();
  page.once("dialog", (dialog) => dialog.accept("workspace-secondary"));
  await page.getByRole("button", { name: "Add workspace connection" }).click();
  const secondary = page.locator(".workspace-roster .settings-card").last();
  page.once("dialog", (dialog) => dialog.accept("Secondary cloud"));
  await secondary.getByRole("button", { name: "Rename" }).click();
  await secondary.getByRole("button", { name: /Move Secondary cloud up/ }).click();
  await expect(page.locator(".workspace-roster .settings-card").first()).toContainText("Secondary cloud");
  await page.locator(".workspace-roster .settings-card").filter({ hasText: "workspace-primary" }).getByRole("button", { name: "Delete" }).click();
  await page.getByLabel("Theme").selectOption("light");
  await page.getByLabel("Enter behavior").selectOption("newline");
  await page.getByLabel("Default permission").selectOption("full");
  page.once("dialog", (dialog) => dialog.accept());
  await page.getByRole("button", { name: "Save and reconnect" }).click();
  await expect(shell).toHaveClass(/theme-light/);
  await expect.poll(() => page.evaluate(() => JSON.parse(localStorage.getItem("harness.ui-preferences.v1") ?? "{}").enterBehavior)).toBe("newline");
  await page.getByTestId("composer").fill("Line one");
  await page.getByTestId("composer").press("Enter");
  await expect(page.getByTestId("composer")).toHaveValue("Line one\n");
  await page.getByTestId("composer").press("Control+Enter");
  await expect(page.getByText("Steering received and committed to this Session.")).toBeVisible();

  await page.getByTestId("new-session").click();
  await page.getByTestId("session-title").fill("Question cancellation");
  await page.getByTestId("session-prompt").fill("Ask once, then allow cancellation.");
  page.once("dialog", (dialog) => dialog.accept());
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByRole("button", { name: "Permission mode" })).toContainText("Full");
  await page.getByTestId("question-composer").getByRole("button", { name: "Cancel question", exact: true }).last().click();
  await expect(page.getByText("The question was cancelled")).toBeVisible();
});
