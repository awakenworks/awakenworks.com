import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { createServer } from "node:http";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import Anthropic from "@anthropic-ai/sdk";

const here = dirname(fileURLToPath(import.meta.url));
const repository = resolve(here, "..");
const awakenSource = resolve(process.env.AWAKEN_SOURCE_DIR ?? resolve(repository, "../awaken-1.0.0-dev"));
const awakenPort = Number(process.env.HARNESS_LIVE_AWAKEN_PORT ?? "4293");
const readinessPort = Number(process.env.HARNESS_LIVE_READY_PORT ?? "4294");
const deepseekKey = process.env.DEEPSEEK_API_KEY;
const managedBetas = ["managed-agents-2026-04-01"];
const skillsBetas = ["skills-2025-10-02"];
const skillMarker = "HARNESS-LIVE-SKILL-7F31";

if (!deepseekKey) throw new Error("DEEPSEEK_API_KEY is required for live acceptance");

const harnessModule = join(awakenSource, "e2e/harness.mjs");
const { deploymentEnv, spawnServer, stopServer, waitForPort } = await import(pathToFileURL(harnessModule).href);
const awakenCommit = execFileSync("git", ["-C", awakenSource, "rev-parse", "HEAD"], { encoding: "utf8" }).trim();
const deployment = mkdtempSync(join(tmpdir(), "deepseek-harness-live-"));
const environment = deploymentEnv(deployment, { identityMode: "no-login" });
const { server, baseUrl } = spawnServer("management-providers", awakenPort, environment);
let readiness;
let stopping = false;

async function json(method, path, body) {
  const response = await fetch(`${baseUrl}${path}`, {
    method,
    headers: body === undefined ? {} : { "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  const value = text ? JSON.parse(text) : null;
  assert.ok(response.ok, `${method} ${path}: ${response.status} ${text}`);
  return value;
}

async function collect(iterable) {
  const values = [];
  for await (const value of iterable) values.push(value);
  return values;
}

function toolset(enabled) {
  return {
    type: "agent_toolset_20260401",
    default_config: { enabled: false, permission_policy: { type: "always_ask" } },
    configs: enabled.map((name) => ({ name, enabled: true, permission_policy: { type: "always_ask" } })),
  };
}

async function provision() {
  await waitForPort(awakenPort, 180_000, server);
  const workspace = readFileSync(join(deployment, "platform-workspace-id"), "utf8").trim();
  const connection = await json("POST", "/v1/config/provider-connections", {
    idempotency_key: "deepseek-harness-live-provider",
    workspace_id: workspace,
    provider_id: "deepseek",
    display_name: "DeepSeek Harness Live",
    dialect: "open_ai_chat",
    base_url: "https://api.deepseek.com",
    timeout_secs: 120,
    secret: deepseekKey,
  });
  assert.ok(connection.sync.discovered > 0, "DeepSeek discovery returned no models");
  assert.ok(!JSON.stringify(connection).includes(deepseekKey), "provider response leaked its credential");

  const catalog = await json("GET", "/v1/config/catalog");
  const offerings = catalog.offerings.filter((offering) => (
    offering.provider_id === "deepseek" && (offering.status ?? "active") === "active"
  ));
  const offering = offerings.find((candidate) => candidate.model_id === "deepseek-v4-flash") ?? offerings[0];
  assert.ok(offering, "DeepSeek discovery produced no active offering");
  await json("PUT", "/v1/config/inference-profiles/deepseek-harness-live", {
    workspace_id: workspace,
    primary: {
      target: {
        model_id: offering.model_id,
        provider_id: offering.provider_id,
        protocol_endpoint_id: offering.protocol_endpoint_id,
      },
      credential_binding: { type: "exact", credential_source_id: connection.credential.id },
    },
    fallbacks: [],
    disabled_endpoint_ids: [],
  });

  await json("PUT", "/v1/config/agents/harness-live-model-bootstrap", {
    id: "harness-live-model-bootstrap",
    name: "Harness live model bootstrap",
    system: "Expose the published executable DeepSeek route to the Managed catalog.",
    max_steps: 2,
    model: { mode: "auto" },
    tools: [],
  });
  await json("POST", "/v1/config/agents/harness-live-model-bootstrap/publish");

  const client = new Anthropic({ apiKey: "awaken-live-local", baseURL: baseUrl });
  const models = await collect(client.beta.models.list({ betas: managedBetas, limit: 100 }));
  const model = models.find((candidate) => candidate.id.includes(offering.model_id))
    ?? models.find((candidate) => candidate.id.toLowerCase().includes("deepseek"));
  assert.ok(model, `Managed model catalog does not expose ${offering.model_id}; saw ${models.map((candidate) => candidate.id).join(", ") || "no models"}`);

  const skill = await client.beta.skills.create({
    display_title: "Harness live verification",
    files: [new File([
      `---\nname: harness-live-verification\ndescription: Proves live Skill delivery\n---\nWhen asked for the live Skill proof token, return exactly ${skillMarker}.`,
    ], "SKILL.md", { type: "text/markdown" })],
    betas: skillsBetas,
  });
  assert.ok(skill.latest_version, "live Skill has no published version");

  const rosterWorker = await client.beta.agents.create({
    name: "Harness Live Roster Worker",
    model: model.id,
    system: "You are a roster worker. Return concise, verifiable answers to delegated tasks.",
    metadata: { harness_live_fixture: "worker" },
    betas: managedBetas,
  });

  const core = ["bash", "read", "write", "edit", "glob", "grep"];
  const standard = await client.beta.agents.create({
    name: "Harness Live Standard",
    model: model.id,
    system: `You are the live Standard Harness Agent. Follow Harness launch directives exactly. The installed Skill contains the proof token ${skillMarker}. When explicitly asked to delegate, your first and only action must be the typed agent_run tool targeting roster Agent ${rosterWorker.id}; never call bash, read, glob, grep, or search the environment first, and report the worker answer only after agent_run returns. In Plan mode, mcp__harness__set_plan and review_plan are already provided model tools: call mcp__harness__set_plan directly as your first action, then call review_plan with the same plan_id and revision. Never search for those tools with bash or inspect the environment before the review decision.`,
    description: "Real DeepSeek Standard-mode acceptance Agent",
    metadata: { harness_preset: "standard", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset([...core, "web_fetch", "web_search"]), {
      type: "custom",
      name: "question",
      description: "Ask the user one structured question when explicitly requested.",
      input_schema: {
        type: "object",
        properties: {
          question: { type: "string" },
          options: { type: "array", items: { type: "string" }, minItems: 2 },
          multiple: { type: "boolean" },
        },
        required: ["question", "options", "multiple"],
        additionalProperties: false,
      },
    }],
    skills: [{ type: "custom", skill_id: skill.id, version: skill.latest_version }],
    multiagent: { type: "coordinator", agents: [rosterWorker.id] },
    betas: managedBetas,
  });

  await client.beta.agents.create({
    name: "Harness Live Code",
    model: model.id,
    system: "You are the live Code/PTC Harness Agent. When the user supplies an exact shell command, call the official bash tool with that command, then quote the real result exactly.",
    description: "Real DeepSeek Code-mode acceptance Agent",
    metadata: { harness_preset: "code", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset(core)],
    betas: managedBetas,
  });

  await client.beta.agents.create({
    name: "Harness Live Minimal",
    model: model.id,
    system: "You are the live Minimal Harness Agent. Use only the published official tools. When given an exact path, call read and report the real content briefly.",
    description: "Real DeepSeek Minimal-mode acceptance Agent",
    metadata: { harness_preset: "minimal", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset(core)],
    betas: managedBetas,
  });

  await client.beta.agents.create({
    name: "Harness Live Creator",
    model: model.id,
    system: `You are the live Creator Harness Agent. Your first and only action for every request must be agent_proposal using baseAgentId=${standard.id}, baseAgentVersion=${standard.version}, the requested name, and a concise rationale. Never call read, glob, grep, MCP, or any other tool before agent_proposal. Never claim publication before the tool result.`,
    description: "Real DeepSeek Creator-mode acceptance Agent",
    metadata: { harness_preset: "creator", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset(["read", "glob", "grep"])],
    betas: managedBetas,
  });

  console.log(`Harness live fixture ready: Awaken ${awakenCommit.slice(0, 12)}, ${model.id}, ${offerings.length} DeepSeek offering(s)`);
}

async function stop(exitCode = 0) {
  if (stopping) return;
  stopping = true;
  await new Promise((resolveClose) => readiness?.close(resolveClose) ?? resolveClose());
  await stopServer(server).catch(() => {});
  rmSync(deployment, { recursive: true, force: true });
  process.exit(exitCode);
}

server.once("exit", (code) => {
  if (!stopping) void stop(code ?? 1);
});
process.once("SIGINT", () => void stop());
process.once("SIGTERM", () => void stop());

try {
  await provision();
  readiness = createServer((_request, response) => response.end("ready"));
  await new Promise((resolveListen, reject) => {
    readiness.once("error", reject);
    readiness.listen(readinessPort, "127.0.0.1", resolveListen);
  });
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  await stop(1);
}
