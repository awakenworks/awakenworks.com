import { resolve } from "node:path";
import { expect, test, type Locator, type Page } from "@playwright/test";

const sourceVideo = resolve("test-results/deepseek-harness-awaken-demo.webm");

async function pause(page: Page, milliseconds = 650): Promise<void> {
  await page.waitForTimeout(milliseconds);
}

async function reveal(page: Page, locator: Locator): Promise<void> {
  await locator.evaluate((element) => element.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" }));
  await pause(page, 350);
}

async function smoothClick(page: Page, locator: Locator, settle = 650): Promise<void> {
  await expect(locator).toBeVisible();
  await reveal(page, locator);
  const box = await locator.boundingBox();
  if (!box) throw new Error("Walkthrough target has no visible bounds");
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 24 });
  await page.mouse.down();
  await page.waitForTimeout(90);
  await page.mouse.up();
  await pause(page, settle);
}

async function smoothFill(page: Page, locator: Locator, value: string): Promise<void> {
  await smoothClick(page, locator, 120);
  await page.keyboard.press("ControlOrMeta+A");
  await page.keyboard.type(value, { delay: 12 });
  await pause(page, 250);
}

async function chapter(page: Page, title: string, detail: string): Promise<void> {
  await page.evaluate(({ title, detail }) => {
    const overlay = document.querySelector<HTMLElement>("#walkthrough-chapter");
    if (!overlay) return;
    overlay.querySelector<HTMLElement>("strong")!.textContent = title;
    overlay.querySelector<HTMLElement>("span")!.textContent = detail;
    overlay.classList.add("visible");
  }, { title, detail });
  await pause(page, 1_350);
  await page.evaluate(() => document.querySelector("#walkthrough-chapter")?.classList.remove("visible"));
  await pause(page, 450);
}

async function createSession(
  page: Page,
  preset: "standard" | "code" | "minimal" | "creator",
  title: string,
  request: string,
  mode: "execute" | "plan" = "execute",
): Promise<void> {
  await smoothClick(page, page.getByTestId("new-session"), 450);
  await smoothClick(page, page.getByTestId(`preset-${preset}`), 350);
  await smoothFill(page, page.getByTestId("session-title"), title);
  await smoothFill(page, page.getByTestId("session-prompt"), request);
  if (mode === "plan") {
    const select = page.getByTestId("create-session-dialog").locator("label").filter({ hasText: /^Mode/ }).locator("select");
    await smoothClick(page, select, 150);
    await select.selectOption("plan");
    await pause(page, 350);
  }
  await smoothClick(page, page.getByTestId("create-session-submit"), 700);
  await expect(page.getByRole("heading", { name: title, exact: true })).toBeVisible();
}

test("record the complete smooth DeepSeek Harness Awaken walkthrough", async ({ page, request }) => {
  test.setTimeout(240_000);
  /**
   * Cause/effect walkthrough matrix:
   * O committed Session facts -> transcript, Plan, official tools, trajectory,
   *   approval, artifact, jobs and child transcript are visible;
   * M catalogs/settings/layout -> SDK-owned inventories and presentation controls;
   * S/C/N/A published Standard/Code/Minimal/Creator Agents -> four distinct
   *   bounded outcomes, with Creator requiring protected publication approval;
   * P Plan-first -> versioned Plan takeover and correlated approval;
   * Q/I/R custom questions, images and running steering -> canonical Session
   *   events and queue behavior. One page and one recording context cover every
   *   rule; smooth pointer/scroll helpers avoid cuts, reloads and visual jumps.
   */
  await request.post("http://127.0.0.1:4283/__fixture/reset");
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "Modernize the agent runtime" })).toBeVisible();
  await page.addStyleTag({ content: `
    html, body, .conversation, .details, .trajectory { scroll-behavior: smooth !important; }
    * { caret-color: transparent; }
    #walkthrough-chapter {
      position: fixed; inset: 0; z-index: 10000; display: grid; place-content: center;
      gap: 10px; padding: 36px; pointer-events: none; opacity: 0;
      background: radial-gradient(circle at center, rgba(10,18,30,.82), rgba(4,7,12,.28));
      backdrop-filter: blur(3px); transition: opacity 420ms ease;
      color: #f5f8ff; text-align: center; font-family: Inter, system-ui, sans-serif;
    }
    #walkthrough-chapter.visible { opacity: 1; }
    #walkthrough-chapter strong { font-size: 34px; letter-spacing: -.03em; }
    #walkthrough-chapter span { max-width: 760px; color: #aebbd0; font-size: 16px; line-height: 1.6; }
  ` });
  await page.evaluate(() => {
    const overlay = document.createElement("div");
    overlay.id = "walkthrough-chapter";
    overlay.innerHTML = "<strong></strong><span></span>";
    document.body.append(overlay);
  });

  await chapter(page, "DeepSeek Harness · Awaken Cloud", "One durable Managed Session authority, four published Agent modes, and no private execution extension.");

  await chapter(page, "Committed Session projection", "Chat, versioned Plan, official Managed tool calls and durable status all come from the same event log.");
  await reveal(page, page.getByTestId("plan-panel"));
  await pause(page, 800);

  await chapter(page, "Safe execution approval", "Sensitive tool calls pause on the official permission fact; approval resumes the same Worker and Session.");
  await smoothClick(page, page.getByRole("button", { name: "Allow once" }), 800);
  await expect(page.getByText("focused change is applied")).toBeVisible();
  const download = page.waitForEvent("download");
  await smoothClick(page, page.getByRole("button", { name: /provider-verification\.md/ }), 350);
  await download;

  await chapter(page, "Awaken-owned jobs and subagents", "Background activity and child transcripts are projected from durable Session Threads—never a browser worker registry.");
  await smoothClick(page, page.getByRole("button", { name: "Background jobs" }), 600);
  await expect(page.getByRole("dialog", { name: "Background jobs" })).toContainText("E2E verifier");
  await smoothClick(page, page.getByRole("button", { name: "Background jobs" }), 350);
  await smoothClick(page, page.getByRole("button", { name: /Provider researcher/ }), 650);
  await expect(page.getByText("I inspected the assigned boundary")).toBeVisible();
  await smoothClick(page, page.getByRole("button", { name: "Catalog" }), 350);

  await chapter(page, "Official Managed tool details", "Every tool card opens its committed input and result without introducing a second execution hierarchy.");
  await smoothClick(page, page.getByText("grep", { exact: true }), 550);
  await expect(page.getByText("ProviderConnection", { exact: true })).toBeVisible();

  await chapter(page, "Trajectory and inspection", "Built-in, MCP and custom calls remain flat, searchable and directly inspectable as committed Awaken facts.");
  await smoothClick(page, page.getByTestId("trajectory-tab"), 500);
  await smoothFill(page, page.getByLabel("Search trajectory"), "ProviderConnection");
  const kind = page.getByLabel("Trajectory record type");
  await kind.selectOption("tools");
  await pause(page, 550);
  await smoothClick(page, page.getByTestId("trajectory").getByText("grep", { exact: true }), 600);
  await page.getByLabel("Zoom").fill("175");
  await pause(page, 550);
  await smoothClick(page, page.getByTestId("chat-tab"), 500);

  await chapter(page, "Effective permission policy", "Safe and Full are derived from effective Session tools. Full changes policy only after explicit risk acknowledgement.");
  await smoothClick(page, page.getByRole("button", { name: "Permission mode" }), 350);
  page.once("dialog", (dialog) => dialog.accept());
  await smoothClick(page, page.getByRole("dialog", { name: "Permission mode" }).getByRole("button", { name: /Full access/ }), 650);
  await expect(page.getByRole("button", { name: "Permission mode" })).toContainText("Full");
  await smoothClick(page, page.getByRole("button", { name: "Permission mode" }), 350);

  await chapter(page, "Goals and discovery", "Durable goal metadata, slash commands and live Skill mentions stay in the existing Session and catalog boundaries.");
  await smoothClick(page, page.getByTestId("goal-bar"), 250);
  await smoothFill(page, page.getByTestId("goal-editor").getByRole("textbox"), "Ship one canonical Awaken Harness");
  await smoothClick(page, page.getByTestId("goal-editor").getByRole("button", { name: "Save" }), 450);
  await smoothFill(page, page.getByTestId("composer"), "/");
  await expect(page.getByTestId("slash-menu")).toBeVisible();
  await pause(page, 600);
  await smoothFill(page, page.getByTestId("composer"), "@");
  await expect(page.getByTestId("mention-menu")).toContainText("@skill:testing");
  await pause(page, 600);
  await page.getByTestId("composer").fill("");

  await chapter(page, "Live control-plane catalogs", "Models, Skills, plugins and published Agent compositions are read through the same-origin SDK BFF.");
  await smoothClick(page, page.getByRole("button", { name: "Settings" }), 400);
  await smoothClick(page, page.getByRole("button", { name: "Models" }), 650);
  await smoothClick(page, page.getByRole("button", { name: "Plugins" }), 650);
  await smoothClick(page, page.getByRole("button", { name: "Agent presets" }), 650);
  page.once("dialog", (dialog) => dialog.accept("Walkthrough Agent copy"));
  await smoothClick(page, page.locator(".management-card").first().getByRole("button", { name: "Copy" }), 650);
  const copied = page.locator(".composition").filter({ hasText: "Walkthrough Agent copy" });
  await expect(copied).toBeVisible();
  await smoothClick(page, copied.locator("summary"), 450);
  page.once("dialog", (dialog) => dialog.accept());
  await smoothClick(page, copied.getByRole("button", { name: "Archive copy" }), 550);
  await smoothClick(page, page.getByTestId("settings-dialog").getByRole("button", { name: "Cancel" }), 450);

  await chapter(page, "Standard mode", "Core Managed tools, published Skills and the coordinator roster support general repository work.");
  await createSession(page, "standard", "Standard mode walkthrough", "Inspect the project with the published Standard composition.");
  await expect(page.getByTestId("conversation")).toContainText("Standard mode completed");
  await smoothClick(page, page.getByRole("button", { name: "Helpful" }).first(), 350);

  await chapter(page, "Durable feedback and branching", "Message feedback persists on the Session, while Branch creates one independent Session at an exact committed event boundary.");
  await smoothClick(page, page.getByRole("button", { name: "Branch" }).last(), 700);
  await expect(page.getByRole("heading", { name: /Standard mode walkthrough — branch/ })).toBeVisible();
  await expect(page.getByTestId("conversation")).toContainText("Continue from this committed Session branch");

  await chapter(page, "Code / PTC mode", "Focused coding uses only official bash, read, write, edit, glob and grep calls—no parallel executor or event family.");
  await createSession(page, "code", "Code mode walkthrough", "Trace the authoritative implementation and verify it.");
  await expect(page.getByTestId("conversation")).toContainText("Code mode completed through the official Awaken Managed toolset.");
  await smoothClick(page, page.getByTestId("conversation").getByText("grep", { exact: true }), 500);

  await chapter(page, "Minimal mode", "The smallest bounded coding composition excludes web access, Skills and subagents.");
  await createSession(page, "minimal", "Minimal mode walkthrough", "Read the bounded project context without expanding capabilities.");
  await expect(page.getByTestId("conversation")).toContainText("Minimal mode completed without web, skills, or subagents.");

  await chapter(page, "Plan-first execution", "A versioned Plan commits first; the protected review endpoint validates the exact revision before execution resumes.");
  await createSession(page, "standard", "Plan mode walkthrough", "Plan and review the bounded cloud change before mutation.", "plan");
  await expect(page.getByTestId("plan-review")).toContainText("Review and execute the cloud change");
  await smoothClick(page, page.getByRole("button", { name: "Approve plan" }), 700);
  await expect(page.getByText("correlated plan decision was recorded")).toBeVisible();

  await chapter(page, "Creator mode", "A read-only Creator drafts one declarative proposal. Publication always requires explicit human approval.");
  await createSession(page, "creator", "Creator mode walkthrough", "Draft a reviewed Agent composition from the canonical Standard base.");
  await expect(page.getByTestId("agent-proposal-review")).toContainText("Creator mode walkthrough Agent");
  await smoothClick(page, page.getByRole("button", { name: "Publish Agent" }), 800);
  await expect(page.getByText("correlated Agent proposal decision was recorded")).toBeVisible();
  await smoothClick(page, page.getByRole("button", { name: "Settings" }), 400);
  await smoothClick(page, page.getByRole("button", { name: "Agent presets" }), 500);
  await expect(page.locator(".composition").filter({ hasText: "Creator mode walkthrough Agent" })).toBeVisible();
  await smoothClick(page, page.getByTestId("settings-dialog").getByRole("button", { name: "Cancel" }), 400);

  await chapter(page, "Structured user questions", "Single and multiple selections produce one correlated custom-tool result only after the response is complete.");
  await createSession(page, "standard", "Multi question walkthrough", "Ask for rollout scope and required checks.");
  await expect(page.getByTestId("question-composer")).toContainText("QUESTION 1 OF 2");
  await smoothClick(page, page.getByRole("button", { name: /Canary/ }), 450);
  await smoothClick(page, page.getByRole("button", { name: "Unit" }), 250);
  await smoothClick(page, page.getByRole("button", { name: "E2E" }), 250);
  await smoothClick(page, page.getByRole("button", { name: "Continue" }), 650);
  await expect(page.getByText("recorded the rollout answer")).toBeVisible();

  await chapter(page, "Native image history", "Browser attachment drafts become official Managed image blocks and reconstruct from the committed transcript.");
  await createSession(page, "standard", "Image walkthrough", "Inspect the attached image through the same Session.");
  await page.locator('input[type="file"]').setInputFiles({ name: "pixel.png", mimeType: "image/png", buffer: Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB", "base64") });
  await pause(page, 450);
  await smoothFill(page, page.getByTestId("composer"), "Inspect this image");
  await smoothClick(page, page.getByRole("button", { name: "Send message" }), 650);
  await expect(page.getByRole("img", { name: "Attached image 1" })).toBeVisible();

  await chapter(page, "Running-session steering", "Messages can wait in the bounded Session metadata queue, then become canonical user events through strict steering.");
  await createSession(page, "standard", "Queue steering walkthrough", "Run a long verification and accept bounded steering.");
  await smoothFill(page, page.getByTestId("composer"), "Apply the verified correction");
  await smoothClick(page, page.getByRole("button", { name: "Send message" }), 500);
  await expect(page.getByTestId("message-queue")).toContainText("Apply the verified correction");
  await smoothClick(page, page.getByRole("button", { name: "Strict steer" }), 650);
  await expect(page.getByText("[STRICT STEER]")).toBeVisible();

  await chapter(page, "Responsive workspace shell", "Sidebar and Details remain presentation-only controls; collapsing or resizing never changes the selected durable Session.");
  const sidebarGrip = page.locator(".sidebar-resizer");
  const sidebarBox = await sidebarGrip.boundingBox();
  if (!sidebarBox) throw new Error("Sidebar resize handle unavailable");
  await page.mouse.move(sidebarBox.x + 1, sidebarBox.y + 50, { steps: 18 });
  await page.mouse.down();
  await page.mouse.move(315, sidebarBox.y + 50, { steps: 36 });
  await page.mouse.up();
  await pause(page, 500);
  await smoothClick(page, page.getByRole("button", { name: "Hide details" }), 400);
  await smoothClick(page, page.getByRole("button", { name: "Show details" }), 400);
  await smoothClick(page, page.getByRole("button", { name: "Collapse sidebar" }), 400);
  await smoothClick(page, page.getByRole("button", { name: "Show sidebar" }), 500);

  await chapter(page, "One authority, complete Harness experience", "Standard · Code/PTC · Minimal · Creator · Execute · Plan · Safe · Full — all verified through the official SDK and committed Awaken Session facts.");
  await pause(page, 1_200);

  const video = page.video();
  await page.close();
  await video?.saveAs(sourceVideo);
});
