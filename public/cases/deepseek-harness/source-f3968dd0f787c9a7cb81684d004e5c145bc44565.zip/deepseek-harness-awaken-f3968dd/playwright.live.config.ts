import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e/live",
  outputDir: "test-results/live",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 300_000,
  expect: { timeout: 180_000 },
  reporter: [["list"], ["html", { outputFolder: "playwright-report-live", open: "never" }]],
  use: {
    baseURL: "http://127.0.0.1:4281",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  webServer: [
    {
      command: "node e2e/live-awaken-server.mjs",
      port: 4294,
      reuseExistingServer: false,
      timeout: 240_000,
    },
    {
      command: "pnpm --filter @harness/interaction-mcp dev",
      port: 4282,
      reuseExistingServer: false,
      timeout: 30_000,
    },
    {
      command: "HARNESS_AWAKEN_API_URL=http://127.0.0.1:4293 HARNESS_INTERACTION_MCP_URL=http://127.0.0.1:4282/mcp pnpm --filter @harness/api dev",
      port: 4280,
      reuseExistingServer: false,
      timeout: 30_000,
    },
    {
      command: "pnpm --filter @harness/web dev",
      port: 4281,
      reuseExistingServer: false,
      timeout: 30_000,
    },
  ],
  projects: [{
    name: "deepseek-live",
    use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } },
  }],
});
