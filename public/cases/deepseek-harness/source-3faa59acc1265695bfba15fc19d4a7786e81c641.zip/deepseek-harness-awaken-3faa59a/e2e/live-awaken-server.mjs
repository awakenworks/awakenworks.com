import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFileSync, statSync, unlinkSync } from "node:fs";
import Anthropic from "@anthropic-ai/sdk";
import { withWorkspace } from "../apps/api/dist/managed.js";

const baseUrl = process.env.HARNESS_LIVE_AWAKEN_BASE_URL;
const bootstrapFile = process.env.HARNESS_LIVE_BOOTSTRAP_FILE;
const keyFile = process.env.HARNESS_LIVE_DEEPSEEK_KEY_FILE;
const readinessPort = Number(process.env.HARNESS_LIVE_READY_PORT ?? "4294");
const managedBetas = ["managed-agents-2026-04-01"];
const skillsBetas = ["skills-2025-10-02"];
const skillMarker = "HARNESS-LIVE-SKILL-7F31";

assert.ok(baseUrl && bootstrapFile && keyFile, "Live acceptance requires the deployed base URL, bootstrap descriptor and one-time key file");
assert.ok(!process.env.DEEPSEEK_API_KEY, "Use the one-time key descriptor, not an ambient provider key");
const bootstrap = JSON.parse(readFileSync(bootstrapFile, "utf8"));
const workspace = bootstrap["platform-workspace-id"];
const token = bootstrap["admin-token"];
assert.ok(workspace && token, "Bootstrap descriptor lacks the exact Workspace or server credential");
assert.equal(statSync(keyFile).mode & 0o077, 0, "Provider input must be private to its owner");
const deepseekKey = readFileSync(keyFile, "utf8").trim();
unlinkSync(keyFile);
assert.ok(deepseekKey, "Provider credential descriptor is empty");
const deployedFetch = withWorkspace(fetch, workspace);
let readiness;
let stopping = false;

async function json(method, path, body) {
  const response = await deployedFetch(`${baseUrl}${path}`, {
    method,
    headers: { Authorization: `Bearer ${token}`, ...(body === undefined ? {} : { "content-type": "application/json" }) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  const safeText = text.replaceAll(deepseekKey, "[redacted]").replaceAll(token, "[redacted]");
  if (!response.ok) {
    const error = new Error(`${method} ${path}: ${response.status} ${safeText.slice(0, 2000)}`);
    error.status = response.status;
    throw error;
  }
  let value;
  try { value = text ? JSON.parse(text) : null; }
  catch { throw new Error(`${method} ${path}: ${response.status} returned invalid JSON: ${safeText.slice(0, 2000)}`); }
  return value;
}

async function collect(iterable) {
  const values = [];
  for await (const value of iterable) values.push(value);
  return values;
}

async function createLiveAgent(client, request) {
  const owned = (await collect(client.beta.agents.list({ betas: managedBetas, limit: 100 })))
    .filter((item) => item.name === request.name && item.metadata.harness_live_fixture);
  assert.ok(owned.length <= 1, `Multiple ${request.name} Agents exist`);
  if (!owned[0]) return client.beta.agents.create(request);
  const agent = await client.beta.agents.retrieve(owned[0].id, { betas: managedBetas });
  assert.equal(agent.model.id, request.model, "Retained live Agent model drifted");
  if (agent.system !== request.system) {
    // A fixture instruction change publishes through the one official Agent
    // owner. Existing Sessions retain their frozen prior version.
    await client.beta.agents.update(agent.id, request);
    return client.beta.agents.retrieve(agent.id, { betas: managedBetas });
  }
  return agent;
}

function toolset(enabled) {
  return {
    type: "agent_toolset_20260401",
    default_config: { enabled: false, permission_policy: { type: "always_ask" } },
    configs: enabled.map((name) => ({ name, enabled: true, permission_policy: { type: "always_ask" } })),
  };
}

async function provision() {
  const connection = await json("POST", "/v1/config/provider-connections", {
    idempotency_key: "deepseek-harness-live-provider",
    workspace_id: workspace,
    provider_id: "deepseek",
    display_name: "DeepSeek Harness Live",
    dialect: "open_ai_chat",
    base_url: "https://api.deepseek.com",
    timeout_secs: 120,
    secret: deepseekKey,
  });
  assert.ok(connection.sync.discovered > 0, "DeepSeek discovery returned no models");
  assert.ok(!JSON.stringify(connection).includes(deepseekKey), "provider response leaked its credential");

  const catalog = await json("GET", "/v1/config/catalog");
  const offerings = catalog.offerings.filter((offering) => (
    offering.provider_id === "deepseek" && (offering.status ?? "active") === "active"
  ));
  const offering = offerings.find((candidate) => candidate.model_id === "deepseek-v4-flash") ?? offerings[0];
  assert.ok(offering, "DeepSeek discovery produced no active offering");
  await json("PUT", "/v1/config/inference-profiles/deepseek-harness-live", {
    workspace_id: workspace,
    primary: {
      target: {
        model_id: offering.model_id,
        provider_id: offering.provider_id,
        protocol_endpoint_id: offering.protocol_endpoint_id,
      },
      credential_binding: { type: "exact", credential_source_id: connection.credential.id },
    },
    fallbacks: [],
    disabled_endpoint_ids: [],
  });

  await json("PUT", "/v1/config/agents/harness-live-model-bootstrap", {
    id: "harness-live-model-bootstrap",
    name: "Harness live model bootstrap",
    system: "Expose the published executable DeepSeek route to the Managed catalog.",
    max_steps: 2,
    model: { mode: "profile", profile_id: "deepseek-harness-live" },
    tools: [],
  });
  await json("POST", "/v1/config/agents/harness-live-model-bootstrap/publish");

  const client = new Anthropic({ apiKey: token, baseURL: baseUrl, fetch: deployedFetch });
  const models = await collect(client.beta.models.list({ betas: managedBetas, limit: 100 }));
  const discoveredModel = models.find((candidate) => candidate.id.includes(offering.model_id))
    ?? models.find((candidate) => candidate.id.toLowerCase().includes("deepseek"));
  assert.ok(discoveredModel, `Managed model catalog does not expose ${offering.model_id}`);
  const model = (await client.beta.agents.retrieve("harness-live-model-bootstrap", { betas: managedBetas })).model;

  const ownedSkills = (await collect(client.beta.skills.list({ betas: skillsBetas, limit: 100 })))
    .filter((item) => item.display_title === "Harness live verification");
  assert.ok(ownedSkills.length <= 1, "Multiple live verification Skills exist");
  const skill = ownedSkills[0] ?? await client.beta.skills.create({
    display_title: "Harness live verification",
    files: [new File([
      `---\nname: harness-live-verification\ndescription: Proves live Skill delivery\n---\nWhen asked for the live Skill proof token, return exactly ${skillMarker}.`,
    ], "SKILL.md", { type: "text/markdown" })],
    betas: skillsBetas,
  });
  assert.ok(skill.latest_version, "live Skill has no published version");

  // Environment rule: an independent live scenario owns one named Environment
  // and an exact on-tool-use policy through Awaken's existing APIs. Every
  // browser Session explicitly selects this Environment, never the first
  // unrelated environment in the deployed Workspace catalog.
  const ownedEnvironments = (await collect(client.beta.environments.list({ betas: managedBetas, limit: 100 })))
    .filter((item) => item.name === "Harness Live Kubernetes" && item.metadata.harness_live_fixture === "true");
  assert.ok(ownedEnvironments.length <= 1, "Multiple live Kubernetes Environments exist");
  const environment = ownedEnvironments[0] ?? await client.beta.environments.create({ name: "Harness Live Kubernetes",
    config: { type: "self_hosted" }, metadata: { harness_live_fixture: "true" }, betas: managedBetas });
  // P1 exact retained policy -> reuse; P2 absent -> create once; P3 any other
  // read/write failure -> stop. A failed setup can be retried without creating
  // another Skill, Environment, policy or published Agent.
  const policy = await json("GET", "/v1/awaken/sandbox-execution-policies/harness-live-kubernetes/versions/1")
    .catch((error) => {
      if (error.status !== 404) throw error;
      return json("POST", "/v1/awaken/sandbox-execution-policies", { id: "harness-live-kubernetes",
        config: {}, provisioning: "on_tool_use", disabled: false });
    });
  assert.equal(policy.provisioning, "on_tool_use");
  assert.equal(policy.disabled, false);
  await json("POST", `/v1/awaken/environments/${environment.id}/sandbox-execution-policy`, { policy_id: policy.id, version: policy.version });

  const rosterWorker = await createLiveAgent(client, {
    name: "Harness Live Roster Worker",
    model: model.id,
    system: "You are a roster worker. Return concise, verifiable answers to delegated tasks.",
    metadata: { harness_live_fixture: "worker" },
    betas: managedBetas,
  });

  const core = ["bash", "read", "write", "edit", "glob", "grep"];
  const standard = await createLiveAgent(client, {
    name: "Harness Live Standard",
    model: model.id,
    system: `You are the live Standard Harness Agent. Follow Harness launch directives exactly. The installed verification Skill defines a proof token; consult that Skill when requested. When explicitly asked to delegate, your first and only action must be the typed agent_run tool targeting roster Agent ${rosterWorker.id}; never call bash, read, glob, grep, or search the environment first, and report the worker answer only after agent_run returns. In Plan mode, mcp__harness__set_plan and review_plan are already provided model tools: call mcp__harness__set_plan directly as your first action, then call review_plan with the same plan_id and revision. Never search for those tools with bash or inspect the environment before the review decision.`,
    description: "Real DeepSeek Standard-mode acceptance Agent",
    metadata: { harness_preset: "standard", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset([...core, "web_fetch", "web_search"]), {
      type: "custom",
      name: "question",
      description: "Ask the user one structured question when explicitly requested.",
      input_schema: {
        type: "object",
        properties: {
          question: { type: "string" },
          options: { type: "array", items: { type: "string" }, minItems: 2 },
          multiple: { type: "boolean" },
        },
        required: ["question", "options", "multiple"],
        additionalProperties: false,
      },
    }],
    skills: [{ type: "custom", skill_id: skill.id, version: skill.latest_version }],
    multiagent: { type: "coordinator", agents: [rosterWorker.id] },
    betas: managedBetas,
  });

  await createLiveAgent(client, {
    name: "Harness Live Code",
    model: model.id,
    system: "You are the live Code/PTC Harness Agent. When the user supplies an exact shell command, call the official bash tool with that command, then quote the real result exactly.",
    description: "Real DeepSeek Code-mode acceptance Agent",
    metadata: { harness_preset: "code", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset(core)],
    betas: managedBetas,
  });

  await createLiveAgent(client, {
    name: "Harness Live Minimal",
    model: model.id,
    system: "You are the live Minimal Harness Agent. Use only the published official tools. When given an exact path, call read and report the real content briefly.",
    description: "Real DeepSeek Minimal-mode acceptance Agent",
    metadata: { harness_preset: "minimal", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset(core)],
    betas: managedBetas,
  });

  await createLiveAgent(client, {
    name: "Harness Live Creator",
    model: model.id,
    system: `You are the live Creator Harness Agent. Your first and only action for every request must be agent_proposal using baseAgentId=${standard.id}, baseAgentVersion=${standard.version}, the requested name, and a concise rationale. Never call read, glob, grep, MCP, or any other tool before agent_proposal. Never claim publication before the tool result.`,
    description: "Real DeepSeek Creator-mode acceptance Agent",
    metadata: { harness_preset: "creator", harness_contract: "v1", harness_live_fixture: "true" },
    tools: [toolset(["read", "glob", "grep"])],
    betas: managedBetas,
  });

  console.log(`Harness live fixture ready: deployed ${baseUrl}, Workspace ${workspace}, ${model.id}, ${offerings.length} DeepSeek offering(s)`);
}

async function stop(exitCode = 0) {
  if (stopping) return;
  stopping = true;
  await new Promise((resolveClose) => readiness?.close(resolveClose) ?? resolveClose());
  process.exit(exitCode);
}

process.once("SIGINT", () => void stop());
process.once("SIGTERM", () => void stop());

try {
  await provision();
  readiness = createServer((_request, response) => response.end("ready"));
  await new Promise((resolveListen, reject) => {
    readiness.once("error", reject);
    readiness.listen(readinessPort, "127.0.0.1", resolveListen);
  });
} catch (error) {
  console.error((error instanceof Error ? error.stack ?? error.message : String(error)).replaceAll(deepseekKey, "[redacted]").replaceAll(token, "[redacted]"));
  await stop(1);
}
