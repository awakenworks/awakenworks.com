import express from "express";

type EventFact = Record<string, unknown> & { id: string; type: string };

const now = "2026-08-15T08:30:00.000Z";
function managedToolset(enabled: string[], ask = true) {
  return {
    type: "agent_toolset_20260401",
    default_config: { enabled: false, permission_policy: { type: ask ? "always_ask" : "always_allow" } },
    configs: enabled.map((name) => ({ name, enabled: true, permission_policy: { type: ask ? "always_ask" : "always_allow" } })),
  };
}

function publishedAgent(preset: "standard" | "code" | "minimal" | "creator", values: Partial<Record<string, unknown>> = {}) {
  return {
    id: `agent_deepseek_${preset}`,
    type: "agent",
    archived_at: null,
    name: `DeepSeek ${preset[0]?.toUpperCase()}${preset.slice(1)} Agent`,
    description: `A published ${preset} Agent backed by DeepSeek.`,
    version: 7,
    model: "deepseek/deepseek-chat",
    system: `You are the authoritative ${preset} Harness Agent.`,
    mcp_servers: [],
    tools: [managedToolset(preset === "creator" ? ["read", "glob", "grep"] : ["bash", "read", "write", "edit", "glob", "grep", ...(preset === "minimal" ? [] : ["web_fetch", "web_search"])])],
    skills: preset === "standard" || preset === "code" ? [{ type: "custom", skill_id: "skill_testing", version: "1" }] : [],
    multiagent: preset === "standard" ? { type: "coordinator", agents: [{ type: "self" }] } : null,
    metadata: { harness_preset: preset, harness_contract: "v1" },
    created_at: now,
    updated_at: now,
    ...values,
  };
}

const agents = [
  publishedAgent("standard"),
  publishedAgent("code"),
  publishedAgent("minimal"),
  publishedAgent("creator"),
];
const standardAgent = agents[0]!;
const environment = {
  id: "env_cloud_workspace",
  type: "environment",
  name: "Cloud repository sandbox",
  description: "Ephemeral isolated coding workspace",
  metadata: {},
  created_at: now,
  updated_at: now,
};
const copiedAgents: Array<Record<string, unknown> & { id: string; archived_at: string | null }> = [];

const sessions = new Map<string, Record<string, unknown>>();
const events = new Map<string, EventFact[]>();

function session(id: string, title: string, preset = "code", status = "running", mode = "execute", selectedAgent = agents.find((candidate) => candidate.metadata.harness_preset === preset) ?? standardAgent) {
  return {
    id,
    type: "session",
    title,
    status,
    agent: { ...selectedAgent, type: "agent" },
    environment_id: environment.id,
    metadata: { application: "deepseek-harness-awaken", harness_contract: "v1", harness_preset: preset, harness_mode: mode },
    archived_at: null,
    budget: null,
    outcome_evaluations: [],
    resources: [],
    stats: { duration_seconds: 70, active_seconds: 41 },
    usage: { input_tokens: 4096, output_tokens: 1024, cache_read_input_tokens: 512 },
    vault_ids: [],
    created_at: now,
    updated_at: now,
  };
}

const demoId = "sesn_cloud_demo";
sessions.set(demoId, session(demoId, "Modernize the agent runtime"));
events.set(demoId, [
  { id: "evt_01", type: "session.status_running", processed_at: now },
  { id: "evt_02", type: "user.message", processed_at: now, content: [{ type: "text", text: "Inspect the runtime architecture, update the provider adapter, and verify the affected tests." }] },
  { id: "evt_03", type: "agent.message", processed_at: now, content: [{ type: "text", text: "I’ll trace the existing execution path first, then make the smallest change through the authoritative provider boundary." }] },
  { id: "evt_think", type: "agent.thinking", processed_at: now },
  { id: "evt_compact", type: "agent.thread_context_compacted", processed_at: now },
  { id: "evt_04", type: "agent.mcp_tool_use", processed_at: now, name: "mcp__harness__set_plan", mcp_server_name: "harness", input: { plan_id: "provider-path", revision: 1, summary: "Inspect, update, and verify the provider path", steps: [
    { id: "inspect", title: "Trace the existing provider and Session path", status: "completed", detail: "Located the canonical DeepSeek route and worker binding." },
    { id: "change", title: "Update the bounded provider adapter", status: "in_progress", detail: "Keeping Session and credential ownership unchanged." },
    { id: "verify", title: "Run focused and browser E2E tests", status: "pending" },
  ] } },
  { id: "evt_05", type: "agent.mcp_tool_result", processed_at: now, mcp_tool_use_id: "evt_04", content: [{ type: "text", text: "Plan published with 3 steps." }], is_error: false },
  { id: "evt_06", type: "agent.tool_use", processed_at: now, name: "glob", input: { pattern: "**/*deepseek*" } },
  { id: "evt_07", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_06", content: [{ type: "text", text: "e2e/provider_connection_deepseek_real_e2e.mjs" }], is_error: false },
  { id: "evt_09", type: "agent.tool_use", processed_at: now, name: "grep", input: { pattern: "ProviderConnection", path: "crates" } },
  { id: "evt_10", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_09", content: [{ type: "text", text: "12 matches across 4 files" }], is_error: false },
  { id: "evt_12", type: "agent.message", processed_at: now, content: [{ type: "text", text: "The model route already freezes the provider, backend, and credential references at Session admission. I found one focused adapter change and am ready to apply it." }] },
  { id: "evt_read", type: "agent.tool_use", processed_at: now, name: "read", input: { path: "crates/control/provider.rs", offset: 1, limit: 80 } },
  { id: "evt_read_result", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_read", content: [{ type: "text", text: "pub struct ProviderConnection { /* authoritative route */ }" }], is_error: false },
  { id: "evt_shell", type: "agent.tool_use", processed_at: now, name: "bash", input: { command: "pnpm test --filter provider" } },
  { id: "evt_shell_result", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_shell", content: [{ type: "text", text: "12 tests passed" }], is_error: false },
  { id: "evt_web", type: "agent.tool_use", processed_at: now, name: "web_search", input: { query: "Anthropic Managed Agents Sessions SDK" } },
  { id: "evt_web_result", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_web", content: [{ type: "text", text: "Official SDK reference verified" }], is_error: false },
  { id: "evt_skill", type: "agent.tool_use", processed_at: now, name: "skill", input: { name: "testing" } },
  { id: "evt_skill_result", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_skill", content: [{ type: "text", text: "Testing workflow loaded" }], is_error: false },
  { id: "evt_question", type: "agent.tool_use", processed_at: now, name: "question", input: { question: "Choose rollout scope", options: ["Canary (Recommended)", "All workspaces"], multiple: false } },
  { id: "evt_question_result", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_question", content: [{ type: "text", text: "Canary" }], is_error: false },
  { id: "evt_13", type: "agent.tool_use", processed_at: now, name: "edit", input: { path: "crates/control/provider.rs", old: "legacy_route", new: "resolved_route" }, evaluated_permission: "ask" },
]);

function page(data: unknown[]) {
  return { data, has_more: false, first_id: (data[0] as { id?: string } | undefined)?.id ?? null, last_id: (data.at(-1) as { id?: string } | undefined)?.id ?? null };
}

function scopePath(request: express.Request): string {
  return request.path.replace(/^\/v1\/workspaces\/[^/]+/, "/v1");
}

function appendAfterApproval(id: string) {
  const facts = events.get(id) ?? [];
  if (facts.some((fact) => fact.id === "evt_20")) return;
  facts.push(
    { id: "evt_14", type: "user.tool_confirmation", processed_at: now, tool_use_id: "evt_13", result: "allow" },
    { id: "evt_15", type: "agent.tool_result", processed_at: now, tool_use_id: "evt_13", content: [{ type: "text", text: "Applied the provider adapter change." }], is_error: false },
    { id: "evt_16", type: "agent.message", processed_at: now, content: [{ type: "text", text: "The focused change is applied. Provider contract, event projection, and E2E verification all pass without introducing a second execution path." }] },
    { id: "evt_18", type: "agent.mcp_tool_use", processed_at: now, name: "mcp__harness__publish_result", mcp_server_name: "harness", input: { summary: "Provider route updated and verified", artifacts: [{ path: "provider-verification.md", description: "Focused verification report" }] } },
    { id: "evt_19", type: "agent.mcp_tool_result", processed_at: now, mcp_tool_use_id: "evt_18", content: [{ type: "text", text: "Result published." }], is_error: false },
    { id: "evt_20", type: "session.status_idle", processed_at: now },
  );
  const current = sessions.get(id);
  if (current) current.status = "idle";
}

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use((request, _response, next) => {
  const beta = request.header("anthropic-beta") ?? "";
  if (!request.path.startsWith("/__fixture/") && !beta.includes("managed-agents-2026-04-01") && !beta.includes("skills-2025-10-02")) {
    console.error("Managed beta header missing", request.path);
  }
  next();
});

app.post("/__fixture/reset", (_request, response) => {
  copiedAgents.length = 0;
  for (const id of [...sessions.keys()]) {
    if (id !== demoId) {
      sessions.delete(id);
      events.delete(id);
    }
  }
  sessions.set(demoId, session(demoId, "Modernize the agent runtime"));
  events.set(demoId, (events.get(demoId) ?? []).filter((fact) => {
    const sequence = Number(fact.id.replace("evt_", ""));
    return !Number.isFinite(sequence) || sequence <= 13;
  }));
  response.json({ reset: true });
});

app.get("*path", (request, response, next) => {
  const path = scopePath(request);
  if (path === "/v1/agents") return response.json(page([...agents, ...copiedAgents].filter((item) => item.archived_at === null)));
  if (path === "/v1/environments") return response.json(page([environment]));
  if (path === "/v1/models") return response.json(page([{ id: "deepseek/deepseek-chat", type: "model", display_name: "DeepSeek Chat", created_at: now, max_input_tokens: 128000, max_tokens: 8192, allowed_fallback_models: [], capabilities: { effort: { supported: true } } }]));
  if (path === "/v1/skills") return response.json(page([{ id: "skill_testing", type: "skill", display_title: "Testing", source: "custom", latest_version: "1", created_at: now, updated_at: now }, { id: "skill_frontend", type: "skill", display_title: "Frontend design", source: "custom", latest_version: "3", created_at: now, updated_at: now }]));
  if (path === "/v1/sessions") return response.json(page([...sessions.values()].reverse()));
  if (path === "/v1/files") return response.json(page(request.query.scope_id === demoId ? [{
    id: "file_report", type: "file", filename: "provider-verification.md", mime_type: "text/markdown", size_bytes: 2840,
    downloadable: true, scope: { type: "session", id: demoId }, created_at: now,
  }] : []));
  const agentMatch = path.match(/^\/v1\/agents\/([^/]+)$/);
  if (agentMatch) {
    const found = [...agents, ...copiedAgents].find((item) => item.id === agentMatch[1]);
    return found ? response.json(found) : response.status(404).json({ error: { message: "Agent not found" } });
  }
  const sessionMatch = path.match(/^\/v1\/sessions\/([^/]+)$/);
  if (sessionMatch) return response.json(sessions.get(sessionMatch[1] ?? "") ?? session(demoId, "Unknown"));
  const eventsMatch = path.match(/^\/v1\/sessions\/([^/]+)\/events$/);
  if (eventsMatch) return response.json(page(events.get(eventsMatch[1] ?? "") ?? []));
  const threadsMatch = path.match(/^\/v1\/sessions\/([^/]+)\/threads$/);
  if (threadsMatch) return response.json(page(threadsMatch[1] === demoId ? [
    { id: "thread_research", type: "session_thread", name: "Provider researcher", status: "idle", session_id: demoId, parent_thread_id: null, archived_at: null, agent: { name: "Provider researcher" }, stats: { duration_seconds: 42, active_seconds: 18 }, usage: { input_tokens: 1200, output_tokens: 340 }, created_at: now, updated_at: now },
    { id: "thread_verify", type: "session_thread", name: "E2E verifier", status: "running", session_id: demoId, parent_thread_id: null, archived_at: null, agent: { name: "E2E verifier" }, stats: { duration_seconds: 28, active_seconds: 22 }, usage: { input_tokens: 900, output_tokens: 210 }, created_at: now, updated_at: now },
  ] : []));
  const threadEventsMatch = path.match(/^\/v1\/sessions\/([^/]+)\/threads\/([^/]+)\/events$/);
  if (threadEventsMatch) return response.json(page([
    { id: `${threadEventsMatch[2]}_1`, type: "user.message", processed_at: now, content: [{ type: "text", text: "Investigate the delegated provider boundary." }] },
    { id: `${threadEventsMatch[2]}_2`, type: "agent.message", processed_at: now, content: [{ type: "text", text: "I inspected the assigned boundary and reported the verified findings to the parent." }] },
  ]));
  if (path === "/v1/files/file_report/content") return response.type("text/markdown").send("# Provider verification\n\nAll focused checks pass.\n");
  next();
});

app.get("*path", (request, response, next) => {
  const path = scopePath(request);
  const match = path.match(/^\/v1\/sessions\/([^/]+)\/events\/stream$/);
  if (!match) return next();
  response.status(200).set({ "Content-Type": "text/event-stream", "Cache-Control": "no-cache" });
  for (const fact of events.get(match[1] ?? "") ?? []) response.write(`data: ${JSON.stringify(fact)}\n\n`);
  response.end();
});

app.post("*path", (request, response, next) => {
  const path = scopePath(request);
  if (path === "/v1/agents") {
    const body = request.body as Record<string, unknown>;
    const created = { ...standardAgent, ...body, id: `agent_copy_${copiedAgents.length + 1}`, type: "agent", name: String(body.name ?? "Copied Agent"), version: 1, archived_at: null, created_at: now, updated_at: now };
    copiedAgents.push(created);
    return response.status(200).json(created);
  }
  if (path === "/v1/sessions") {
    const id = `sesn_created_${sessions.size}`;
    const body = request.body as Record<string, unknown>;
    const metadata = body.metadata as Record<string, string> | undefined;
    const title = typeof body.title === "string" ? body.title : "New Session";
    const agentInput = body.agent as Record<string, unknown> | undefined;
    const selectedAgent = [...agents, ...copiedAgents].find((candidate) => candidate.id === agentInput?.id) ?? standardAgent;
    const effectiveAgent = { ...selectedAgent, ...agentInput, type: "agent" };
    const created = session(id, title, metadata?.harness_preset ?? "standard", "idle", metadata?.harness_mode ?? "execute", effectiveAgent);
    created.metadata = { ...created.metadata as Record<string, string>, ...metadata };
    sessions.set(id, created);
    const initial = Array.isArray(body.initial_events) ? body.initial_events[0] as Record<string, unknown> : undefined;
    const base: EventFact[] = [
      { id: `${id}_1`, type: "session.status_running", processed_at: now },
      { id: `${id}_2`, type: "user.message", processed_at: now, content: initial?.content ?? [{ type: "text", text: "New request" }] },
    ];
    if (title.toLowerCase().includes("multi question")) base.push(
      { id: `${id}_3`, type: "agent.custom_tool_use", processed_at: now, name: "question", input: { questions: [{ id: "scope", question: "Which rollout scope should I use?", options: [{ label: "Canary", description: "Start with a bounded cohort.", recommended: true }, { label: "All workspaces", description: "Roll out immediately." }], multiple: false }, { id: "checks", question: "Which checks are required?", options: ["Unit", "E2E"], multiple: true }] } },
      { id: `${id}_4`, type: "session.status_idle", processed_at: now },
    );
    else if (title.toLowerCase().includes("question")) base.push(
      { id: `${id}_3`, type: "agent.custom_tool_use", processed_at: now, name: "question", input: { question: "Which rollout scope should I use?", options: ["Canary (Recommended)", "All workspaces"], multiple: false } },
      { id: `${id}_4`, type: "session.status_idle", processed_at: now },
    );
    else if (title.toLowerCase().includes("queue")) base.push(
      { id: `${id}_3`, type: "agent.message", processed_at: now, content: [{ type: "text", text: "Long-running verification is active; steering can be queued." }] },
    );
    else if (metadata?.harness_mode === "plan") base.push(
      { id: `${id}_3`, type: "agent.mcp_tool_use", processed_at: now, name: "mcp__harness__set_plan", mcp_server_name: "harness", input: { plan_id: `${id}_plan`, revision: 1, summary: "Review and execute the cloud change", steps: [{ id: "review", title: "Review the affected boundary", status: "completed" }, { id: "execute", title: "Apply after approval", status: "pending" }] } },
      { id: `${id}_4`, type: "agent.mcp_tool_result", processed_at: now, mcp_tool_use_id: `${id}_3`, content: [{ type: "text", text: "Plan published." }], is_error: false },
      { id: `${id}_5`, type: "agent.custom_tool_use", processed_at: now, name: "review_plan", input: { plan_id: `${id}_plan`, revision: 1, summary: "Review and execute the cloud change" } },
      { id: `${id}_6`, type: "session.status_idle", processed_at: now },
    );
    else if (metadata?.harness_preset === "creator") base.push(
      { id: `${id}_3`, type: "agent.custom_tool_use", processed_at: now, name: "agent_proposal", input: { baseAgentId: standardAgent.id, baseAgentVersion: standardAgent.version, name: `${title} Agent`, description: "A reviewed Agent composition produced by Creator mode.", system: "Execute the approved composition through official Awaken Managed Agents.", rationale: "Reuse the canonical Standard composition and publish only reviewed overrides." } },
      { id: `${id}_4`, type: "session.status_idle", processed_at: now },
    );
    else if (metadata?.harness_preset === "code") base.push(
      { id: `${id}_3`, type: "agent.tool_use", processed_at: now, name: "grep", input: { pattern: "authoritative", path: "src" } },
      { id: `${id}_4`, type: "agent.tool_result", processed_at: now, tool_use_id: `${id}_3`, content: [{ type: "text", text: "src/runtime.ts:12" }], is_error: false },
      { id: `${id}_5`, type: "agent.message", processed_at: now, content: [{ type: "text", text: "Code mode completed through the official Awaken Managed toolset." }] },
      { id: `${id}_6`, type: "session.status_idle", processed_at: now },
    );
    else if (metadata?.harness_preset === "minimal") base.push(
      { id: `${id}_3`, type: "agent.tool_use", processed_at: now, name: "read", input: { path: "README.md", offset: 1, limit: 40 } },
      { id: `${id}_4`, type: "agent.tool_result", processed_at: now, tool_use_id: `${id}_3`, content: [{ type: "text", text: "Minimal bounded context." }], is_error: false },
      { id: `${id}_5`, type: "agent.message", processed_at: now, content: [{ type: "text", text: "Minimal mode completed without web, skills, or subagents." }] },
      { id: `${id}_6`, type: "session.status_idle", processed_at: now },
    );
    else base.push(
      { id: `${id}_3`, type: "agent.message", processed_at: now, content: [{ type: "text", text: "Standard mode completed through its published skills and coordinator composition." }] },
      { id: `${id}_4`, type: "session.status_idle", processed_at: now },
    );
    events.set(id, base);
    return response.status(200).json(created);
  }
  const eventMatch = path.match(/^\/v1\/sessions\/([^/]+)\/events$/);
  if (eventMatch) {
    const id = eventMatch[1] ?? "";
    const incoming = (request.body as { events?: Array<Record<string, unknown>> }).events ?? [];
    if (incoming.some((fact) => fact.type === "user.tool_confirmation")) appendAfterApproval(id);
    else if (incoming.some((fact) => fact.type === "user.custom_tool_result")) {
      const facts = events.get(id) ?? [];
      const answer = incoming.find((fact) => fact.type === "user.custom_tool_result") ?? {};
      const pending = facts.find((fact) => fact.id === answer.custom_tool_use_id);
      const completion = pending?.name === "review_plan"
        ? "The correlated plan decision was recorded; execution can continue from the reviewed revision."
        : pending?.name === "agent_proposal"
          ? "The correlated Agent proposal decision was recorded."
          : answer.is_error
            ? "The question was cancelled, so I stopped waiting for operator input."
            : "I recorded the rollout answer and can continue with the selected scope.";
      facts.push(
        { id: `${id}_answer`, type: "user.custom_tool_result", processed_at: now, custom_tool_use_id: answer.custom_tool_use_id, content: answer.content ?? [], is_error: answer.is_error ?? false },
        { id: `${id}_answered`, type: "agent.message", processed_at: now, content: [{ type: "text", text: completion }] },
        { id: `${id}_settled`, type: "session.status_idle", processed_at: now },
      );
      events.set(id, facts);
    }
    else if (incoming.some((fact) => fact.type === "user.message")) {
      const facts = events.get(id) ?? [];
      const suffix = facts.length + 1;
      facts.push(
        { id: `${id}_${suffix}`, type: "user.message", processed_at: now, content: incoming[0]?.content ?? [] },
        { id: `${id}_${suffix + 1}`, type: "agent.message", processed_at: now, content: [{ type: "text", text: "Steering received and committed to this Session." }] },
      );
      events.set(id, facts);
    }
    return response.json({ accepted: true });
  }
  const archiveMatch = path.match(/^\/v1\/sessions\/([^/]+)\/archive$/);
  if (archiveMatch) return response.json(sessions.get(archiveMatch[1] ?? ""));
  const archiveThreadMatch = path.match(/^\/v1\/sessions\/([^/]+)\/threads\/([^/]+)\/archive$/);
  if (archiveThreadMatch) return response.json({ id: archiveThreadMatch[2], type: "session_thread", status: "terminated", session_id: archiveThreadMatch[1], parent_thread_id: null, archived_at: now, agent: { name: "Archived worker" }, stats: null, usage: null, created_at: now, updated_at: now });
  const archiveAgentMatch = path.match(/^\/v1\/agents\/([^/]+)\/archive$/);
  if (archiveAgentMatch) {
    const found = copiedAgents.find((item) => item.id === archiveAgentMatch[1]);
    if (!found) return response.status(404).json({ error: { message: "Agent not found" } });
    found.archived_at = now;
    return response.json(found);
  }
  const updateMatch = path.match(/^\/v1\/sessions\/([^/]+)$/);
  if (updateMatch) {
    const current = sessions.get(updateMatch[1] ?? "");
    if (!current) return response.status(404).json({ error: { message: "Session not found" } });
    const body = request.body as { title?: string; metadata?: Record<string, string | null>; agent?: Record<string, unknown> };
    if (body.title !== undefined) current.title = body.title;
    if (body.agent) current.agent = { ...current.agent as Record<string, unknown>, ...body.agent };
    if (body.metadata) {
      const metadata = { ...current.metadata as Record<string, string> };
      for (const [key, value] of Object.entries(body.metadata)) value === null ? delete metadata[key] : metadata[key] = value;
      current.metadata = metadata;
    }
    current.updated_at = now;
    return response.json(current);
  }
  next();
});

app.use((_request, response) => response.status(404).json({ error: { type: "not_found_error", message: "Fixture route not found" } }));
app.listen(4283, "127.0.0.1", () => console.log("Fake Awaken Managed API listening on http://127.0.0.1:4283"));
