import { expect, test, type APIRequestContext, type Page } from "@playwright/test";

type Session = { id: string; title: string; status: string; metadata: Record<string, string> };
type Event = { id: string; type: string; name?: string; content?: Array<{ type: string; text?: string }>; input?: unknown; is_error?: boolean; tool_use_id?: string; custom_tool_use_id?: string };

const skillMarker = "HARNESS-LIVE-SKILL-7F31";

async function createSession(
  page: Page,
  preset: "standard" | "code" | "minimal" | "creator",
  title: string,
  prompt: string,
  options: { mode?: "execute" | "plan"; permission?: "safe" | "full" } = {},
): Promise<void> {
  await page.getByTestId("new-session").click();
  await page.getByTestId(`preset-${preset}`).click();
  await page.getByTestId("session-title").fill(title);
  await page.getByTestId("session-prompt").fill(prompt);
  const dialog = page.getByTestId("create-session-dialog");
  await dialog.locator("label").filter({ hasText: /^Environment/ }).locator("select").selectOption({ label: "Harness Live Kubernetes" });
  if (options.mode === "plan") {
    await dialog.locator("label").filter({ hasText: /^Mode/ }).locator("select").selectOption("plan");
  }
  if (options.permission === "full") {
    await dialog.locator("label").filter({ hasText: /^Permission/ }).locator("select").selectOption("full");
    page.once("dialog", (confirmation) => confirmation.accept());
  }
  await page.getByTestId("create-session-submit").click();
  await expect(page.getByRole("heading", { name: title, exact: true })).toBeVisible();
}

async function sessions(request: APIRequestContext): Promise<Session[]> {
  const response = await request.get("/api/sessions");
  expect(response.ok()).toBeTruthy();
  return response.json();
}

async function sessionByTitle(request: APIRequestContext, title: string): Promise<Session> {
  let found: Session | undefined;
  await expect.poll(async () => {
    found = (await sessions(request)).find((session) => session.title === title);
    return Boolean(found);
  }).toBe(true);
  return found!;
}

async function events(request: APIRequestContext, id: string): Promise<Event[]> {
  const response = await request.get(`/api/sessions/${id}/events`);
  expect(response.ok()).toBeTruthy();
  return response.json();
}

async function waitForEvent(
  request: APIRequestContext,
  id: string,
  predicate: (event: Event) => boolean,
): Promise<Event> {
  let found: Event | undefined;
  await expect.poll(async () => {
    found = (await events(request, id)).find(predicate);
    return Boolean(found);
  }).toBe(true);
  return found!;
}

function text(event: Event): string {
  return (event.content ?? []).map((block) => block.text ?? "").join("");
}

async function steerToPlanReview(
  page: Page,
  request: APIRequestContext,
  sessionId: string,
  correction: string,
): Promise<void> {
  const review = page.getByTestId("plan-review");
  const approval = page.getByTestId("approval-card");
  for (let attempt = 0; attempt < 3; attempt += 1) {
    await expect.poll(async () => {
      if (await review.isVisible()) return "review";
      if (await approval.isVisible()) return "unexpected-permission";
      return "waiting";
    }, { timeout: 180_000 }).not.toBe("waiting");
    if (await review.isVisible()) return;

    const latestToolUse = (await events(request, sessionId))
      .filter((event) => event.type === "agent.tool_use")
      .at(-1);
    expect(latestToolUse, "permission card must project a committed tool use").toBeDefined();
    await approval.getByRole("button", { name: "Deny", exact: true }).click();
    await waitForEvent(request, sessionId, (event) => (
      event.type === "user.tool_confirmation" && event.tool_use_id === latestToolUse!.id
    ));
    await expect(approval).toHaveCount(0);
    if (attempt === 2) break;
    await page.getByTestId("composer").fill(correction);
    await page.getByRole("button", { name: "Send message" }).click();
    await page.reload();
  }
  throw new Error("real model did not reach typed Plan review after two corrective turns");
}

test("real DeepSeek validates every Harness mode and live recovery boundary", async ({ page, request }) => {
  /**
   * Live cause/effect decision table (all rows cross Browser -> BFF -> official
   * SDK -> latest Awaken -> real DeepSeek; Awaken setup uses a fresh data root):
   * L1 discovered Provider + published compositions -> live model/Agent catalogs;
   * L2 Standard + runtime nonce + Skill + dropped SSE -> genuine model output,
   *    durable Skill context, history polling recovery, refresh, and multi-turn;
   * L3 Code + model-selected bash + deny/allow -> both permission terminals and
   *    a real sandbox result consumed by the model;
   * L4 Minimal + Full + sandbox write/read -> auto-approved official tools,
   *    deterministic isolated content, and no expanded owner;
   * L5a Plan + direct MCP set_plan/review_plan -> protected approval/resume;
   * L5b an off-sequence permission tool -> deny and corrective real-model turn
   *    -> the same correlated typed review terminal, without bypassing policy;
   * L6 Creator + agent_proposal -> explicit publication and correlated resume;
   * L7 structured question -> one custom result and resumed real-model answer;
   * L8 coordinator request -> durable child Thread. Random per-run nonces prevent
   *    a canned fixture response from satisfying any real-model assertion.
   */
  const nonce = `${Date.now().toString(36)}-${crypto.randomUUID().slice(0, 8)}`.toUpperCase();
  const standardMarker = `STANDARD-${nonce}`;
  const reconnectMarker = `RECONNECT-${nonce}`;
  const codeMarker = `CODE-${nonce}`;
  const minimalMarker = `MINIMAL-${nonce}`;
  const planMarker = `PLAN-${nonce}`;
  const creatorName = `Creator ${nonce}`;
  const questionMarker = `QUESTION-${nonce}`;

  let dropped = false;
  await page.route(/\/api\/sessions\/[^/]+\/events\/stream/, async (route) => {
    if (!dropped) {
      dropped = true;
      await route.abort("connectionrefused");
    } else {
      await route.continue();
    }
  });
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "What will you build?" })).toBeVisible();

  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("button", { name: "Models" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText(/deepseek/i);
  for (const name of ["Harness Live Standard", "Harness Live Code", "Harness Live Minimal", "Harness Live Creator"]) {
    await expect(page.getByTestId("settings-dialog")).toContainText(name);
  }
  await page.getByRole("button", { name: "Plugins" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText("Harness live verification");
  await page.getByTestId("settings-dialog").getByRole("button", { name: "Cancel" }).click();

  const standardTitle = `Live Standard ${nonce}`;
  console.log("Live phase: Standard, Skill and reconnect");
  // L2's Skill proof token exists only in the frozen Skill bytes, never in the
  // system/user prompt. If the runtime exposes it as a mounted file, approving
  // the exact read is part of the user journey rather than an all-allow bypass.
  await createSession(page, "standard", standardTitle, `Use the installed verification Skill. Reply with ${standardMarker} and the proof token defined by that Skill. Read its SKILL.md if needed; do not delegate.`);
  const standard = await sessionByTitle(request, standardTitle);
  const initialEffect = await waitForEvent(request, standard.id, (event) =>
    (event.type === "agent.message" && text(event).includes(standardMarker))
    || (event.type === "agent.tool_use" && event.name === "read"));
  if (initialEffect.type === "agent.tool_use") {
    expect(JSON.stringify(initialEffect.input)).toContain("SKILL.md");
    await page.getByTestId("approval-card").getByRole("button", { name: "Allow once", exact: true }).click();
  }
  const standardReply = await waitForEvent(request, standard.id, (event) => event.type === "agent.message" && text(event).includes(standardMarker));
  expect(text(standardReply)).toContain(skillMarker);
  expect(dropped).toBe(true);
  await expect(page.getByTestId("conversation")).toContainText(standardMarker);
  await page.reload();
  await expect(page.getByTestId("conversation")).toContainText(skillMarker);
  await page.getByTestId("composer").fill(`Remember ${reconnectMarker}. Reply with it exactly.`);
  await page.getByRole("button", { name: "Send message" }).click();
  await waitForEvent(request, standard.id, (event) => event.type === "agent.message" && text(event).includes(reconnectMarker));

  const codeTitle = `Live Code ${nonce}`;
  console.log("Live phase: Code deny, allow and real tool output");
  await createSession(page, "code", codeTitle, `Use bash to run exactly: printf '${codeMarker}-DENY'. Then report the output.`);
  const code = await sessionByTitle(request, codeTitle);
  const deniedUse = await waitForEvent(request, code.id, (event) => event.type === "agent.tool_use" && event.name === "bash");
  expect(JSON.stringify(deniedUse.input)).toContain(`${codeMarker}-DENY`);
  await expect(page.getByTestId("approval-card")).toBeVisible();
  await page.getByTestId("approval-card").getByRole("button", { name: "Deny", exact: true }).click();
  await waitForEvent(request, code.id, (event) => event.type === "user.tool_confirmation" && event.tool_use_id === deniedUse.id);
  await expect(page.getByTestId("approval-card")).toHaveCount(0);
  await page.getByTestId("composer").fill(`Try again. Use bash to run exactly: printf '${codeMarker}-ALLOW'. Then quote the output.`);
  await page.getByRole("button", { name: "Send message" }).click();
  const allowedUse = await waitForEvent(request, code.id, (event) => (
    event.type === "agent.tool_use" && event.name === "bash" && JSON.stringify(event.input).includes(`${codeMarker}-ALLOW`)
  ));
  await expect(page.getByTestId("approval-card")).toBeVisible();
  await page.getByTestId("approval-card").getByRole("button", { name: "Allow once", exact: true }).click();
  const toolResult = await waitForEvent(request, code.id, (event) => event.type === "agent.tool_result" && event.tool_use_id === allowedUse.id);
  expect(text(toolResult)).toContain(`${codeMarker}-ALLOW`);
  await waitForEvent(request, code.id, (event) => event.type === "agent.message" && text(event).includes(`${codeMarker}-ALLOW`));

  const minimalTitle = `Live Minimal ${nonce}`;
  console.log("Live phase: Minimal write and read");
  await createSession(page, "minimal", minimalTitle, `Use write to create the workdir-relative file minimal-proof.txt containing exactly ${minimalMarker}. Then use read on minimal-proof.txt and reply with the real file content.`, { permission: "full" });
  const minimal = await sessionByTitle(request, minimalTitle);
  const minimalWrite = await waitForEvent(request, minimal.id, (event) => event.type === "agent.tool_use" && event.name === "write");
  // Full access approves a tool; it never expands the sandbox path boundary.
  // Require an admitted workdir-relative path and inspect failures directly,
  // rather than polling for a success that a failed tool can never produce.
  const minimalWriteResult = await waitForEvent(request, minimal.id, (event) => event.type === "agent.tool_result" && event.tool_use_id === minimalWrite.id);
  expect(minimalWriteResult.is_error, text(minimalWriteResult)).not.toBe(true);
  const minimalRead = await waitForEvent(request, minimal.id, (event) => event.type === "agent.tool_use" && event.name === "read");
  const minimalResult = await waitForEvent(request, minimal.id, (event) => event.type === "agent.tool_result" && event.tool_use_id === minimalRead.id);
  expect(minimalResult.is_error, text(minimalResult)).not.toBe(true);
  expect(text(minimalResult)).toContain(minimalMarker);
  await waitForEvent(request, minimal.id, (event) => event.type === "agent.message" && text(event).includes(minimalMarker));
  await expect(page.getByTestId("approval-card")).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Permission mode" })).toContainText("Full");

  const planTitle = `Live Plan ${nonce}`;
  console.log("Live phase: Plan approval");
  const planInstruction = `Call mcp__harness__set_plan directly with exactly {"plan_id":"live-${nonce}","revision":1,"summary":"${planMarker}","steps":[{"id":"step-1","title":"Verify live plan","status":"pending"}]}. Do not call bash or any other tool first. Immediately call review_plan with exactly {"plan_id":"live-${nonce}","revision":1}; after approval reply exactly ${planMarker}.`;
  await createSession(page, "standard", planTitle, planInstruction, { mode: "plan" });
  const plan = await sessionByTitle(request, planTitle);
  await steerToPlanReview(page, request, plan.id, `The previous tool was out of sequence and was denied. ${planInstruction}`);
  await expect(page.getByTestId("plan-review")).toBeVisible();
  await waitForEvent(request, plan.id, (event) => event.type === "agent.mcp_tool_use" && event.name === "mcp__harness__set_plan");
  await page.getByRole("button", { name: "Approve plan" }).click();
  await waitForEvent(request, plan.id, (event) => event.type === "user.custom_tool_result");
  await waitForEvent(request, plan.id, (event) => event.type === "agent.message" && text(event).includes(planMarker));

  const creatorTitle = `Live Creator ${nonce}`;
  console.log("Live phase: Creator publication");
  await createSession(page, "creator", creatorTitle, `As your first and only action, call agent_proposal exactly once to propose a new Agent named ${creatorName}. Do not inspect files.`);
  const creator = await sessionByTitle(request, creatorTitle);
  await expect(page.getByTestId("agent-proposal-review")).toContainText(creatorName);
  await waitForEvent(request, creator.id, (event) => event.type === "agent.custom_tool_use" && event.name === "agent_proposal");
  await page.getByRole("button", { name: "Publish Agent" }).click();
  await waitForEvent(request, creator.id, (event) => event.type === "user.custom_tool_result" && text(event).includes("agent_id"));
  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("button", { name: "Models" }).click();
  await expect(page.getByTestId("settings-dialog")).toContainText(creatorName);
  await page.getByTestId("settings-dialog").getByRole("button", { name: "Cancel" }).click();

  const questionTitle = `Live Question ${nonce}`;
  console.log("Live phase: Structured question");
  await createSession(page, "standard", questionTitle, `Call the question tool with question '${questionMarker}', options Alpha and Beta, and multiple false. After the answer, report it.`);
  const question = await sessionByTitle(request, questionTitle);
  await expect(page.getByTestId("question-composer")).toContainText(questionMarker);
  await page.getByRole("button", { name: "Alpha" }).click();
  await waitForEvent(request, question.id, (event) => event.type === "user.custom_tool_result" && text(event).includes("Alpha"));
  await waitForEvent(request, question.id, (event) => event.type === "agent.message" && /Alpha/u.test(text(event)));

  const delegateTitle = `Live Delegate ${nonce}`;
  await createSession(page, "standard", delegateTitle, `As your first and only action, call the typed agent_run tool for the published roster worker to calculate 17 + 25. Do not inspect or search the environment. Then report ${nonce} and the worker's answer.`);
  const delegate = await sessionByTitle(request, delegateTitle);
  await expect.poll(async () => {
    const response = await request.get(`/api/sessions/${delegate.id}/threads`);
    if (!response.ok()) return 0;
    return ((await response.json()) as unknown[]).length;
  }).toBeGreaterThan(0);
  await waitForEvent(request, delegate.id, (event) => event.type === "agent.message" && text(event).includes(nonce));
});
