import { spawnSync } from "node:child_process";
import { renameSync, rmSync, statSync } from "node:fs";
import { resolve } from "node:path";

const source = resolve("test-results/deepseek-harness-awaken-demo.webm");
const target = resolve("artifacts/deepseek-harness-awaken-demo.mp4");
const temporary = resolve("artifacts/deepseek-harness-awaken-demo.tmp.mp4");

statSync(source);
const conversion = spawnSync("ffmpeg", [
  "-hide_banner", "-loglevel", "error", "-y", "-i", source,
  "-c:v", "libx264", "-preset", "slow", "-crf", "20",
  "-pix_fmt", "yuv420p", "-r", "25", "-movflags", "+faststart",
  temporary,
], { stdio: "inherit" });

if (conversion.status !== 0) {
  rmSync(temporary, { force: true });
  process.exit(conversion.status ?? 1);
}

renameSync(temporary, target);
const output = statSync(target);
console.log(`Recorded ${target} (${output.size} bytes)`);
