import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
const source = process.env.AWAKEN_SOURCE_DIR;
assert.ok(source, "verify:live requires the explicit frozen Awaken source path");
const awaken = path.resolve(source);
const gate = path.join(awaken, "scripts", "ci", "check-all.sh");
assert.ok(fs.statSync(gate, { throwIfNoEntry: false })?.isFile(), "Awaken canonical full gate is missing");

// The runtime repository owns its qualification groups and record. This
// wrapper adds ordering only; a historical handpicked scenario list must not
// become a second runtime qualification authority.
const result = spawnSync("bash", [gate, "--full-gate", "--record"], {
  cwd: awaken, env: process.env, stdio: "inherit",
});
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status ?? 1);
process.stdout.write("Canonical Awaken full gate passed and recorded.\n");
