import { defineConfig, devices } from "@playwright/test";

const webServers = [
  {
    command: "pnpm exec tsx e2e/fake-managed-server.ts",
    port: 4283,
    reuseExistingServer: false,
    timeout: 30_000,
  },
  {
    command: "pnpm --filter @harness/interaction-mcp dev",
    port: 4282,
    reuseExistingServer: false,
    timeout: 30_000,
  },
  {
    command: "HARNESS_AWAKEN_API_URL=http://127.0.0.1:4283 HARNESS_DEFAULT_WORKSPACE_ID=workspace-demo HARNESS_INTERACTION_MCP_URL=http://127.0.0.1:4282/mcp pnpm --filter @harness/api dev",
    port: 4280,
    reuseExistingServer: false,
    timeout: 30_000,
  },
  {
    command: "pnpm --filter @harness/web dev",
    port: 4281,
    reuseExistingServer: false,
    timeout: 30_000,
  },
] as const;

export default defineConfig({
  testDir: "./e2e",
  outputDir: "test-results",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 45_000,
  expect: { timeout: 8_000 },
  reporter: [["list"], ["html", { open: "never" }]],
  use: {
    baseURL: "http://127.0.0.1:4281",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  webServer: [...webServers],
  projects: [
    { name: "chromium", use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } }, testIgnore: [/demo-video\.spec\.ts/, /\/live\//] },
    { name: "video", use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 }, video: { mode: "on", size: { width: 1440, height: 900 } } }, testMatch: /demo-video\.spec\.ts/ },
  ],
});
