import { createMcpApp } from "./http.js";

const host = process.env.HARNESS_MCP_HOST?.trim() || "127.0.0.1";
const port = Number(process.env.HARNESS_MCP_PORT ?? "4282");
if (!Number.isInteger(port) || port < 1 || port > 65_535) throw new Error("Invalid HARNESS_MCP_PORT");
const bearer = process.env.HARNESS_MCP_BEARER_TOKEN;
const allowedHosts = process.env.HARNESS_MCP_ALLOWED_HOSTS?.split(",").map((value) => value.trim()).filter(Boolean);
const app = createMcpApp({ host, ...(bearer ? { bearer } : {}), ...(allowedHosts?.length ? { allowedHosts } : {}) });
const listener = app.listen(port, host, () => console.log(`Harness interaction MCP listening on http://${host}:${port}/mcp`));
for (const signal of ["SIGINT", "SIGTERM"] as const) process.once(signal, () => listener.close());

