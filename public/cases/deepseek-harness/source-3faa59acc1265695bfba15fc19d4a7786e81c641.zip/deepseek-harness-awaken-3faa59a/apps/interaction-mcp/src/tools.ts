import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";

export const planSchema = z.object({
  plan_id: z.string().min(1).max(80),
  revision: z.number().int().positive(),
  summary: z.string().min(1).max(2_000),
  steps: z.array(z.object({
    id: z.string().min(1).max(80),
    title: z.string().min(1).max(500),
    status: z.enum(["pending", "in_progress", "completed", "blocked"]),
    detail: z.string().max(2_000).optional(),
  })).min(1).max(100),
});

export const notificationSchema = z.object({
  level: z.enum(["info", "warning", "success"]),
  message: z.string().min(1).max(4_000),
});

export const resultSchema = z.object({
  summary: z.string().min(1).max(8_000),
  artifacts: z.array(z.object({
    path: z.string().min(1).max(1_000),
    description: z.string().max(2_000).optional(),
  })).max(100).default([]),
});

export type InteractionTool = "set_plan" | "notify_user" | "publish_result";

export function executeInteractionTool(name: InteractionTool, input: unknown) {
  const value = name === "set_plan"
    ? planSchema.parse(input)
    : name === "notify_user"
      ? notificationSchema.parse(input)
      : resultSchema.parse(input);
  const summary = name === "set_plan"
    ? `Plan published with ${(value as z.infer<typeof planSchema>).steps.length} step(s).`
    : name === "notify_user"
      ? (value as z.infer<typeof notificationSchema>).message
      : (value as z.infer<typeof resultSchema>).summary;
  return {
    content: [{ type: "text" as const, text: summary }],
    structuredContent: { kind: `harness.${name}.v1`, ...value },
  };
}

/**
 * One MCP protocol instance per transport request owns no durable state. Awaken
 * records complete tool inputs/results into the authoritative Session log.
 */
export function createInteractionServer(): McpServer {
  const server = new McpServer({ name: "deepseek-harness-awaken", version: "0.1.0" });
  server.registerTool("set_plan", {
    title: "Publish plan",
    description: "Publish one complete versioned plan snapshot. In Plan-first Sessions, call review_plan immediately afterward and wait for its client result before mutation.",
    inputSchema: planSchema,
  }, (input) => executeInteractionTool("set_plan", input));
  server.registerTool("notify_user", {
    title: "Notify user",
    description: "Surface material progress, risk, or completion.",
    inputSchema: notificationSchema,
  }, (input) => executeInteractionTool("notify_user", input));
  server.registerTool("publish_result", {
    title: "Publish result",
    description: "Publish the terminal summary and logical artifact paths.",
    inputSchema: resultSchema,
  }, (input) => executeInteractionTool("publish_result", input));
  return server;
}
