import { describe, expect, it } from "vitest";
import { executeInteractionTool } from "./tools.js";

describe("stateless interaction tools", () => {
  /**
   * Cause/effect rule R1: a complete plan snapshot arrives. Effect: return the
   * same snapshot as structured content; no plan repository or mutation occurs.
   */
  it("returns a complete plan snapshot", () => {
    const result = executeInteractionTool("set_plan", {
      plan_id: "plan-main",
      revision: 1,
      summary: "Repair and verify",
      steps: [{ id: "one", title: "Repair", status: "in_progress" }],
    });
    expect(result.structuredContent).toMatchObject({
      kind: "harness.set_plan.v1",
      plan_id: "plan-main",
      revision: 1,
      summary: "Repair and verify",
    });
  });

  /**
   * Rule R2: invalid terminal artifact shape. Effect: fail closed before a tool
   * result can be committed, keeping the Session log schema trustworthy.
   */
  it("rejects an invalid result artifact", () => {
    expect(() => executeInteractionTool("publish_result", {
      summary: "done",
      artifacts: [{ path: "" }],
    })).toThrow();
  });
});
