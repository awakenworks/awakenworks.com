import { createMcpExpressApp } from "@modelcontextprotocol/sdk/server/express.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import type { Express } from "express";
import { createInteractionServer } from "./tools.js";

export interface McpOptions {
  host: string;
  bearer?: string;
  allowedHosts?: string[];
}

export function createMcpApp(options: McpOptions): Express {
  const app = createMcpExpressApp({
    host: options.host,
    ...(options.allowedHosts?.length ? { allowedHosts: options.allowedHosts } : {}),
  });
  app.get("/healthz", (_request, response) => response.json({ status: "ok" }));
  app.use("/mcp", (request, response, next) => {
    if (!options.bearer || request.headers.authorization === `Bearer ${options.bearer}`) return next();
    response.status(401).set("WWW-Authenticate", "Bearer").json({ error: "unauthorized" });
  });
  app.all("/mcp", async (request, response) => {
    const server = createInteractionServer();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    let closed = false;
    const cleanup = async () => {
      if (closed) return;
      closed = true;
      await transport.close().catch(() => undefined);
      await server.close().catch(() => undefined);
    };
    response.once("close", () => void cleanup());
    try {
      await server.connect(transport);
      await transport.handleRequest(request, response, request.body);
    } catch {
      await cleanup();
      if (!response.headersSent) response.status(500).json({ error: "mcp_request_failed" });
    }
  });
  return app;
}

