import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import {
  EMPTY_LIVE_PREVIEW,
  isCommittedStreamEvent,
  mergeCommittedEvents,
  reduceLivePreview,
  type LivePreview,
  type ManagedEvent,
} from "@awaken/managed-session-projection";
import { projectSession } from "@harness/session-domain";
import type { HarnessApi } from "../infrastructure/api";
import type { ToolAnswer, ToolDecision } from "@harness/contracts";
import type { MessageCommand } from "@harness/contracts";

export const sessionKeys = {
  all: ["sessions"] as const,
  detail: (id: string) => ["sessions", id] as const,
  events: (id: string) => ["sessions", id, "events"] as const,
  threads: (id: string) => ["sessions", id, "threads"] as const,
  artifacts: (id: string) => ["sessions", id, "artifacts"] as const,
};

export function useSession(id: string, api: HarnessApi) {
  const cache = useQueryClient();
  const [preview, setPreview] = useState<LivePreview>(EMPTY_LIVE_PREVIEW);
  const session = useQuery({ queryKey: sessionKeys.detail(id), queryFn: () => api.getSession(id), refetchInterval: 10_000 });
  const events = useQuery({ queryKey: sessionKeys.events(id), queryFn: () => api.listEvents(id), refetchInterval: 5_000 });
  const threads = useQuery({ queryKey: sessionKeys.threads(id), queryFn: () => api.listThreads(id), refetchInterval: 10_000 });
  const artifacts = useQuery({ queryKey: sessionKeys.artifacts(id), queryFn: () => api.listArtifacts(id), refetchInterval: 12_000 });

  useEffect(() => {
    const controller = new AbortController();
    const receive: Parameters<HarnessApi["followEvents"]>[1] = (event) => {
      setPreview((current) => reduceLivePreview(current, event));
      if (isCommittedStreamEvent(event)) {
        cache.setQueryData<ManagedEvent[]>(sessionKeys.events(id), (current = []) => mergeCommittedEvents(current, [event]));
      }
    };
    void api.followEvents(id, receive, controller.signal).catch((error: unknown) => {
      if (!(error instanceof DOMException && error.name === "AbortError")) void events.refetch();
    });
    return () => controller.abort();
  }, [api, cache, id]);

  const refresh = () => Promise.all([session.refetch(), events.refetch(), threads.refetch(), artifacts.refetch()]);
  const send = useMutation({ mutationFn: (command: MessageCommand) => api.sendMessage(id, command), onSuccess: refresh });
  const interrupt = useMutation({ mutationFn: () => api.interrupt(id), onSuccess: refresh });
  const decide = useMutation({ mutationFn: (decision: ToolDecision) => api.decide(id, decision), onSuccess: refresh });
  const answerTool = useMutation({ mutationFn: (answer: ToolAnswer) => api.answerTool(id, answer), onSuccess: refresh });
  const projection = useMemo(() => projectSession(events.data ?? []), [events.data]);
  return { session, events, threads, artifacts, projection, preview, send, interrupt, decide, answerTool, refresh };
}
