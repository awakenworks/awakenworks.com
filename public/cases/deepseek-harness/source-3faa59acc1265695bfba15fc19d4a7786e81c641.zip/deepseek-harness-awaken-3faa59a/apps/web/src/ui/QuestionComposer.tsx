import { useMemo, useState } from "react";

interface QuestionOption { label: string; description?: string; recommended?: boolean }
interface QuestionSpec { id: string; prompt: string; options: QuestionOption[]; multiple: boolean }

function normalize(input: unknown): QuestionSpec[] {
  const value = typeof input === "object" && input !== null ? input as Record<string, unknown> : {};
  const rows = Array.isArray(value.questions) ? value.questions : [value];
  return rows.flatMap((raw, index) => {
    const question = typeof raw === "object" && raw !== null ? raw as Record<string, unknown> : {};
    const prompt = typeof question.question === "string" ? question.question : typeof question.prompt === "string" ? question.prompt : "The agent needs your input";
    const options = Array.isArray(question.options) ? question.options.flatMap((rawOption) => {
      if (typeof rawOption === "string") return [{ label: rawOption, recommended: rawOption.includes("Recommended") }];
      if (typeof rawOption !== "object" || rawOption === null) return [];
      const option = rawOption as Record<string, unknown>;
      return typeof option.label === "string" ? [{ label: option.label, ...(typeof option.description === "string" ? { description: option.description } : {}), ...(option.recommended === true ? { recommended: true } : {}) }] : [];
    }) : [];
    return [{ id: typeof question.id === "string" ? question.id : `question-${index + 1}`, prompt, options, multiple: question.multiple === true }];
  });
}

export function QuestionComposer({ toolId, input, answer }: { toolId: string; input: unknown; answer(text: string, cancelled?: boolean): Promise<unknown> }) {
  const questions = useMemo(() => normalize(input), [input]);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [selected, setSelected] = useState<string[]>([]);
  const [custom, setCustom] = useState("");
  const question = questions[index]!;
  const finish = (next: Record<string, string[]>) => answer(JSON.stringify({ answers: questions.map((item) => ({ id: item.id, values: next[item.id] ?? [] })) }));
  const commit = (values: string[]) => {
    const next = { ...answers, [question.id]: values };
    if (index === questions.length - 1) return void finish(next);
    setAnswers(next); setIndex(index + 1); setSelected([]); setCustom("");
  };
  return <section className="composer question-takeover" data-testid="question-composer" data-tool-id={toolId}>
    <div className="question-progress"><span>QUESTION {index + 1} OF {questions.length}</span><button aria-label="Cancel question" onClick={() => void answer("Question cancelled", true)}>×</button></div>
    <h3>{question.prompt}</h3>
    <div className="question-options">{question.options.map((option) => <button className={selected.includes(option.label) ? "selected" : ""} key={option.label} onClick={() => question.multiple ? setSelected((current) => current.includes(option.label) ? current.filter((item) => item !== option.label) : [...current, option.label]) : commit([option.label])}><span><strong>{option.label}</strong>{option.description && <small>{option.description}</small>}</span>{option.recommended && <em>Recommended</em>}</button>)}</div>
    <form onSubmit={(event) => { event.preventDefault(); if (custom.trim()) commit([...selected, custom.trim()]); }}><input value={custom} onChange={(event) => setCustom(event.target.value)} placeholder="Type a custom answer…" /><button disabled={!custom.trim()}>Submit</button></form>
    <div className="approval-actions">{index > 0 && <button onClick={() => { setIndex(index - 1); setSelected(answers[questions[index - 1]!.id] ?? []); }}>Back</button>}<button onClick={() => commit([])}>Skip</button>{question.multiple && <button className="allow" disabled={!selected.length} onClick={() => commit(selected)}>Continue</button>}<button onClick={() => void answer("Question cancelled", true)}>Cancel question</button></div>
  </section>;
}
