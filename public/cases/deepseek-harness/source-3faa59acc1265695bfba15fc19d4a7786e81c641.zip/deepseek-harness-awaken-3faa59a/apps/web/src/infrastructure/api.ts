import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaEnvironment } from "@anthropic-ai/sdk/resources/beta/environments/environments";
import type { FileMetadata } from "@anthropic-ai/sdk/resources/beta/files";
import type { BetaModelInfo } from "@anthropic-ai/sdk/resources/beta/models";
import type { SkillListResponse } from "@anthropic-ai/sdk/resources/beta/skills/skills";
import type { BetaManagedAgentsSession } from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import type { BetaManagedAgentsSessionThread } from "@anthropic-ai/sdk/resources/beta/sessions/threads/threads";
import type { AgentProposalDecision, CopyAgentCommand, CreateSessionCommand, ForkSessionCommand, MessageCommand, PermissionModeCommand, PlanReviewDecision, ToolAnswer, ToolDecision, UpdateSessionCommand } from "@harness/contracts";
import { workspaceHeader } from "@harness/contracts";
import type {
  ManagedEvent,
  ManagedStreamEvent,
} from "@awaken/managed-session-projection";

export interface Identity {
  token: string;
  workspaceId: string;
}

export interface HarnessApi {
  listAgents(): Promise<BetaManagedAgentsAgent[]>;
  copyAgent(id: string, command: CopyAgentCommand): Promise<BetaManagedAgentsAgent>;
  archiveAgent(id: string): Promise<BetaManagedAgentsAgent>;
  listEnvironments(): Promise<BetaEnvironment[]>;
  listModels(): Promise<BetaModelInfo[]>;
  listSkills(): Promise<SkillListResponse[]>;
  listSessions(): Promise<BetaManagedAgentsSession[]>;
  createSession(command: CreateSessionCommand): Promise<BetaManagedAgentsSession>;
  getSession(id: string): Promise<BetaManagedAgentsSession>;
  updateSession(id: string, command: UpdateSessionCommand): Promise<BetaManagedAgentsSession>;
  forkSession(id: string, command: ForkSessionCommand): Promise<BetaManagedAgentsSession>;
  setPermissionMode(id: string, command: PermissionModeCommand): Promise<BetaManagedAgentsSession>;
  listEvents(id: string): Promise<ManagedEvent[]>;
  followEvents(id: string, receive: (event: ManagedStreamEvent) => void, signal: AbortSignal): Promise<void>;
  sendMessage(id: string, command: MessageCommand): Promise<void>;
  interrupt(id: string): Promise<void>;
  decide(id: string, decision: ToolDecision): Promise<void>;
  answerTool(id: string, answer: ToolAnswer): Promise<void>;
  decidePlanReview(id: string, decision: PlanReviewDecision): Promise<void>;
  decideAgentProposal(id: string, decision: AgentProposalDecision): Promise<void>;
  listThreads(id: string): Promise<BetaManagedAgentsSessionThread[]>;
  listThreadEvents(id: string, threadId: string): Promise<ManagedEvent[]>;
  archiveThread(id: string, threadId: string): Promise<BetaManagedAgentsSessionThread>;
  listArtifacts(id: string): Promise<FileMetadata[]>;
  downloadArtifact(id: string, file: FileMetadata): Promise<void>;
  archive(id: string): Promise<void>;
  exportSession(id: string): Promise<void>;
}

async function requireOk(response: Response): Promise<Response> {
  if (response.ok) return response;
  let message = response.statusText || `Request failed (${response.status})`;
  try {
    const body = await response.json() as { error?: unknown };
    if (typeof body.error === "string") message = body.error;
  } catch {
    // Stable status fallback.
  }
  throw new Error(message);
}

export async function consumeSse(
  body: ReadableStream<Uint8Array>,
  receive: (event: ManagedStreamEvent) => void,
): Promise<void> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const frame = (raw: string) => {
    const data = raw.split(/\r?\n/).filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).replace(/^ /, "")).join("\n");
    if (data) receive(JSON.parse(data) as ManagedStreamEvent);
  };
  try {
    while (true) {
      const { done, value } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });
      const frames = buffer.split(/\r?\n\r?\n/);
      buffer = frames.pop() ?? "";
      for (const value of frames) frame(value);
      if (done) {
        if (buffer.trim()) frame(buffer);
        return;
      }
    }
  } finally {
    reader.releaseLock();
  }
}

export class BrowserHarnessApi implements HarnessApi {
  constructor(private readonly identity: () => Identity) {}

  private request(path: string, init: RequestInit = {}): Promise<Response> {
    const identity = this.identity();
    const headers = new Headers(init.headers);
    if (identity.token) headers.set("Authorization", `Bearer ${identity.token}`);
    if (identity.workspaceId) headers.set(workspaceHeader, identity.workspaceId);
    return fetch(path, { ...init, headers, credentials: "same-origin" });
  }

  private async json<T>(path: string, init?: RequestInit): Promise<T> {
    return requireOk(await this.request(path, init)).then((response) => response.json() as Promise<T>);
  }

  listAgents(): Promise<BetaManagedAgentsAgent[]> { return this.json("/api/catalog/agents"); }
  copyAgent(id: string, command: CopyAgentCommand): Promise<BetaManagedAgentsAgent> { return this.json(`/api/catalog/agents/${encodeURIComponent(id)}/copy`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(command) }); }
  archiveAgent(id: string): Promise<BetaManagedAgentsAgent> { return this.json(`/api/catalog/agents/${encodeURIComponent(id)}/archive`, { method: "POST" }); }
  listEnvironments(): Promise<BetaEnvironment[]> { return this.json("/api/catalog/environments"); }
  listModels(): Promise<BetaModelInfo[]> { return this.json("/api/catalog/models"); }
  listSkills(): Promise<SkillListResponse[]> { return this.json("/api/catalog/skills"); }
  listSessions(): Promise<BetaManagedAgentsSession[]> { return this.json("/api/sessions"); }
  createSession(command: CreateSessionCommand): Promise<BetaManagedAgentsSession> {
    return this.json("/api/sessions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(command) });
  }
  getSession(id: string): Promise<BetaManagedAgentsSession> { return this.json(`/api/sessions/${encodeURIComponent(id)}`); }
  updateSession(id: string, command: UpdateSessionCommand): Promise<BetaManagedAgentsSession> {
    return this.json(`/api/sessions/${encodeURIComponent(id)}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(command) });
  }
  forkSession(id: string, command: ForkSessionCommand): Promise<BetaManagedAgentsSession> {
    return this.json(`/api/sessions/${encodeURIComponent(id)}/fork`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(command) });
  }
  setPermissionMode(id: string, command: PermissionModeCommand): Promise<BetaManagedAgentsSession> {
    return this.json(`/api/sessions/${encodeURIComponent(id)}/permission`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(command) });
  }
  listEvents(id: string): Promise<ManagedEvent[]> { return this.json(`/api/sessions/${encodeURIComponent(id)}/events`); }
  async followEvents(id: string, receive: (event: ManagedStreamEvent) => void, signal: AbortSignal): Promise<void> {
    const response = await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/events/stream`, { signal }));
    if (!response.body) throw new Error("Event stream has no body");
    await consumeSse(response.body, receive);
  }
  async sendMessage(id: string, command: MessageCommand): Promise<void> {
    await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/messages`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(command),
    }));
  }
  async interrupt(id: string): Promise<void> { await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/interrupt`, { method: "POST" })); }
  async decide(id: string, decision: ToolDecision): Promise<void> {
    await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/decisions`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(decision),
    }));
  }
  async answerTool(id: string, answer: ToolAnswer): Promise<void> {
    await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/tool-answers`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(answer),
    }));
  }
  async decidePlanReview(id: string, decision: PlanReviewDecision): Promise<void> {
    await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/plan-reviews`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(decision),
    }));
  }
  async decideAgentProposal(id: string, decision: AgentProposalDecision): Promise<void> {
    await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/agent-proposals`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(decision),
    }));
  }
  listThreads(id: string): Promise<BetaManagedAgentsSessionThread[]> { return this.json(`/api/sessions/${encodeURIComponent(id)}/threads`); }
  listThreadEvents(id: string, threadId: string): Promise<ManagedEvent[]> { return this.json(`/api/sessions/${encodeURIComponent(id)}/threads/${encodeURIComponent(threadId)}/events`); }
  archiveThread(id: string, threadId: string): Promise<BetaManagedAgentsSessionThread> { return this.json(`/api/sessions/${encodeURIComponent(id)}/threads/${encodeURIComponent(threadId)}/archive`, { method: "POST" }); }
  listArtifacts(id: string): Promise<FileMetadata[]> { return this.json(`/api/sessions/${encodeURIComponent(id)}/artifacts`); }
  async downloadArtifact(id: string, file: FileMetadata): Promise<void> {
    const response = await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/artifacts/${encodeURIComponent(file.id)}/content`));
    const url = URL.createObjectURL(await response.blob());
    const link = document.createElement("a");
    link.href = url;
    link.download = file.filename;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }
  async archive(id: string): Promise<void> { await requireOk(await this.request(`/api/sessions/${encodeURIComponent(id)}/archive`, { method: "POST" })); }
  async exportSession(id: string): Promise<void> {
    const [session, events] = await Promise.all([this.getSession(id), this.listEvents(id)]);
    const url = URL.createObjectURL(new Blob([JSON.stringify({ session, events }, null, 2)], { type: "application/json" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `${id}.session.json`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }
}
