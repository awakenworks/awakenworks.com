export interface WorkspaceConnection {
  id: string;
  name: string;
}

export interface UiPreferences {
  theme: "dark" | "light" | "system";
  locale: "en" | "zh";
  enterBehavior: "send" | "newline";
  defaultPermission: "safe" | "full";
  workspaces: WorkspaceConnection[];
}

const key = "harness.ui-preferences.v1";

export function loadPreferences(activeWorkspace = ""): UiPreferences {
  const fallback: UiPreferences = {
    theme: "dark", locale: "en", enterBehavior: "send", defaultPermission: "safe",
    workspaces: activeWorkspace ? [{ id: activeWorkspace, name: activeWorkspace }] : [],
  };
  try {
    const parsed = JSON.parse(localStorage.getItem(key) ?? "null") as Partial<UiPreferences> | null;
    if (!parsed) return fallback;
    return {
      theme: ["dark", "light", "system"].includes(String(parsed.theme)) ? parsed.theme as UiPreferences["theme"] : fallback.theme,
      locale: parsed.locale === "zh" ? "zh" : "en",
      enterBehavior: parsed.enterBehavior === "newline" ? "newline" : "send",
      defaultPermission: parsed.defaultPermission === "full" ? "full" : "safe",
      workspaces: Array.isArray(parsed.workspaces) ? parsed.workspaces.filter((item): item is WorkspaceConnection => Boolean(item && typeof item.id === "string" && typeof item.name === "string")) : fallback.workspaces,
    };
  } catch {
    return fallback;
  }
}

export function savePreferences(value: UiPreferences): void {
  localStorage.setItem(key, JSON.stringify(value));
}
