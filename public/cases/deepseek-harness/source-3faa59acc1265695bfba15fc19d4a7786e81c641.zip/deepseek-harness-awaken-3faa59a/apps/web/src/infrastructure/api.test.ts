import { describe, expect, it } from "vitest";
import { consumeSse } from "./api.js";

describe("browser Managed event stream", () => {
  /**
   * Cause/effect decision R1: two JSON SSE frames are split across arbitrary
   * network chunks and a heartbeat is interleaved. Effects: both facts arrive
   * once, in order, while the heartbeat creates no domain event.
   */
  it("parses chunked JSON event frames without treating heartbeats as facts", async () => {
    const encoder = new TextEncoder();
    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(encoder.encode(": heartbeat\n\ndata: {\"id\":\"one\",\"type\":\"session.status_running\"}\n"));
        controller.enqueue(encoder.encode("\ndata: {\"id\":\"two\",\"type\":\"session.status_idle\"}\n\n"));
        controller.close();
      },
    });
    const events: unknown[] = [];
    await consumeSse(body, (event) => events.push(event));
    expect(events).toEqual([
      { id: "one", type: "session.status_running" },
      { id: "two", type: "session.status_idle" },
    ]);
  });
});
