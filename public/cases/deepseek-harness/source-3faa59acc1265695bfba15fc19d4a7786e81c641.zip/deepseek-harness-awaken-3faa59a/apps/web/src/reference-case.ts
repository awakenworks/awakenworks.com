export const deepSeekHarnessReferenceCase = Object.freeze({
  kind: "Independent Reference Reimplementation",
  adoption: "Advanced Agent workbench",
  label: "Built on Awaken",
  summary: "DeepSeek Harness interaction model, rebuilt on Awaken.",
  readerPromise: "Build a Harness-class workbench without rebuilding the Agent runtime.",
  disclosure: "Independent project. No partnership or endorsement is implied.",
  caseUrl: "https://awakenworks.com/cases/deepseek-harness",
  portfolioUrl: "https://awakenworks.com/cases",
  applicationTruth: ["preset UX", "browser preferences", "product projections", "stateless BFF"],
  awakenTruth: ["Session", "model route", "credentials", "tools", "Worker", "Sandbox", "recovery"],
});
