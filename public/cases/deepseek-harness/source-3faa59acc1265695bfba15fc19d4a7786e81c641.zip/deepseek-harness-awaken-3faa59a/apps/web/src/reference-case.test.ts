import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { describe, expect, it } from "vitest";
import { deepSeekHarnessReferenceCase } from "./reference-case";

/**
 * Reference-integration decision table.
 * Causes: C1 the rebuilt Harness interaction model remains visible; C2 Awaken owns
 * execution and durable Session facts; C3 the DeepSeek name is present; C4 the
 * reader follows the canonical case link; C5 the link gives readers a concrete
 * reason to inspect the implementation. Effects: E1 adoption is described as
 * an independent reimplementation rather than a migration; E2 the product API does not become an Agent loop;
 * E3 no partnership or endorsement is implied; E4 the other Awaken adoption
 * paths remain discoverable. Constraint: this metadata is presentation only.
 * Rule R1: C1+C2+C3+C4+C5 => E1+E2+E3+E4.
 */
describe("DeepSeek Harness reference-reimplementation contract", () => {
  it("R1 preserves the independent-reimplementation disclosure and owner boundary", () => {
    expect(deepSeekHarnessReferenceCase).toMatchObject({
      kind: "Independent Reference Reimplementation",
      adoption: "Advanced Agent workbench",
      summary: "DeepSeek Harness interaction model, rebuilt on Awaken.",
      readerPromise: "Build a Harness-class workbench without rebuilding the Agent runtime.",
      disclosure: "Independent project. No partnership or endorsement is implied.",
      caseUrl: "https://awakenworks.com/cases/deepseek-harness",
      portfolioUrl: "https://awakenworks.com/cases",
    });
    expect(deepSeekHarnessReferenceCase.applicationTruth).toContain("stateless BFF");
    expect(deepSeekHarnessReferenceCase.awakenTruth).toContain("Session");
  });
});

/**
 * Fixed-source build-input graph: C1 source archive has no Git or sibling
 * checkout; C2 each admitted shared archive is included; C3 bytes match the
 * recorded SHA-256; C4 the consumer resolves to the archive via package/lock.
 * E1 all shared owners remain build inputs; E2 a changed/missing archive fails
 * qualification; E3 no copied reducer/UI source becomes an alternate owner.
 * R-P1 C1+C2+C3+C4 -> install/typecheck/test/build in an isolated source archive;
 * R-P2 !C2 or !C3 -> reject here. The real clean-install qualification runs the
 * same existing pnpm checks outside the worktree; this assertion keeps the
 * recorded input evidence bound to bytes on later changes.
 */
it("R-P2 binds every shared build archive to its recorded digest", () => {
  const record = readFileSync(new URL("../../../vendor/README.md", import.meta.url), "utf8");
  const rows = [...record.matchAll(/\| `([^`]+\.tgz)` \|[^\n]+\| `([a-f0-9]{64})` \|/g)];
  expect(rows.length).toBeGreaterThanOrEqual(2);
  for (const [, filename, expected] of rows) {
    const bytes = readFileSync(new URL(`../../../vendor/${filename!}`, import.meta.url));
    expect(createHash("sha256").update(bytes).digest("hex"), filename).toBe(expected);
  }
});
