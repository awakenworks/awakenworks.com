type ModelValue = string | { id?: string; effort?: string | { type?: string } } | null | undefined;

export function modelDisplay(value: ModelValue): string {
  return typeof value === "string" ? value : value?.id ?? "DeepSeek";
}

export function effortDisplay(value: ModelValue): string {
  if (typeof value !== "object" || value === null || value.effort === undefined) return "default";
  return typeof value.effort === "string" ? value.effort : value.effort.type ?? "default";
}
