import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaModelInfo } from "@anthropic-ai/sdk/resources/beta/models";
import type { SkillListResponse } from "@anthropic-ai/sdk/resources/beta/skills/skills";
import { isHarnessV1Preset, presetCatalog } from "@harness/contracts";
import { useState, type FormEvent, type ReactNode } from "react";
import type { Identity } from "../infrastructure/api";
import { modelDisplay } from "./model-display";
import type { UiPreferences } from "./preferences";
import { Modal } from "./Modal";

export function Popover({ trigger, children, label }: { trigger: ReactNode; children: ReactNode; label: string }) {
  const [open, setOpen] = useState(false);
  return <div className="popover-owner">
    <button type="button" className={`header-chip ${open ? "active" : ""}`} aria-label={label} aria-expanded={open} onClick={() => setOpen(!open)}>{trigger}</button>
    {open && <div className="popover" role="dialog" aria-label={label}>{children}</div>}
  </div>;
}

export function SessionActivity({ threads, runningTools }: { threads: Array<{ id: string; name?: string; status?: string }>; runningTools: number }) {
  const running = threads.filter((thread) => thread.status === "running").length + runningTools;
  return <Popover label="Background jobs" trigger={<><span className={running ? "activity-dot live" : "activity-dot"} /> Jobs {running || ""}</>}>
    <div className="popover-title"><strong>Background jobs</strong><small>{running ? `${running} active` : "No active jobs"}</small></div>
    {threads.map((thread) => <div className="menu-row" key={thread.id}><span>↳</span><div><strong>{thread.name ?? "Worker"}</strong><small>{thread.status ?? "inactive"} · durable child Session</small></div></div>)}
    {runningTools > 0 && <div className="menu-row"><span>&gt;_</span><div><strong>Tool execution</strong><small>{runningTools} call{runningTools === 1 ? "" : "s"} running</small></div></div>}
  </Popover>;
}

export function GoalBar({ value, onSave }: { value: string; onSave(value: string): Promise<void> }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    await onSave(draft.trim());
    setEditing(false);
  };
  if (editing) return <form className="goal-bar editing" onSubmit={(event) => void submit(event)} data-testid="goal-editor"><span>◎</span><input autoFocus maxLength={512} value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Set a durable goal" /><button>Save</button><button type="button" onClick={() => setEditing(false)}>Cancel</button></form>;
  return <button type="button" className="goal-bar" onClick={() => { setDraft(value); setEditing(true); }} data-testid="goal-bar"><span>◎</span><strong>{value || "Set session goal"}</strong><small>Edit</small></button>;
}

export function SettingsDialog({ identity, preferences, agents, models, skills, onClose, onSave, onCopyAgent, onArchiveAgent }: { identity: Identity; preferences: UiPreferences; agents: BetaManagedAgentsAgent[]; models: BetaModelInfo[]; skills: SkillListResponse[]; onClose(): void; onSave(value: Identity, preferences: UiPreferences): void; onCopyAgent(id: string, name: string): Promise<void>; onArchiveAgent(id: string): Promise<void> }) {
  const [value, setValue] = useState(identity);
  const [prefs, setPrefs] = useState(preferences);
  const [tab, setTab] = useState<"general" | "models" | "plugins" | "presets">("general");
  const [viewer, setViewer] = useState<(typeof presetCatalog)[number]>();
  const moveWorkspace = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= prefs.workspaces.length) return;
    const workspaces = [...prefs.workspaces];
    [workspaces[index]!, workspaces[target]!] = [workspaces[target]!, workspaces[index]!];
    setPrefs({ ...prefs, workspaces });
  };
  return <Modal label="Settings" className="settings-dialog" onClose={onClose}><form className="settings-shell" onSubmit={(event) => { event.preventDefault(); onSave(value, prefs); }} data-testid="settings-dialog">
    <aside className="settings-nav"><div><span className="eyebrow">DEEPSEEK HARNESS</span><h2>Settings</h2></div>
      <button type="button" className={tab === "general" ? "active" : ""} onClick={() => setTab("general")}>General</button>
      <button type="button" className={tab === "models" ? "active" : ""} onClick={() => setTab("models")}>Models</button>
      <button type="button" className={tab === "plugins" ? "active" : ""} onClick={() => setTab("plugins")}>Plugins</button>
      <button type="button" className={tab === "presets" ? "active" : ""} onClick={() => setTab("presets")}>Agent presets</button>
    </aside>
    <section className="settings-content"><div className="modal-head"><div><span className="eyebrow">{tab.toUpperCase()}</span><h2>{tab === "presets" ? "Agent presets" : tab[0]?.toUpperCase() + tab.slice(1)}</h2></div><button type="button" className="icon-button" aria-label="Close settings" onClick={onClose}>×</button></div>
      {tab === "general" && <div className="setting-sections">
        <Setting title="Cloud workspace" note="The selected connection scopes every SDK request; connection names and order are browser preferences."><label>Active Workspace<select value={value.workspaceId} onChange={(event) => setValue({ ...value, workspaceId: event.target.value })} data-testid="workspace-input"><option value="">Local workspace</option>{prefs.workspaces.map((workspace) => <option key={workspace.id} value={workspace.id}>{workspace.name}</option>)}</select></label><div className="workspace-roster">{prefs.workspaces.map((workspace, index) => <div className="settings-card" key={workspace.id}><span className="preset-glyph">▣</span><div><strong>{workspace.name}</strong><small>{workspace.id}</small></div><button type="button" onClick={() => { const name = window.prompt("Rename workspace connection", workspace.name)?.trim(); if (name) setPrefs({ ...prefs, workspaces: prefs.workspaces.map((item) => item.id === workspace.id ? { ...item, name } : item) }); }}>Rename</button><button type="button" onClick={() => moveWorkspace(index, -1)} aria-label={`Move ${workspace.name} up`}>↑</button><button type="button" onClick={() => moveWorkspace(index, 1)} aria-label={`Move ${workspace.name} down`}>↓</button><button type="button" className="danger" onClick={() => { setPrefs({ ...prefs, workspaces: prefs.workspaces.filter((item) => item.id !== workspace.id) }); if (value.workspaceId === workspace.id) setValue({ ...value, workspaceId: "" }); }}>Delete</button></div>)}</div><button type="button" className="dashed-card" onClick={() => { const id = window.prompt("Workspace ID")?.trim(); if (id && !prefs.workspaces.some((item) => item.id === id)) setPrefs({ ...prefs, workspaces: [...prefs.workspaces, { id, name: id }] }); }}>＋ Add workspace connection</button><label>Product bearer token<input type="password" value={value.token} onChange={(event) => setValue({ ...value, token: event.target.value })} placeholder="Optional in local mode" /></label></Setting>
        <Setting title="Appearance & input" note="UI preferences persist in this browser; runtime permission is applied separately to each Session."><div className="settings-grid"><label>Theme<select value={prefs.theme} onChange={(event) => setPrefs({ ...prefs, theme: event.target.value as UiPreferences["theme"] })}><option value="dark">Dark</option><option value="system">System</option><option value="light">Light</option></select></label><label>Language<select value={prefs.locale} onChange={(event) => setPrefs({ ...prefs, locale: event.target.value as UiPreferences["locale"] })}><option value="en">English</option><option value="zh">简体中文</option></select></label><label>Enter behavior<select value={prefs.enterBehavior} onChange={(event) => setPrefs({ ...prefs, enterBehavior: event.target.value as UiPreferences["enterBehavior"] })}><option value="send">Enter sends</option><option value="newline">Enter adds newline</option></select></label><label>Default permission<select value={prefs.defaultPermission} onChange={(event) => setPrefs({ ...prefs, defaultPermission: event.target.value as UiPreferences["defaultPermission"] })}><option value="safe">Safe mode</option><option value="full">Full access (confirm)</option></select></label></div></Setting>
      </div>}
      {tab === "models" && <div className="setting-sections"><Setting title="Available models" note="The SDK model catalog reports context and effort support; a running Session remains frozen to its Agent snapshot.">{models.map((model) => <div className="settings-card" key={model.id}><span className="preset-glyph">◇</span><div><strong>{model.display_name}</strong><small>{model.id} · {model.max_input_tokens?.toLocaleString() ?? "?"} context</small></div><span className="tag success">Available</span></div>)}</Setting><Setting title="Published Agents" note="Provider routes and secrets remain owned by Awaken.">{agents.map((agent) => <div className="settings-card" key={agent.id}><span className="preset-glyph">⌁</span><div><strong>{agent.name}</strong><small>{modelDisplay(agent.model)} · v{agent.version}</small></div><span className="tag success">Published</span></div>)}</Setting></div>}
      {tab === "plugins" && <div className="setting-sections"><Setting title="Installed capabilities" note="One inventory; each capability has a single runtime owner."><Plugin name="Managed Agents bridge" owner="Awaken + Anthropic SDK" status="Connected" /><Plugin name="Harness interactions" owner="Stateless MCP · plans and deliverables" status="Enabled" /><Plugin name="Code Mode / PTC" owner="Official Awaken Managed toolset" status="Enabled" /><Plugin name="Cloud sandbox" owner="Awaken Environment" status="Connected" /></Setting><Setting title="Skills" note="Live catalog from the official Skills API.">{skills.map((skill) => <div className="settings-card" key={skill.id}><span className="preset-glyph">✦</span><div><strong>{skill.display_title ?? skill.id}</strong><small>{skill.source} · {skill.latest_version ?? "unversioned"}</small></div><span className="tag success">Ready</span></div>)}</Setting></div>}
      {tab === "presets" && <div className="setting-sections"><p className="muted">System modes remain immutable after Session admission. Published Agent compositions can be revealed, copied, and copied compositions can be archived through the official Agents API.</p>{viewer ? <div className="preset-viewer"><div><button type="button" onClick={() => setViewer(undefined)}>← Back</button><strong>{viewer.name}</strong><small>Read-only composition contract</small></div><pre>{`preset: ${viewer.id}\nagent_owner: awaken\nexecution_owner: managed-session\ncapability: ${viewer.description}\nmutable_after_admission: false`}</pre></div> : <><div className="management-grid">{presetCatalog.map((preset) => { const owner = agents.find((agent) => isHarnessV1Preset(agent.metadata, preset.id)); return <div className="management-card" key={preset.id}><span className="preset-glyph">{preset.mark}</span><div><strong>{preset.name}</strong><p>{preset.description}</p><small>{owner ? `${owner.name} · v${owner.version}` : "No compatible published Agent"}</small></div><div className="card-actions"><button type="button" onClick={() => setViewer(preset)}>View</button><button type="button" disabled={!owner} onClick={() => { if (!owner) return; const name = window.prompt("Copied Agent name", `${owner.name} — ${preset.name} copy`)?.trim(); if (name) void onCopyAgent(owner.id, name); }}>Copy</button></div></div>; })}</div><h3 className="composition-heading">Published compositions</h3><div className="composition-list">{agents.map((agent) => <details className="composition" key={agent.id}><summary><span className="preset-glyph">⌁</span><span><strong>{agent.name}</strong><small>{modelDisplay(agent.model)} · v{agent.version}</small></span><span>Reveal</span></summary><pre>{JSON.stringify({ id: agent.id, model: agent.model, system: agent.system, tools: agent.tools, skills: agent.skills, multiagent: agent.multiagent, metadata: agent.metadata }, null, 2)}</pre><div><button type="button" onClick={() => { const name = window.prompt("Copied Agent name", `${agent.name} — copy`)?.trim(); if (name) void onCopyAgent(agent.id, name); }}>Copy composition</button>{agent.metadata.harness_copied_from && <button type="button" className="danger" onClick={() => { if (window.confirm(`Archive ${agent.name}?`)) void onArchiveAgent(agent.id); }}>Archive copy</button>}</div></details>)}</div><button type="button" className="dashed-card" disabled={!agents.some((agent) => isHarnessV1Preset(agent.metadata, "creator"))} onClick={() => { const owner = agents.find((agent) => isHarnessV1Preset(agent.metadata, "creator")); if (!owner) return; const name = window.prompt("Creator composition name", `${owner.name} — creator draft`)?.trim(); if (name) void onCopyAgent(owner.id, name); }}>＋ Compose with Creator</button></>}</div>}
      <div className="modal-actions"><button type="button" className="button secondary" onClick={onClose}>Cancel</button><button className="button primary">Save and reconnect</button></div>
    </section>
  </form></Modal>;
}

function Setting({ title, note, children }: { title: string; note: string; children: ReactNode }) {
  return <section className="setting"><div><h3>{title}</h3><p>{note}</p></div><div>{children}</div></section>;
}

function Plugin({ name, owner, status }: { name: string; owner: string; status: string }) {
  return <div className="settings-card"><span className="preset-glyph">⌁</span><div><strong>{name}</strong><small>{owner}</small></div><span className="tag success">{status}</span></div>;
}
