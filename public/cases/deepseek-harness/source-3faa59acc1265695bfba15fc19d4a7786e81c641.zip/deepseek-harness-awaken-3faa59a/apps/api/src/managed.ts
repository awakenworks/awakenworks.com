import Anthropic from "@anthropic-ai/sdk";
import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import type { BetaEnvironment } from "@anthropic-ai/sdk/resources/beta/environments/environments";
import type { FileMetadata } from "@anthropic-ai/sdk/resources/beta/files";
import type { BetaModelInfo } from "@anthropic-ai/sdk/resources/beta/models";
import type { SkillListResponse } from "@anthropic-ai/sdk/resources/beta/skills/skills";
import type { BetaManagedAgentsSessionEvent } from "@anthropic-ai/sdk/resources/beta/sessions/events";
import type { BetaManagedAgentsSession } from "@anthropic-ai/sdk/resources/beta/sessions/sessions";
import type { BetaManagedAgentsSessionThread } from "@anthropic-ai/sdk/resources/beta/sessions/threads/threads";
import { agentProposalSchema, type AgentProposalDecision, type CopyAgentCommand, type CreateSessionCommand, type ForkSessionCommand, type HarnessPreset, type MessageCommand, type PermissionModeCommand, type PlanReviewDecision, type ToolAnswer, type ToolDecision, type UpdateSessionCommand } from "@harness/contracts";
import { launchPrompt, sessionMcpServers, sessionTools, validatePresetCompatibility } from "./presets.js";

export const managedBetas = ["managed-agents-2026-04-01"] as const;
export const harnessApplication = "deepseek-harness-awaken";

export interface RequestContext {
  credential: string;
  workspaceId: string;
}

export function withWorkspace(fetcher: typeof fetch, workspaceId: string): typeof fetch {
  if (!workspaceId) return fetcher;
  return (async (input: RequestInfo | URL, init?: RequestInit) => {
    const request = input instanceof Request ? input : new Request(input, init);
    const url = new URL(request.url);
    if (url.pathname.startsWith("/v1/") && !url.pathname.startsWith("/v1/workspaces/")) {
      url.pathname = `/v1/workspaces/${encodeURIComponent(workspaceId)}/${url.pathname.slice(4)}`;
      return fetcher(new Request(url, request));
    }
    return fetcher(request);
  }) as typeof fetch;
}

export function createClient(
  baseURL: string,
  context: RequestContext,
  fetcher: typeof fetch = fetch,
): Anthropic {
  return new Anthropic({
    baseURL,
    apiKey: context.credential ? null : "awaken-local",
    authToken: context.credential || null,
    fetch: withWorkspace(fetcher, context.workspaceId),
  });
}

async function collect<T>(iterable: AsyncIterable<T>, maximum = 500): Promise<T[]> {
  const values: T[] = [];
  for await (const value of iterable) {
    values.push(value);
    if (values.length >= maximum) break;
  }
  return values;
}

type CustomToolUse = { id: string; name: string; input: unknown };

function customToolUse(events: readonly BetaManagedAgentsSessionEvent[], id: string, name?: string): CustomToolUse | undefined {
  return events.find((event) => {
    const value = event as unknown as { id?: string; type?: string; name?: string };
    return value.id === id && value.type === "agent.custom_tool_use" && (!name || value.name === name);
  }) as unknown as CustomToolUse | undefined;
}

function customToolSettled(events: readonly BetaManagedAgentsSessionEvent[], id: string): boolean {
  return events.some((event) => {
    const value = event as unknown as { type?: string; custom_tool_use_id?: string };
    return value.type === "user.custom_tool_result" && value.custom_tool_use_id === id;
  });
}

export class ManagedHarnessGateway {
  readonly client: Anthropic;

  constructor(
    baseURL: string,
    context: RequestContext,
    private readonly interactionMcpUrl = "",
    fetcher: typeof fetch = fetch,
  ) {
    this.client = createClient(baseURL, context, fetcher);
  }

  listAgents(): Promise<BetaManagedAgentsAgent[]> {
    return collect(this.client.beta.agents.list({ betas: [...managedBetas], limit: 100 }));
  }

  async copyAgent(id: string, command: CopyAgentCommand): Promise<BetaManagedAgentsAgent> {
    const source = await this.client.beta.agents.retrieve(id, { betas: [...managedBetas] });
    const metadata = Object.fromEntries(Object.entries(source.metadata).filter(([key]) => key !== "harness_copied_from").sort(([left], [right]) => Number(right === "harness_preset") - Number(left === "harness_preset")).slice(0, 15));
    return this.client.beta.agents.create({
      name: command.name,
      model: source.model,
      description: source.description,
      system: source.system,
      mcp_servers: source.mcp_servers,
      tools: source.tools,
      skills: source.skills,
      multiagent: source.multiagent,
      metadata: { ...metadata, harness_copied_from: source.id },
      betas: [...managedBetas],
    });
  }

  archiveAgent(id: string): Promise<BetaManagedAgentsAgent> {
    return this.client.beta.agents.archive(id, { betas: [...managedBetas] });
  }

  listEnvironments(): Promise<BetaEnvironment[]> {
    return collect(this.client.beta.environments.list({ betas: [...managedBetas], limit: 100 }));
  }

  listModels(): Promise<BetaModelInfo[]> {
    return collect(this.client.beta.models.list({ betas: [...managedBetas], limit: 100 }));
  }

  listSkills(): Promise<SkillListResponse[]> {
    return collect(this.client.beta.skills.list({ betas: ["skills-2025-10-02"], limit: 100 }));
  }

  listSessions(): Promise<BetaManagedAgentsSession[]> {
    return collect(this.client.beta.sessions.list({ betas: [...managedBetas], order: "desc", limit: 100 }))
      .then((sessions) => sessions.filter((session) => session.metadata.application === harnessApplication));
  }

  async createSession(command: CreateSessionCommand): Promise<BetaManagedAgentsSession> {
    const agent = await this.client.beta.agents.retrieve(command.agentId, {
      version: command.agentVersion,
      betas: [...managedBetas],
    });
    validatePresetCompatibility(agent, command.preset);
    const mcpServers = sessionMcpServers(agent, this.interactionMcpUrl);
    const tools = sessionTools(agent, command.preset, command.mode, command.permission, this.interactionMcpUrl);
    return this.client.beta.sessions.create({
      title: command.title,
      agent: {
        id: agent.id,
        type: "agent_with_overrides",
        version: agent.version,
        mcp_servers: mcpServers,
        tools,
      },
      environment_id: command.environmentId,
      metadata: {
        application: harnessApplication,
        harness_contract: "v1",
        harness_preset: command.preset,
        harness_mode: command.mode,
      },
      initial_events: [{
        type: "user.message",
        content: [{ type: "text", text: launchPrompt(command.preset, command.mode, command.prompt) }],
      }],
      betas: [...managedBetas],
    });
  }

  getSession(id: string): Promise<BetaManagedAgentsSession> {
    return this.client.beta.sessions.retrieve(id, { betas: [...managedBetas] });
  }

  updateSession(id: string, command: UpdateSessionCommand): Promise<BetaManagedAgentsSession> {
    return this.client.beta.sessions.update(id, {
      ...(command.title !== undefined ? { title: command.title } : {}),
      ...(command.metadata !== undefined ? { metadata: command.metadata } : {}),
      betas: [...managedBetas],
    });
  }

  async forkSession(id: string, command: ForkSessionCommand): Promise<BetaManagedAgentsSession> {
    const [source, allEvents] = await Promise.all([this.getSession(id), this.listEvents(id)]);
    const boundary = command.throughEventId ? allEvents.findIndex((event) => event.id === command.throughEventId) : allEvents.length - 1;
    if (command.throughEventId && boundary < 0) throw Object.assign(new Error("Fork boundary event not found"), { status: 404 });
    const transcript = allEvents.slice(0, boundary + 1).flatMap((event) => {
      const value = event as unknown as { type: string; name?: string; input?: unknown; content?: unknown; result?: unknown; is_error?: boolean };
      const text = Array.isArray(value.content) ? value.content.flatMap((block) => typeof block === "object" && block !== null && "type" in block && block.type === "text" && "text" in block && typeof block.text === "string" ? [block.text] : []).join("\n") : "";
      if (value.type === "user.message" || value.type === "agent.message") return text ? [`${value.type === "user.message" ? "User" : "Assistant"}: ${text}`] : [];
      if (value.type.includes("tool_use")) return [`Tool call: ${value.name ?? value.type} ${JSON.stringify(value.input ?? {})}`];
      if (value.type.includes("tool_result")) return [`Tool result (${value.is_error ? "error" : "ok"}): ${text}`];
      if (value.type === "user.tool_confirmation") return [`Tool decision: ${JSON.stringify(event)}`];
      return [];
    }).join("\n\n").slice(-80_000);
    const metadataPriority = ["application", "harness_contract", "harness_preset", "harness_mode", "harness_goal"];
    const inheritedMetadata = Object.fromEntries(Object.entries(source.metadata)
      .filter(([key]) => key !== "harness_queue" && key !== "harness_order" && !key.startsWith("feedback_"))
      .sort(([left], [right]) => {
        const leftRank = metadataPriority.indexOf(left);
        const rightRank = metadataPriority.indexOf(right);
        return (leftRank < 0 ? metadataPriority.length : leftRank) - (rightRank < 0 ? metadataPriority.length : rightRank);
      }).slice(0, 14));
    return this.client.beta.sessions.create({
      title: command.title,
      agent: { id: source.agent.id, version: source.agent.version, type: "agent_with_overrides", mcp_servers: source.agent.mcp_servers, tools: source.agent.tools },
      environment_id: source.environment_id,
      metadata: { ...inheritedMetadata, harness_forked_from: id, harness_fork_boundary: command.throughEventId ?? "tail" },
      initial_events: [{ type: "user.message", content: [{ type: "text", text: `Continue from this committed Session branch. Preserve decisions but independently verify future work.\n\n<branched_transcript>\n${transcript}\n</branched_transcript>` }] }],
      betas: [...managedBetas],
    });
  }

  async setPermissionMode(id: string, command: PermissionModeCommand): Promise<BetaManagedAgentsSession> {
    const session = await this.getSession(id);
    const preset = session.metadata.harness_preset as HarnessPreset;
    const mode = session.metadata.harness_mode === "plan" ? "plan" : "execute";
    const source = await this.client.beta.agents.retrieve(session.agent.id, { version: session.agent.version, betas: [...managedBetas] });
    validatePresetCompatibility(source, preset);
    const tools = sessionTools(source, preset, mode, command.mode, this.interactionMcpUrl);
    return this.client.beta.sessions.update(id, {
      agent: { tools }, betas: [...managedBetas],
    });
  }

  async decideAgentProposal(id: string, command: AgentProposalDecision): Promise<BetaManagedAgentsAgent | undefined> {
    const [session, events] = await Promise.all([this.getSession(id), this.listEvents(id)]);
    if (session.metadata.harness_preset !== "creator") throw Object.assign(new Error("Agent proposals require a Creator Session"), { status: 409 });
    const use = customToolUse(events, command.toolUseId, "agent_proposal");
    if (!use) throw Object.assign(new Error("Pending Agent proposal not found"), { status: 404 });
    if (customToolSettled(events, command.toolUseId)) return undefined;

    if (command.decision !== "approve") {
      await this.sendCustomToolResult(id, {
        toolUseId: command.toolUseId,
        text: JSON.stringify({ decision: command.decision, ...(command.feedback ? { feedback: command.feedback } : {}) }),
        cancelled: command.decision === "cancel",
      });
      return undefined;
    }

    const parsed = agentProposalSchema.safeParse(use.input);
    if (!parsed.success) throw Object.assign(new Error("Invalid Agent proposal"), { status: 400, issues: parsed.error.issues });
    const proposal = parsed.data;
    const marker = `${id}:${command.toolUseId}`.slice(-512);
    let created = (await this.listAgents()).find((agent) => agent.metadata.harness_proposal_id === marker);
    if (!created) {
      const source = await this.client.beta.agents.retrieve(proposal.baseAgentId, { version: proposal.baseAgentVersion, betas: [...managedBetas] });
      const metadata = Object.fromEntries(Object.entries(source.metadata)
        .filter(([key]) => !["harness_copied_from", "harness_proposal_id"].includes(key))
        .sort(([left], [right]) => Number(right === "harness_preset") - Number(left === "harness_preset"))
        .slice(0, 14));
      created = await this.client.beta.agents.create({
        name: proposal.name,
        model: source.model,
        description: proposal.description ?? source.description,
        system: proposal.system ?? source.system,
        mcp_servers: source.mcp_servers,
        tools: source.tools,
        skills: source.skills,
        multiagent: source.multiagent,
        metadata: { ...metadata, harness_copied_from: source.id, harness_proposal_id: marker },
        betas: [...managedBetas],
      });
    }
    await this.sendCustomToolResult(id, {
      toolUseId: command.toolUseId,
      text: JSON.stringify({ decision: "approve", agent_id: created.id, version: created.version }),
      cancelled: false,
    });
    return created;
  }

  async decidePlanReview(id: string, command: PlanReviewDecision): Promise<void> {
    const [session, events] = await Promise.all([this.getSession(id), this.listEvents(id)]);
    if (session.metadata.harness_mode !== "plan") throw Object.assign(new Error("Plan review requires a Plan-first Session"), { status: 409 });
    const use = customToolUse(events, command.toolUseId, "review_plan");
    if (!use) throw Object.assign(new Error("Pending Plan review not found"), { status: 404 });
    if (customToolSettled(events, command.toolUseId)) return;
    const review = use.input as { plan_id?: unknown; revision?: unknown } | undefined;
    if (typeof review?.plan_id !== "string" || !Number.isInteger(review.revision) || Number(review.revision) < 1) {
      throw Object.assign(new Error("Invalid Plan review correlation"), { status: 409 });
    }
    const planCommitted = events.some((event) => {
      const value = event as unknown as { id?: string; type?: string; name?: string; input?: { plan_id?: unknown; revision?: unknown } };
      if (value.type !== "agent.mcp_tool_use" || value.name !== "mcp__harness__set_plan") return false;
      if (value.input?.plan_id !== review.plan_id || value.input?.revision !== review.revision) return false;
      return events.some((candidate) => {
        const result = candidate as unknown as { type?: string; mcp_tool_use_id?: string; is_error?: boolean };
        return result.type === "agent.mcp_tool_result" && result.mcp_tool_use_id === value.id && result.is_error !== true;
      });
    });
    if (!planCommitted) throw Object.assign(new Error("Plan review does not match a committed Plan revision"), { status: 409 });
    await this.sendCustomToolResult(id, {
      toolUseId: command.toolUseId,
      text: JSON.stringify({ decision: command.decision, ...(command.feedback ? { feedback: command.feedback } : {}) }),
      cancelled: command.decision === "cancel",
    });
  }

  listEvents(id: string): Promise<BetaManagedAgentsSessionEvent[]> {
    return collect(this.client.beta.sessions.events.list(id, {
      betas: [...managedBetas], order: "asc", limit: 100,
    }));
  }

  async followEvents(id: string, receive: (event: unknown) => void, signal: AbortSignal): Promise<void> {
    const stream = await this.client.beta.sessions.events.stream(id, {
      betas: [...managedBetas],
      event_deltas: ["agent.message", "agent.thinking"],
    }, { signal });
    for await (const event of stream) receive(event);
  }

  async sendMessage(id: string, command: MessageCommand): Promise<void> {
    await this.client.beta.sessions.events.send(id, {
      events: [{ type: "user.message", content: [
        ...command.images.map((image) => ({ type: "image" as const, source: { type: "base64" as const, media_type: image.mediaType, data: image.data } })),
        { type: "text", text: command.text },
      ] }],
      betas: [...managedBetas],
    });
  }

  async interrupt(id: string): Promise<void> {
    await this.client.beta.sessions.events.send(id, {
      events: [{ type: "user.interrupt" }],
      betas: [...managedBetas],
    });
  }

  async decide(id: string, decision: ToolDecision): Promise<void> {
    await this.client.beta.sessions.events.send(id, {
      events: [{
        type: "user.tool_confirmation",
        tool_use_id: decision.toolUseId,
        result: decision.allow ? "allow" : "deny",
        ...(!decision.allow && decision.reason ? { deny_message: decision.reason } : {}),
        ...(decision.sessionThreadId ? { session_thread_id: decision.sessionThreadId } : {}),
      }],
      betas: [...managedBetas],
    });
  }

  private async sendCustomToolResult(id: string, answer: ToolAnswer): Promise<void> {
    await this.client.beta.sessions.events.send(id, {
      events: [{
        type: "user.custom_tool_result",
        custom_tool_use_id: answer.toolUseId,
        content: [{ type: "text", text: answer.text }],
        is_error: answer.cancelled,
      }],
      betas: [...managedBetas],
    });
  }

  async answerTool(id: string, answer: ToolAnswer): Promise<void> {
    const events = await this.listEvents(id);
    const use = customToolUse(events, answer.toolUseId);
    if (!use) throw Object.assign(new Error("Pending custom tool interaction not found"), { status: 404 });
    if (["review_plan", "agent_proposal"].includes(use.name)) {
      throw Object.assign(new Error(`${use.name} requires its protected decision endpoint`), { status: 409 });
    }
    if (customToolSettled(events, answer.toolUseId)) return;
    await this.sendCustomToolResult(id, answer);
  }

  listThreads(id: string): Promise<BetaManagedAgentsSessionThread[]> {
    return collect(this.client.beta.sessions.threads.list(id, { betas: [...managedBetas], limit: 100 }));
  }

  listThreadEvents(sessionId: string, threadId: string): Promise<BetaManagedAgentsSessionEvent[]> {
    return collect(this.client.beta.sessions.threads.events.list(threadId, { session_id: sessionId, betas: [...managedBetas], limit: 100 }));
  }

  archiveThread(sessionId: string, threadId: string): Promise<BetaManagedAgentsSessionThread> {
    return this.client.beta.sessions.threads.archive(threadId, { session_id: sessionId, betas: [...managedBetas] });
  }

  listArtifacts(id: string): Promise<FileMetadata[]> {
    return collect(this.client.beta.files.list({ scope_id: id, betas: [...managedBetas], limit: 100 }));
  }

  async downloadArtifact(sessionId: string, fileId: string): Promise<{ file: FileMetadata; response: Response } | undefined> {
    const file = (await this.listArtifacts(sessionId)).find((candidate) => candidate.id === fileId);
    if (!file || file.downloadable === false) return undefined;
    return {
      file,
      response: await this.client.beta.files.download(fileId, { betas: [...managedBetas] }),
    };
  }

  async archive(id: string): Promise<void> {
    await this.client.beta.sessions.archive(id, { betas: [...managedBetas] });
  }
}
