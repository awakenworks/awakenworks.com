import express, { type NextFunction, type Request, type Response } from "express";
import { agentProposalDecisionSchema, copyAgentSchema, createSessionSchema, decisionSchema, forkSessionSchema, messageSchema, parseWith, permissionModeSchema, planReviewDecisionSchema, toolAnswerSchema, updateSessionSchema, workspaceHeader } from "@harness/contracts";
import type { ApiConfig } from "./config.js";
import { ManagedHarnessGateway, type RequestContext } from "./managed.js";

function routeId(request: Request, name = "id"): string {
  const value = request.params[name];
  if (typeof value !== "string" || !value) throw Object.assign(new Error(`Missing ${name}`), { status: 400 });
  return value;
}

function requestContext(config: ApiConfig, request: Request): RequestContext {
  const authorization = request.header("authorization");
  const match = authorization?.match(/^Bearer ([^\s]+)$/);
  if (authorization && !match?.[1]) throw Object.assign(new Error("Invalid bearer credential"), { status: 401 });
  const credential = match?.[1] ?? config.serviceToken;
  const workspaceId = request.header(workspaceHeader)?.trim() || config.defaultWorkspaceId;
  if (workspaceId.length > 500 || /[\x00-\x1f/\\]/.test(workspaceId)) {
    throw Object.assign(new Error("Invalid workspace"), { status: 400 });
  }
  if (config.requireIdentity && (!credential || !workspaceId)) {
    throw Object.assign(new Error("Authentication and Workspace are required"), { status: 401 });
  }
  return { credential, workspaceId };
}

function status(error: unknown): number {
  if (typeof error !== "object" || error === null || !("status" in error)) return 502;
  const value = Number(error.status);
  return Number.isInteger(value) && value >= 400 && value <= 599 ? value : 502;
}

export function createApp(
  config: ApiConfig,
  gatewayFactory: (context: RequestContext) => ManagedHarnessGateway =
    (context) => new ManagedHarnessGateway(config.awakenApiUrl, context, config.interactionMcpUrl),
): express.Express {
  const app = express();
  app.disable("x-powered-by");
  app.use(express.json({ limit: "1mb" }));
  const gateway = (request: Request) => gatewayFactory(requestContext(config, request));

  app.get("/healthz", (_request, response) => response.json({ status: "ok", service: "deepseek-harness-awaken" }));
  app.get("/api/catalog/agents", async (request, response) => response.json(await gateway(request).listAgents()));
  app.post("/api/catalog/agents/:id/copy", async (request, response) => response.status(201).json(await gateway(request).copyAgent(routeId(request), parseWith(copyAgentSchema, request.body))));
  app.post("/api/catalog/agents/:id/archive", async (request, response) => response.json(await gateway(request).archiveAgent(routeId(request))));
  app.get("/api/catalog/environments", async (request, response) => response.json(await gateway(request).listEnvironments()));
  app.get("/api/catalog/models", async (request, response) => response.json(await gateway(request).listModels()));
  app.get("/api/catalog/skills", async (request, response) => response.json(await gateway(request).listSkills()));
  app.get("/api/sessions", async (request, response) => response.json(await gateway(request).listSessions()));
  app.post("/api/sessions", async (request, response) => {
    response.status(201).json(await gateway(request).createSession(parseWith(createSessionSchema, request.body)));
  });
  app.get("/api/sessions/:id", async (request, response) => response.json(await gateway(request).getSession(routeId(request))));
  app.patch("/api/sessions/:id", async (request, response) => {
    response.json(await gateway(request).updateSession(routeId(request), parseWith(updateSessionSchema, request.body)));
  });
  app.post("/api/sessions/:id/fork", async (request, response) => {
    response.status(201).json(await gateway(request).forkSession(routeId(request), parseWith(forkSessionSchema, request.body)));
  });
  app.post("/api/sessions/:id/permission", async (request, response) => {
    response.json(await gateway(request).setPermissionMode(routeId(request), parseWith(permissionModeSchema, request.body)));
  });
  app.get("/api/sessions/:id/events", async (request, response) => response.json(await gateway(request).listEvents(routeId(request))));
  app.get("/api/sessions/:id/events/stream", async (request, response) => {
    const controller = new AbortController();
    response.status(200).set({
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "Content-Type": "text/event-stream; charset=utf-8",
    });
    response.flushHeaders();
    response.write(": connected\n\n");
    const heartbeat = setInterval(() => response.write(": heartbeat\n\n"), 15_000);
    const close = () => controller.abort();
    response.once("close", close);
    try {
      await gateway(request).followEvents(routeId(request), (event) => {
        response.write(`data: ${JSON.stringify(event)}\n\n`);
      }, controller.signal);
    } catch {
      // Committed history is the recovery authority after a stream failure.
    } finally {
      clearInterval(heartbeat);
      response.off("close", close);
      if (!response.writableEnded) response.end();
    }
  });
  app.post("/api/sessions/:id/messages", async (request, response) => {
    await gateway(request).sendMessage(routeId(request), parseWith(messageSchema, request.body));
    response.status(204).end();
  });
  app.post("/api/sessions/:id/interrupt", async (request, response) => {
    await gateway(request).interrupt(routeId(request));
    response.status(204).end();
  });
  app.post("/api/sessions/:id/decisions", async (request, response) => {
    await gateway(request).decide(routeId(request), parseWith(decisionSchema, request.body));
    response.status(204).end();
  });
  app.post("/api/sessions/:id/tool-answers", async (request, response) => {
    await gateway(request).answerTool(routeId(request), parseWith(toolAnswerSchema, request.body));
    response.status(204).end();
  });
  app.post("/api/sessions/:id/plan-reviews", async (request, response) => {
    const command = parseWith(planReviewDecisionSchema, request.body);
    await gateway(request).decidePlanReview(routeId(request), command);
    response.json({ decision: command.decision });
  });
  app.post("/api/sessions/:id/agent-proposals", async (request, response) => {
    const command = parseWith(agentProposalDecisionSchema, request.body);
    const agent = await gateway(request).decideAgentProposal(routeId(request), command);
    response.json({ decision: command.decision, ...(agent ? { agent } : {}) });
  });
  app.get("/api/sessions/:id/threads", async (request, response) => response.json(await gateway(request).listThreads(routeId(request))));
  app.get("/api/sessions/:id/threads/:threadId/events", async (request, response) => response.json(await gateway(request).listThreadEvents(routeId(request), routeId(request, "threadId"))));
  app.post("/api/sessions/:id/threads/:threadId/archive", async (request, response) => response.json(await gateway(request).archiveThread(routeId(request), routeId(request, "threadId"))));
  app.get("/api/sessions/:id/artifacts", async (request, response) => response.json(await gateway(request).listArtifacts(routeId(request))));
  app.get("/api/sessions/:id/artifacts/:fileId/content", async (request, response) => {
    const artifact = await gateway(request).downloadArtifact(routeId(request), routeId(request, "fileId"));
    if (!artifact) throw Object.assign(new Error("Artifact not found"), { status: 404 });
    response.set({
      "Content-Type": artifact.response.headers.get("content-type") ?? "application/octet-stream",
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(artifact.file.filename)}`,
    });
    response.send(Buffer.from(await artifact.response.arrayBuffer()));
  });
  app.post("/api/sessions/:id/archive", async (request, response) => {
    await gateway(request).archive(routeId(request));
    response.status(204).end();
  });

  if (config.webDist) {
    app.use(express.static(config.webDist));
    app.get("*path", (_request, response) => response.sendFile("index.html", { root: config.webDist }));
  }

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    const message = error instanceof Error && status(error) < 500 ? error.message : "Awaken request failed";
    const issues = typeof error === "object" && error !== null && "issues" in error ? error.issues : undefined;
    response.status(status(error)).json({ error: message, ...(issues ? { issues } : {}) });
  });
  return app;
}
