import { describe, expect, it } from "vitest";
import { createClient, ManagedHarnessGateway, managedBetas, withWorkspace } from "./managed.js";

describe("Managed Agents SDK boundary", () => {
  /**
   * Cause/effect decision R1: Workspace is selected and the SDK emits /v1/sessions.
   * Effect: exactly one path rewrite scopes the canonical request; auth remains SDK-owned.
   */
  it("scopes official SDK requests to one Workspace", async () => {
    let captured: Request | undefined;
    const fetcher: typeof fetch = async (input, init) => {
      captured = input instanceof Request ? input : new Request(input, init);
      return new Response(JSON.stringify({ data: [], has_more: false }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    };
    const client = createClient("https://awaken.example.test", {
      credential: "user-token",
      workspaceId: "workspace-a",
    }, fetcher);
    for await (const _session of client.beta.sessions.list({ betas: [...managedBetas], limit: 1 })) {
      // Empty fixture.
    }
    expect(captured?.url).toBe("https://awaken.example.test/v1/workspaces/workspace-a/sessions?beta=true&limit=1");
    expect(captured?.headers.get("authorization")).toBe("Bearer user-token");
  });

  /**
   * Decision R2: an already scoped extension path enters the fetch seam.
   * Constraint: never scope twice. Effect: the original path is preserved.
   */
  it("does not double-scope an existing Workspace path", async () => {
    let url = "";
    const scoped = withWorkspace(async (input) => {
      url = input instanceof Request ? input.url : String(input);
      return new Response();
    }, "workspace-a");
    await scoped("https://awaken.example.test/v1/workspaces/workspace-b/sessions");
    expect(url).toContain("/v1/workspaces/workspace-b/sessions");
  });

  /**
   * Cause/effect decision table — R3: a compatible Standard Session switches
   * from Safe to Full. The pinned published Agent remains the policy source;
   * native and MCP overrides become always_allow while custom tools stay
   * policy-free. Effect: one official Session update replaces its effective
   * tools, and no permission metadata is written as a second source of truth.
   */
  it("updates every mutable Session tool policy through the SDK", async () => {
    let update: Record<string, unknown> | undefined;
    const tools = [
        { type: "agent_toolset_20260401", default_config: { enabled: true, permission_policy: { type: "always_ask" } }, configs: [{ name: "bash", enabled: true, permission_policy: { type: "always_ask" } }] },
        { type: "mcp_toolset", mcp_server_name: "files", default_config: { enabled: true, permission_policy: { type: "always_ask" } }, configs: [{ name: "read", enabled: true, permission_policy: { type: "always_ask" } }] },
        { type: "custom", name: "question", description: "Ask", input_schema: { type: "object" } },
    ];
    const sourceSession = {
      id: "session-a", environment_id: "env-a", metadata: { harness_preset: "standard", harness_mode: "execute" },
      agent: { id: "agent-a", version: 1, tools },
    };
    const sourceAgent = {
      id: "agent-a", name: "Standard", version: 1, metadata: { harness_preset: "standard", harness_contract: "v1" },
      model: "deepseek/deepseek-chat", system: "Use the canonical path", description: "Standard Agent", mcp_servers: [], tools,
      skills: [{ type: "custom", skill_id: "testing", version: "1" }], multiagent: { type: "coordinator", agents: [{ type: "self" }] },
    };
    const fetcher: typeof fetch = async (input) => {
      const request = input instanceof Request ? input : new Request(input);
      if (request.method === "POST") update = await request.json() as Record<string, unknown>;
      const value = new URL(request.url).pathname.endsWith("/agents/agent-a") ? sourceAgent : sourceSession;
      return new Response(JSON.stringify(value), { status: 200, headers: { "Content-Type": "application/json" } });
    };
    const gateway = new ManagedHarnessGateway("https://awaken.example.test", { credential: "token", workspaceId: "workspace-a" }, "", fetcher);
    await gateway.setPermissionMode("session-a", { mode: "full", acknowledgedRisk: true });
    const updatedTools = ((update?.agent as { tools?: Array<Record<string, unknown>> } | undefined)?.tools ?? []);
    expect((updatedTools[0]?.default_config as { permission_policy?: { type?: string } }).permission_policy?.type).toBe("always_allow");
    expect(((updatedTools[1]?.configs as Array<{ permission_policy?: { type?: string } }>)[0]?.permission_policy?.type)).toBe("always_allow");
    expect(updatedTools[2]?.type).toBe("custom");
    expect(update).not.toHaveProperty("metadata");
  });

  /**
   * Cause/effect rule R3b: a compatible Code Agent, Full permission with risk
   * acknowledgement, and Execute mode are admitted together. Effect: the only
   * mutation is sessions.create and its frozen override already contains the
   * effective always_allow policy; no post-create policy patch can race Worker
   * dispatch.
   */
  it("admits preset and Full permission atomically in one Session create", async () => {
    const mutations: Array<{ path: string; body: Record<string, unknown> }> = [];
    const sourceAgent = {
      id: "agent-code", type: "agent", name: "Code", version: 2, description: "Code Agent",
      model: "deepseek/deepseek-chat", system: "Use official tools", mcp_servers: [],
      tools: [{
        type: "agent_toolset_20260401",
        default_config: { enabled: false, permission_policy: { type: "always_ask" } },
        configs: ["bash", "read", "write", "edit", "glob", "grep"].map((name) => ({ name, enabled: true, permission_policy: { type: "always_ask" } })),
      }],
      skills: [], multiagent: null, metadata: { harness_preset: "code", harness_contract: "v1" },
      archived_at: null, created_at: "2026-08-15T00:00:00Z", updated_at: "2026-08-15T00:00:00Z",
    };
    const fetcher: typeof fetch = async (input) => {
      const request = input instanceof Request ? input : new Request(input);
      const path = new URL(request.url).pathname;
      if (request.method === "POST") {
        const body = await request.json() as Record<string, unknown>;
        mutations.push({ path, body });
        return new Response(JSON.stringify({ id: "session-code", ...body, status: "idle" }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify(sourceAgent), { status: 200, headers: { "Content-Type": "application/json" } });
    };
    const gateway = new ManagedHarnessGateway("https://awaken.example.test", { credential: "token", workspaceId: "workspace-a" }, "", fetcher);
    await gateway.createSession({
      title: "Atomic Code", prompt: "Inspect", agentId: sourceAgent.id, agentVersion: 2,
      environmentId: "env-a", preset: "code", mode: "execute", permission: "full", acknowledgedRisk: true,
    });
    expect(mutations).toHaveLength(1);
    expect(mutations[0]?.path).toMatch(/\/sessions$/);
    const tools = ((mutations[0]?.body.agent as { tools?: Array<Record<string, unknown>> }).tools ?? []);
    expect((tools[0]?.default_config as { permission_policy?: { type?: string } }).permission_policy?.type).toBe("always_allow");
    expect(mutations[0]?.body.metadata).toEqual(expect.objectContaining({ harness_contract: "v1", harness_preset: "code", harness_mode: "execute" }));
  });

  /**
   * Cause/effect decision table — R4: an existing committed message boundary is
   * requested for a branch. Effects: the gateway reads source plus ordered facts,
   * creates exactly one new Session against the same frozen Agent/Environment,
   * and records source/boundary metadata; an unknown boundary terminates with 404
   * and creates nothing.
   */
  it("creates an exact-boundary Session branch and rejects unknown boundaries", async () => {
    const creates: Array<Record<string, unknown>> = [];
    const source = { id: "session-a", environment_id: "env-a", metadata: { application: "deepseek-harness-awaken" }, agent: { id: "agent-a", version: 3 } };
    const fetcher: typeof fetch = async (input) => {
      const request = input instanceof Request ? input : new Request(input);
      const path = new URL(request.url).pathname;
      if (request.method === "POST" && path.endsWith("/sessions")) {
        creates.push(await request.json() as Record<string, unknown>);
        return new Response(JSON.stringify({ id: "session-branch" }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      if (path.endsWith("/events")) return new Response(JSON.stringify({ data: [
        { id: "u1", type: "user.message", content: [{ type: "text", text: "Inspect" }] },
        { id: "a1", type: "agent.message", content: [{ type: "text", text: "Found it" }] },
        { id: "later", type: "agent.message", content: [{ type: "text", text: "Do not include" }] },
      ], has_more: false }), { status: 200, headers: { "Content-Type": "application/json" } });
      return new Response(JSON.stringify(source), { status: 200, headers: { "Content-Type": "application/json" } });
    };
    const gateway = new ManagedHarnessGateway("https://awaken.example.test", { credential: "token", workspaceId: "workspace-a" }, "", fetcher);
    await gateway.forkSession("session-a", { title: "Focused branch", throughEventId: "a1" });
    expect(creates).toHaveLength(1);
    expect(creates[0]?.metadata).toEqual(expect.objectContaining({ harness_forked_from: "session-a", harness_fork_boundary: "a1" }));
    expect(JSON.stringify(creates[0]?.initial_events)).toContain("Found it");
    expect(JSON.stringify(creates[0]?.initial_events)).not.toContain("Do not include");
    await expect(gateway.forkSession("session-a", { title: "Invalid", throughEventId: "missing" })).rejects.toMatchObject({ status: 404 });
    expect(creates).toHaveLength(1);
  });

  /**
   * Cause/effect decision table — R5: a published Agent with model, tools, Skills,
   * MCP and coordinator topology is copied under a new name. Effects: one official
   * Agents create call preserves the composition, assigns copy provenance, and
   * remains within the 16-pair metadata limit; source identity/version are not
   * reused as a second mutable alias.
   */
  it("copies a complete Agent composition through the SDK", async () => {
    let create: Record<string, unknown> | undefined;
    const source = {
      id: "agent-source", version: 4, name: "Source", description: "Cloud coder",
      model: { id: "deepseek/deepseek-chat", effort: { type: "high" } }, system: "Be precise",
      mcp_servers: [{ name: "files", type: "url", url: "https://mcp.example.test" }],
      tools: [{ type: "mcp_toolset", mcp_server_name: "files", default_config: { enabled: true, permission_policy: { type: "always_ask" } }, configs: [] }],
      skills: [{ type: "custom", skill_id: "skill-testing", version: "1" }], multiagent: { type: "coordinator", agents: [{ type: "self" }] },
      metadata: Object.fromEntries(Array.from({ length: 16 }, (_, index) => [`key_${index}`, `value_${index}`])),
    };
    const fetcher: typeof fetch = async (input) => {
      const request = input instanceof Request ? input : new Request(input);
      if (request.method === "POST") {
        create = await request.json() as Record<string, unknown>;
        return new Response(JSON.stringify({ ...source, ...create, id: "agent-copy", version: 1 }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify(source), { status: 200, headers: { "Content-Type": "application/json" } });
    };
    const gateway = new ManagedHarnessGateway("https://awaken.example.test", { credential: "token", workspaceId: "workspace-a" }, "", fetcher);
    await gateway.copyAgent("agent-source", { name: "Focused copy" });
    expect(create).toEqual(expect.objectContaining({ name: "Focused copy", model: source.model, tools: source.tools, skills: source.skills }));
    expect(create?.metadata).toEqual(expect.objectContaining({ harness_copied_from: "agent-source" }));
    expect(Object.keys(create?.metadata as Record<string, string>)).toHaveLength(16);
    expect(create).not.toHaveProperty("id");
    expect(create).not.toHaveProperty("version");
  });

  /**
   * Cause/effect decision rule R6: one pending Creator proposal is approved,
   * then the same command is retried after its correlated result commits.
   * Effects: the first call publishes one official Agent and records its ID;
   * the replay observes the Session log and performs no second publication.
   */
  it("publishes an approved Creator proposal once and settles it by correlation", async () => {
    let agentCreates = 0;
    let resultSends = 0;
    const eventRows: Array<Record<string, unknown>> = [{
      id: "proposal-1", type: "agent.custom_tool_use", name: "agent_proposal",
      input: { baseAgentId: "agent-base", baseAgentVersion: 4, name: "Reviewed Agent", system: "Stay bounded" },
    }];
    const session = { id: "session-creator", metadata: { harness_preset: "creator" }, agent: { id: "agent-creator", version: 1 } };
    const base = {
      id: "agent-base", type: "agent", version: 4, name: "Base", description: "Base Agent",
      model: "deepseek/deepseek-chat", system: "Base system", mcp_servers: [], tools: [], skills: [], multiagent: null,
      metadata: { harness_preset: "code", harness_contract: "v1" }, archived_at: null,
      created_at: "2026-08-15T00:00:00Z", updated_at: "2026-08-15T00:00:00Z",
    };
    const fetcher: typeof fetch = async (input) => {
      const request = input instanceof Request ? input : new Request(input);
      const path = new URL(request.url).pathname;
      if (request.method === "GET" && path.endsWith("/sessions/session-creator")) return new Response(JSON.stringify(session), { status: 200, headers: { "Content-Type": "application/json" } });
      if (request.method === "GET" && path.endsWith("/sessions/session-creator/events")) return new Response(JSON.stringify({ data: eventRows, has_more: false }), { status: 200, headers: { "Content-Type": "application/json" } });
      if (request.method === "GET" && path.endsWith("/agents")) return new Response(JSON.stringify({ data: [], has_more: false }), { status: 200, headers: { "Content-Type": "application/json" } });
      if (request.method === "GET" && path.endsWith("/agents/agent-base")) return new Response(JSON.stringify(base), { status: 200, headers: { "Content-Type": "application/json" } });
      if (request.method === "POST" && path.endsWith("/agents")) {
        agentCreates += 1;
        return new Response(JSON.stringify({ ...base, ...await request.json() as object, id: "agent-reviewed", version: 1 }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      if (request.method === "POST" && path.endsWith("/sessions/session-creator/events")) {
        resultSends += 1;
        const body = await request.json() as { events: Array<Record<string, unknown>> };
        eventRows.push({ id: "proposal-result", ...body.events[0] });
        return new Response(JSON.stringify({ accepted: true }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      return new Response(JSON.stringify({ error: { message: "unexpected request" } }), { status: 404, headers: { "Content-Type": "application/json" } });
    };
    const gateway = new ManagedHarnessGateway("https://awaken.example.test", { credential: "token", workspaceId: "workspace-a" }, "", fetcher);
    const command = { toolUseId: "proposal-1", decision: "approve" as const };
    const created = await gateway.decideAgentProposal("session-creator", command);
    const replay = await gateway.decideAgentProposal("session-creator", command);
    expect(created?.id).toBe("agent-reviewed");
    expect(replay).toBeUndefined();
    expect(agentCreates).toBe(1);
    expect(resultSends).toBe(1);
    expect(JSON.stringify(eventRows.at(-1))).toContain("agent-reviewed");
  });

  /**
   * Cause/effect decision table — R7: an invalid attempt and a later committed
   * attempt may share one Plan revision; review accepts the successfully
   * correlated attempt, while a generic-answer bypass or revision drift fails.
   * Effects: only the matching protected command sends one result; retry history
   * cannot make a committed revision look uncommitted.
   */
  it("protects Plan review and validates its committed revision", async () => {
    let sends = 0;
    const reviewInput: { plan_id: string; revision: number } = { plan_id: "plan-a", revision: 1 };
    const rows = [
      { id: "plan-failed-use", type: "agent.mcp_tool_use", name: "mcp__harness__set_plan", input: { plan_id: "plan-a", revision: 1 } },
      { id: "plan-failed-result", type: "agent.mcp_tool_result", mcp_tool_use_id: "plan-failed-use", is_error: true },
      { id: "plan-use", type: "agent.mcp_tool_use", name: "mcp__harness__set_plan", input: { plan_id: "plan-a", revision: 1 } },
      { id: "plan-result", type: "agent.mcp_tool_result", mcp_tool_use_id: "plan-use", is_error: false },
      { id: "review-use", type: "agent.custom_tool_use", name: "review_plan", input: reviewInput },
    ];
    const fetcher: typeof fetch = async (input) => {
      const request = input instanceof Request ? input : new Request(input);
      const path = new URL(request.url).pathname;
      if (request.method === "POST") {
        sends += 1;
        return new Response(JSON.stringify({ accepted: true }), { status: 200, headers: { "Content-Type": "application/json" } });
      }
      if (path.endsWith("/events")) return new Response(JSON.stringify({ data: rows, has_more: false }), { status: 200, headers: { "Content-Type": "application/json" } });
      return new Response(JSON.stringify({ id: "session-plan", metadata: { harness_mode: "plan" } }), { status: 200, headers: { "Content-Type": "application/json" } });
    };
    const gateway = new ManagedHarnessGateway("https://awaken.example.test", { credential: "token", workspaceId: "workspace-a" }, "", fetcher);
    await gateway.decidePlanReview("session-plan", { toolUseId: "review-use", decision: "approve" });
    await expect(gateway.answerTool("session-plan", { toolUseId: "review-use", text: "bypass", cancelled: false })).rejects.toMatchObject({ status: 409 });
    reviewInput.revision = 2;
    await expect(gateway.decidePlanReview("session-plan", { toolUseId: "review-use", decision: "approve" })).rejects.toMatchObject({ status: 409 });
    expect(sends).toBe(1);
  });
});
