import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import { declaredHarnessPreset, type HarnessPreset } from "@harness/contracts";

type SessionMode = "execute" | "plan";
type PermissionMode = "safe" | "full";
type AgentTool = BetaManagedAgentsAgent["tools"][number];

const coreCodingTools = ["bash", "read", "write", "edit", "glob", "grep"] as const;
const minimalForbiddenTools = ["web_fetch", "web_search"] as const;
const productCustomTools = new Set(["review_plan", "agent_proposal"]);

function conflict(message: string): Error {
  return Object.assign(new Error(message), { status: 409 });
}

function builtInTools(agent: BetaManagedAgentsAgent): Set<string> {
  const toolset = agent.tools.find((tool) => tool.type === "agent_toolset_20260401");
  if (!toolset || toolset.type !== "agent_toolset_20260401") return new Set();
  const enabledByDefault = toolset.default_config.enabled;
  const known = ["bash", "read", "write", "edit", "glob", "grep", "web_fetch", "web_search"];
  return new Set(known.filter((name) => {
    const config = toolset.configs.find((candidate) => candidate.name === name);
    return config?.enabled ?? enabledByDefault;
  }));
}

/**
 * The published Agent is the execution authority. This validator only proves
 * that its frozen composition satisfies the selected Harness product contract.
 */
export function validatePresetCompatibility(agent: BetaManagedAgentsAgent, preset: HarnessPreset): void {
  if ((agent as unknown as { x_awaken?: unknown }).x_awaken != null) {
    throw conflict(`Agent ${agent.name} uses unsupported Awaken extension fields`);
  }
  const declared = declaredHarnessPreset(agent.metadata);
  if (declared !== preset) throw conflict(`Agent ${agent.name} is published for ${declared ?? "no Harness preset"}, not ${preset}`);
  if (agent.metadata.harness_contract !== "v1") throw conflict(`Agent ${agent.name} does not publish the Harness v1 contract`);

  const enabled = builtInTools(agent);
  const required = preset === "creator" ? ["read", "glob", "grep"] : [...coreCodingTools];
  const missing = required.filter((name) => !enabled.has(name));
  if (missing.length) throw conflict(`${preset} Agent is missing official Managed tools: ${missing.join(", ")}`);

  if (preset === "standard") {
    if (!agent.skills.length) throw conflict("Standard Agent must publish at least one Skill");
    if (agent.multiagent?.type !== "coordinator" || !agent.multiagent.agents.length) {
      throw conflict("Standard Agent must publish a coordinator roster");
    }
  }
  if (preset === "minimal") {
    const forbidden = minimalForbiddenTools.filter((name) => enabled.has(name));
    if (forbidden.length || agent.skills.length || agent.multiagent !== null) {
      throw conflict("Minimal Agent must exclude web tools, Skills, and subagents");
    }
  }
  if (preset === "creator") {
    const unexpected = [...enabled].filter((name) => !required.includes(name));
    if (unexpected.length || agent.skills.length || agent.multiagent !== null) {
      throw conflict("Creator Agent must be read-only and exclude Skills and subagents");
    }
  }
}

function reviewPlanTool(): AgentTool {
  return {
    type: "custom",
    name: "review_plan",
    description: "Pause a Plan-first Session for an explicit approve, revise, or cancel decision. Call only after the matching set_plan revision has committed.",
    input_schema: {
      type: "object",
      properties: {
        plan_id: { type: "string" },
        revision: { type: "integer", minimum: 1 },
      },
      required: ["plan_id", "revision"],
      additionalProperties: false,
    },
  };
}

function agentProposalTool(): AgentTool {
  return {
    type: "custom",
    name: "agent_proposal",
    description: "Submit one declarative Agent composition proposal for human review. This tool never publishes by itself.",
    input_schema: {
      type: "object",
      properties: {
        baseAgentId: { type: "string" },
        baseAgentVersion: { type: "integer", minimum: 1 },
        name: { type: "string" },
        description: { type: "string" },
        system: { type: "string" },
        rationale: { type: "string" },
      },
      required: ["baseAgentId", "baseAgentVersion", "name"],
      additionalProperties: false,
    },
  };
}

function withPermission(tool: AgentTool, permission: PermissionMode): AgentTool {
  if (permission !== "full") return tool;
  const policy = { type: "always_allow" as const };
  if (tool.type === "agent_toolset_20260401") return {
    type: tool.type,
    default_config: { ...tool.default_config, permission_policy: policy },
    configs: tool.configs.map((config) => ({ ...config, permission_policy: policy })),
  };
  if (tool.type === "mcp_toolset") return {
    type: tool.type,
    mcp_server_name: tool.mcp_server_name,
    default_config: { ...tool.default_config, permission_policy: policy },
    configs: tool.configs.map((config) => ({ ...config, permission_policy: policy })),
  };
  return tool;
}

export function sessionTools(
  agent: BetaManagedAgentsAgent,
  preset: HarnessPreset,
  mode: SessionMode,
  permission: PermissionMode,
  interactionMcpUrl: string,
): AgentTool[] {
  let keptPublishedHarness = false;
  const tools = agent.tools.filter((tool) => {
    if (tool.type === "custom") return !productCustomTools.has(tool.name);
    if (tool.type !== "mcp_toolset" || tool.mcp_server_name !== "harness") return true;
    if (interactionMcpUrl || keptPublishedHarness) return false;
    keptPublishedHarness = true;
    return true;
  });
  if (interactionMcpUrl) tools.push({
    type: "mcp_toolset",
    mcp_server_name: "harness",
    default_config: { enabled: true, permission_policy: { type: "always_allow" } },
    configs: [],
  });
  const hasHarnessToolset = tools.some((tool) => tool.type === "mcp_toolset" && tool.mcp_server_name === "harness");
  const hasHarnessServer = Boolean(interactionMcpUrl) || agent.mcp_servers.some((server) => server.name === "harness");
  if (mode === "plan" && (!hasHarnessToolset || !hasHarnessServer)) {
    throw conflict("Plan mode requires the stateless harness interaction MCP");
  }
  if (mode === "plan") tools.push(reviewPlanTool());
  if (preset === "creator") tools.push(agentProposalTool());
  return tools.map((tool) => withPermission(tool, permission));
}

export function sessionMcpServers(agent: BetaManagedAgentsAgent, interactionMcpUrl: string) {
  const withoutHarness = agent.mcp_servers.filter((server) => server.name !== "harness");
  const harness = interactionMcpUrl
    ? { name: "harness", type: "url" as const, url: interactionMcpUrl }
    : agent.mcp_servers.find((server) => server.name === "harness");
  return harness ? [...withoutHarness, harness] : withoutHarness;
}

export function launchPrompt(preset: HarnessPreset, mode: SessionMode, userPrompt: string): string {
  const directives = [
    mode === "plan"
      ? "Your first tool action must be mcp__harness__set_plan. Publish a versioned plan, then immediately call review_plan with the same plan_id and revision. Do not call any other tool before its client result approves execution."
      : "Execute autonomously until complete or a genuine user decision is required.",
  ];
  if (preset === "creator") directives.push("Submit the final draft through agent_proposal and wait for human review. Never claim publication before its client result returns an Agent ID.");
  if (preset === "code") directives.push("Use only the official Managed Agent toolset published by this Agent; do not request provider-specific executor or event extensions.");
  return `<harness_launch version="1" preset="${preset}" mode="${mode}">\n${directives.join("\n")}\n</harness_launch>\n\nUser request:\n${userPrompt}`;
}
