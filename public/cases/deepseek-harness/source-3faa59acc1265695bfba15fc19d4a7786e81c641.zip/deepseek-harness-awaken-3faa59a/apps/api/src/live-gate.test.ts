import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { expect, it } from "vitest";

const runner = fileURLToPath(new URL("../../../scripts/run-awaken-live-gates.mjs", import.meta.url));

// Runtime delegation decision table: G1 missing declared source/owner -> reject;
// G2 canonical child rejects -> preserve that nonzero exit, no PASS message;
// G3 child accepts exact full-gate/record arguments -> report its completion.
// The child here tests process-boundary failure propagation, not runtime or
// provider qualification; the real source owns those tests and its record.
for (const outcome of ["missing", "failed", "passed"] as const) {
  it(`delegates runtime qualification without a second scenario list: ${outcome}`, () => {
    const dir = mkdtempSync(join(tmpdir(), "harness-gate-boundary-"));
    try {
      if (outcome !== "missing") {
        const owner = join(dir, "scripts/ci");
        mkdirSync(owner, { recursive: true });
        writeFileSync(join(owner, "check-all.sh"), `#!/bin/bash\n[[ "$*" == "--full-gate --record" ]] || exit 23\nexit ${outcome === "failed" ? 17 : 0}\n`);
      }
      const result = spawnSync(process.execPath, [runner], { env: { ...process.env, AWAKEN_SOURCE_DIR: dir }, encoding: "utf8" });
      expect(result.status).toBe(outcome === "passed" ? 0 : outcome === "failed" ? 17 : 1);
      expect(result.stdout.includes("Canonical Awaken full gate passed")).toBe(outcome === "passed");
    } finally { rmSync(dir, { recursive: true, force: true }); }
  });
}
