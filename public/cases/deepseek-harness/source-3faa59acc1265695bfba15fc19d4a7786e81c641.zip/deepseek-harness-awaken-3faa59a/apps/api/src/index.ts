import { createServer } from "node:http";
import { readConfig } from "./config.js";
import { createApp } from "./http.js";

const config = readConfig();
const server = createServer(createApp(config));
server.listen(config.port, config.host, () => {
  console.log(`DeepSeek Harness Awaken API listening on http://${config.host}:${config.port}`);
});
for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.once(signal, () => server.close(() => process.exit(0)));
}

