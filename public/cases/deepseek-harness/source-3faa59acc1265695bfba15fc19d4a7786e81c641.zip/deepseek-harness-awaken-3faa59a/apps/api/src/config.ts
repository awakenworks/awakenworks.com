export interface ApiConfig {
  host: string;
  port: number;
  awakenApiUrl: string;
  serviceToken: string;
  defaultWorkspaceId: string;
  requireIdentity: boolean;
  interactionMcpUrl: string;
  webDist: string;
}

function bool(name: string, value: string | undefined): boolean {
  if (!value) return false;
  if (value === "true") return true;
  if (value === "false") return false;
  throw new Error(`${name} must be true or false`);
}

function httpUrl(name: string, value: string, optional = false): string {
  if (optional && !value) return "";
  if (!URL.canParse(value) || !["http:", "https:"].includes(new URL(value).protocol)) {
    throw new Error(`${name} must be an HTTP(S) URL`);
  }
  return value.replace(/\/$/, "");
}

export function readConfig(environment: NodeJS.ProcessEnv = process.env): ApiConfig {
  const port = Number(environment.HARNESS_API_PORT ?? "4280");
  if (!Number.isInteger(port) || port < 1 || port > 65_535) {
    throw new Error("HARNESS_API_PORT must be an integer between 1 and 65535");
  }
  return {
    host: environment.HARNESS_API_HOST?.trim() || "127.0.0.1",
    port,
    awakenApiUrl: httpUrl("HARNESS_AWAKEN_API_URL", environment.HARNESS_AWAKEN_API_URL?.trim() || "http://127.0.0.1:8080"),
    serviceToken: environment.HARNESS_AWAKEN_AUTH_TOKEN ?? "",
    defaultWorkspaceId: environment.HARNESS_DEFAULT_WORKSPACE_ID?.trim() ?? "",
    requireIdentity: bool("HARNESS_REQUIRE_REQUEST_IDENTITY", environment.HARNESS_REQUIRE_REQUEST_IDENTITY),
    interactionMcpUrl: httpUrl("HARNESS_INTERACTION_MCP_URL", environment.HARNESS_INTERACTION_MCP_URL?.trim() || "", true),
    webDist: environment.HARNESS_WEB_DIST?.trim() ?? "",
  };
}

