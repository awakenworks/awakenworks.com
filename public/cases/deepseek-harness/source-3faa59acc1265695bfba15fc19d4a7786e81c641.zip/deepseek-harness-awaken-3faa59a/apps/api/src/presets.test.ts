import type { BetaManagedAgentsAgent } from "@anthropic-ai/sdk/resources/beta/agents/agents";
import { describe, expect, it } from "vitest";
import { launchPrompt, sessionMcpServers, sessionTools, validatePresetCompatibility } from "./presets.js";

const core = ["bash", "read", "write", "edit", "glob", "grep"];

function agent(
  preset: "standard" | "code" | "minimal" | "creator",
  enabled: string[],
): BetaManagedAgentsAgent {
  return {
    id: `agent-${preset}`,
    type: "agent",
    name: preset,
    description: preset,
    version: 1,
    model: "deepseek/deepseek-chat",
    system: "Use the published composition.",
    metadata: { harness_preset: preset, harness_contract: "v1" },
    mcp_servers: [],
    tools: [{
      type: "agent_toolset_20260401",
      default_config: { enabled: false, permission_policy: { type: "always_ask" } },
      configs: enabled.map((name) => ({ name: name as typeof core[number], enabled: true, permission_policy: { type: "always_ask" } })),
    }],
    skills: preset === "standard" || preset === "code" ? [{ type: "custom", skill_id: "testing", version: "1" }] : [],
    multiagent: preset === "standard" ? { type: "coordinator", agents: [{ type: "self" }] } : null,
    archived_at: null,
    created_at: "2026-08-15T00:00:00Z",
    updated_at: "2026-08-15T00:00:00Z",
  } as unknown as BetaManagedAgentsAgent;
}

describe("published Harness preset contracts", () => {
  /**
   * Cause/effect decision table:
   * Standard = core + Skill + coordinator; Code = core; Minimal = core with no
   * web/Skill/subagent; Creator = read/glob/grep. Effect for rules S/C/M/A:
   * each authoritative published Agent is admitted for exactly its declared
   * preset without inventing a parallel runtime implementation.
   */
  it.each([
    ["standard", agent("standard", [...core, "web_fetch", "web_search"])],
    ["code", agent("code", [...core, "web_fetch", "web_search"])],
    ["minimal", agent("minimal", core)],
    ["creator", agent("creator", ["read", "glob", "grep"])],
  ] as const)("admits the %s Agent composition", (preset, candidate) => {
    expect(() => validatePresetCompatibility(candidate, preset)).not.toThrow();
  });

  /**
   * Cause/effect rule M-invalid: Minimal enables web_search while all other
   * required conditions hold. Effect: admission terminates with conflict before
   * any Session exists, preserving the preset's bounded capability contract.
   */
  it("rejects capability drift in a published Minimal Agent", () => {
    expect(() => validatePresetCompatibility(agent("minimal", [...core, "web_search"]), "minimal"))
      .toThrow("Minimal Agent must exclude web tools, Skills, and subagents");
  });

  /**
   * Cause/effect rule A-invalid: Creator includes bash while its read-only
   * discovery tools remain present. Effect: admission rejects the composition
   * so proposal drafting cannot silently become a second execution preset.
   */
  it("rejects mutation capability drift in a Creator Agent", () => {
    expect(() => validatePresetCompatibility(agent("creator", ["read", "glob", "grep", "bash"]), "creator"))
      .toThrow("Creator Agent must be read-only and exclude Skills and subagents");
  });

  /**
   * Cause/effect rule X-invalid: an otherwise compatible Code Agent carries a
   * provider extension object. Effect: admission rejects it before Session
   * creation, guaranteeing this Harness consumes only the official SDK surface.
   */
  it("rejects extension-bearing published Agents", () => {
    const candidate = { ...agent("code", core), x_awaken: { tool_kinds: ["executor"] } } as unknown as BetaManagedAgentsAgent;
    expect(() => validatePresetCompatibility(candidate, "code"))
      .toThrow("uses unsupported Awaken extension fields");
  });

  /**
   * Cause/effect decision table: Plan adds review_plan; Creator adds
   * agent_proposal; their intersection adds each once. Full changes only
   * permission-bearing official toolsets. Effect: the effective Session tool
   * array is one canonical, duplicate-free admission result.
   */
  it("builds one deduplicated official Session tool composition", () => {
    const creator = agent("creator", ["read", "glob", "grep"]);
    creator.tools.push({ type: "custom", name: "review_plan", description: "stale", input_schema: { type: "object" } });
    const tools = sessionTools(creator, "creator", "plan", "full", "https://harness.example/mcp");
    expect(tools.filter((tool) => tool.type === "custom" && tool.name === "review_plan")).toHaveLength(1);
    expect(tools.filter((tool) => tool.type === "custom" && tool.name === "agent_proposal")).toHaveLength(1);
    expect(tools.filter((tool) => tool.type === "mcp_toolset" && tool.mcp_server_name === "harness")).toHaveLength(1);
    const managed = tools.find((tool) => tool.type === "agent_toolset_20260401");
    expect(managed?.default_config.permission_policy.type).toBe("always_allow");
    const withPublishedMcp = agent("code", core);
    withPublishedMcp.mcp_servers.push(
      { name: "harness", type: "url", url: "https://published.example/mcp" },
      { name: "harness", type: "url", url: "https://duplicate.example/mcp" },
    );
    withPublishedMcp.tools.push(
      { type: "mcp_toolset", mcp_server_name: "harness", default_config: { enabled: true, permission_policy: { type: "always_allow" } }, configs: [] },
      { type: "mcp_toolset", mcp_server_name: "harness", default_config: { enabled: true, permission_policy: { type: "always_allow" } }, configs: [] },
    );
    expect(sessionMcpServers(withPublishedMcp, "").filter((server) => server.name === "harness")).toHaveLength(1);
    expect(sessionTools(withPublishedMcp, "code", "plan", "safe", "").filter((tool) => tool.type === "mcp_toolset" && tool.mcp_server_name === "harness")).toHaveLength(1);
  });

  /**
   * Cause/effect rule P-missing: Plan is selected but neither the product URL
   * nor the published Agent supplies the stateless harness MCP. Effect: Session
   * admission fails explicitly instead of launching a plan that cannot publish
   * or correlate its review revision.
   */
  it("rejects Plan composition without the interaction MCP", () => {
    expect(() => sessionTools(agent("code", core), "code", "plan", "safe", ""))
      .toThrow("Plan mode requires the stateless harness interaction MCP");
  });

  /**
   * Cause/effect rule P-order: Plan mode plus an arbitrary user request must
   * tell the model that set_plan is the first tool action and that all other
   * tools remain out of sequence until the typed review result. Effect: the
   * canonical launch prompt exposes the protected ordering without a second
   * runtime, tool registry, or provider-specific extension.
   */
  it("makes the Plan review ordering explicit in the canonical launch prompt", () => {
    const prompt = launchPrompt("standard", "plan", "Inspect the repository");
    expect(prompt).toContain("Your first tool action must be mcp__harness__set_plan");
    expect(prompt).toContain("Do not call any other tool before its client result approves execution");
  });
});
