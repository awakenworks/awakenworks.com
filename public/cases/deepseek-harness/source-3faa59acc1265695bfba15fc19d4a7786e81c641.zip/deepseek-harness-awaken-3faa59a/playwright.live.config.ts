import { defineConfig, devices } from "@playwright/test";
import { readFileSync } from "node:fs";

const bootstrap = process.env.HARNESS_LIVE_BOOTSTRAP_FILE
  ? JSON.parse(readFileSync(process.env.HARNESS_LIVE_BOOTSTRAP_FILE, "utf8")) : {};
const baseUrl = process.env.HARNESS_LIVE_AWAKEN_BASE_URL ?? "";
const mcpUrl = process.env.HARNESS_LIVE_INTERACTION_MCP_URL ?? "";

export default defineConfig({
  testDir: "./e2e/live",
  outputDir: "test-results/live",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 900_000,
  expect: { timeout: 180_000 },
  reporter: [["list"], ["html", { outputFolder: "playwright-report-live", open: "never" }]],
  use: {
    baseURL: "http://127.0.0.1:4281",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    actionTimeout: 45_000,
  },
  webServer: [
    {
      command: "node e2e/live-awaken-server.mjs",
      port: 4294,
      reuseExistingServer: false,
      timeout: 240_000,
    },
    {
      command: "pnpm --filter @harness/interaction-mcp dev",
      env: { HARNESS_MCP_HOST: "0.0.0.0", HARNESS_MCP_ALLOWED_HOSTS: `127.0.0.1,localhost,${mcpUrl ? new URL(mcpUrl).hostname : ""}` },
      port: 4282,
      reuseExistingServer: false,
      timeout: 30_000,
    },
    {
      command: "pnpm --filter @harness/api dev",
      env: { HARNESS_AWAKEN_API_URL: baseUrl, HARNESS_INTERACTION_MCP_URL: mcpUrl,
        HARNESS_DEFAULT_WORKSPACE_ID: bootstrap["platform-workspace-id"] ?? "",
        HARNESS_AWAKEN_AUTH_TOKEN: bootstrap["admin-token"] ?? "" },
      port: 4280,
      reuseExistingServer: false,
      timeout: 30_000,
    },
    {
      command: "pnpm --filter @harness/web dev",
      port: 4281,
      reuseExistingServer: false,
      timeout: 30_000,
    },
  ],
  projects: [{
    name: "deepseek-live",
    use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } },
  }],
});
