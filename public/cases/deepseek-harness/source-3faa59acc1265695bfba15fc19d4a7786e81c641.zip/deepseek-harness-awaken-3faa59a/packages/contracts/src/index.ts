import { z } from "zod";

const id = z.string().trim().min(1).max(500);

export const presetIds = ["standard", "code", "minimal", "creator"] as const;
export const presetSchema = z.enum(presetIds);
export type HarnessPreset = z.infer<typeof presetSchema>;

export const presetCatalog = [
  { id: "standard", name: "Standard", mark: "S", description: "Full Managed tools, plans, skills and subagents" },
  { id: "code", name: "Code / PTC", mark: "</>", description: "Focused coding through official Managed tool calls" },
  { id: "minimal", name: "Minimal", mark: "M", description: "Compact shell and filesystem composition" },
  { id: "creator", name: "Creator", mark: "C", description: "Draft, review and publish Agent configurations" },
] as const satisfies ReadonlyArray<{ id: HarnessPreset; name: string; mark: string; description: string }>;

export function declaredHarnessPreset(metadata: Readonly<Record<string, string>>): HarnessPreset | undefined {
  return presetIds.find((preset) => preset === metadata.harness_preset);
}

export function isHarnessV1Preset(metadata: Readonly<Record<string, string>>, preset: HarnessPreset): boolean {
  return metadata.harness_contract === "v1" && declaredHarnessPreset(metadata) === preset;
}

export const createSessionSchema = z.object({
  title: z.string().trim().min(1).max(500),
  prompt: z.string().trim().min(1).max(100_000),
  agentId: id,
  agentVersion: z.number().int().positive(),
  environmentId: id,
  preset: presetSchema,
  mode: z.enum(["execute", "plan"]),
  permission: z.enum(["safe", "full"]).default("safe"),
  acknowledgedRisk: z.boolean().default(false),
}).superRefine((value, context) => {
  if (value.permission === "full" && !value.acknowledgedRisk) context.addIssue({
    code: "custom", path: ["acknowledgedRisk"], message: "Full access requires risk acknowledgement",
  });
});
export type CreateSessionCommand = z.infer<typeof createSessionSchema>;

export const messageSchema = z.object({
  text: z.string().trim().min(1).max(100_000),
  images: z.array(z.object({
    name: z.string().trim().min(1).max(500),
    mediaType: z.enum(["image/png", "image/jpeg", "image/gif", "image/webp"]),
    data: z.string().min(1).max(15_000_000),
  })).max(20).default([]),
});
export type MessageCommand = z.infer<typeof messageSchema>;

export const updateSessionSchema = z.object({
  title: z.string().trim().min(1).max(500).optional(),
  metadata: z.record(z.string().max(64), z.string().max(512).nullable()).optional(),
}).refine((value) => value.title !== undefined || value.metadata !== undefined, {
  message: "At least one Session field is required",
});
export type UpdateSessionCommand = z.infer<typeof updateSessionSchema>;

export const forkSessionSchema = z.object({
  title: z.string().trim().min(1).max(500),
  throughEventId: id.optional(),
});
export type ForkSessionCommand = z.infer<typeof forkSessionSchema>;

export const permissionModeSchema = z.object({
  mode: z.enum(["safe", "full"]),
  acknowledgedRisk: z.boolean().default(false),
}).superRefine((value, context) => {
  if (value.mode === "full" && !value.acknowledgedRisk) context.addIssue({
    code: "custom", path: ["acknowledgedRisk"], message: "Full access requires risk acknowledgement",
  });
});
export type PermissionModeCommand = z.infer<typeof permissionModeSchema>;

export const copyAgentSchema = z.object({ name: z.string().trim().min(1).max(255) });
export type CopyAgentCommand = z.infer<typeof copyAgentSchema>;

export const decisionSchema = z.object({
  toolUseId: id,
  allow: z.boolean(),
  reason: z.string().trim().min(1).max(4_000).optional(),
  sessionThreadId: id.optional(),
}).superRefine((decision, context) => {
  if (decision.allow && decision.reason !== undefined) {
    context.addIssue({
      code: "custom",
      path: ["reason"],
      message: "An allowed decision cannot include a denial reason",
    });
  }
});
export type ToolDecision = z.infer<typeof decisionSchema>;

export const toolAnswerSchema = z.object({
  toolUseId: id,
  text: z.string().trim().min(1).max(20_000),
  cancelled: z.boolean().default(false),
});
export type ToolAnswer = z.infer<typeof toolAnswerSchema>;

export const planReviewDecisionSchema = z.object({
  toolUseId: id,
  decision: z.enum(["approve", "revise", "cancel"]),
  feedback: z.string().trim().min(1).max(8_000).optional(),
}).superRefine((value, context) => {
  if (value.decision === "revise" && !value.feedback) context.addIssue({
    code: "custom", path: ["feedback"], message: "Revision feedback is required",
  });
});
export type PlanReviewDecision = z.infer<typeof planReviewDecisionSchema>;

export const agentProposalSchema = z.object({
  baseAgentId: id,
  baseAgentVersion: z.number().int().positive(),
  name: z.string().trim().min(1).max(255),
  description: z.string().max(10_000).optional(),
  system: z.string().max(100_000).optional(),
  rationale: z.string().max(8_000).optional(),
});
export type AgentProposal = z.infer<typeof agentProposalSchema>;

export const agentProposalDecisionSchema = z.object({
  toolUseId: id,
  decision: z.enum(["approve", "revise", "cancel"]),
  feedback: z.string().trim().min(1).max(8_000).optional(),
}).superRefine((value, context) => {
  if (value.decision === "revise" && !value.feedback) context.addIssue({
    code: "custom", path: ["feedback"], message: "Revision feedback is required",
  });
});
export type AgentProposalDecision = z.infer<typeof agentProposalDecisionSchema>;

export function permissionModeFromTools(tools: readonly unknown[]): "safe" | "full" {
  let sawPolicy = false;
  for (const raw of tools) {
    if (typeof raw !== "object" || raw === null || !("type" in raw)) continue;
    const tool = raw as { type: unknown; default_config?: unknown; configs?: unknown };
    if (tool.type !== "agent_toolset_20260401" && tool.type !== "mcp_toolset") continue;
    const defaultConfig = typeof tool.default_config === "object" && tool.default_config !== null
      ? tool.default_config as { enabled?: unknown }
      : undefined;
    const values = [
      ...(defaultConfig?.enabled === true ? [defaultConfig] : []),
      ...(Array.isArray(tool.configs) ? tool.configs.filter((config) => (
        typeof config === "object" && config !== null && (config as { enabled?: unknown }).enabled === true
      )) : []),
    ];
    for (const value of values) {
      if (typeof value !== "object" || value === null || !("permission_policy" in value)) continue;
      const policy = (value as { permission_policy?: { type?: unknown } }).permission_policy;
      if (!policy?.type) continue;
      sawPolicy = true;
      if (policy.type !== "always_allow") return "safe";
    }
  }
  return sawPolicy ? "full" : "safe";
}

export const workspaceHeader = "x-harness-workspace-id";

export function parseWith<T>(schema: z.ZodType<T>, input: unknown): T {
  const result = schema.safeParse(input);
  if (!result.success) {
    throw Object.assign(new Error("Invalid request"), {
      status: 400,
      issues: result.error.issues,
    });
  }
  return result.data;
}
