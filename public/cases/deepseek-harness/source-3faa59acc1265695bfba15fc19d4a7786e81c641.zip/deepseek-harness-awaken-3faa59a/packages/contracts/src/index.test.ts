import { describe, expect, it } from "vitest";
import { agentProposalDecisionSchema, copyAgentSchema, createSessionSchema, decisionSchema, forkSessionSchema, isHarnessV1Preset, messageSchema, permissionModeFromTools, permissionModeSchema, planReviewDecisionSchema, presetCatalog, updateSessionSchema } from "./index.js";

describe("browser command contracts", () => {
  /**
   * Cause/effect design — R1: all required launch facts are present and valid.
   * Effect: the command is normalized and admitted without inventing defaults.
   */
  it("admits a complete session command", () => {
    expect(createSessionSchema.parse({
      title: "Investigate build",
      prompt: "Find and repair the failing build.",
      agentId: "agent_standard",
      agentVersion: 2,
      environmentId: "env_cloud",
      preset: "standard",
      mode: "execute",
      permission: "safe",
    }).agentVersion).toBe(2);
    expect(presetCatalog.map((preset) => preset.id)).toEqual(["standard", "code", "minimal", "creator"]);
    expect(isHarnessV1Preset({ harness_preset: "standard", harness_contract: "v1" }, "standard")).toBe(true);
    expect(isHarnessV1Preset({ harness_preset: "standard" }, "standard")).toBe(false);
  });

  /**
   * Cause/effect design — R2: an allow decision also carries a denial reason.
   * Constraint: reasons belong only to deny. Effect: reject before any SDK call.
   */
  it("rejects contradictory approval decisions", () => {
    expect(() => decisionSchema.parse({
      toolUseId: "tool_1",
      allow: true,
      reason: "not allowed",
    })).toThrow();
  });

  /**
   * Cause/effect design — R3: a Session patch has no title and no metadata.
   * Constraint: an empty write has no domain effect. Effect: reject it at the
   * BFF boundary; a title or metadata patch remains the one SDK-owned path.
   */
  it("rejects an effect-free Session update", () => {
    expect(() => updateSessionSchema.parse({})).toThrow();
    expect(updateSessionSchema.parse({ metadata: { harness_goal: "Ship safely" } })).toEqual({
      metadata: { harness_goal: "Ship safely" },
    });
  });

  /**
   * Cause/effect design — R4: an image uses an SDK-supported MIME type and base64
   * body, while omitted images normalize to an empty list. Effects: supported
   * input is admitted; executable/arbitrary MIME input is rejected before upload.
   */
  it("admits only Managed image-block attachment types", () => {
    expect(messageSchema.parse({ text: "Inspect this" }).images).toEqual([]);
    expect(messageSchema.parse({ text: "Inspect", images: [{ name: "ui.png", mediaType: "image/png", data: "AA==" }] }).images).toHaveLength(1);
    expect(() => messageSchema.parse({ text: "Inspect", images: [{ name: "x.svg", mediaType: "image/svg+xml", data: "PHN2Zy8+" }] })).toThrow();
  });

  /**
   * Cause/effect decision table — R5: a branch has a durable title and may name
   * one committed event boundary. Effects: exact-boundary commands are admitted;
   * an empty title or boundary is rejected before the SDK creates a Session.
   */
  it("validates Session fork boundaries", () => {
    expect(forkSessionSchema.parse({ title: "Focused branch", throughEventId: "evt_12" })).toEqual({ title: "Focused branch", throughEventId: "evt_12" });
    expect(() => forkSessionSchema.parse({ title: "", throughEventId: "evt_12" })).toThrow();
  });

  /**
   * Cause/effect decision table — R6: safe mode never needs risk consent; full
   * mode changes every tool policy and therefore requires explicit consent.
   * Effects: safe and acknowledged-full pass, unacknowledged-full is rejected.
   */
  it("requires explicit risk acknowledgement for full permission", () => {
    expect(permissionModeSchema.parse({ mode: "safe" })).toEqual({ mode: "safe", acknowledgedRisk: false });
    expect(permissionModeSchema.parse({ mode: "full", acknowledgedRisk: true }).mode).toBe("full");
    expect(() => permissionModeSchema.parse({ mode: "full", acknowledgedRisk: false })).toThrow();
  });

  /**
   * Cause/effect decision R7: copying a composition creates a new Agent identity,
   * so it requires one bounded human-readable name. Effect: valid names cross the
   * BFF; blank or control-plane-oversized names never invoke the Agents API.
   */
  it("validates copied Agent names", () => {
    expect(copyAgentSchema.parse({ name: "Focused code preset" })).toEqual({ name: "Focused code preset" });
    expect(() => copyAgentSchema.parse({ name: "" })).toThrow();
    expect(() => copyAgentSchema.parse({ name: "x".repeat(256) })).toThrow();
  });

  /**
   * Cause/effect decision table — R8: effective tool policies, not metadata,
   * own the permission label. Any authored ask policy yields Safe; a non-empty
   * all-allow policy yields Full; disabled policies have no effect; missing
   * effective policy facts fail closed to Safe.
   */
  it("derives permission mode from effective tool policies", () => {
    expect(permissionModeFromTools([{ type: "agent_toolset_20260401", default_config: { enabled: true, permission_policy: { type: "always_allow" } }, configs: [] }])).toBe("full");
    expect(permissionModeFromTools([{ type: "agent_toolset_20260401", default_config: { enabled: false, permission_policy: { type: "always_ask" } }, configs: [{ enabled: true, permission_policy: { type: "always_allow" } }] }])).toBe("full");
    expect(permissionModeFromTools([{ type: "agent_toolset_20260401", default_config: { enabled: true, permission_policy: { type: "always_allow" } }, configs: [{ enabled: true, permission_policy: { type: "always_ask" } }] }])).toBe("safe");
    expect(permissionModeFromTools([])).toBe("safe");
  });

  /**
   * Cause/effect decision table — R9: Creator approve/cancel need no feedback,
   * while revise must carry actionable feedback. Invalid revision commands stop
   * before any Agent publication or custom-result event.
   */
  it("validates Creator proposal decisions", () => {
    expect(planReviewDecisionSchema.parse({ toolUseId: "review-1", decision: "approve" }).decision).toBe("approve");
    expect(() => planReviewDecisionSchema.parse({ toolUseId: "review-1", decision: "revise" })).toThrow();
    expect(agentProposalDecisionSchema.parse({ toolUseId: "proposal-1", decision: "approve" }).decision).toBe("approve");
    expect(agentProposalDecisionSchema.parse({ toolUseId: "proposal-1", decision: "revise", feedback: "Narrow the tools" }).feedback).toBe("Narrow the tools");
    expect(() => agentProposalDecisionSchema.parse({ toolUseId: "proposal-1", decision: "revise" })).toThrow();
  });
});
