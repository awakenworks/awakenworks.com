import {
  mergeCommittedEvents,
  type ManagedEvent,
} from "@awaken/managed-session-projection";

export type SessionStatus = "idle" | "running" | "rescheduling" | "terminated" | "error" | "unknown";
export type ToolState = "running" | "done" | "error" | "waiting";

export interface MessageView {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  images: Array<{ id: string; url: string; alt: string }>;
  at?: string;
}

export interface ToolView {
  id: string;
  name: string;
  input: unknown;
  output?: unknown;
  state: ToolState;
  kind: "builtin" | "mcp" | "custom";
  permission?: "allow" | "ask" | "deny";
  at?: string;
}

export interface ApprovalView {
  id: string;
  name: string;
  input: unknown;
  sessionThreadId?: string;
}

export interface PlanView {
  planId: string;
  revision: number;
  summary: string;
  steps: Array<{
    id: string;
    title: string;
    status: "pending" | "in_progress" | "completed" | "blocked";
    detail?: string;
  }>;
  eventId: string;
}

export interface ResultView {
  summary: string;
  artifacts: Array<{ path: string; description?: string }>;
  eventId: string;
}

export interface SessionProjection {
  status: SessionStatus;
  phase: "planning" | "awaiting_plan_review" | "executing" | "awaiting_permission" | "awaiting_question" | "awaiting_agent_proposal" | "idle" | "cancelled" | "error";
  messages: MessageView[];
  tools: ToolView[];
  approvals: ApprovalView[];
  markers: Array<{ id: string; kind: "thinking" | "compaction"; at?: string }>;
  plan?: PlanView;
  planReview?: { id: string; planId: string; revision: number };
  agentProposal?: { id: string; input: unknown };
  result?: ResultView;
  error?: string;
}

type JsonObject = Record<string, unknown>;

function object(value: unknown): JsonObject | undefined {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? value as JsonObject
    : undefined;
}

export function contentText(content: unknown): string {
  if (!Array.isArray(content)) return "";
  return content.flatMap((raw) => {
    const block = object(raw);
    return block?.type === "text" && typeof block.text === "string"
      ? [block.text]
      : [];
  }).join("\n");
}

export function contentImages(content: unknown, eventId: string): MessageView["images"] {
  if (!Array.isArray(content)) return [];
  return content.flatMap((raw, index) => {
    const block = object(raw);
    const source = object(block?.source);
    if (block?.type !== "image" || !source) return [];
    if (source.type === "base64" && typeof source.media_type === "string" && typeof source.data === "string") {
      return [{ id: `${eventId}:image:${index}`, url: `data:${source.media_type};base64,${source.data}`, alt: `Attached image ${index + 1}` }];
    }
    if (source.type === "url" && typeof source.url === "string") {
      return [{ id: `${eventId}:image:${index}`, url: source.url, alt: `Attached image ${index + 1}` }];
    }
    return [];
  });
}

function resultReference(value: JsonObject): string | undefined {
  if (typeof value.tool_use_id === "string") return value.tool_use_id;
  if (typeof value.custom_tool_use_id === "string") return value.custom_tool_use_id;
  if (typeof value.mcp_tool_use_id === "string") return value.mcp_tool_use_id;
  return undefined;
}

function interactionName(name: string): string {
  return name.replace(/^mcp__(?:awaken_interaction|harness)__/, "");
}

function planFrom(input: unknown, eventId: string): PlanView | undefined {
  const value = object(input);
  if (!value || typeof value.summary !== "string" || !Array.isArray(value.steps)) return undefined;
  const steps = value.steps.flatMap((raw) => {
    const step = object(raw);
    if (!step || typeof step.id !== "string" || typeof step.title !== "string") return [];
    if (!["pending", "in_progress", "completed", "blocked"].includes(String(step.status))) return [];
    return [{
      id: step.id,
      title: step.title,
      status: step.status as PlanView["steps"][number]["status"],
      ...(typeof step.detail === "string" ? { detail: step.detail } : {}),
    }];
  });
  if (steps.length !== value.steps.length) return undefined;
  return {
    planId: typeof value.plan_id === "string" ? value.plan_id : eventId,
    revision: typeof value.revision === "number" && Number.isInteger(value.revision) && value.revision > 0 ? value.revision : 1,
    summary: value.summary,
    steps,
    eventId,
  };
}

function resultFrom(input: unknown, eventId: string): ResultView | undefined {
  const value = object(input);
  if (!value || typeof value.summary !== "string") return undefined;
  const artifacts = Array.isArray(value.artifacts) ? value.artifacts.flatMap((raw) => {
    const artifact = object(raw);
    if (!artifact || typeof artifact.path !== "string") return [];
    return [{
      path: artifact.path,
      ...(typeof artifact.description === "string" ? { description: artifact.description } : {}),
    }];
  }) : [];
  return { summary: value.summary, artifacts, eventId };
}

export function projectSession(events: readonly ManagedEvent[]): SessionProjection {
  const committed = mergeCommittedEvents([], events);
  const results = new Map<string, JsonObject>();
  const confirmations = new Set<string>();

  for (const event of committed) {
    const value = event as unknown as JsonObject;
    const reference = resultReference(value);
    if (reference) results.set(reference, value);
    if (event.type === "user.tool_confirmation" && typeof value.tool_use_id === "string") {
      confirmations.add(value.tool_use_id);
    }
  }

  let status: SessionStatus = "unknown";
  let plan: PlanView | undefined;
  let result: ResultView | undefined;
  let planReview: SessionProjection["planReview"];
  let agentProposal: SessionProjection["agentProposal"];
  let error: string | undefined;
  const messages: MessageView[] = [];
  const tools: ToolView[] = [];
  const approvals: ApprovalView[] = [];
  const markers: SessionProjection["markers"] = [];

  for (const event of committed) {
    const value = event as unknown as JsonObject;
    if (event.type === "session.status_running") status = "running";
    else if (event.type === "session.status_idle") status = "idle";
    else if (event.type === "session.status_rescheduled") status = "rescheduling";
    else if (event.type === "session.status_terminated") status = "terminated";
    else if (event.type === "session.error") {
      status = "error";
      const detail = object(value.error);
      error = typeof detail?.message === "string" ? detail.message : "Session failed";
    }

    if (["user.message", "agent.message", "system.message"].includes(event.type)) {
      const text = contentText(value.content);
      const images = contentImages(value.content, event.id);
      if (text || images.length) messages.push({
        id: event.id,
        role: event.type === "user.message" ? "user" : event.type === "agent.message" ? "assistant" : "system",
        text,
        images,
        ...(typeof value.processed_at === "string" ? { at: value.processed_at } : {}),
      });
    }
    if (event.type === "agent.thinking" || event.type === "agent.thread_context_compacted") {
      markers.push({
        id: event.id,
        kind: event.type === "agent.thinking" ? "thinking" : "compaction",
        ...(typeof value.processed_at === "string" ? { at: value.processed_at } : {}),
      });
    }

    if (["agent.tool_use", "agent.mcp_tool_use", "agent.custom_tool_use"].includes(event.type)) {
      const name = typeof value.name === "string" ? value.name : "tool";
      const matched = results.get(event.id);
      const waiting = value.evaluated_permission === "ask" && !confirmations.has(event.id);
      tools.push({
        id: event.id,
        name,
        input: value.input,
        kind: event.type === "agent.custom_tool_use" ? "custom" : event.type === "agent.mcp_tool_use" ? "mcp" : "builtin",
        ...(matched ? { output: matched.content } : {}),
        state: waiting ? "waiting" : matched ? matched.is_error === true ? "error" : "done" : "running",
        ...(value.evaluated_permission === "ask" ? { permission: "ask" as const } : {}),
        ...(typeof value.processed_at === "string" ? { at: value.processed_at } : {}),
      });
      if (waiting) approvals.push({
        id: event.id,
        name,
        input: value.input,
        ...(typeof value.session_thread_id === "string" ? { sessionThreadId: value.session_thread_id } : {}),
      });
      const interaction = interactionName(name);
      if (matched && matched.is_error !== true && interaction === "set_plan") {
        plan = planFrom(value.input, event.id) ?? plan;
      }
      if (matched && matched.is_error !== true && interaction === "publish_result") {
        result = resultFrom(value.input, event.id) ?? result;
      }
      if (!matched && event.type === "agent.custom_tool_use" && name === "review_plan") {
        const input = object(value.input);
        planReview = {
          id: event.id,
          planId: typeof input?.plan_id === "string" ? input.plan_id : plan?.planId ?? event.id,
          revision: typeof input?.revision === "number" ? input.revision : plan?.revision ?? 1,
        };
      }
      if (!matched && event.type === "agent.custom_tool_use" && name === "agent_proposal") {
        agentProposal = { id: event.id, input: value.input };
      }
    }
  }

  const pendingQuestion = tools.some((tool) => tool.kind === "custom" && tool.name === "question" && tool.state === "running");
  const phase: SessionProjection["phase"] = status === "error" ? "error"
    : agentProposal ? "awaiting_agent_proposal"
      : planReview ? "awaiting_plan_review"
        : pendingQuestion ? "awaiting_question"
          : approvals.length ? "awaiting_permission"
            : status === "terminated" ? "cancelled"
              : status === "running" ? plan && !result && plan.steps.every((step) => step.status === "pending") ? "planning" : "executing"
                : "idle";

  return {
    status,
    phase,
    messages,
    tools,
    approvals,
    markers,
    ...(plan ? { plan } : {}),
    ...(planReview ? { planReview } : {}),
    ...(agentProposal ? { agentProposal } : {}),
    ...(result ? { result } : {}),
    ...(error ? { error } : {}),
  };
}
