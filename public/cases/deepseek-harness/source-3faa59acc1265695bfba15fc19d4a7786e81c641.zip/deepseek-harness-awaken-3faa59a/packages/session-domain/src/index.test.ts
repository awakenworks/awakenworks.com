import { describe, expect, it } from "vitest";
import type { ManagedEvent } from "@awaken/managed-session-projection";
import { projectSession } from "./index.js";

const event = (value: Record<string, unknown>) => value as unknown as ManagedEvent;

describe("Session event projection", () => {
  /**
   * Cause/effect graph: C1 committed status; C2 message; C3 ask tool; C4 no
   * confirmation/result. Effects: E1 running, E2 transcript, E3 waiting card,
   * E4 approval. Decision rule R1 covers the only open-permission state.
   */
  it("projects a running tool approval from committed facts", () => {
    const projection = projectSession([
      event({ id: "s1", type: "session.status_running" }),
      event({ id: "u1", type: "user.message", content: [{ type: "text", text: "Inspect it" }] }),
      event({ id: "t1", type: "agent.tool_use", name: "bash", input: { command: "pwd" }, evaluated_permission: "ask" }),
    ]);
    expect(projection.status).toBe("running");
    expect(projection.messages[0]?.text).toBe("Inspect it");
    expect(projection.tools[0]?.state).toBe("waiting");
    expect(projection.approvals[0]?.id).toBe("t1");
  });

  /**
   * Replay graph for the fixed shared projection archive:
   * C1 same event identity; C2 identical immutable payload; C3 processed_at
   * absent -> recorded; C4 changed payload or an already recorded timestamp.
   * E1 one durable row; E2 only legal processing enrichment; E3 reject conflict.
   * R2a C1+C2+C3 -> E1+E2; R2b C1+!C2 -> E3;
   * R2c C1+C2+C4(timestamp) -> E3. Live preview is never a committed rewrite.
   * This is the consumer boundary of the existing shared owner, not a reducer
   * reimplementation or a second package-dependent event catalog.
   */
  it("R2a deduplicates immutable replay with processing enrichment", () => {
    const first = event({ id: "a1", type: "agent.message", content: [{ type: "text", text: "done" }] });
    const replay = event({ ...first, processed_at: "2026-10-10T00:00:00Z" });
    expect(projectSession([first, replay]).messages).toEqual([
      expect.objectContaining({ id: "a1", text: "done" }),
    ]);
  });

  it("R2b/R2c rejects committed replay that changes content or recorded processing time", () => {
    const first = event({ id: "a1", type: "agent.message", content: [{ type: "text", text: "done" }], processed_at: "2026-10-10T00:00:00Z" });
    expect(() => projectSession([first, event({ ...first, content: [] })])).toThrow(/immutable projection/);
    expect(() => projectSession([first, event({ ...first, processed_at: "2026-10-10T00:00:01Z" })])).toThrow(/processed_at changed/);
  });

  /**
   * Decision rule R3: Code Mode uses only the latest Awaken 1.0 official
   * Managed tool-use/result events. Effects: each call is one canonical row;
   * no provider-specific wrapper or event extension creates a parallel hierarchy.
   */
  it("projects Code Mode through official Managed tool events", () => {
    const projection = projectSession([
      event({ id: "r1", type: "agent.tool_use", name: "read", input: { path: "README.md" } }),
      event({ id: "r2", type: "agent.tool_result", tool_use_id: "r1", content: [{ type: "text", text: "ok" }] }),
      event({ id: "g1", type: "agent.tool_use", name: "grep", input: { pattern: "Session" } }),
      event({ id: "g2", type: "agent.tool_result", tool_use_id: "g1", content: [{ type: "text", text: "2 matches" }] }),
    ]);
    expect(projection.tools).toEqual([
      expect.objectContaining({ id: "r1", name: "read", state: "done", kind: "builtin" }),
      expect.objectContaining({ id: "g1", name: "grep", state: "done", kind: "builtin" }),
    ]);
  });

  /**
   * Decision rule R4: committed thinking and context-compaction progress facts
   * carry no text. Effects: they remain visible as typed markers and never become
   * invented assistant prose or a parallel transcript.
   */
  it("projects thinking and compaction as disclosure markers", () => {
    const projection = projectSession([
      event({ id: "think", type: "agent.thinking", processed_at: "2026-08-15T00:00:00Z" }),
      event({ id: "compact", type: "agent.thread_context_compacted", processed_at: "2026-08-15T00:00:01Z" }),
    ]);
    expect(projection.messages).toEqual([]);
    expect(projection.markers).toEqual([
      expect.objectContaining({ id: "think", kind: "thinking" }),
      expect.objectContaining({ id: "compact", kind: "compaction" }),
    ]);
  });

  /**
   * Cause/effect decision table — R5: a committed user message contains text,
   * one supported base64 image, one URL image, and one unrelated block. Effects:
   * the transcript remains a single message, both supported images retain order,
   * and the unrelated block does not become invented content.
   */
  it("projects committed message images without a parallel attachment store", () => {
    const projection = projectSession([event({ id: "images", type: "user.message", content: [
      { type: "text", text: "Compare these" },
      { type: "image", source: { type: "base64", media_type: "image/png", data: "AA==" } },
      { type: "image", source: { type: "url", url: "https://example.test/reference.webp" } },
      { type: "document", source: { type: "text", data: "ignored" } },
    ] })]);
    expect(projection.messages).toEqual([expect.objectContaining({
      id: "images", text: "Compare these", images: [
        expect.objectContaining({ url: "data:image/png;base64,AA==" }),
        expect.objectContaining({ url: "https://example.test/reference.webp" }),
      ],
    })]);
  });

  /**
   * Cause/effect decision table — R6: a committed plan followed by an unanswered
   * review_plan custom tool enters awaiting review; its correlated custom result
   * settles exactly that review and clears the takeover after refresh/replay.
   */
  it("derives Plan review lifecycle from correlated custom-tool facts", () => {
    const base = [
      event({ id: "plan", type: "agent.mcp_tool_use", name: "mcp__harness__set_plan", input: { plan_id: "p", revision: 1, summary: "Review", steps: [{ id: "s", title: "Inspect", status: "pending" }] } }),
      event({ id: "plan-result", type: "agent.mcp_tool_result", mcp_tool_use_id: "plan", content: [{ type: "text", text: "published" }], is_error: false }),
      event({ id: "review", type: "agent.custom_tool_use", name: "review_plan", input: { plan_id: "p", revision: 1 } }),
      event({ id: "idle", type: "session.status_idle" }),
    ];
    const pending = projectSession(base);
    expect(pending.phase).toBe("awaiting_plan_review");
    expect(pending.planReview).toEqual({ id: "review", planId: "p", revision: 1 });
    const settled = projectSession([...base, event({ id: "decision", type: "user.custom_tool_result", custom_tool_use_id: "review", content: [{ type: "text", text: "{\"decision\":\"approve\"}" }] })]);
    expect(settled.planReview).toBeUndefined();
    expect(settled.phase).toBe("idle");
  });
});
