# DeepSeek Harness UI parity contract

This inventory was derived from the official `packages/client/ui-*` package READMEs and
`ui-theme/src/styles/design-platform.css` at the audited DeepSeek Harness revision. It is
the acceptance source for this demonstration; a screenshot is not considered parity.

Status meanings:

- **Native**: implemented through the official Managed Agents surface in
  `@anthropic-ai/sdk`; committed Awaken state is authoritative.
- **Equivalent**: the same user capability exists, but Awaken owns the cloud-shaped
  aggregate instead of the local DSH Host.
- **Presentation**: the renderer and interaction contract exist, while the published
  Agent/MCP must emit the documented fact for it to become active.
- **Unavailable**: the current Managed Agents SDK has no equivalent mutation. The UI
  must not pretend that a browser-local change is durable.

| DSH UI owner / capability | Cloud implementation | Status | E2E evidence |
|---|---|---:|---|
| `ui-theme`: semantic palette, typography, focus/status tokens | DeepSeek dark tokens plus light/system variants are mapped in `styles.css`; no remote font dependency | Equivalent | visual walkthrough |
| `ui-layout`: three columns, collapse and resize controls | Sidebar and Details collapse independently and expose bounded pointer resizers; Chat remains fluid | Equivalent | management + extended E2E |
| `ui-workspace`: workspace picker | Workspace selection is the BFF `x-harness-workspace-id`, not a filesystem root | Equivalent | settings E2E |
| workspace add/rename/reorder/delete | Browser connection profiles manage names/order while the selected Workspace ID still scopes every SDK request and Awaken IAM remains authoritative | Equivalent | extended E2E |
| session list/search/status/grouping/view option | searchable live list; group by status/preset and sort by update/title/cloud-backed manual order | Equivalent | management E2E |
| session rename/archive | `beta.sessions.update` / `archive` | Native | management E2E |
| session fork and manual reorder | branch creates a new Managed Session with the same frozen Agent/Environment and an exact committed transcript boundary; order is Session metadata | Equivalent | SDK unit + extended E2E |
| `ui-conversation`: Chat, streaming, Stop | committed Session projection plus delta-only preview; `user.interrupt` | Native | critical-path E2E |
| compaction and thinking disclosure | `agent.thread_context_compacted` and `agent.thinking` markers | Native | critical-path E2E |
| tool approval composer takeover | `user.tool_confirmation` allow/deny | Native | critical-path E2E |
| model/effort chrome | model is frozen in the published Agent snapshot; effort is read-only until the SDK exposes a Session field | Presentation | header E2E |
| permission preset chrome | Safe/Full rewrites every mutable Session toolset policy through `beta.sessions.update`; Full requires explicit risk acknowledgement | Native | SDK unit + extended E2E |
| context disclosure / usage | indicator derives cumulative input/cache usage from the Session and context capacity from the SDK model catalog | Equivalent | extended E2E |
| message actions: time, copy, branch, feedback | time/copy plus exact-boundary branch; rating persists in Session metadata and restores after refresh | Equivalent | extended E2E |
| running-session guidance | one canonical user event enters Awaken admission; rejected sends retain the browser draft | Native | fixture and live E2E |
| edit/delete queued committed messages | unavailable because committed events are immutable; no parallel metadata queue is retained | Unavailable | owner boundary |
| todo strip | canonical `set_plan` MCP call projects one plan into strip and Details | Equivalent | critical-path E2E |
| attachments, rail, drop overlay, image blocks | image rail/drop are browser atoms; send uses native base64 Managed image blocks | Native | attachment contract unit/E2E |
| slash commands | `/` fuzzy surface is present; text is submitted as a normal user message because Managed Agents exposes no command directory RPC | Presentation | input surface E2E |
| `@` subagent / skill reference suggestions | live Skills catalog uses stable skill IDs; subagent/skill suggestions insert model-visible references | Equivalent | input surface E2E |
| `ui-tool`: terminal/read/diff/search/web/code/skill/question cards | one canonical flat tool projection classifies official committed built-in, MCP, and custom calls | Equivalent | critical-path + all-presets E2E |
| `ui-trajectory`: ledger, selection, inspector, overview | committed messages/tools/markers, kind labels, search/type filtering, model-request count, zoom and raw-record inspector | Equivalent | trajectory + extended E2E |
| virtual paging/zoom/range selection | SDK iterators page to the safety cap and zoom is interactive; timing-range selection lacks stable timing facts for every row | Presentation | extended E2E |
| `ui-plan`: plan mode + review takeover | atomic admission fixes plan mode; versioned `set_plan` is followed by `review_plan`; approve/revise/cancel sends its correlated custom-tool result | Equivalent | plan E2E |
| `ui-user-questions`: single/multiple questions, recommended/described options, custom/back/skip/cancel | running `agent.custom_tool_use(name=question)` takes over composer; one correlated `user.custom_tool_result` is sent at a terminal path | Native | question + extended E2E |
| `ui-subagent`: catalog/activity | `beta.sessions.threads.list` is the authoritative catalog; header and Details render it | Native | header E2E |
| child transcript navigation / stop | official Thread Events project the child transcript with usage/timing; official Thread archive stops it. The SDK has no addressed send-to-child mutation | Native / Presentation | extended E2E |
| `ui-jobs`: active job popover | running child threads and tool calls project into a header activity list | Equivalent | header E2E |
| `ui-goal`: durable goal bar | goal is persisted through `beta.sessions.update(metadata.harness_goal)` | Equivalent | management E2E |
| `ui-workflow-run`: phase/member disclosure | generic committed Tool calls render; DSH-specific `tool-workflow/*` event family is not emitted by Awaken | Presentation | tool projection E2E |
| `ui-deliverables`: produced files and links | `publish_result` MCP result plus scoped `beta.files` downloads | Equivalent | critical-path E2E |
| `ui-agent-preset`: Standard/Code/Minimal/Creator | published Agent contract validation plus immutable, atomic Session admission; cards in new Session/settings/header | Equivalent | all-presets + settings E2E |
| Creator proposal review/publication | pending `agent_proposal` custom call requires explicit approve/revise/cancel; approval uses official Agents create then commits the correlated result | Native / Equivalent | all-presets E2E |
| preset copy/delete/reveal composition path | official Agents retrieve/create/archive APIs reveal full compositions, copy them into independent versioned Agents, and archive user-created copies | Native | management E2E |
| settings General/Models/Plugins/preset inventory | theme/locale/Enter/default permission and Workspace profiles are live preferences; model/skill/Agent inventories come from official catalogs | Equivalent | settings + extended E2E |
| model provider onboarding/custom endpoint | provider routes and secrets are configured in Awaken and deliberately absent from the browser | Unavailable | security invariant |
| session log download | exports the SDK Session snapshot and committed events | Native | management E2E |

## Acceptance rule

“Behavioral parity” means every Native/Equivalent row works end to end and every
Presentation row is driven by a real committed fact or an explicit immutable owner.
The remaining Presentation boundaries are not disabled mock features: model hot-swap,
addressed child prompts, provider-secret onboarding, and timing-range selection need
upstream SDK mutations or facts. Implementing them as a local Agent loop, credential
store, or fake child-session API would violate the single-authority contract.
