# Architecture

## Whole-system objective

Reimplement the essential DeepSeek Harness interaction model as a secure cloud product with one execution authority: Awaken Managed Agents.

```text
Harness Web -> same-origin TypeScript BFF -> official Anthropic SDK -> Awaken
     ^                                                    |
     |          committed Session facts + live deltas     |
     +----------------------------------------------------+
```

The bounded focus of this repository is the Harness experience and its protocol adapter. It does not own execution.

Protocol review baseline: `awaken-1.0.0-dev` commit `686b906c0` (2026-08-15),
including the typed Session-tool projection fix from `807918888`.
The Harness uses the Managed Agents beta contract and its official built-in, MCP,
custom-tool, result, status, and delta events. The baseline's newer DeepSeek
reasoning replay remains provider-owned and requires no Harness-side event path.
Session-local custom tools travel through Awaken's canonical
`SessionToolConfiguration` projection and become typed `ClientExecuted`
descriptors with exact schemas. Harness does not register a `RawTool` for
`review_plan`, `agent_proposal`, or `question`.

## Duplication review and implementation classification

| Classification | Authority | Use |
|---|---|---|
| Reused unchanged | `@anthropic-ai/sdk` | Managed requests, pagination, uploads, stream parsing, and response types |
| Reused unchanged | Awaken IAM/Control/Coordinator/Worker/Resources | Workspace authorization, Agent publication, DeepSeek route, Session log, tools, permissions, retry, sandbox, compaction, subagents, Files |
| Existing code modified | `packages/contracts`, `apps/api/src/managed.ts`, `apps/web`, `packages/session-domain` | One preset catalog, atomic admission, effective-policy projection, correlated reviews, and flat official tool events |
| Existing code modified | `apps/interaction-mcp` | Versioned plan snapshots require `plan_id` and `revision`; remains stateless |
| Genuinely new | `apps/api/src/presets.ts` | The single preset-compatibility and effective Session-composition owner |
| Genuinely new | Creator proposal route and schema | Validates one pending proposal and publishes through the existing official Agents owner after approval |
| Genuinely new durable component | None | All durable facts remain in Awaken |

## Static DDD view

| Bounded context | Owner | Local representation | Contract |
|---|---|---|---|
| Identity and Workspace | Awaken IAM | request-scoped `Identity` | bearer + `x-harness-workspace-id` |
| Agent configuration | Awaken Control | selected Agent ID/version | SDK Agents API |
| Preset admission | BFF, derived from published Agent | no stored aggregate | singular Agent metadata + frozen Agent composition |
| Session execution | Awaken | pure `SessionProjection` only | SDK Sessions/events API |
| Resources | Awaken | read-only File/thread views | SDK Files/threads APIs |
| Harness experience | this Web app | composer commands, selected tool, attachment drafts, connection/layout preferences, live preview | same-origin API |
| Interaction affordances | stateless MCP | validated request/result value | MCP Streamable HTTP |

Ubiquitous language is intentionally small: Workspace, Agent, Environment, Session,
Event, Thread, Tool Call, Approval, and Artifact. There is no local Mission, Run,
Transcript, Plan aggregate, Worker registry, artifact catalog, policy registry, or
queue database. Running-session guidance enters the canonical user-event admission queue.
Goal, feedback and manual order are idle-only Session metadata extensions;
Awaken remains the only durable owner. Workspace
connection names and UI/input choices are explicitly browser preferences.

The API adapter is a port implementation rather than a Repository. The TypeScript process does not own the persistence it accesses.

## Dynamic behavior

```text
User      Web             BFF/SDK          Awaken Coordinator      Worker
 | create |                 |                     |                   |
 |------->| preset/permission command             |                   |
 |        |---------------->| retrieve Agent      |                   |
 |        |                 | validate + compose  |                   |
 |        |                 | sessions.create -->| admit frozen facts |
 |<-------|<----------------| Session ID          | dispatch -------->|
 |        | follow SSE ---->| events.stream ---->|                   | DeepSeek
 |        |<-- live preview / committed facts ---|<------------------|
 |        | project committed log                | tool gate         |
 | approve| POST decision --> events.send ------>| resume ---------->|
 | plan   | correlated custom result ------------>| resume ---------->|
 | create Agent proposal --> explicit review     | park Session       |
 | publish| Agents create + correlated result --->| resume ---------->|
 | answer | custom result ---> events.send ------>| resume ---------->|
 | attach | image blocks ----> events.send ------>| model context ---->|
 | goal   | Session patch ---> sessions.update -->| metadata commit    |
 | steer  | canonical user event -> events.send -->| native input queue |
 | branch | source+events ----> sessions.create -->| independent Worker |
 | policy | toolset patch ----> sessions.update -->| next turn gate     |
 |        |<-- idle/error/terminated + Files ----|<------------------|
```

### State and consistency

- Live `event_delta` values are volatile previews and disappear on disconnect or terminal facts.
- Only events with committed IDs contribute to durable UI projection.
- SSE and history overlap is merged by event ID.
- A dropped stream triggers a history refresh, never a command replay.
- Awaken owns Worker retry and claim fencing.
- Branching never copies a Worker or local event store: it admits one new Session
  with an exact source event boundary and a model-visible committed transcript.
- New Session admission retrieves the exact Agent version, validates its singular
  preset contract, deduplicates product tools/MCP, applies permission policy, and
  performs one `sessions.create` mutation.
- Full access is not metadata or a CSS preference: the UI derives it from the
  effective Session tools. A later switch rebuilds those tools from the pinned
  published Agent and sends one official update.
- Plan review and Creator approval are pending only while an official custom tool
  use lacks its correlated `user.custom_tool_result`; refresh reconstructs both.
- Protected Plan/Creator tool names cannot be settled through the generic custom
  answer route; their endpoints validate the committed Session facts first.
- The BFF is stateless and can be horizontally replicated without sticky sessions.

### Failure and terminal outcomes

| Cause | Effect |
|---|---|
| invalid browser command | 400 before SDK call |
| missing/invalid identity | 401 before upstream mutation |
| Workspace access denied | upstream 403/404, no local override |
| SSE disconnect | clear live preview; refresh committed history |
| permission `ask` | render pending approval until confirmation fact |
| incompatible or drifted preset Agent | 409 before Session creation |
| Plan selected without interaction MCP | 409 before Session creation |
| denied tool | send canonical deny event with optional reason |
| revised/cancelled Plan or Agent proposal | correlated custom result; no mutation/publish |
| approved Creator proposal | reuse a matching proposal marker or publish through Agents API, then commit the correlated result; result replay performs no second publication |
| Worker loss | Awaken reschedules under lease/commit fencing |
| terminal Session error | committed error projection; no local retry loop |

## Simple design

The design passes behavior through the fewest elements needed:

- one SDK adapter;
- one Session event log;
- one pure projection;
- one same-origin BFF;
- one stateless MCP;
- no database, ORM, message broker, CQRS framework, Saga, or local retry scheduler.

Types reveal intent at boundaries, while SDK response types remain authoritative. Zod validates only commands owned by the browser product.

## Preset contracts

| Preset | Required published composition | Product behavior |
|---|---|---|
| Standard | core six tools, one or more Skills, coordinator roster | general execution with Awaken-owned Skills and subagents |
| Code / PTC | core six tools | focused coding through flat official Managed tool calls |
| Minimal | core six tools; no web, Skills, or subagents | smallest bounded coding composition |
| Creator | `read`, `glob`, `grep` | drafts `agent_proposal`; explicit review is required before Agents API publication |

The core six are `bash`, `read`, `write`, `edit`, `glob`, and `grep`. The BFF does
not implement an executor, tool loop, event family, or policy registry. Plan mode
is orthogonal to the preset: it adds the stateless harness MCP plus `review_plan`
before the single Session admission.

## Required production acceptance

1. The Browser contains no Awaken service credential or model-provider secret.
2. Cross-Workspace Agent, Session, Thread, and File access is rejected upstream.
3. Refreshing the page reconstructs the same transcript, plan, approval, and tool tree.
4. Stream replay produces no duplicate committed rows.
5. Every Code Mode tool call is an official committed Managed tool event and is permission-checked and auditable.
6. Worker loss does not create two committed tool effects.
7. Files download only within the requested Session scope.
8. The MCP process can restart without losing application state.
9. A real DeepSeek turn exercises every preset, Plan review, Creator publication,
   typed question, Skill, official tool approval, delegation, and reconnect path.
10. Awaken's real-provider, typed model inheritance/override, restart,
    resilience, secret non-leak, and Workspace fence gates pass through
    `pnpm verify:live`.

The complete official-UI audit and the deliberate current-SDK gaps are maintained in
[ui-parity.md](ui-parity.md). That matrix is the parity acceptance contract; a missing
upstream mutation is reported as unavailable instead of being duplicated in browser
state.
