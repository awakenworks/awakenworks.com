# DeepSeek Harness on Awaken

Rebuild a Harness-class workbench. Let Awaken own execution.

This TypeScript project is the advanced-workbench case in the [Built on Awaken](https://awakenworks.com/cases) portfolio. It independently reimplements the DeepSeek Harness interaction model with presets, trajectory views, approvals, Plan review, Skills, subagents, and deliverables on the Awaken Managed Agents boundary.

The browser and BFF contain no Agent loop. `@anthropic-ai/sdk` talks to Awaken; Awaken owns the durable Session, model route, provider credential, Worker, Sandbox, tools, permissions, retries, compaction, resources, and subagents. The application owns the Harness UX and its stateless BFF.

This is an independent reference reimplementation. It is not a migration of an existing Harness product. The name describes compatibility with DeepSeek models and the reproduced Harness interaction pattern; it does not imply a partnership with or endorsement by DeepSeek. See the [case overview](https://awakenworks.com/cases/deepseek-harness) for its place beside Pilot and Awaken Design.

Choose this case when you want to build a serious Agent workbench without first building an Agent runtime. Run the deterministic demo, then trace one Session from the browser through the stateless product API and official SDK to committed Awaken events. The result is a full workbench interaction model with one Agent loop, one Session log, and one recovery path.

## Trace the product boundary first

Use the canonical deterministic demo below and inspect one Session end to end:

1. send a message from the reimplemented Harness workbench;
2. follow it through the stateless product API and official SDK;
3. reload the page and confirm the UI rebuilds from committed Awaken events.

The browser and product API own no Agent loop, durable transcript, or recovery state. The fixture makes that boundary easy to inspect; a credentialed live run uses the same browser contract against a real DeepSeek route.

## Full capability inventory

- DeepSeek Harness semantic dark design tokens and collapsible three-column UI
- Standard, Code/PTC, Minimal, and Creator preset selection
- durable Managed Session creation, grouping, manual ordering, branching and archiving
- Chat and detailed Trajectory views over one committed event log
- live thinking/message deltas with committed-history recovery
- native, MCP, and custom tool cards
- Code/PTC execution through the official Awaken Managed toolset
- approval, plan-review, and user-question composer takeovers
- native image attachments/history, live Skill references, native running-session guidance, thinking and compaction disclosures
- complete Plan/todo snapshots, jobs, durable goal/feedback, child transcripts/stop, and deliverables
- Safe/Full runtime policy changes with explicit risk acknowledgement
- searchable/filterable/zoomable trajectory and resizable/collapsible three-column layout
- persisted Workspace connection, theme, locale, Enter and default-permission preferences
- Session rename/archive/log export and scoped artifact download
- General plus live SDK model/skill/Agent settings and Agent-preset reveal/copy/archive
- Workspace-scoped user authentication forwarded through the same-origin BFF
- stateless plan/notification/result MCP

Code/PTC execution is intentionally not reimplemented in the BFF. A Code Session uses the published Agent's official Managed `bash`, `read`, `write`, `edit`, `glob`, and `grep` tools, and projects their committed events directly. Provider-specific executor and event extensions are neither emitted nor consumed.

## Start with the deterministic demo

Requirements: Node 22+, pnpm 11+, Chromium installed through Playwright, and
FFmpeg when regenerating the MP4 walkthrough. Fixed projection and SDK-oracle
build archives are included under `vendor/`; the deterministic demo does not
require another Awaken checkout.

```bash
pnpm install
pnpm exec playwright install chromium
pnpm demo
```

The existing Awaken projection package owns generic committed-event and
live-preview rules. Harness keeps its preset, Plan, approval, tool, and result
projection here. Archive revisions and hashes are recorded in
[`vendor/README.md`](vendor/README.md); the lockfile binds the install inputs.

Open `http://127.0.0.1:4281`. The demo server implements the Awaken Managed API boundary. The BFF still reaches it through the official Anthropic SDK, so the browser-to-BFF contract is the same one used in live acceptance. Demo output is fixture evidence, not a claim about a real DeepSeek account.

## Connect to Awaken

```bash
cp .env.example .env
set -a
source .env
set +a
pnpm dev
```

Before creating a Session, publish in Awaken:

1. a DeepSeek Provider Connection and discovered Managed model;
2. versioned Harness v1 Agents using singular `metadata.harness_preset` ownership:
   - Standard: the six core tools, at least one Skill, and a coordinator roster;
   - Code: the six core tools, with optional web tools and Skills;
   - Minimal: the six core tools without web tools, Skills, or subagents;
   - Creator: `read`, `glob`, and `grep` for drafting reviewed Agent proposals;
3. an Environment compatible with the Agent's tools;
4. the stateless interaction MCP when Plan-first Sessions are enabled.

Preset compatibility, permission policy, product MCP replacement, and custom review tools are resolved before the single `sessions.create` call. Full access therefore cannot race a newly dispatched Worker. Plan revisions and Creator proposals pause through official custom-tool use/result correlation; only an explicit Creator approval publishes an Agent through the official Agents API.

For cloud deployments, serve the web build and API from one origin, require request identity, and let Awaken IAM make the final Workspace authorization decision. Never place provider or service credentials in Vite environment variables.

## Source-archive installation qualification (2026-10-10)

The fixed build inputs were installed with `pnpm install --frozen-lockfile`
in a fresh source directory without Git metadata or a sibling Awaken checkout.
Type checks, unit tests and production builds passed there. Archive digests
are checked by the existing reference-case test. Harness also passed its
fixture-backed browser suite and regenerated its continuous deterministic
walkthrough. This qualifies installation and deterministic behaviour; real
provider, deployment and customer acceptance remain separate gates.

## Verification

```bash
pnpm typecheck
pnpm test
pnpm build
pnpm e2e
pnpm record:demo
```

Live browser acceptance targets an explicitly selected deployed Awaken. Supply
its base URL, a private bootstrap JSON descriptor containing `admin-token` and
`platform-workspace-id`, a mode-0600 one-time DeepSeek input file, and an MCP
URL reachable from its Kubernetes Worker. The key file is consumed through the
write-only Provider Connection API; no provider key enters a runtime or browser.

```bash
HARNESS_LIVE_AWAKEN_BASE_URL=http://127.0.0.1:8080 \
HARNESS_LIVE_BOOTSTRAP_FILE=/private/deployment-bootstrap.json \
HARNESS_LIVE_DEEPSEEK_KEY_FILE=/private/deepseek-input \
HARNESS_LIVE_INTERACTION_MCP_URL=http://worker-reachable-host:4282/mcp \
pnpm e2e:live
```

This command reuses that deployed Awaken, discovers the live DeepSeek
catalog, publishes exact Harness Agents, and runs the browser through Standard,
Code, Minimal, Creator, Plan, Safe/Full approval, Skill, typed custom-tool,
delegation, multi-turn, reload, and dropped-SSE recovery paths. For complete
runtime qualification, `pnpm verify:live` additionally requires the explicit
frozen `AWAKEN_SOURCE_DIR` and invokes that repository's canonical
`scripts/ci/check-all.sh --full-gate --record`. Browser success and the runtime
qualification record are separate evidence; neither replaces the other.
No `x_awaken` field or provider-specific execution path is used.

The browser E2E path is:

```text
React -> same-origin BFF -> @anthropic-ai/sdk -> Managed API fixture
      <- JSON SSE / committed Session events <-
```

The live acceptance path replaces the fixture with the selected deployment and
real DeepSeek route; the browser/BFF boundary is otherwise identical.

The committed walkthrough is available at [`artifacts/deepseek-harness-awaken-demo.mp4`](artifacts/deepseek-harness-awaken-demo.mp4). It is one continuous 1440×900 recording with smooth pointer/scroll transitions and chapters covering the canonical Session, tools, trajectory, approvals, catalogs, all four presets, Plan review, Creator publication, feedback/branching, questions, images, steering, and layout controls.

## Repository structure

```text
apps/api               same-origin SDK BFF
apps/web               Harness product shell and event projections
apps/interaction-mcp   stateless plan/notification/result tools
packages/contracts     browser command schemas
packages/session-domain pure committed-event projection
e2e                    SDK-backed Managed fixture and browser tests
docs                    architecture and acceptance contract
```

See [docs/architecture.md](docs/architecture.md) for the DDD boundaries, runtime sequence, failure semantics, and implementation classification. [docs/ui-parity.md](docs/ui-parity.md) is the audited feature-by-feature DeepSeek Harness UI comparison, including the SDK gaps that must not be faked with browser-local state.
